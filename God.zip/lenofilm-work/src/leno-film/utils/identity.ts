const persianDigits = '۰۱۲۳۴۵۶۷۸۹'
const arabicDigits = '٠١٢٣٤٥٦٧٨٩'

export function normalizeDigits(value: string) {
  return String(value ?? '')
    .replace(/[۰-۹]/g, (digit) => String(persianDigits.indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String(arabicDigits.indexOf(digit)))
}

export function normalizeIdentifier(value: string) {
  const raw = normalizeDigits(value).trim().toLowerCase()
  if (!raw) return { ok: false, value: '', type: 'empty' as const, message: 'شماره موبایل یا ایمیل را وارد کنید' }

  if (raw.includes('@')) {
    const email = raw.replace(/\s+/g, '')
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false, value: email, type: 'email' as const, message: 'ایمیل وارد شده معتبر نیست' }
    }
    return { ok: true, value: email, type: 'email' as const, message: '' }
  }

  if (/[a-z.]/i.test(raw)) {
    return { ok: false, value: raw, type: 'email' as const, message: 'شماره موبایل یا ایمیل معتبر وارد کنید' }
  }

  const mobile = raw.replace(/[\s\-()]/g, '').replace(/^\+98/, '0').replace(/^98/, '0')
  if (!/^09\d{9}$/.test(mobile)) {
    return { ok: false, value: mobile, type: 'mobile' as const, message: 'شماره موبایل باید با ۰۹ شروع شود و ۱۱ رقم باشد' }
  }
  return { ok: true, value: mobile, type: 'mobile' as const, message: '' }
}
