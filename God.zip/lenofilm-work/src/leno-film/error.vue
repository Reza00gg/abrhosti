<template>
  <div class="min-h-screen bg-ink-950 text-ink-50 flex flex-col">
    <AppHeader />
    <main class="flex-1 pt-[calc(var(--header-h)+var(--safe-top))] pb-[calc(var(--nav-h)+var(--safe-bottom))] flex items-center justify-center px-6">
      <div class="text-center max-w-md">
        <div class="text-[64px] sm:text-[80px] font-bold text-ink-700 leading-none">{{ error.statusCode }}</div>
        <h1 class="mt-4 text-[18px] sm:text-[22px] font-semibold text-ink-50">
          {{ error.statusCode === 404 ? 'صفحه پیدا نشد' : 'خطایی رخ داده' }}
        </h1>
        <p class="mt-2 text-[13px] text-ink-500 leading-6">
          {{ error.statusCode === 404 ? 'این صفحه وجود ندارد یا دیگر در دسترس نیست.' : 'مشکلی پیش آمده. لطفاً دوباره تلاش کنید.' }}
        </p>
        <button
          v-wave="appDarkWave"
          @click="handleClear"
          class="auth-primary-button mt-6 inline-flex h-11 items-center gap-2 rounded-2xl px-5 text-[14px] font-semibold"
        >
          <Icon icon="lucide:home" class="text-[16px]" />
          بازگشت به خانه
        </button>
      </div>
    </main>
    <BottomNav />
    <SideMenu />
    <ToastContainer variant="app" />
  </div>
</template>

<script setup lang="ts">
const appWave = useAppWave()
const appDarkWave = useAppWave('dark')
const props = defineProps<{ error: { statusCode: number; message?: string } }>()

function handleClear() {
  clearError({ redirect: '/' })
}
</script>
