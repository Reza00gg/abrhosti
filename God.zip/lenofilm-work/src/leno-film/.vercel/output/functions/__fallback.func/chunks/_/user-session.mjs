import { i as getCookie } from '../nitro/nitro.mjs';

function readUserAuthCookie(event) {
  const raw = getCookie(event, "user-auth");
  if (!raw) return null;
  const candidates = [raw];
  try {
    candidates.push(decodeURIComponent(raw));
  } catch {
  }
  for (const value of candidates) {
    try {
      const normalized = value.startsWith("j:") ? value.slice(2) : value;
      const parsed = JSON.parse(normalized);
      const id = Number(parsed == null ? void 0 : parsed.id);
      if (id && !Number.isNaN(id)) return { id, name: parsed == null ? void 0 : parsed.name, email: parsed == null ? void 0 : parsed.email };
    } catch {
    }
  }
  return null;
}

export { readUserAuthCookie as r };
//# sourceMappingURL=user-session.mjs.map
