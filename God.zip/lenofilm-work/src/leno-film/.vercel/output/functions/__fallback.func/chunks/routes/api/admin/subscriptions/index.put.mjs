import { d as defineEventHandler, r as readBody } from '../../../../nitro/nitro.mjs';
import { u as useDb, c as subscriptionSettings } from '../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_put = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const db = useDb();
  const current = await db.select().from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1);
  await db.insert(subscriptionSettings).values({ id: 1, rialEnabled: body.rialEnabled !== false, cardEnabled: body.cardEnabled === true }).onConflictDoNothing();
  const merchant = String(body.zarinpalMerchant || "").trim();
  const updateData = {
    rialEnabled: body.rialEnabled !== false,
    cardEnabled: body.cardEnabled === true,
    zarinpalSandbox: body.zarinpalSandbox !== false,
    updatedAt: /* @__PURE__ */ new Date()
  };
  if (merchant) updateData.zarinpalMerchant = merchant;
  else if (!((_a = current[0]) == null ? void 0 : _a.zarinpalMerchant)) updateData.zarinpalMerchant = null;
  const [updated] = await db.update(subscriptionSettings).set(updateData).where(eq(subscriptionSettings.id, 1)).returning();
  return { ...updated, zarinpalMerchant: "", zarinpalMasked: updated.zarinpalMerchant ? `${updated.zarinpalMerchant.slice(0, 4)}\u2022\u2022\u2022\u2022${updated.zarinpalMerchant.slice(-4)}` : "" };
});

export { index_put as default };
//# sourceMappingURL=index.put.mjs.map
