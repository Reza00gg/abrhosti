function planBaseDiscountAmount(plan) {
  const subtotal = Math.max(0, Number(plan.price) + Number(plan.fee || 0));
  const percent = Math.floor(subtotal * Number(plan.discountPercent || 0) / 100);
  return Math.min(subtotal, percent + Number(plan.discountAmount || 0));
}
function planFinalPrice(plan) {
  const subtotal = Math.max(0, Number(plan.price) + Number(plan.fee || 0));
  return Math.max(0, subtotal - planBaseDiscountAmount(plan));
}
function addMonths(base, months) {
  const next = new Date(base);
  next.setMonth(next.getMonth() + Number(months || 0));
  return next;
}

export { addMonths as a, planBaseDiscountAmount as b, planFinalPrice as p };
//# sourceMappingURL=subscription.mjs.map
