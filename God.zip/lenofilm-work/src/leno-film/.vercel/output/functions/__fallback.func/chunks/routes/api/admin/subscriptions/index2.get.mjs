import { d as defineEventHandler } from '../../../../nitro/nitro.mjs';
import { u as useDb, b as subscriptionPlans } from '../../../../_/index.mjs';
import { asc } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_get = defineEventHandler(async () => {
  const db = useDb();
  return await db.select().from(subscriptionPlans).orderBy(asc(subscriptionPlans.months), asc(subscriptionPlans.price));
});

export { index_get as default };
//# sourceMappingURL=index2.get.mjs.map
