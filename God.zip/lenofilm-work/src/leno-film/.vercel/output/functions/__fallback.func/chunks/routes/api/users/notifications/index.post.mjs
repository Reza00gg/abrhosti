import { d as defineEventHandler, c as createError } from '../../../../nitro/nitro.mjs';
import { u as useDb, g as userNotifications } from '../../../../_/index.mjs';
import { sql } from 'drizzle-orm';
import { r as readUserAuthCookie } from '../../../../_/user-session.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_post = defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "\u0628\u0631\u0627\u06CC \u0645\u0634\u0627\u0647\u062F\u0647 \u0627\u0639\u0644\u0627\u0646\u200C\u0647\u0627 \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F" });
  const db = useDb();
  await db.update(userNotifications).set({ status: "read", readAt: /* @__PURE__ */ new Date() }).where(sql`${userNotifications.userId} = ${session.id} and ${userNotifications.status} = 'unread'`);
  return { success: true };
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
