import { d as defineEventHandler, c as createError, r as readBody } from '../../../nitro/nitro.mjs';
import { u as useDb, d as users } from '../../../_/index.mjs';
import { eq, and, ne, or } from 'drizzle-orm';
import { r as readUserAuthCookie } from '../../../_/user-session.mjs';
import { n as normalizeIdentifier } from '../../../_/identity.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function isPrimaryMobile(value) {
  return /^09\d{9}$/.test(String(value || ""));
}
const profile_put = defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "\u0628\u0631\u0627\u06CC \u0648\u06CC\u0631\u0627\u06CC\u0634 \u062D\u0633\u0627\u0628 \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F" });
  const body = await readBody(event);
  const name = String((body == null ? void 0 : body.name) || "").trim();
  if (!name) throw createError({ statusCode: 400, statusMessage: "\u0646\u0627\u0645 \u0646\u0645\u0627\u06CC\u0634\u06CC \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F" });
  if (name.length > 60) throw createError({ statusCode: 400, statusMessage: "\u0646\u0627\u0645 \u0646\u0645\u0627\u06CC\u0634\u06CC \u062E\u06CC\u0644\u06CC \u0637\u0648\u0644\u0627\u0646\u06CC \u0627\u0633\u062A" });
  const db = useDb();
  const [current] = await db.select().from(users).where(eq(users.id, session.id)).limit(1);
  if (!current || current.status === "deleted") throw createError({ statusCode: 404, statusMessage: "\u062D\u0633\u0627\u0628 \u06A9\u0627\u0631\u0628\u0631\u06CC \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  if (current.banned) throw createError({ statusCode: 403, statusMessage: "\u0634\u0645\u0627 \u0627\u0632 \u0637\u0631\u0641 \u0645\u062F\u06CC\u0631\u06CC\u062A \u0645\u0633\u062F\u0648\u062F \u0634\u062F\u0647\u200C\u0627\u06CC\u062F" });
  const patch = { name };
  const rawContactEmail = String((body == null ? void 0 : body.contactEmail) || "").trim();
  if (isPrimaryMobile(current.email)) {
    if (!current.contactEmail && rawContactEmail) {
      const normalized = normalizeIdentifier(rawContactEmail);
      if (!normalized.ok || normalized.type !== "email") {
        throw createError({ statusCode: 400, statusMessage: normalized.ok ? "\u0627\u06CC\u0645\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F" : normalized.message });
      }
      const [duplicate] = await db.select({ id: users.id }).from(users).where(and(ne(users.id, current.id), or(eq(users.email, normalized.value), eq(users.contactEmail, normalized.value)))).limit(1);
      if (duplicate) throw createError({ statusCode: 409, statusMessage: "\u0627\u06CC\u0646 \u0627\u06CC\u0645\u06CC\u0644 \u0642\u0628\u0644\u0627\u064B \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A" });
      patch.contactEmail = normalized.value;
    }
  }
  const [updated] = await db.update(users).set(patch).where(eq(users.id, current.id)).returning({
    id: users.id,
    name: users.name,
    email: users.email,
    contactEmail: users.contactEmail,
    avatarUrl: users.avatarUrl,
    avatarMime: users.avatarMime,
    subscriptionExpiresAt: users.subscriptionExpiresAt,
    createdAt: users.createdAt
  });
  return updated;
});

export { profile_put as default };
//# sourceMappingURL=profile.put.mjs.map
