import { d as defineEventHandler, c as createError, r as readBody } from '../../../nitro/nitro.mjs';
import { u as useDb, d as users } from '../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import { v as verifyPassword, h as hashPassword } from '../../../_/password.mjs';
import { r as readUserAuthCookie } from '../../../_/user-session.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'crypto';

const password_put = defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "\u0628\u0631\u0627\u06CC \u062A\u063A\u06CC\u06CC\u0631 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F" });
  const body = await readBody(event);
  const currentPassword = String((body == null ? void 0 : body.currentPassword) || "");
  const newPassword = String((body == null ? void 0 : body.newPassword) || "");
  const confirmPassword = String((body == null ? void 0 : body.confirmPassword) || "");
  if (!currentPassword) throw createError({ statusCode: 400, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0641\u0639\u0644\u06CC \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F" });
  if (!newPassword) throw createError({ statusCode: 400, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F" });
  if (newPassword.length < 6) throw createError({ statusCode: 400, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06F6 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F" });
  if (newPassword !== confirmPassword) throw createError({ statusCode: 400, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0648 \u062A\u06A9\u0631\u0627\u0631 \u0622\u0646 \u06CC\u06A9\u0633\u0627\u0646 \u0646\u06CC\u0633\u062A\u0646\u062F" });
  const db = useDb();
  const [user] = await db.select().from(users).where(eq(users.id, session.id)).limit(1);
  if (!user || user.status === "deleted") throw createError({ statusCode: 404, statusMessage: "\u062D\u0633\u0627\u0628 \u06A9\u0627\u0631\u0628\u0631\u06CC \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  if (user.banned) throw createError({ statusCode: 403, statusMessage: "\u0634\u0645\u0627 \u0627\u0632 \u0637\u0631\u0641 \u0645\u062F\u06CC\u0631\u06CC\u062A \u0645\u0633\u062F\u0648\u062F \u0634\u062F\u0647\u200C\u0627\u06CC\u062F" });
  if (!verifyPassword(currentPassword, user.passwordHash)) {
    throw createError({ statusCode: 401, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0641\u0639\u0644\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A" });
  }
  if (verifyPassword(newPassword, user.passwordHash)) {
    throw createError({ statusCode: 400, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0647\u0645\u0627\u0646 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0641\u0639\u0644\u06CC \u0628\u0627\u0634\u062F" });
  }
  await db.update(users).set({ passwordHash: hashPassword(newPassword) }).where(eq(users.id, user.id));
  return { success: true };
});

export { password_put as default };
//# sourceMappingURL=password.put.mjs.map
