import { d as defineEventHandler, c as createError, r as readBody } from '../../../nitro/nitro.mjs';
import { u as useDb, d as users } from '../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import { r as readUserAuthCookie } from '../../../_/user-session.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const MAX_AVATAR_BYTES = 900 * 1024;
function parseAvatar(value) {
  const avatarUrl = String(value || "").trim();
  if (/^\/api\/avatars\/(?:24|25)$/i.test(avatarUrl)) {
    return { avatarUrl, avatarMime: "image/jpeg" };
  }
  if (/^\/avatars\/[a-z0-9-]+\.svg$/i.test(avatarUrl)) {
    return { avatarUrl, avatarMime: "image/svg+xml" };
  }
  const match = avatarUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\s]+)$/);
  if (!match) {
    throw createError({ statusCode: 400, statusMessage: "\u0622\u0648\u0627\u062A\u0627\u0631 \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  }
  const mime = match[1];
  const base64 = match[2].replace(/\s/g, "");
  const bytes = Buffer.byteLength(base64, "base64");
  if (bytes > MAX_AVATAR_BYTES) {
    throw createError({ statusCode: 400, statusMessage: "\u062D\u062C\u0645 \u062A\u0635\u0648\u06CC\u0631 \u067E\u0631\u0648\u0641\u0627\u06CC\u0644 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634\u062A\u0631 \u0627\u0632 \u06F9\u06F0\u06F0 \u06A9\u06CC\u0644\u0648\u0628\u0627\u06CC\u062A \u0628\u0627\u0634\u062F" });
  }
  return { avatarUrl: `data:${mime};base64,${base64}`, avatarMime: mime };
}
const avatar_put = defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "\u0628\u0631\u0627\u06CC \u062A\u063A\u06CC\u06CC\u0631 \u062A\u0635\u0648\u06CC\u0631 \u067E\u0631\u0648\u0641\u0627\u06CC\u0644 \u0648\u0627\u0631\u062F \u062D\u0633\u0627\u0628 \u0634\u0648\u06CC\u062F" });
  const body = await readBody(event);
  const avatar = parseAvatar(body == null ? void 0 : body.avatarUrl);
  const db = useDb();
  const [user] = await db.select({ id: users.id, banned: users.banned, status: users.status }).from(users).where(eq(users.id, session.id)).limit(1);
  if (!user || user.status === "deleted") throw createError({ statusCode: 404, statusMessage: "\u062D\u0633\u0627\u0628 \u06A9\u0627\u0631\u0628\u0631\u06CC \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  if (user.banned) throw createError({ statusCode: 403, statusMessage: "\u0634\u0645\u0627 \u0627\u0632 \u0637\u0631\u0641 \u0645\u062F\u06CC\u0631\u06CC\u062A \u0645\u0633\u062F\u0648\u062F \u0634\u062F\u0647\u200C\u0627\u06CC\u062F" });
  const [updated] = await db.update(users).set({
    avatarUrl: avatar.avatarUrl,
    avatarMime: avatar.avatarMime,
    avatarUpdatedAt: /* @__PURE__ */ new Date()
  }).where(eq(users.id, session.id)).returning({
    id: users.id,
    name: users.name,
    email: users.email,
    contactEmail: users.contactEmail,
    avatarUrl: users.avatarUrl,
    avatarMime: users.avatarMime,
    subscriptionExpiresAt: users.subscriptionExpiresAt,
    createdAt: users.createdAt
  });
  return updated;
});

export { avatar_put as default };
//# sourceMappingURL=avatar.put.mjs.map
