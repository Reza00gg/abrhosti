import { d as defineEventHandler, a as getQuery } from '../../../nitro/nitro.mjs';
import { u as useDb, d as users } from '../../../_/index.mjs';
import { eq, and, or, ilike, sql, desc } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const TABS = ["all", "active", "inactive", "deleted"];
function safeTab(value) {
  const tab = String(value || "all");
  return TABS.includes(tab) ? tab : "all";
}
function safeLimit(value, fallback = 15) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(Math.max(Math.floor(n), 1), 100);
}
function safeOffset(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(Math.floor(n), 0);
}
const selectFields = {
  id: users.id,
  name: users.name,
  email: users.email,
  banned: users.banned,
  status: users.status,
  createdAt: users.createdAt,
  subscriptionExpiresAt: users.subscriptionExpiresAt
};
const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f;
  const q = getQuery(event);
  const search = (_a = q.q) == null ? void 0 : _a.trim();
  const tab = safeTab(q.tab);
  const limit = safeLimit(q.limit, 15);
  const offset = safeOffset(q.offset);
  const db = useDb();
  const tabWhere = tab === "deleted" ? eq(users.status, "deleted") : tab === "active" ? and(eq(users.status, "active"), eq(users.banned, false)) : tab === "inactive" ? and(eq(users.status, "active"), eq(users.banned, true)) : eq(users.status, "active");
  const searchWhere = search ? or(ilike(users.name, `%${search}%`), ilike(users.email, `%${search}%`)) : void 0;
  const where = searchWhere ? and(tabWhere, searchWhere) : tabWhere;
  const [totalRow, allRow, activeRow, inactiveRow, deletedRow] = await Promise.all([
    db.select({ total: sql`count(*)::int` }).from(users).where(where),
    db.select({ total: sql`count(*)::int` }).from(users).where(eq(users.status, "active")),
    db.select({ total: sql`count(*)::int` }).from(users).where(and(eq(users.status, "active"), eq(users.banned, false))),
    db.select({ total: sql`count(*)::int` }).from(users).where(and(eq(users.status, "active"), eq(users.banned, true))),
    db.select({ total: sql`count(*)::int` }).from(users).where(eq(users.status, "deleted"))
  ]);
  const items = await db.select(selectFields).from(users).where(where).orderBy(desc(users.createdAt)).limit(limit).offset(offset);
  return {
    items,
    total: Number(((_b = totalRow[0]) == null ? void 0 : _b.total) || 0),
    counts: {
      all: Number(((_c = allRow[0]) == null ? void 0 : _c.total) || 0),
      active: Number(((_d = activeRow[0]) == null ? void 0 : _d.total) || 0),
      inactive: Number(((_e = inactiveRow[0]) == null ? void 0 : _e.total) || 0),
      deleted: Number(((_f = deletedRow[0]) == null ? void 0 : _f.total) || 0)
    },
    limit,
    offset,
    tab
  };
});

export { index_get as default };
//# sourceMappingURL=index2.get.mjs.map
