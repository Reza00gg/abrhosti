import { d as defineEventHandler, c as createError, e as readRawBody, f as getHeader } from '../../../nitro/nitro.mjs';
import nodeCrypto from 'node:crypto';
import { eq } from 'drizzle-orm';
import { u as useDb, e as subscriptionOrders, d as users } from '../../../_/index.mjs';
import { a as addMonths } from '../../../_/subscription.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function bridgeSecret() {
  return process.env.LENO_ABRAHOST_PAYMENT_SECRET || "";
}
function sign(raw) {
  return nodeCrypto.createHmac("sha256", bridgeSecret()).update(raw).digest("hex");
}
function safeEqual(a, b) {
  const left = Buffer.from(a || "", "hex");
  const right = Buffer.from(b || "", "hex");
  return left.length === right.length && left.length > 0 && nodeCrypto.timingSafeEqual(left, right);
}
const abrahostCallback_post = defineEventHandler(async (event) => {
  const secret = bridgeSecret();
  if (!secret) throw createError({ statusCode: 500, statusMessage: "\u06A9\u0644\u06CC\u062F \u0627\u062A\u0635\u0627\u0644 \u0627\u0628\u0631\u0647\u0627\u0633\u062A \u062A\u0646\u0638\u06CC\u0645 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A" });
  const raw = await readRawBody(event, "utf8");
  if (!raw) throw createError({ statusCode: 400, statusMessage: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  const signature = getHeader(event, "x-abrahost-signature") || "";
  if (!safeEqual(signature, sign(raw))) throw createError({ statusCode: 401, statusMessage: "\u0627\u0645\u0636\u0627\u06CC \u0627\u0628\u0631\u0647\u0627\u0633\u062A \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    throw createError({ statusCode: 400, statusMessage: "\u0628\u062F\u0646\u0647 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  }
  const orderId = Number(body.orderId);
  const status = String(body.status || "");
  const amountToman = Number(body.amountToman);
  const authority = String(body.authority || "");
  const refId = String(body.refId || "");
  const message = String(body.message || "");
  if (!orderId || !Number.isFinite(orderId)) throw createError({ statusCode: 400, statusMessage: "\u0634\u0646\u0627\u0633\u0647 \u0633\u0641\u0627\u0631\u0634 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  if (!["paid", "failed"].includes(status)) throw createError({ statusCode: 400, statusMessage: "\u0648\u0636\u0639\u06CC\u062A \u067E\u0631\u062F\u0627\u062E\u062A \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  const db = useDb();
  const [order] = await db.select().from(subscriptionOrders).where(eq(subscriptionOrders.id, orderId)).limit(1);
  if (!order) throw createError({ statusCode: 404, statusMessage: "\u0633\u0641\u0627\u0631\u0634 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  if (Number(order.finalAmount) !== amountToman) throw createError({ statusCode: 409, statusMessage: "\u0645\u0628\u0644\u063A \u067E\u0631\u062F\u0627\u062E\u062A \u0628\u0627 \u0633\u0641\u0627\u0631\u0634 \u0647\u0645\u062E\u0648\u0627\u0646\u06CC \u0646\u062F\u0627\u0631\u062F" });
  if (order.authority && authority && order.authority !== authority) throw createError({ statusCode: 409, statusMessage: "\u0634\u0646\u0627\u0633\u0647 \u067E\u0631\u062F\u0627\u062E\u062A \u0628\u0627 \u0633\u0641\u0627\u0631\u0634 \u0647\u0645\u062E\u0648\u0627\u0646\u06CC \u0646\u062F\u0627\u0631\u062F" });
  if (order.status === "paid") return { ok: true, alreadyPaid: true };
  if (status === "failed") {
    await db.update(subscriptionOrders).set({
      status: "failed",
      failureMessage: message || "\u067E\u0631\u062F\u0627\u062E\u062A \u0646\u0627\u0645\u0648\u0641\u0642 \u06CC\u0627 \u0644\u063A\u0648 \u0634\u062F\u0647 \u0627\u0633\u062A",
      verifyPayload: raw,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(subscriptionOrders.id, order.id));
    return { ok: true };
  }
  if (!authority || !refId) throw createError({ statusCode: 400, statusMessage: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u067E\u0631\u062F\u0627\u062E\u062A \u06A9\u0627\u0645\u0644 \u0646\u06CC\u0633\u062A" });
  const paidAt = /* @__PURE__ */ new Date();
  const [user] = await db.select().from(users).where(eq(users.id, order.userId)).limit(1);
  if (!user || user.status === "deleted" || user.banned) throw createError({ statusCode: 403, statusMessage: "\u062D\u0633\u0627\u0628 \u06A9\u0627\u0631\u0628\u0631 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  const base = user.subscriptionExpiresAt && new Date(user.subscriptionExpiresAt).getTime() > Date.now() ? new Date(user.subscriptionExpiresAt) : paidAt;
  const subscriptionExpiresAt = addMonths(base, order.months);
  await db.update(subscriptionOrders).set({
    status: "paid",
    authority,
    refId,
    paidAt,
    verifyPayload: raw,
    updatedAt: /* @__PURE__ */ new Date()
  }).where(eq(subscriptionOrders.id, order.id));
  await db.update(users).set({ subscriptionExpiresAt }).where(eq(users.id, order.userId));
  return { ok: true, subscriptionExpiresAt };
});

export { abrahostCallback_post as default };
//# sourceMappingURL=abrahost-callback.post.mjs.map
