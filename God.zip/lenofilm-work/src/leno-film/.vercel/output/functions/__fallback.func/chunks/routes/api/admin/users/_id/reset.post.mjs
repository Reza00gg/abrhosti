import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../../../nitro/nitro.mjs';
import { u as useDb, d as users, e as subscriptionOrders, g as userNotifications } from '../../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const reset_post = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const db = useDb();
  const [user] = await db.select({ id: users.id }).from(users).where(eq(users.id, id)).limit(1);
  if (!user) throw createError({ statusCode: 404, statusMessage: "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  await db.delete(subscriptionOrders).where(eq(subscriptionOrders.userId, id));
  await db.delete(userNotifications).where(eq(userNotifications.userId, id));
  const [updated] = await db.update(users).set({ subscriptionExpiresAt: null }).where(eq(users.id, id)).returning({
    id: users.id,
    subscriptionExpiresAt: users.subscriptionExpiresAt
  });
  return { success: true, user: updated };
});

export { reset_post as default };
//# sourceMappingURL=reset.post.mjs.map
