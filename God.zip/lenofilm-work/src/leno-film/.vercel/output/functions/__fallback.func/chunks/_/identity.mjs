const persianDigits = "\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9";
const arabicDigits = "\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669";
function normalizeDigits(value) {
  return String(value != null ? value : "").replace(/[۰-۹]/g, (digit) => String(persianDigits.indexOf(digit))).replace(/[٠-٩]/g, (digit) => String(arabicDigits.indexOf(digit)));
}
function normalizeIdentifier(value) {
  const raw = normalizeDigits(value).trim().toLowerCase();
  if (!raw) return { ok: false, value: "", type: "empty", message: "\u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644 \u06CC\u0627 \u0627\u06CC\u0645\u06CC\u0644 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F" };
  if (raw.includes("@")) {
    const email = raw.replace(/\s+/g, "");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false, value: email, type: "email", message: "\u0627\u06CC\u0645\u06CC\u0644 \u0648\u0627\u0631\u062F \u0634\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" };
    }
    return { ok: true, value: email, type: "email", message: "" };
  }
  if (/[a-z.]/i.test(raw)) {
    return { ok: false, value: raw, type: "email", message: "\u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644 \u06CC\u0627 \u0627\u06CC\u0645\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F" };
  }
  const mobile = raw.replace(/[\s\-()]/g, "").replace(/^\+98/, "0").replace(/^98/, "0");
  if (!/^09\d{9}$/.test(mobile)) {
    return { ok: false, value: mobile, type: "mobile", message: "\u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644 \u0628\u0627\u06CC\u062F \u0628\u0627 \u06F0\u06F9 \u0634\u0631\u0648\u0639 \u0634\u0648\u062F \u0648 \u06F1\u06F1 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F" };
  }
  return { ok: true, value: mobile, type: "mobile", message: "" };
}

export { normalizeIdentifier as n };
//# sourceMappingURL=identity.mjs.map
