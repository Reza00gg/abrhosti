import { d as defineEventHandler, a as getQuery } from '../../nitro/nitro.mjs';
import { u as useDb, m as movies } from '../../_/index.mjs';
import { or, ilike, and, eq, sql, desc } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const STATUSES = ["active", "archived", "deleted"];
function safeStatus(value) {
  const status = String(value || "active");
  return STATUSES.includes(status) ? status : "active";
}
function safeLimit(value, fallback = 15) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(Math.max(Math.floor(n), 1), 100);
}
function safeOffset(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(Math.floor(n), 0);
}
const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const q = getQuery(event);
  const search = (_a = q.q) == null ? void 0 : _a.trim();
  const status = safeStatus(q.status);
  const limit = safeLimit(q.limit, 15);
  const offset = safeOffset(q.offset);
  const db = useDb();
  const searchWhere = search ? or(ilike(movies.titleFa, `%${search}%`), ilike(movies.titleEn, `%${search}%`)) : void 0;
  const where = searchWhere ? and(eq(movies.status, status), searchWhere) : eq(movies.status, status);
  const [totalRow, activeRow, archivedRow, deletedRow] = await Promise.all([
    db.select({ total: sql`count(*)::int` }).from(movies).where(where),
    db.select({ total: sql`count(*)::int` }).from(movies).where(eq(movies.status, "active")),
    db.select({ total: sql`count(*)::int` }).from(movies).where(eq(movies.status, "archived")),
    db.select({ total: sql`count(*)::int` }).from(movies).where(eq(movies.status, "deleted"))
  ]);
  const items = await db.select().from(movies).where(where).orderBy(desc(movies.createdAt)).limit(limit).offset(offset);
  return {
    items,
    total: Number(((_b = totalRow[0]) == null ? void 0 : _b.total) || 0),
    counts: {
      active: Number(((_c = activeRow[0]) == null ? void 0 : _c.total) || 0),
      archived: Number(((_d = archivedRow[0]) == null ? void 0 : _d.total) || 0),
      deleted: Number(((_e = deletedRow[0]) == null ? void 0 : _e.total) || 0)
    },
    limit,
    offset,
    status
  };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
