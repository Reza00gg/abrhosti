import { d as defineEventHandler, g as getRouterParam, c as createError, r as readBody } from '../../../../../nitro/nitro.mjs';
import { u as useDb, d as users } from '../../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const STATUSES = ["active", "deleted"];
function normalizeStatus(value) {
  const status = String(value || "").trim();
  if (STATUSES.includes(status)) return status;
  throw createError({ statusCode: 400, statusMessage: "\u0648\u0636\u0639\u06CC\u062A \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
}
const status_put = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const body = await readBody(event);
  const status = normalizeStatus(body.status);
  const db = useDb();
  const [updated] = await db.update(users).set({ status }).where(eq(users.id, id)).returning();
  if (!updated) throw createError({ statusCode: 404, statusMessage: "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  return updated;
});

export { status_put as default };
//# sourceMappingURL=status.put.mjs.map
