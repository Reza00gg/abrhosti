import { d as defineEventHandler } from '../../../../nitro/nitro.mjs';
import { u as useDb, c as subscriptionSettings } from '../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function mask(value) {
  if (!value) return "";
  if (value.length <= 8) return "\u2022\u2022\u2022\u2022";
  return `${value.slice(0, 4)}\u2022\u2022\u2022\u2022${value.slice(-4)}`;
}
const index_get = defineEventHandler(async () => {
  const db = useDb();
  const [settings] = await db.select().from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1);
  if (!settings) return { id: 1, rialEnabled: true, cardEnabled: false, zarinpalSandbox: true, zarinpalMasked: "" };
  return { ...settings, zarinpalMasked: mask(settings.zarinpalMerchant), zarinpalMerchant: "" };
});

export { index_get as default };
//# sourceMappingURL=index3.get.mjs.map
