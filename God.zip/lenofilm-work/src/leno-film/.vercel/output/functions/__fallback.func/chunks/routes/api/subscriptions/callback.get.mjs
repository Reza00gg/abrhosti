import { d as defineEventHandler, a as getQuery, b as sendRedirect, h as getRequestURL } from '../../../nitro/nitro.mjs';
import { u as useDb, e as subscriptionOrders, c as subscriptionSettings, d as users } from '../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import { a as addMonths } from '../../../_/subscription.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function apiBase(sandbox) {
  return sandbox ? "https://sandbox.zarinpal.com" : "https://payment.zarinpal.com";
}
function errorMessage(errors) {
  if (!errors) return "";
  if (Array.isArray(errors)) return errors.map((e) => e.message || e.code).filter(Boolean).join("\u060C ");
  const values = Object.values(errors).filter(Boolean);
  return values.length ? values.join("\u060C ") : "";
}
async function zarinpalVerifyPayment(input) {
  var _a, _b;
  const response = await fetch(`${apiBase(input.sandbox)}/pg/v4/payment/verify.json`, {
    method: "POST",
    headers: { accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ merchant_id: input.merchantId, amount: input.amountToman, authority: input.authority })
  });
  const data = await response.json();
  const code = (_a = data.data) == null ? void 0 : _a.code;
  const ok = response.ok && (code === 100 || code === 101);
  return { ok, data, message: ((_b = data.data) == null ? void 0 : _b.message) || errorMessage(data.errors) || "\u062E\u0637\u0627 \u062F\u0631 \u062A\u0627\u06CC\u06CC\u062F \u067E\u0631\u062F\u0627\u062E\u062A \u0632\u0631\u06CC\u0646\u200C\u067E\u0627\u0644" };
}

function merchantFor(settings) {
  if (settings.zarinpalMerchant) return settings.zarinpalMerchant;
  if (settings.zarinpalSandbox) return "00000000-0000-0000-0000-000000000000";
  return "";
}
function resultUrl(event, id, status = "failed") {
  const origin = getRequestURL(event).origin;
  return `${origin}/account/subscription?orderId=${id || ""}&payment=${status}`;
}
const callback_get = defineEventHandler(async (event) => {
  var _a, _b;
  const query = getQuery(event);
  const authority = String(query.Authority || query.authority || "");
  const status = String(query.Status || query.status || "");
  const db = useDb();
  if (!authority) return sendRedirect(event, resultUrl(event, void 0, "failed"), 302);
  const [order] = await db.select().from(subscriptionOrders).where(eq(subscriptionOrders.authority, authority)).limit(1);
  if (!order) return sendRedirect(event, resultUrl(event, void 0, "failed"), 302);
  if (order.status === "paid") return sendRedirect(event, resultUrl(event, order.id, "success"), 302);
  if (status !== "OK") {
    await db.update(subscriptionOrders).set({ status: "failed", failureMessage: `\u067E\u0631\u062F\u0627\u062E\u062A \u0646\u0627\u0645\u0648\u0641\u0642 \u06CC\u0627 \u0644\u063A\u0648 \u0634\u062F\u0647. Status=${status}`, verifyPayload: JSON.stringify(query), updatedAt: /* @__PURE__ */ new Date() }).where(eq(subscriptionOrders.id, order.id));
    return sendRedirect(event, resultUrl(event, order.id, "failed"), 302);
  }
  const [settings] = await db.select().from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1);
  const merchantId = settings ? merchantFor(settings) : "";
  if (!merchantId) {
    await db.update(subscriptionOrders).set({ status: "failed", failureMessage: "\u0645\u0631\u0686\u0646\u062A \u0632\u0631\u06CC\u0646\u200C\u067E\u0627\u0644 \u062A\u0646\u0638\u06CC\u0645 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A", updatedAt: /* @__PURE__ */ new Date() }).where(eq(subscriptionOrders.id, order.id));
    return sendRedirect(event, resultUrl(event, order.id, "failed"), 302);
  }
  const verify = await zarinpalVerifyPayment({ merchantId, amountToman: order.finalAmount, authority, sandbox: settings == null ? void 0 : settings.zarinpalSandbox });
  if (!verify.ok) {
    await db.update(subscriptionOrders).set({ status: "failed", failureMessage: verify.message, verifyPayload: JSON.stringify({ callback: query, verify: verify.data }), updatedAt: /* @__PURE__ */ new Date() }).where(eq(subscriptionOrders.id, order.id));
    return sendRedirect(event, resultUrl(event, order.id, "failed"), 302);
  }
  const paidAt = /* @__PURE__ */ new Date();
  const refId = String(((_b = (_a = verify.data) == null ? void 0 : _a.data) == null ? void 0 : _b.ref_id) || "");
  const [user] = await db.select().from(users).where(eq(users.id, order.userId)).limit(1);
  const base = (user == null ? void 0 : user.subscriptionExpiresAt) && new Date(user.subscriptionExpiresAt).getTime() > Date.now() ? new Date(user.subscriptionExpiresAt) : paidAt;
  const subscriptionExpiresAt = addMonths(base, order.months);
  await db.update(subscriptionOrders).set({
    status: "paid",
    refId,
    paidAt,
    verifyPayload: JSON.stringify({ callback: query, verify: verify.data }),
    updatedAt: /* @__PURE__ */ new Date()
  }).where(eq(subscriptionOrders.id, order.id));
  await db.update(users).set({ subscriptionExpiresAt }).where(eq(users.id, order.userId));
  return sendRedirect(event, resultUrl(event, order.id, "success"), 302);
});

export { callback_get as default };
//# sourceMappingURL=callback.get.mjs.map
