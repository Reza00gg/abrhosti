import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, m as movies, s as series, f as featuredItems } from '../../../_/index.mjs';
import { and, eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const mediaType = String(body.mediaType || "").trim();
  const mediaId = Number(body.mediaId);
  if (!["movie", "series"].includes(mediaType) || !mediaId || Number.isNaN(mediaId)) {
    throw createError({ statusCode: 400, statusMessage: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0633\u0644\u0627\u06CC\u062F \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  }
  const db = useDb();
  const exists = mediaType === "movie" ? await db.select({ id: movies.id }).from(movies).where(and(eq(movies.id, mediaId), eq(movies.status, "active"))).limit(1) : await db.select({ id: series.id }).from(series).where(and(eq(series.id, mediaId), eq(series.status, "active"))).limit(1);
  if (!exists.length) throw createError({ statusCode: 404, statusMessage: "\u0622\u06CC\u062A\u0645 \u0641\u0639\u0627\u0644 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  const already = await db.select().from(featuredItems).where(and(eq(featuredItems.mediaType, mediaType), eq(featuredItems.mediaId, mediaId))).limit(1);
  if (already[0]) return already[0];
  const [created] = await db.insert(featuredItems).values({ mediaType, mediaId }).returning();
  return created;
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
