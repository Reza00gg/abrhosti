import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { u as useDb, f as featuredItems } from '../../../_/index.mjs';
import { desc } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_get = defineEventHandler(async () => {
  const db = useDb();
  return await db.select().from(featuredItems).orderBy(desc(featuredItems.createdAt));
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
