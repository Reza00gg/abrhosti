import { d as defineEventHandler, g as getRouterParam, c as createError, b as sendRedirect, s as setHeader } from '../../../../nitro/nitro.mjs';
import { u as useDb, s as series } from '../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const poster_get = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const db = useDb();
  const [row] = await db.select({ posterUrl: series.posterUrl, createdAt: series.createdAt }).from(series).where(eq(series.id, id)).limit(1);
  if (!(row == null ? void 0 : row.posterUrl)) throw createError({ statusCode: 404, statusMessage: "\u067E\u0648\u0633\u062A\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  if (/^https?:\/\//i.test(row.posterUrl)) return sendRedirect(event, row.posterUrl, 302);
  const match = row.posterUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\s]+)$/);
  if (!match) throw createError({ statusCode: 415, statusMessage: "\u0641\u0631\u0645\u062A \u067E\u0648\u0633\u062A\u0631 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0646\u0645\u06CC\u200C\u0634\u0648\u062F" });
  const mime = match[1];
  const base64 = match[2].replace(/\s/g, "");
  const buffer = Buffer.from(base64, "base64");
  const version = new Date(row.createdAt).getTime() || Date.now();
  setHeader(event, "Content-Type", mime);
  setHeader(event, "Content-Length", String(buffer.length));
  setHeader(event, "Cache-Control", "public, max-age=31536000, s-maxage=31536000, immutable");
  setHeader(event, "CDN-Cache-Control", "public, max-age=31536000, immutable");
  setHeader(event, "Vercel-CDN-Cache-Control", "public, max-age=31536000, immutable");
  setHeader(event, "ETag", `"series-poster-${id}-${version}-${buffer.length}"`);
  return buffer;
});

export { poster_get as default };
//# sourceMappingURL=poster.get.mjs.map
