import { d as defineEventHandler, c as createError, r as readBody, h as getRequestURL } from '../../../nitro/nitro.mjs';
import { u as useDb, d as users, c as subscriptionSettings, b as subscriptionPlans, a as subscriptionDiscounts, e as subscriptionOrders } from '../../../_/index.mjs';
import nodeCrypto from 'node:crypto';
import { eq, and } from 'drizzle-orm';
import { r as readUserAuthCookie } from '../../../_/user-session.mjs';
import { b as planBaseDiscountAmount, p as planFinalPrice } from '../../../_/subscription.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function normalizeCode(value) {
  return String(value || "").trim().toUpperCase();
}
function bridgeSecret() {
  return process.env.LENO_ABRAHOST_PAYMENT_SECRET || "";
}
function abrahostBaseUrl() {
  return (process.env.ABRAHOST_PAYMENT_BASE_URL || "https://lnupro.sbs").replace(/\/$/, "");
}
function lenofilmBaseUrl(event) {
  return (process.env.LENOFILM_BASE_URL || getRequestURL(event).origin).replace(/\/$/, "");
}
function bridgeSignature(raw) {
  return nodeCrypto.createHmac("sha256", bridgeSecret()).update(raw).digest("hex");
}
async function createAbrahostPayment(payload) {
  var _a;
  const secret = bridgeSecret();
  if (!secret) throw createError({ statusCode: 500, statusMessage: "\u06A9\u0644\u06CC\u062F \u0627\u062A\u0635\u0627\u0644 \u0627\u0628\u0631\u0647\u0627\u0633\u062A \u062A\u0646\u0638\u06CC\u0645 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A" });
  const raw = JSON.stringify(payload);
  const response = await fetch(`${abrahostBaseUrl()}/api/lenofilm/subscriptions/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-leno-signature": bridgeSignature(raw) },
    body: raw
  });
  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
  }
  if (!response.ok || (data == null ? void 0 : data.ok) === false) {
    const message = ((_a = data == null ? void 0 : data.error) == null ? void 0 : _a.message) || (data == null ? void 0 : data.message) || text || "\u0633\u0627\u062E\u062A \u067E\u0631\u062F\u0627\u062E\u062A \u062F\u0631 \u0627\u0628\u0631\u0647\u0627\u0633\u062A \u0627\u0646\u062C\u0627\u0645 \u0646\u0634\u062F";
    throw createError({ statusCode: response.status || 502, statusMessage: message });
  }
  return (data == null ? void 0 : data.data) || data;
}
const index_post = defineEventHandler(async (event) => {
  var _a;
  const session = readUserAuthCookie(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "\u0628\u0631\u0627\u06CC \u062E\u0631\u06CC\u062F \u0627\u0634\u062A\u0631\u0627\u06A9 \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F" });
  const body = await readBody(event);
  const planId = Number(body.planId);
  const discountCode = normalizeCode(body.discountCode);
  if (!planId || Number.isNaN(planId)) throw createError({ statusCode: 400, statusMessage: "\u067E\u0644\u0646 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  const db = useDb();
  const [user] = await db.select().from(users).where(eq(users.id, session.id)).limit(1);
  if (!user || user.status === "deleted") throw createError({ statusCode: 404, statusMessage: "\u062D\u0633\u0627\u0628 \u06A9\u0627\u0631\u0628\u0631\u06CC \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  if (user.banned) throw createError({ statusCode: 403, statusMessage: "\u0634\u0645\u0627 \u0627\u0632 \u0637\u0631\u0641 \u0645\u062F\u06CC\u0631\u06CC\u062A \u0645\u0633\u062F\u0648\u062F \u0634\u062F\u0647\u200C\u0627\u06CC\u062F" });
  const [settings] = await db.select().from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1);
  if (!(settings == null ? void 0 : settings.rialEnabled)) throw createError({ statusCode: 400, statusMessage: "\u062F\u0631\u06AF\u0627\u0647 \u0631\u06CC\u0627\u0644\u06CC \u063A\u06CC\u0631\u0641\u0639\u0627\u0644 \u0627\u0633\u062A" });
  const [plan] = await db.select().from(subscriptionPlans).where(and(eq(subscriptionPlans.id, planId), eq(subscriptionPlans.active, true))).limit(1);
  if (!plan) throw createError({ statusCode: 404, statusMessage: "\u067E\u0644\u0646 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  const basePrice = Number(plan.price);
  const fee = Number(plan.fee || 0);
  const planDiscountAmount = planBaseDiscountAmount(plan);
  let couponDiscountAmount = 0;
  let couponCode = null;
  if (discountCode) {
    const [discount] = await db.select().from(subscriptionDiscounts).where(eq(subscriptionDiscounts.code, discountCode)).limit(1);
    if (!discount || !discount.active) throw createError({ statusCode: 404, statusMessage: "\u06A9\u062F \u062A\u062E\u0641\u06CC\u0641 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
    if (discount.planId && discount.planId !== plan.id) throw createError({ statusCode: 400, statusMessage: "\u0627\u06CC\u0646 \u06A9\u062F \u0628\u0631\u0627\u06CC \u067E\u0644\u0646 \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u0646\u06CC\u0633\u062A" });
    const afterPlanDiscount = planFinalPrice(plan);
    couponDiscountAmount = discount.type === "fixed" ? Math.min(afterPlanDiscount, discount.value) : Math.min(afterPlanDiscount, Math.floor(afterPlanDiscount * discount.value / 100));
    couponCode = discount.code;
  }
  const finalAmount = Math.max(0, planFinalPrice(plan) - couponDiscountAmount);
  if (finalAmount < 1e3) throw createError({ statusCode: 400, statusMessage: "\u0645\u0628\u0644\u063A \u067E\u0631\u062F\u0627\u062E\u062A \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  const expiresAt = new Date(Date.now() + 2 * 60 * 60 * 1e3);
  const [order] = await db.insert(subscriptionOrders).values({
    userId: user.id,
    planId: plan.id,
    planTitle: plan.title,
    months: plan.months,
    basePrice,
    fee,
    planDiscountAmount,
    couponCode,
    couponDiscountAmount,
    finalAmount,
    status: "pending",
    gateway: "zarinpal",
    expiresAt
  }).returning();
  const publicBase = lenofilmBaseUrl(event);
  const bridgePayload = {
    orderId: order.id,
    amountToman: finalAmount,
    title: `\u0627\u0634\u062A\u0631\u0627\u06A9 ${plan.title} \u0644\u0646\u0648\u0641\u06CC\u0644\u0645`,
    description: `\u062E\u0631\u06CC\u062F \u0627\u0634\u062A\u0631\u0627\u06A9 ${plan.title} \u0644\u0646\u0648\u0641\u06CC\u0644\u0645`,
    userEmail: user.contactEmail || (user.email.includes("@") ? user.email : void 0),
    userMobile: /^09\d{9}$/.test(user.email) ? user.email : void 0,
    notifyUrl: `${publicBase}/api/subscriptions/abrahost-callback`,
    returnSuccessUrl: `${publicBase}/account/subscription?orderId=${order.id}&payment=success`,
    returnFailedUrl: `${publicBase}/account/subscription?orderId=${order.id}&payment=failed`
  };
  try {
    const bridge = await createAbrahostPayment(bridgePayload);
    const authority = String(bridge.authority || "");
    const gatewayUrl = String(bridge.gatewayUrl || "");
    if (!gatewayUrl) throw createError({ statusCode: 502, statusMessage: "\u0644\u06CC\u0646\u06A9 \u062F\u0631\u06AF\u0627\u0647 \u0627\u0632 \u0627\u0628\u0631\u0647\u0627\u0633\u062A \u062F\u0631\u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
    await db.update(subscriptionOrders).set({
      authority: authority || null,
      requestPayload: JSON.stringify({ bridge: { paymentId: bridge.paymentId, authority, gatewayUrl }, payload: bridgePayload }),
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(subscriptionOrders.id, order.id));
    return { orderId: order.id, gatewayUrl };
  } catch (err) {
    const message = ((_a = err == null ? void 0 : err.data) == null ? void 0 : _a.statusMessage) || (err == null ? void 0 : err.statusMessage) || (err == null ? void 0 : err.message) || "\u0634\u0631\u0648\u0639 \u067E\u0631\u062F\u0627\u062E\u062A \u0627\u0646\u062C\u0627\u0645 \u0646\u0634\u062F";
    await db.update(subscriptionOrders).set({ status: "failed", failureMessage: message, requestPayload: JSON.stringify({ bridgePayload, error: message }), updatedAt: /* @__PURE__ */ new Date() }).where(eq(subscriptionOrders.id, order.id));
    throw createError({ statusCode: (err == null ? void 0 : err.statusCode) || 502, statusMessage: message });
  }
});

export { index_post as default };
//# sourceMappingURL=index2.post.mjs.map
