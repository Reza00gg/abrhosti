import { d as defineEventHandler, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, g as userNotifications } from '../../../_/index.mjs';
import { sql, eq, desc } from 'drizzle-orm';
import { r as readUserAuthCookie } from '../../../_/user-session.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_get = defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "\u0628\u0631\u0627\u06CC \u0645\u0634\u0627\u0647\u062F\u0647 \u0627\u0639\u0644\u0627\u0646\u200C\u0647\u0627 \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F" });
  const db = useDb();
  const [unread] = await db.select({ total: sql`count(*)::int` }).from(userNotifications).where(sql`${userNotifications.userId} = ${session.id} and ${userNotifications.status} = 'unread'`);
  const items = await db.select().from(userNotifications).where(eq(userNotifications.userId, session.id)).orderBy(desc(userNotifications.createdAt)).limit(50);
  return { unread: Number((unread == null ? void 0 : unread.total) || 0), items };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
