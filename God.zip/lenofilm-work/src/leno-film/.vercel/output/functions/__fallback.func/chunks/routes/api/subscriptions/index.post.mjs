import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, b as subscriptionPlans, a as subscriptionDiscounts } from '../../../_/index.mjs';
import { and, eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function normalizeCode(value) {
  return String(value || "").trim().toUpperCase();
}
const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const code = normalizeCode(body.code);
  const planId = Number(body.planId);
  if (!code) throw createError({ statusCode: 400, statusMessage: "\u06A9\u062F \u062A\u062E\u0641\u06CC\u0641 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F" });
  if (!planId || Number.isNaN(planId)) throw createError({ statusCode: 400, statusMessage: "\u067E\u0644\u0646 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  const db = useDb();
  const [plan] = await db.select().from(subscriptionPlans).where(and(eq(subscriptionPlans.id, planId), eq(subscriptionPlans.active, true))).limit(1);
  if (!plan) throw createError({ statusCode: 404, statusMessage: "\u067E\u0644\u0646 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  const [discount] = await db.select().from(subscriptionDiscounts).where(eq(subscriptionDiscounts.code, code)).limit(1);
  if (!discount || !discount.active) throw createError({ statusCode: 404, statusMessage: "\u06A9\u062F \u062A\u062E\u0641\u06CC\u0641 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  if (discount.planId && discount.planId !== planId) throw createError({ statusCode: 400, statusMessage: "\u0627\u06CC\u0646 \u06A9\u062F \u0628\u0631\u0627\u06CC \u067E\u0644\u0646 \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u0646\u06CC\u0633\u062A" });
  const base = Math.max(0, plan.price + plan.fee);
  const amount = discount.type === "fixed" ? Math.min(base, discount.value) : Math.min(base, Math.floor(base * discount.value / 100));
  return { success: true, code: discount.code, type: discount.type, value: discount.value, amount };
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
