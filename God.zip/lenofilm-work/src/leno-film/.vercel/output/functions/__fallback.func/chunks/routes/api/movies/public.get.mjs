import { d as defineEventHandler, a as getQuery } from '../../../nitro/nitro.mjs';
import { u as useDb, m as movies } from '../../../_/index.mjs';
import { sql, eq, or, ilike, and, desc } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function publicPosterUrl(id, posterUrl, createdAt) {
  if (!posterUrl) return "";
  if (posterUrl.startsWith("data:image/")) {
    const version = new Date(createdAt).getTime() || Date.now();
    return `/api/movies/${id}/poster?v=${version}`;
  }
  return posterUrl;
}
function safeLimit(value, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(Math.max(Math.floor(n), 1), 60);
}
function safeOffset(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(Math.floor(n), 0);
}
const public_get = defineEventHandler(async (event) => {
  var _a;
  const q = getQuery(event);
  const search = (_a = q.q) == null ? void 0 : _a.trim();
  const limit = safeLimit(q.limit, search ? 50 : 20);
  const offset = safeOffset(q.offset);
  const db = useDb();
  const releaseOrder = sql`coalesce(${movies.releaseDate}, make_date(${movies.year}, 1, 1))`;
  const selectFields = {
    id: movies.id,
    titleCode: movies.titleCode,
    titleFa: movies.titleFa,
    titleEn: movies.titleEn,
    duration: movies.duration,
    year: movies.year,
    releaseDate: movies.releaseDate,
    rating: movies.rating,
    posterUrl: movies.posterUrl,
    createdAt: movies.createdAt
  };
  const activeWhere = eq(movies.status, "active");
  const searchWhere = search ? or(ilike(movies.titleFa, `%${search}%`), ilike(movies.titleEn, `%${search}%`)) : void 0;
  const rows = searchWhere ? await db.select(selectFields).from(movies).where(and(activeWhere, searchWhere)).orderBy(desc(releaseOrder), desc(movies.createdAt)).limit(limit).offset(offset) : await db.select(selectFields).from(movies).where(activeWhere).orderBy(desc(releaseOrder), desc(movies.createdAt)).limit(limit).offset(offset);
  return rows.map((movie) => ({
    ...movie,
    posterUrl: publicPosterUrl(movie.id, movie.posterUrl, movie.createdAt),
    coverUrl: "",
    description: ""
  }));
});

export { public_get as default };
//# sourceMappingURL=public.get.mjs.map
