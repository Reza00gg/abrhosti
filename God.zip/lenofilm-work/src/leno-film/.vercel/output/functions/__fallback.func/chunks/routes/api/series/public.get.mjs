import { d as defineEventHandler, a as getQuery } from '../../../nitro/nitro.mjs';
import { u as useDb, s as series } from '../../../_/index.mjs';
import { sql, eq, or, ilike, and, desc } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function publicPosterUrl(id, posterUrl, createdAt) {
  if (!posterUrl) return "";
  if (posterUrl.startsWith("data:image/")) {
    const version = new Date(createdAt).getTime() || Date.now();
    return `/api/series/${id}/poster?v=${version}`;
  }
  return posterUrl;
}
function safeLimit(value, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(Math.max(Math.floor(n), 1), 60);
}
function safeOffset(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(Math.floor(n), 0);
}
const public_get = defineEventHandler(async (event) => {
  var _a;
  const q = getQuery(event);
  const search = (_a = q.q) == null ? void 0 : _a.trim();
  const limit = safeLimit(q.limit, search ? 50 : 20);
  const offset = safeOffset(q.offset);
  const db = useDb();
  const releaseOrder = sql`coalesce(${series.releaseDate}, make_date(${series.year}, 1, 1))`;
  const selectFields = {
    id: series.id,
    titleCode: series.titleCode,
    titleFa: series.titleFa,
    titleEn: series.titleEn,
    seasons: series.seasons,
    episodes: series.episodes,
    year: series.year,
    releaseDate: series.releaseDate,
    rating: series.rating,
    posterUrl: series.posterUrl,
    createdAt: series.createdAt
  };
  const activeWhere = eq(series.status, "active");
  const searchWhere = search ? or(ilike(series.titleFa, `%${search}%`), ilike(series.titleEn, `%${search}%`)) : void 0;
  const rows = searchWhere ? await db.select(selectFields).from(series).where(and(activeWhere, searchWhere)).orderBy(desc(releaseOrder), desc(series.createdAt)).limit(limit).offset(offset) : await db.select(selectFields).from(series).where(activeWhere).orderBy(desc(releaseOrder), desc(series.createdAt)).limit(limit).offset(offset);
  return rows.map((row) => ({
    ...row,
    type: "series",
    duration: 0,
    durationLabel: `${row.seasons} \u0641\u0635\u0644`,
    posterUrl: publicPosterUrl(row.id, row.posterUrl, row.createdAt),
    coverUrl: "",
    description: ""
  }));
});

export { public_get as default };
//# sourceMappingURL=public.get.mjs.map
