import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../../nitro/nitro.mjs';
import { u as useDb, m as movies } from '../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import { m as mediaImageResponse } from '../../../../_/media-image.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const cover_get = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const db = useDb();
  const [movie] = await db.select({ coverUrl: movies.coverUrl, createdAt: movies.createdAt }).from(movies).where(eq(movies.id, id)).limit(1);
  return mediaImageResponse(event, (movie == null ? void 0 : movie.coverUrl) || "", `movie-cover-${id}`, (movie == null ? void 0 : movie.createdAt) || /* @__PURE__ */ new Date());
});

export { cover_get as default };
//# sourceMappingURL=cover.get.mjs.map
