import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import { u as useDb, c as subscriptionSettings, b as subscriptionPlans } from '../../_/index.mjs';
import { eq, asc } from 'drizzle-orm';
import { p as planFinalPrice } from '../../_/subscription.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_get = defineEventHandler(async () => {
  const db = useDb();
  const [settings] = await db.select({
    id: subscriptionSettings.id,
    rialEnabled: subscriptionSettings.rialEnabled,
    cardEnabled: subscriptionSettings.cardEnabled
  }).from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1);
  const plans = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.active, true)).orderBy(asc(subscriptionPlans.months), asc(subscriptionPlans.price));
  return {
    settings: settings || { rialEnabled: true, cardEnabled: false },
    plans: plans.map((plan) => ({ ...plan, finalPrice: planFinalPrice(plan) }))
  };
});

export { index_get as default };
//# sourceMappingURL=index3.get.mjs.map
