import { d as defineEventHandler, c as createError, g as getRouterParam } from '../../../../nitro/nitro.mjs';
import { u as useDb, e as subscriptionOrders, d as users } from '../../../../_/index.mjs';
import { and, eq } from 'drizzle-orm';
import { r as readUserAuthCookie } from '../../../../_/user-session.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_get = defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "\u0628\u0631\u0627\u06CC \u0645\u0634\u0627\u0647\u062F\u0647 \u0633\u0641\u0627\u0631\u0634 \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F" });
  const id = Number(getRouterParam(event, "id"));
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const db = useDb();
  const [order] = await db.select().from(subscriptionOrders).where(and(eq(subscriptionOrders.id, id), eq(subscriptionOrders.userId, session.id))).limit(1);
  if (!order) throw createError({ statusCode: 404, statusMessage: "\u0633\u0641\u0627\u0631\u0634 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  const [user] = await db.select({ subscriptionExpiresAt: users.subscriptionExpiresAt }).from(users).where(eq(users.id, session.id)).limit(1);
  return { order, subscriptionExpiresAt: (user == null ? void 0 : user.subscriptionExpiresAt) || null };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
