import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, d as users } from '../../../_/index.mjs';
import { h as hashPassword } from '../../../_/password.mjs';
import { or, eq } from 'drizzle-orm';
import { n as normalizeIdentifier } from '../../../_/identity.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'crypto';

const signup_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  if (!((_a = body.name) == null ? void 0 : _a.trim())) {
    throw createError({ statusCode: 400, statusMessage: "\u0646\u0627\u0645 \u0646\u0645\u0627\u06CC\u0634\u06CC \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A" });
  }
  const identity = normalizeIdentifier(String((_b = body.email) != null ? _b : ""));
  if (!identity.ok) {
    throw createError({ statusCode: 400, statusMessage: identity.message });
  }
  if (!body.password) {
    throw createError({ statusCode: 400, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A" });
  }
  if (body.password.length < 6) {
    throw createError({ statusCode: 400, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06F6 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F" });
  }
  const db = useDb();
  const email = identity.value;
  const existing = await db.select().from(users).where(or(eq(users.email, email), eq(users.contactEmail, email))).limit(1);
  if (existing.length > 0) {
    throw createError({ statusCode: 409, statusMessage: "\u0633\u0627\u062E\u062A \u062D\u0633\u0627\u0628 \u0628\u0627 \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644 \u06CC\u0627 \u0627\u06CC\u0645\u06CC\u0644 \u0627\u0645\u06A9\u0627\u0646\u200C\u067E\u0630\u06CC\u0631 \u0646\u06CC\u0633\u062A" });
  }
  const [user] = await db.insert(users).values({
    name: body.name.trim(),
    email,
    passwordHash: hashPassword(body.password)
  }).returning();
  return { id: user.id, name: user.name, email: user.email, contactEmail: user.contactEmail, avatarUrl: user.avatarUrl, avatarMime: user.avatarMime, subscriptionExpiresAt: user.subscriptionExpiresAt, createdAt: user.createdAt };
});

export { signup_post as default };
//# sourceMappingURL=signup.post.mjs.map
