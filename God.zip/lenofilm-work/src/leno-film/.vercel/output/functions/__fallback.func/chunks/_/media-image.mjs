import { c as createError, b as sendRedirect, s as setHeader } from '../nitro/nitro.mjs';

function mediaImageResponse(event, source, key, versionSeed) {
  if (!source) throw createError({ statusCode: 404, statusMessage: "\u062A\u0635\u0648\u06CC\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  if (/^https?:\/\//i.test(source)) {
    return sendRedirect(event, source, 302);
  }
  const match = source.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\s]+)$/);
  if (!match) throw createError({ statusCode: 415, statusMessage: "\u0641\u0631\u0645\u062A \u062A\u0635\u0648\u06CC\u0631 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0646\u0645\u06CC\u200C\u0634\u0648\u062F" });
  const mime = match[1];
  const base64 = match[2].replace(/\s/g, "");
  const buffer = Buffer.from(base64, "base64");
  const version = new Date(versionSeed).getTime() || Date.now();
  setHeader(event, "Content-Type", mime);
  setHeader(event, "Content-Length", String(buffer.length));
  setHeader(event, "Cache-Control", "public, max-age=31536000, s-maxage=31536000, immutable");
  setHeader(event, "CDN-Cache-Control", "public, max-age=31536000, immutable");
  setHeader(event, "Vercel-CDN-Cache-Control", "public, max-age=31536000, immutable");
  setHeader(event, "ETag", `"${key}-${version}-${buffer.length}"`);
  return buffer;
}

export { mediaImageResponse as m };
//# sourceMappingURL=media-image.mjs.map
