import { d as defineEventHandler, r as readBody, c as createError } from '../../nitro/nitro.mjs';
import { u as useDb, s as series } from '../../_/index.mjs';
import { n as normalizeReleaseDate, r as releaseYear } from '../../_/release-date.mjs';
import { n as nextTitleCode } from '../../_/title-code.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'drizzle-orm';

function normalizeImageSource(value) {
  const source = String(value || "").trim();
  if (!source) return "";
  if (source.startsWith("data:image/")) return source;
  if (/^https?:\/\//i.test(source)) return source;
  throw createError({ statusCode: 400, statusMessage: "\u0622\u062F\u0631\u0633 \u06CC\u0627 \u0641\u0627\u06CC\u0644 \u0639\u06A9\u0633 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
}
const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!body.titleFa || !body.titleEn || !body.seasons || !body.episodes || !body.year || body.rating == null) {
    throw createError({ statusCode: 400, statusMessage: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0633\u0631\u06CC\u0627\u0644 \u0646\u0627\u0642\u0635 \u0627\u0633\u062A" });
  }
  const releaseDate = normalizeReleaseDate(body.releaseDate, body.year);
  const year = releaseYear(releaseDate);
  const db = useDb();
  const titleCode = await nextTitleCode(db);
  const [row] = await db.insert(series).values({
    titleCode,
    titleFa: String(body.titleFa),
    titleEn: String(body.titleEn),
    seasons: Number(body.seasons),
    episodes: Number(body.episodes),
    year,
    releaseDate,
    rating: Number(body.rating),
    posterUrl: normalizeImageSource(body.posterUrl),
    coverUrl: normalizeImageSource(body.coverUrl),
    description: String(body.description || "")
  }).returning();
  return row;
});

export { index_post as default };
//# sourceMappingURL=index2.post.mjs.map
