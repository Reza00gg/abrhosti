import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { pgTable, timestamp, integer, text, serial, uniqueIndex, real, date, boolean } from 'drizzle-orm/pg-core';

const movies = pgTable("movies", {
  id: serial("id").primaryKey(),
  titleCode: integer("title_code"),
  titleFa: text("title_fa").notNull(),
  titleEn: text("title_en").notNull(),
  duration: integer("duration").notNull(),
  year: integer("year").notNull(),
  releaseDate: date("release_date"),
  status: text("status").notNull().default("active"),
  rating: real("rating").notNull(),
  posterUrl: text("poster_url").notNull(),
  coverUrl: text("cover_url").notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
const series = pgTable("series", {
  id: serial("id").primaryKey(),
  titleCode: integer("title_code"),
  titleFa: text("title_fa").notNull(),
  titleEn: text("title_en").notNull(),
  seasons: integer("seasons").notNull(),
  episodes: integer("episodes").notNull(),
  year: integer("year").notNull(),
  releaseDate: date("release_date"),
  status: text("status").notNull().default("active"),
  rating: real("rating").notNull(),
  posterUrl: text("poster_url").notNull(),
  coverUrl: text("cover_url").notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
const featuredItems = pgTable("featured_items", {
  id: serial("id").primaryKey(),
  mediaType: text("media_type").notNull(),
  mediaId: integer("media_id").notNull(),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull()
}, (table) => ({
  mediaUniqueIdx: uniqueIndex("featured_items_media_unique_idx").on(table.mediaType, table.mediaId)
}));
const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  months: integer("months").notNull(),
  price: integer("price").notNull(),
  fee: integer("fee").notNull().default(0),
  discountPercent: integer("discount_percent").notNull().default(0),
  discountAmount: integer("discount_amount").notNull().default(0),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
const subscriptionDiscounts = pgTable("subscription_discounts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull(),
  type: text("type").notNull().default("percent"),
  value: integer("value").notNull(),
  planId: integer("plan_id"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull()
}, (table) => ({
  codeIdx: uniqueIndex("subscription_discounts_code_idx").on(table.code)
}));
const subscriptionSettings = pgTable("subscription_settings", {
  id: serial("id").primaryKey(),
  rialEnabled: boolean("rial_enabled").notNull().default(true),
  cardEnabled: boolean("card_enabled").notNull().default(false),
  zarinpalMerchant: text("zarinpal_merchant"),
  zarinpalSandbox: boolean("zarinpal_sandbox").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});
const subscriptionOrders = pgTable("subscription_orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  planId: integer("plan_id").notNull(),
  planTitle: text("plan_title").notNull(),
  months: integer("months").notNull(),
  basePrice: integer("base_price").notNull(),
  fee: integer("fee").notNull().default(0),
  planDiscountAmount: integer("plan_discount_amount").notNull().default(0),
  couponCode: text("coupon_code"),
  couponDiscountAmount: integer("coupon_discount_amount").notNull().default(0),
  finalAmount: integer("final_amount").notNull(),
  status: text("status").notNull().default("pending"),
  gateway: text("gateway").notNull().default("zarinpal"),
  authority: text("authority"),
  refId: text("ref_id"),
  failureMessage: text("failure_message"),
  requestPayload: text("request_payload"),
  verifyPayload: text("verify_payload"),
  paidAt: timestamp("paid_at"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});
const userNotifications = pgTable("user_notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("unread"),
  meta: text("meta"),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  contactEmail: text("contact_email"),
  passwordHash: text("password_hash").notNull(),
  banned: boolean("banned").notNull().default(false),
  status: text("status").notNull().default("active"),
  avatarUrl: text("avatar_url"),
  avatarMime: text("avatar_mime"),
  avatarUpdatedAt: timestamp("avatar_updated_at"),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull()
}, (table) => ({
  emailIdx: uniqueIndex("users_email_idx").on(table.email),
  contactEmailIdx: uniqueIndex("users_contact_email_idx").on(table.contactEmail)
}));

const schema = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  featuredItems: featuredItems,
  movies: movies,
  series: series,
  subscriptionDiscounts: subscriptionDiscounts,
  subscriptionOrders: subscriptionOrders,
  subscriptionPlans: subscriptionPlans,
  subscriptionSettings: subscriptionSettings,
  userNotifications: userNotifications,
  users: users
}, Symbol.toStringTag, { value: 'Module' }));

let _db = null;
function useDb() {
  if (_db) return _db;
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is not set");
  const client = postgres(url, { ssl: "require", max: 1 });
  _db = drizzle(client, { schema });
  return _db;
}

export { subscriptionDiscounts as a, subscriptionPlans as b, subscriptionSettings as c, users as d, subscriptionOrders as e, featuredItems as f, userNotifications as g, movies as m, series as s, useDb as u };
//# sourceMappingURL=index.mjs.map
