import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../../nitro/nitro.mjs';
import { u as useDb, s as series } from '../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import { m as mediaImageResponse } from '../../../../_/media-image.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const cover_get = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const db = useDb();
  const [row] = await db.select({ coverUrl: series.coverUrl, createdAt: series.createdAt }).from(series).where(eq(series.id, id)).limit(1);
  return mediaImageResponse(event, (row == null ? void 0 : row.coverUrl) || "", `series-cover-${id}`, (row == null ? void 0 : row.createdAt) || /* @__PURE__ */ new Date());
});

export { cover_get as default };
//# sourceMappingURL=cover.get.mjs.map
