import { d as defineEventHandler, r as readBody, c as createError } from '../../../../nitro/nitro.mjs';
import { u as useDb, a as subscriptionDiscounts } from '../../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function code(value) {
  return String(value || "").trim().toUpperCase();
}
function safeInt(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : fallback;
}
function type(value) {
  const t = String(value || "percent");
  return t === "fixed" ? "fixed" : "percent";
}
const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const normalizedCode = code(body.code);
  const normalizedType = type(body.type);
  const value = safeInt(body.value);
  if (!normalizedCode) throw createError({ statusCode: 400, statusMessage: "\u06A9\u062F \u062A\u062E\u0641\u06CC\u0641 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F" });
  if (!value) throw createError({ statusCode: 400, statusMessage: "\u0645\u0642\u062F\u0627\u0631 \u062A\u062E\u0641\u06CC\u0641 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  const db = useDb();
  try {
    const [created] = await db.insert(subscriptionDiscounts).values({
      code: normalizedCode,
      type: normalizedType,
      value: normalizedType === "percent" ? Math.min(value, 100) : value,
      planId: body.planId ? Number(body.planId) : null,
      active: body.active !== false
    }).returning();
    return created;
  } catch {
    throw createError({ statusCode: 409, statusMessage: "\u0627\u06CC\u0646 \u06A9\u062F \u062A\u062E\u0641\u06CC\u0641 \u0642\u0628\u0644\u0627\u064B \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A" });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
