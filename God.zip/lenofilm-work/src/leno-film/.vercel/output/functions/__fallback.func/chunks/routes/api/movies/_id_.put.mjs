import { d as defineEventHandler, g as getRouterParam, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, m as movies } from '../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import { n as normalizeReleaseDate, r as releaseYear } from '../../../_/release-date.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function normalizeImageSource(value) {
  const source = String(value || "").trim();
  if (!source) return "";
  if (source.startsWith("data:image/")) return source;
  if (/^https?:\/\//i.test(source)) return source;
  throw createError({ statusCode: 400, statusMessage: "\u0622\u062F\u0631\u0633 \u06CC\u0627 \u0641\u0627\u06CC\u0644 \u0639\u06A9\u0633 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
}
const _id__put = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  const body = await readBody(event);
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const releaseDate = normalizeReleaseDate(body.releaseDate, body.year);
  const year = releaseYear(releaseDate);
  const db = useDb();
  const [updated] = await db.update(movies).set({
    titleFa: String(body.titleFa),
    titleEn: String(body.titleEn),
    duration: Number(body.duration),
    year,
    releaseDate,
    rating: Number(body.rating),
    posterUrl: normalizeImageSource(body.posterUrl),
    coverUrl: normalizeImageSource(body.coverUrl),
    description: String(body.description || "")
  }).where(eq(movies.id, id)).returning();
  if (!updated) throw createError({ statusCode: 404, statusMessage: "\u0641\u06CC\u0644\u0645 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  return updated;
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
