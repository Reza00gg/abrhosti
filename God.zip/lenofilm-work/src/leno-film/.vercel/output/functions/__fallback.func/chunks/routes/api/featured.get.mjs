import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import { u as useDb, f as featuredItems, m as movies, s as series } from '../../_/index.mjs';
import { desc, and, inArray, eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function publicImageUrl(type, id, source, kind, createdAt) {
  if (!source) return "";
  if (source.startsWith("data:image/")) {
    const version = new Date(createdAt).getTime() || Date.now();
    return `/api/${type === "movie" ? "movies" : "series"}/${id}/${kind}?v=${version}`;
  }
  return source;
}
const featured_get = defineEventHandler(async () => {
  const db = useDb();
  const featured = await db.select().from(featuredItems).orderBy(desc(featuredItems.createdAt)).limit(12);
  if (!featured.length) return [];
  const movieIds = featured.filter((item) => item.mediaType === "movie").map((item) => item.mediaId);
  const seriesIds = featured.filter((item) => item.mediaType === "series").map((item) => item.mediaId);
  const movieRows = movieIds.length ? await db.select().from(movies).where(and(inArray(movies.id, movieIds), eq(movies.status, "active"))) : [];
  const seriesRows = seriesIds.length ? await db.select().from(series).where(and(inArray(series.id, seriesIds), eq(series.status, "active"))) : [];
  const movieMap = new Map(movieRows.map((item) => [item.id, item]));
  const seriesMap = new Map(seriesRows.map((item) => [item.id, item]));
  return featured.map((item) => {
    if (item.mediaType === "movie") {
      const row2 = movieMap.get(item.mediaId);
      if (!row2) return null;
      return {
        id: `movie-${row2.id}`,
        mediaType: "movie",
        mediaId: row2.id,
        titleFa: row2.titleFa,
        titleEn: row2.titleEn,
        year: row2.year,
        coverUrl: publicImageUrl("movie", row2.id, row2.coverUrl, "cover", row2.createdAt),
        posterUrl: publicImageUrl("movie", row2.id, row2.posterUrl, "poster", row2.createdAt)
      };
    }
    const row = seriesMap.get(item.mediaId);
    if (!row) return null;
    return {
      id: `series-${row.id}`,
      mediaType: "series",
      mediaId: row.id,
      titleFa: row.titleFa,
      titleEn: row.titleEn,
      year: row.year,
      coverUrl: publicImageUrl("series", row.id, row.coverUrl, "cover", row.createdAt),
      posterUrl: publicImageUrl("series", row.id, row.posterUrl, "poster", row.createdAt)
    };
  }).filter(Boolean);
});

export { featured_get as default };
//# sourceMappingURL=featured.get.mjs.map
