import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../../../nitro/nitro.mjs';
import { u as useDb, f as featuredItems } from '../../../../../_/index.mjs';
import { and, eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const _mediaId__delete = defineEventHandler(async (event) => {
  const mediaType = String(getRouterParam(event, "mediaType") || "");
  const mediaId = Number(getRouterParam(event, "mediaId"));
  if (!["movie", "series"].includes(mediaType) || !mediaId || Number.isNaN(mediaId)) {
    throw createError({ statusCode: 400, statusMessage: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0633\u0644\u0627\u06CC\u062F \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  }
  const db = useDb();
  const [deleted] = await db.delete(featuredItems).where(and(eq(featuredItems.mediaType, mediaType), eq(featuredItems.mediaId, mediaId))).returning();
  return { success: true, deleted: Boolean(deleted), mediaType, mediaId };
});

export { _mediaId__delete as default };
//# sourceMappingURL=_mediaId_.delete.mjs.map
