import { c as createError } from '../nitro/nitro.mjs';

function normalizeReleaseDate(value, fallbackYear) {
  const raw = String(value || "").trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  const year = Number(fallbackYear);
  if (Number.isFinite(year) && year >= 1900 && year <= 2100) return `${year}-01-01`;
  throw createError({ statusCode: 400, statusMessage: "\u062A\u0627\u0631\u06CC\u062E \u0627\u0646\u062A\u0634\u0627\u0631 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
}
function releaseYear(releaseDate) {
  return Number(String(releaseDate).slice(0, 4));
}

export { normalizeReleaseDate as n, releaseYear as r };
//# sourceMappingURL=release-date.mjs.map
