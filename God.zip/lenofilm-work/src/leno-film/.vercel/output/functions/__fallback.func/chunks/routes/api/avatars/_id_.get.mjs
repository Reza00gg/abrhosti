import { d as defineEventHandler, g as getRouterParam, c as createError, s as setHeader, b as sendRedirect } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const avatarSources = {
  "24": "aHR0cHM6Ly9tZWRpYS5sb29rYXBvLnRvcC9hdmF0YXJzLzI0LmpwZw==",
  "25": "aHR0cHM6Ly9tZWRpYS5sb29rYXBvLnRvcC9hdmF0YXJzLzI1LmpwZw=="
};
const _id__get = defineEventHandler((event) => {
  const id = String(getRouterParam(event, "id") || "");
  const encoded = avatarSources[id];
  if (!encoded) throw createError({ statusCode: 404, statusMessage: "\u0622\u0648\u0627\u062A\u0627\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  const source = Buffer.from(encoded, "base64").toString("utf8");
  setHeader(event, "cache-control", "public, max-age=86400, s-maxage=604800");
  return sendRedirect(event, source, 302);
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
