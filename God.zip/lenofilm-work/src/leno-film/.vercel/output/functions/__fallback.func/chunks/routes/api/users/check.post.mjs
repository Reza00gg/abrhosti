import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { u as useDb, d as users } from '../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const check_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const id = Number(body == null ? void 0 : body.id);
  if (!id || isNaN(id)) {
    return { exists: false, banned: false };
  }
  const db = useDb();
  const [user] = await db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    contactEmail: users.contactEmail,
    banned: users.banned,
    status: users.status,
    avatarUrl: users.avatarUrl,
    avatarMime: users.avatarMime,
    subscriptionExpiresAt: users.subscriptionExpiresAt,
    createdAt: users.createdAt
  }).from(users).where(eq(users.id, id)).limit(1);
  if (!user || user.status === "deleted") return { exists: false, banned: false };
  return { exists: true, banned: user.banned, name: user.name, email: user.email, contactEmail: user.contactEmail, avatarUrl: user.avatarUrl, avatarMime: user.avatarMime, subscriptionExpiresAt: user.subscriptionExpiresAt, createdAt: user.createdAt };
});

export { check_post as default };
//# sourceMappingURL=check.post.mjs.map
