import { d as defineEventHandler, g as getRouterParam, c as createError, r as readBody } from '../../../../nitro/nitro.mjs';
import { u as useDb, m as movies, f as featuredItems } from '../../../../_/index.mjs';
import { eq, and } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const STATUSES = ["active", "archived", "deleted"];
function normalizeStatus(value) {
  const status = String(value || "").trim();
  if (STATUSES.includes(status)) return status;
  throw createError({ statusCode: 400, statusMessage: "\u0648\u0636\u0639\u06CC\u062A \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
}
const status_put = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const body = await readBody(event);
  const status = normalizeStatus(body.status);
  const db = useDb();
  const [updated] = await db.update(movies).set({ status }).where(eq(movies.id, id)).returning();
  if (!updated) throw createError({ statusCode: 404, statusMessage: "\u0641\u06CC\u0644\u0645 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  if (status !== "active") {
    await db.delete(featuredItems).where(and(eq(featuredItems.mediaType, "movie"), eq(featuredItems.mediaId, id)));
  }
  return updated;
});

export { status_put as default };
//# sourceMappingURL=status.put.mjs.map
