import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../../../nitro/nitro.mjs';
import { u as useDb, b as subscriptionPlans } from '../../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const _id__delete = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const db = useDb();
  const [deleted] = await db.delete(subscriptionPlans).where(eq(subscriptionPlans.id, id)).returning();
  if (!deleted) throw createError({ statusCode: 404, statusMessage: "\u067E\u0644\u0646 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  return { success: true, id };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
