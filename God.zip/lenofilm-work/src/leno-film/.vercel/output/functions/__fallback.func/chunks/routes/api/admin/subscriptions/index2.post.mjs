import { d as defineEventHandler, r as readBody, c as createError } from '../../../../nitro/nitro.mjs';
import { u as useDb, b as subscriptionPlans } from '../../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function safeInt(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : fallback;
}
const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const months = safeInt(body.months);
  const price = safeInt(body.price);
  if (!months) throw createError({ statusCode: 400, statusMessage: "\u0645\u062F\u062A \u0627\u0634\u062A\u0631\u0627\u06A9 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  if (!price) throw createError({ statusCode: 400, statusMessage: "\u0642\u06CC\u0645\u062A \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  const db = useDb();
  const [created] = await db.insert(subscriptionPlans).values({
    title: String(body.title || `${months} \u0645\u0627\u0647\u0647`).trim(),
    months,
    price,
    fee: safeInt(body.fee),
    discountPercent: Math.min(safeInt(body.discountPercent), 100),
    discountAmount: safeInt(body.discountAmount),
    active: body.active !== false
  }).returning();
  return created;
});

export { index_post as default };
//# sourceMappingURL=index2.post.mjs.map
