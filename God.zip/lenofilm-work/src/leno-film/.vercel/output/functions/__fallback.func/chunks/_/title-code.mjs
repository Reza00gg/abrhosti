import { sql } from 'drizzle-orm';

async function nextTitleCode(db) {
  var _a;
  const rows = await db.execute(sql`
    select greatest(
      coalesce((select max(title_code) from movies), 0),
      coalesce((select max(title_code) from series), 0)
    ) + 1 as code
  `);
  return Number(((_a = rows == null ? void 0 : rows[0]) == null ? void 0 : _a.code) || 1);
}

export { nextTitleCode as n };
//# sourceMappingURL=title-code.mjs.map
