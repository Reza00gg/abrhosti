import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, d as users } from '../../../_/index.mjs';
import { v as verifyPassword } from '../../../_/password.mjs';
import { or, eq } from 'drizzle-orm';
import { n as normalizeIdentifier } from '../../../_/identity.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'crypto';

const signin_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const identity = normalizeIdentifier(String((_a = body.email) != null ? _a : ""));
  if (!identity.ok) {
    throw createError({ statusCode: 400, statusMessage: identity.message });
  }
  if (!body.password) {
    throw createError({ statusCode: 400, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F" });
  }
  const db = useDb();
  const email = identity.value;
  const [user] = await db.select().from(users).where(or(eq(users.email, email), eq(users.contactEmail, email))).limit(1);
  if (!user || user.status === "deleted") {
    throw createError({ statusCode: 404, statusMessage: "\u062D\u0633\u0627\u0628\u06CC \u0628\u0627 \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644 \u06CC\u0627 \u0627\u06CC\u0645\u06CC\u0644 \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F" });
  }
  if (user.banned) {
    throw createError({ statusCode: 403, statusMessage: "\u0634\u0645\u0627 \u0627\u0632 \u0637\u0631\u0641 \u0645\u062F\u06CC\u0631\u06CC\u062A \u0645\u0633\u062F\u0648\u062F \u0634\u062F\u0647\u200C\u0627\u06CC\u062F" });
  }
  if (!verifyPassword(body.password, user.passwordHash)) {
    throw createError({ statusCode: 401, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A" });
  }
  return { id: user.id, name: user.name, email: user.email, contactEmail: user.contactEmail, avatarUrl: user.avatarUrl, avatarMime: user.avatarMime, subscriptionExpiresAt: user.subscriptionExpiresAt, createdAt: user.createdAt };
});

export { signin_post as default };
//# sourceMappingURL=signin.post.mjs.map
