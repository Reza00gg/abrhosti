import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, m as movies, s as series } from '../../../_/index.mjs';
import { and, eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function imageUrl(kind, id, value, field, createdAt) {
  if (!value) return "";
  if (value.startsWith("data:image/")) {
    const version = new Date(createdAt).getTime() || Date.now();
    return `/api/${kind}/${id}/${field}?v=${version}`;
  }
  return value;
}
const _code__get = defineEventHandler(async (event) => {
  const code = Number(getRouterParam(event, "code"));
  if (!Number.isFinite(code) || code < 1) {
    throw createError({ statusCode: 404, statusMessage: "\u0639\u0646\u0648\u0627\u0646 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  }
  const db = useDb();
  const [movie] = await db.select().from(movies).where(and(eq(movies.titleCode, code), eq(movies.status, "active"))).limit(1);
  if (movie) {
    return {
      type: "movie",
      id: movie.id,
      titleCode: movie.titleCode,
      titleFa: movie.titleFa,
      titleEn: movie.titleEn,
      year: movie.year,
      releaseDate: movie.releaseDate,
      rating: movie.rating,
      duration: movie.duration,
      durationLabel: `${movie.duration} \u062F\u0642\u06CC\u0642\u0647`,
      description: movie.description,
      posterUrl: imageUrl("movies", movie.id, movie.posterUrl, "poster", movie.createdAt),
      coverUrl: imageUrl("movies", movie.id, movie.coverUrl, "cover", movie.createdAt)
    };
  }
  const [row] = await db.select().from(series).where(and(eq(series.titleCode, code), eq(series.status, "active"))).limit(1);
  if (row) {
    return {
      type: "series",
      id: row.id,
      titleCode: row.titleCode,
      titleFa: row.titleFa,
      titleEn: row.titleEn,
      year: row.year,
      releaseDate: row.releaseDate,
      rating: row.rating,
      duration: 0,
      durationLabel: `${row.seasons} \u0641\u0635\u0644 | ${row.episodes} \u0642\u0633\u0645\u062A`,
      seasons: row.seasons,
      episodes: row.episodes,
      description: row.description,
      posterUrl: imageUrl("series", row.id, row.posterUrl, "poster", row.createdAt),
      coverUrl: imageUrl("series", row.id, row.coverUrl, "cover", row.createdAt)
    };
  }
  throw createError({ statusCode: 404, statusMessage: "\u0639\u0646\u0648\u0627\u0646 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
});

export { _code__get as default };
//# sourceMappingURL=_code_.get.mjs.map
