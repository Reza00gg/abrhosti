import { d as defineEventHandler, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, e as subscriptionOrders } from '../../../_/index.mjs';
import { eq, desc } from 'drizzle-orm';
import { r as readUserAuthCookie } from '../../../_/user-session.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_get = defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event);
  if (!session) throw createError({ statusCode: 401, statusMessage: "\u0628\u0631\u0627\u06CC \u0645\u0634\u0627\u0647\u062F\u0647 \u0633\u0648\u0627\u0628\u0642 \u062E\u0631\u06CC\u062F \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F" });
  const db = useDb();
  const items = await db.select().from(subscriptionOrders).where(eq(subscriptionOrders.userId, session.id)).orderBy(desc(subscriptionOrders.createdAt)).limit(50);
  return { items };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
