import { d as defineEventHandler, g as getRouterParam, c as createError, r as readBody } from '../../../../../nitro/nitro.mjs';
import { u as useDb, b as subscriptionPlans } from '../../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function safeInt(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : fallback;
}
const _id__put = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const body = await readBody(event);
  const months = safeInt(body.months);
  const price = safeInt(body.price);
  if (!months) throw createError({ statusCode: 400, statusMessage: "\u0645\u062F\u062A \u0627\u0634\u062A\u0631\u0627\u06A9 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  if (!price) throw createError({ statusCode: 400, statusMessage: "\u0642\u06CC\u0645\u062A \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
  const db = useDb();
  const [updated] = await db.update(subscriptionPlans).set({
    title: String(body.title || `${months} \u0645\u0627\u0647\u0647`).trim(),
    months,
    price,
    fee: safeInt(body.fee),
    discountPercent: Math.min(safeInt(body.discountPercent), 100),
    discountAmount: safeInt(body.discountAmount),
    active: body.active !== false
  }).where(eq(subscriptionPlans.id, id)).returning();
  if (!updated) throw createError({ statusCode: 404, statusMessage: "\u067E\u0644\u0646 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  return updated;
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
