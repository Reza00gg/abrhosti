export function normalizeReleaseDate(value: unknown, fallbackYear: unknown) {
  const raw = String(value || '').trim()
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw
  const year = Number(fallbackYear)
  if (Number.isFinite(year) && year >= 1900 && year <= 2100) return `${year}-01-01`
  throw createError({ statusCode: 400, statusMessage: 'تاریخ انتشار معتبر نیست' })
}

export function releaseYear(releaseDate: string) {
  return Number(String(releaseDate).slice(0, 4))
}
