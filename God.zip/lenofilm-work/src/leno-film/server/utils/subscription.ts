export function planBaseDiscountAmount(plan: { price: number; fee: number; discountPercent: number; discountAmount: number }) {
  const subtotal = Math.max(0, Number(plan.price) + Number(plan.fee || 0))
  const percent = Math.floor(subtotal * Number(plan.discountPercent || 0) / 100)
  return Math.min(subtotal, percent + Number(plan.discountAmount || 0))
}

export function planFinalPrice(plan: { price: number; fee: number; discountPercent: number; discountAmount: number }) {
  const subtotal = Math.max(0, Number(plan.price) + Number(plan.fee || 0))
  return Math.max(0, subtotal - planBaseDiscountAmount(plan))
}

export function addMonths(base: Date, months: number) {
  const next = new Date(base)
  next.setMonth(next.getMonth() + Number(months || 0))
  return next
}

export function activeSubscriptionDays(expiresAt?: Date | string | null) {
  if (!expiresAt) return 0
  const ms = new Date(expiresAt).getTime() - Date.now()
  if (ms <= 0) return 0
  return Math.max(1, Math.ceil(ms / (24 * 60 * 60 * 1000)))
}
