import { sql } from 'drizzle-orm'

export async function nextTitleCode(db: any) {
  const rows = await db.execute(sql`
    select greatest(
      coalesce((select max(title_code) from movies), 0),
      coalesce((select max(title_code) from series), 0)
    ) + 1 as code
  `)
  return Number(rows?.[0]?.code || 1)
}
