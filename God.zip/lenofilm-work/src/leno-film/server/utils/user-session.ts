export function readUserAuthCookie(event: any): { id: number; name?: string; email?: string } | null {
  const raw = getCookie(event, 'user-auth')
  if (!raw) return null

  const candidates = [raw]
  try { candidates.push(decodeURIComponent(raw)) } catch {}

  for (const value of candidates) {
    try {
      const normalized = value.startsWith('j:') ? value.slice(2) : value
      const parsed = JSON.parse(normalized)
      const id = Number(parsed?.id)
      if (id && !Number.isNaN(id)) return { id, name: parsed?.name, email: parsed?.email }
    } catch {}
  }

  return null
}
