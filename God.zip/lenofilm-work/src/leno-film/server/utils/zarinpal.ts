type ZarinpalRequestInput = {
  merchantId: string
  amountToman: number
  callbackUrl: string
  description: string
  orderId: number | string
  email?: string
  mobile?: string
  sandbox?: boolean
}

type ZarinpalVerifyInput = {
  merchantId: string
  amountToman: number
  authority: string
  sandbox?: boolean
}

type ZarinpalResponse = {
  data?: any
  errors?: Array<{ code?: number; message?: string }> | Record<string, unknown>
}

function apiBase(sandbox?: boolean) { return sandbox ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com' }
function startBase(sandbox?: boolean) { return sandbox ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com' }
function errorMessage(errors: ZarinpalResponse['errors']) {
  if (!errors) return ''
  if (Array.isArray(errors)) return errors.map(e => e.message || e.code).filter(Boolean).join('، ')
  const values = Object.values(errors).filter(Boolean)
  return values.length ? values.join('، ') : ''
}

export async function zarinpalRequestPayment(input: ZarinpalRequestInput) {
  const response = await fetch(`${apiBase(input.sandbox)}/pg/v4/payment/request.json`, {
    method: 'POST',
    headers: { accept: 'application/json', 'Content-Type': 'application/json' },
    body: JSON.stringify({
      merchant_id: input.merchantId,
      amount: input.amountToman,
      currency: 'IRT',
      callback_url: input.callbackUrl,
      description: input.description,
      metadata: { email: input.email, mobile: input.mobile, order_id: String(input.orderId) }
    })
  })
  const data = await response.json() as ZarinpalResponse
  const ok = response.ok && data.data?.code === 100 && Boolean(data.data?.authority)
  return { ok, data, message: data.data?.message || errorMessage(data.errors) || 'خطا در درخواست پرداخت زرین‌پال' }
}

export async function zarinpalVerifyPayment(input: ZarinpalVerifyInput) {
  const response = await fetch(`${apiBase(input.sandbox)}/pg/v4/payment/verify.json`, {
    method: 'POST',
    headers: { accept: 'application/json', 'Content-Type': 'application/json' },
    body: JSON.stringify({ merchant_id: input.merchantId, amount: input.amountToman, authority: input.authority })
  })
  const data = await response.json() as ZarinpalResponse
  const code = data.data?.code
  const ok = response.ok && (code === 100 || code === 101)
  return { ok, data, message: data.data?.message || errorMessage(data.errors) || 'خطا در تایید پرداخت زرین‌پال' }
}

export function zarinpalStartUrl(authority: string, sandbox?: boolean) {
  return `${startBase(sandbox)}/pg/StartPay/${authority}`
}
