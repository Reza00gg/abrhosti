export function mediaImageResponse(event: any, source: string, key: string, versionSeed: Date | string) {
  if (!source) throw createError({ statusCode: 404, statusMessage: 'تصویر پیدا نشد' })

  if (/^https?:\/\//i.test(source)) {
    return sendRedirect(event, source, 302)
  }

  const match = source.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\s]+)$/)
  if (!match) throw createError({ statusCode: 415, statusMessage: 'فرمت تصویر پشتیبانی نمی‌شود' })

  const mime = match[1]
  const base64 = match[2].replace(/\s/g, '')
  const buffer = Buffer.from(base64, 'base64')
  const version = new Date(versionSeed).getTime() || Date.now()

  setHeader(event, 'Content-Type', mime)
  setHeader(event, 'Content-Length', String(buffer.length))
  setHeader(event, 'Cache-Control', 'public, max-age=31536000, s-maxage=31536000, immutable')
  setHeader(event, 'CDN-Cache-Control', 'public, max-age=31536000, immutable')
  setHeader(event, 'Vercel-CDN-Cache-Control', 'public, max-age=31536000, immutable')
  setHeader(event, 'ETag', `"${key}-${version}-${buffer.length}"`)
  return buffer
}
