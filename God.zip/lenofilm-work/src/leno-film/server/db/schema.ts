import { pgTable, serial, text, integer, real, timestamp, boolean, uniqueIndex, date } from 'drizzle-orm/pg-core'

export const movies = pgTable('movies', {
  id: serial('id').primaryKey(),
  titleCode: integer('title_code'),
  titleFa: text('title_fa').notNull(),
  titleEn: text('title_en').notNull(),
  duration: integer('duration').notNull(),
  year: integer('year').notNull(),
  releaseDate: date('release_date'),
  status: text('status').notNull().default('active'),
  rating: real('rating').notNull(),
  posterUrl: text('poster_url').notNull(),
  coverUrl: text('cover_url').notNull(),
  description: text('description').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})


export const series = pgTable('series', {
  id: serial('id').primaryKey(),
  titleCode: integer('title_code'),
  titleFa: text('title_fa').notNull(),
  titleEn: text('title_en').notNull(),
  seasons: integer('seasons').notNull(),
  episodes: integer('episodes').notNull(),
  year: integer('year').notNull(),
  releaseDate: date('release_date'),
  status: text('status').notNull().default('active'),
  rating: real('rating').notNull(),
  posterUrl: text('poster_url').notNull(),
  coverUrl: text('cover_url').notNull(),
  description: text('description').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})


export const featuredItems = pgTable('featured_items', {
  id: serial('id').primaryKey(),
  mediaType: text('media_type').notNull(),
  mediaId: integer('media_id').notNull(),
  position: integer('position').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  mediaUniqueIdx: uniqueIndex('featured_items_media_unique_idx').on(table.mediaType, table.mediaId),
}))


export const subscriptionPlans = pgTable('subscription_plans', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  months: integer('months').notNull(),
  price: integer('price').notNull(),
  fee: integer('fee').notNull().default(0),
  discountPercent: integer('discount_percent').notNull().default(0),
  discountAmount: integer('discount_amount').notNull().default(0),
  active: boolean('active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const subscriptionDiscounts = pgTable('subscription_discounts', {
  id: serial('id').primaryKey(),
  code: text('code').notNull(),
  type: text('type').notNull().default('percent'),
  value: integer('value').notNull(),
  planId: integer('plan_id'),
  active: boolean('active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  codeIdx: uniqueIndex('subscription_discounts_code_idx').on(table.code),
}))

export const subscriptionSettings = pgTable('subscription_settings', {
  id: serial('id').primaryKey(),
  rialEnabled: boolean('rial_enabled').notNull().default(true),
  cardEnabled: boolean('card_enabled').notNull().default(false),
  zarinpalMerchant: text('zarinpal_merchant'),
  zarinpalSandbox: boolean('zarinpal_sandbox').notNull().default(true),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})


export const subscriptionOrders = pgTable('subscription_orders', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  planId: integer('plan_id').notNull(),
  planTitle: text('plan_title').notNull(),
  months: integer('months').notNull(),
  basePrice: integer('base_price').notNull(),
  fee: integer('fee').notNull().default(0),
  planDiscountAmount: integer('plan_discount_amount').notNull().default(0),
  couponCode: text('coupon_code'),
  couponDiscountAmount: integer('coupon_discount_amount').notNull().default(0),
  finalAmount: integer('final_amount').notNull(),
  status: text('status').notNull().default('pending'),
  gateway: text('gateway').notNull().default('zarinpal'),
  authority: text('authority'),
  refId: text('ref_id'),
  failureMessage: text('failure_message'),
  requestPayload: text('request_payload'),
  verifyPayload: text('verify_payload'),
  paidAt: timestamp('paid_at'),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

export const userNotifications = pgTable('user_notifications', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  type: text('type').notNull(),
  title: text('title').notNull(),
  message: text('message').notNull(),
  status: text('status').notNull().default('unread'),
  meta: text('meta'),
  readAt: timestamp('read_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  contactEmail: text('contact_email'),
  passwordHash: text('password_hash').notNull(),
  banned: boolean('banned').notNull().default(false),
  status: text('status').notNull().default('active'),
  avatarUrl: text('avatar_url'),
  avatarMime: text('avatar_mime'),
  avatarUpdatedAt: timestamp('avatar_updated_at'),
  subscriptionExpiresAt: timestamp('subscription_expires_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  emailIdx: uniqueIndex('users_email_idx').on(table.email),
  contactEmailIdx: uniqueIndex('users_contact_email_idx').on(table.contactEmail),
}))

export type Movie = typeof movies.$inferSelect
export type NewMovie = typeof movies.$inferInsert
export type Series = typeof series.$inferSelect
export type NewSeries = typeof series.$inferInsert
export type FeaturedItem = typeof featuredItems.$inferSelect
export type NewFeaturedItem = typeof featuredItems.$inferInsert
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect
export type NewSubscriptionPlan = typeof subscriptionPlans.$inferInsert
export type SubscriptionDiscount = typeof subscriptionDiscounts.$inferSelect
export type NewSubscriptionDiscount = typeof subscriptionDiscounts.$inferInsert
export type SubscriptionSettings = typeof subscriptionSettings.$inferSelect
export type SubscriptionOrder = typeof subscriptionOrders.$inferSelect
export type NewSubscriptionOrder = typeof subscriptionOrders.$inferInsert
export type UserNotification = typeof userNotifications.$inferSelect
export type NewUserNotification = typeof userNotifications.$inferInsert
export type User = typeof users.$inferSelect
export type NewUser = typeof users.$inferInsert
