import { useDb } from '~~/server/db'
import { featuredItems, movies, series } from '~~/server/db/schema'
import { and, desc, eq, inArray } from 'drizzle-orm'

function publicImageUrl(type: 'movie' | 'series', id: number, source: string, kind: 'cover' | 'poster', createdAt: Date | string) {
  if (!source) return ''
  if (source.startsWith('data:image/')) {
    const version = new Date(createdAt).getTime() || Date.now()
    return `/api/${type === 'movie' ? 'movies' : 'series'}/${id}/${kind}?v=${version}`
  }
  return source
}

export default defineEventHandler(async () => {
  const db = useDb()
  const featured = await db.select().from(featuredItems).orderBy(desc(featuredItems.createdAt)).limit(12)
  if (!featured.length) return []

  const movieIds = featured.filter(item => item.mediaType === 'movie').map(item => item.mediaId)
  const seriesIds = featured.filter(item => item.mediaType === 'series').map(item => item.mediaId)
  const movieRows = movieIds.length ? await db.select().from(movies).where(and(inArray(movies.id, movieIds), eq(movies.status, 'active'))) : []
  const seriesRows = seriesIds.length ? await db.select().from(series).where(and(inArray(series.id, seriesIds), eq(series.status, 'active'))) : []
  const movieMap = new Map(movieRows.map(item => [item.id, item]))
  const seriesMap = new Map(seriesRows.map(item => [item.id, item]))

  return featured.map((item) => {
    if (item.mediaType === 'movie') {
      const row = movieMap.get(item.mediaId)
      if (!row) return null
      return {
        id: `movie-${row.id}`,
        mediaType: 'movie',
        mediaId: row.id,
        titleFa: row.titleFa,
        titleEn: row.titleEn,
        year: row.year,
        coverUrl: publicImageUrl('movie', row.id, row.coverUrl, 'cover', row.createdAt),
        posterUrl: publicImageUrl('movie', row.id, row.posterUrl, 'poster', row.createdAt),
      }
    }
    const row = seriesMap.get(item.mediaId)
    if (!row) return null
    return {
      id: `series-${row.id}`,
      mediaType: 'series',
      mediaId: row.id,
      titleFa: row.titleFa,
      titleEn: row.titleEn,
      year: row.year,
      coverUrl: publicImageUrl('series', row.id, row.coverUrl, 'cover', row.createdAt),
      posterUrl: publicImageUrl('series', row.id, row.posterUrl, 'poster', row.createdAt),
    }
  }).filter(Boolean)
})
