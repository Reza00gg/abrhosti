import { useDb } from '~~/server/db'
import { series } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'
import { mediaImageResponse } from '~~/server/utils/media-image'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const db = useDb()
  const [row] = await db.select({ coverUrl: series.coverUrl, createdAt: series.createdAt }).from(series).where(eq(series.id, id)).limit(1)
  return mediaImageResponse(event, row?.coverUrl || '', `series-cover-${id}`, row?.createdAt || new Date())
})
