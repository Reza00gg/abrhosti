import { useDb } from '~~/server/db'
import { featuredItems, series } from '~~/server/db/schema'
import { and, eq } from 'drizzle-orm'

const STATUSES = ['active', 'archived', 'deleted'] as const
type MediaStatus = typeof STATUSES[number]

function normalizeStatus(value: unknown): MediaStatus {
  const status = String(value || '').trim()
  if (STATUSES.includes(status as MediaStatus)) return status as MediaStatus
  throw createError({ statusCode: 400, statusMessage: 'وضعیت معتبر نیست' })
}

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const body = await readBody(event)
  const status = normalizeStatus(body.status)
  const db = useDb()
  const [updated] = await db.update(series).set({ status }).where(eq(series.id, id)).returning()
  if (!updated) throw createError({ statusCode: 404, statusMessage: 'سریال پیدا نشد' })
  if (status !== 'active') {
    await db.delete(featuredItems).where(and(eq(featuredItems.mediaType, 'series'), eq(featuredItems.mediaId, id)))
  }
  return updated
})
