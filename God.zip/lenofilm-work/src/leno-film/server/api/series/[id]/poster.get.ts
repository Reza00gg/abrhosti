import { useDb } from '~~/server/db'
import { series } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })

  const db = useDb()
  const [row] = await db.select({ posterUrl: series.posterUrl, createdAt: series.createdAt }).from(series).where(eq(series.id, id)).limit(1)
  if (!row?.posterUrl) throw createError({ statusCode: 404, statusMessage: 'پوستر پیدا نشد' })

  if (/^https?:\/\//i.test(row.posterUrl)) return sendRedirect(event, row.posterUrl, 302)

  const match = row.posterUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\s]+)$/)
  if (!match) throw createError({ statusCode: 415, statusMessage: 'فرمت پوستر پشتیبانی نمی‌شود' })

  const mime = match[1]
  const base64 = match[2].replace(/\s/g, '')
  const buffer = Buffer.from(base64, 'base64')
  const version = new Date(row.createdAt).getTime() || Date.now()

  setHeader(event, 'Content-Type', mime)
  setHeader(event, 'Content-Length', String(buffer.length))
  setHeader(event, 'Cache-Control', 'public, max-age=31536000, s-maxage=31536000, immutable')
  setHeader(event, 'CDN-Cache-Control', 'public, max-age=31536000, immutable')
  setHeader(event, 'Vercel-CDN-Cache-Control', 'public, max-age=31536000, immutable')
  setHeader(event, 'ETag', `"series-poster-${id}-${version}-${buffer.length}"`)
  return buffer
})
