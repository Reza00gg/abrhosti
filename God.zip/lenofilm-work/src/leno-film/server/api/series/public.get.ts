import { useDb } from '~~/server/db'
import { series } from '~~/server/db/schema'
import { and, desc, eq, ilike, or, sql } from 'drizzle-orm'

function publicPosterUrl(id: number, posterUrl: string, createdAt: Date | string) {
  if (!posterUrl) return ''
  if (posterUrl.startsWith('data:image/')) {
    const version = new Date(createdAt).getTime() || Date.now()
    return `/api/series/${id}/poster?v=${version}`
  }
  return posterUrl
}

function safeLimit(value: unknown, fallback: number) {
  const n = Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(Math.max(Math.floor(n), 1), 60)
}

function safeOffset(value: unknown) {
  const n = Number(value)
  if (!Number.isFinite(n)) return 0
  return Math.max(Math.floor(n), 0)
}

export default defineEventHandler(async (event) => {
  const q = getQuery(event)
  const search = (q.q as string | undefined)?.trim()
  const limit = safeLimit(q.limit, search ? 50 : 20)
  const offset = safeOffset(q.offset)
  const db = useDb()
  const releaseOrder = sql`coalesce(${series.releaseDate}, make_date(${series.year}, 1, 1))`

  const selectFields = {
    id: series.id,
    titleCode: series.titleCode,
    titleFa: series.titleFa,
    titleEn: series.titleEn,
    seasons: series.seasons,
    episodes: series.episodes,
    year: series.year,
    releaseDate: series.releaseDate,
    rating: series.rating,
    posterUrl: series.posterUrl,
    createdAt: series.createdAt,
  }

  const activeWhere = eq(series.status, 'active')
  const searchWhere = search ? or(ilike(series.titleFa, `%${search}%`), ilike(series.titleEn, `%${search}%`)) : undefined
  const rows = searchWhere
    ? await db.select(selectFields).from(series)
      .where(and(activeWhere, searchWhere))
      .orderBy(desc(releaseOrder), desc(series.createdAt))
      .limit(limit)
      .offset(offset)
    : await db.select(selectFields).from(series).where(activeWhere).orderBy(desc(releaseOrder), desc(series.createdAt)).limit(limit).offset(offset)

  return rows.map((row) => ({
    ...row,
    type: 'series',
    duration: 0,
    durationLabel: `${row.seasons} فصل`,
    posterUrl: publicPosterUrl(row.id, row.posterUrl, row.createdAt),
    coverUrl: '',
    description: '',
  }))
})
