import { useDb } from '~~/server/db'
import { series } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'
import { normalizeReleaseDate, releaseYear } from '~~/server/utils/release-date'

function normalizeImageSource(value: unknown) {
  const source = String(value || '').trim()
  if (!source) return ''
  if (source.startsWith('data:image/')) return source
  if (/^https?:\/\//i.test(source)) return source
  throw createError({ statusCode: 400, statusMessage: 'آدرس یا فایل عکس معتبر نیست' })
}

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  const body = await readBody(event)
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const releaseDate = normalizeReleaseDate(body.releaseDate, body.year)
  const year = releaseYear(releaseDate)
  const db = useDb()
  const [updated] = await db.update(series).set({
    titleFa: String(body.titleFa),
    titleEn: String(body.titleEn),
    seasons: Number(body.seasons),
    episodes: Number(body.episodes),
    year,
    releaseDate,
    rating: Number(body.rating),
    posterUrl: normalizeImageSource(body.posterUrl),
    coverUrl: normalizeImageSource(body.coverUrl),
    description: String(body.description || ''),
  }).where(eq(series.id, id)).returning()
  if (!updated) throw createError({ statusCode: 404, statusMessage: 'سریال پیدا نشد' })
  return updated
})
