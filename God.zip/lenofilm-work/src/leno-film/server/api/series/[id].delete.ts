import { useDb } from '~~/server/db'
import { featuredItems, series } from '~~/server/db/schema'
import { and, eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const permanent = ['1', 'true', 'yes'].includes(String(getQuery(event).permanent || '').toLowerCase())
  const db = useDb()

  if (permanent) {
    await db.delete(featuredItems).where(and(eq(featuredItems.mediaType, 'series'), eq(featuredItems.mediaId, id)))
    const [deleted] = await db.delete(series).where(eq(series.id, id)).returning()
    if (!deleted) throw createError({ statusCode: 404, statusMessage: 'سریال پیدا نشد' })
    return { success: true, id, permanent: true }
  }

  const [updated] = await db.update(series).set({ status: 'deleted' }).where(eq(series.id, id)).returning()
  if (!updated) throw createError({ statusCode: 404, statusMessage: 'سریال پیدا نشد' })
  await db.delete(featuredItems).where(and(eq(featuredItems.mediaType, 'series'), eq(featuredItems.mediaId, id)))
  return { success: true, id, permanent: false, item: updated }
})
