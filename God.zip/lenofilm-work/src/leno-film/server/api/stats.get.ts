import { useDb } from '~~/server/db'
import { movies, series } from '~~/server/db/schema'
import { count } from 'drizzle-orm'

export default defineEventHandler(async () => {
  const db = useDb()
  const [moviesCount] = await db.select({ count: count() }).from(movies)
  const [seriesCount] = await db.select({ count: count() }).from(series)
  return {
    movies: moviesCount?.count ?? 0,
    series: seriesCount?.count ?? 0,
    users: 1,
    comments: 0,
  }
})
