import { useDb } from '~~/server/db'
import { featuredItems } from '~~/server/db/schema'
import { and, eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const mediaType = String(getRouterParam(event, 'mediaType') || '')
  const mediaId = Number(getRouterParam(event, 'mediaId'))
  if (!['movie', 'series'].includes(mediaType) || !mediaId || Number.isNaN(mediaId)) {
    throw createError({ statusCode: 400, statusMessage: 'اطلاعات اسلاید معتبر نیست' })
  }
  const db = useDb()
  const [deleted] = await db.delete(featuredItems).where(and(eq(featuredItems.mediaType, mediaType), eq(featuredItems.mediaId, mediaId))).returning()
  return { success: true, deleted: Boolean(deleted), mediaType, mediaId }
})
