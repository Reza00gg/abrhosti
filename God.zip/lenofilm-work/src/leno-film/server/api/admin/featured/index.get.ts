import { useDb } from '~~/server/db'
import { featuredItems } from '~~/server/db/schema'
import { desc } from 'drizzle-orm'

export default defineEventHandler(async () => {
  const db = useDb()
  return await db.select().from(featuredItems).orderBy(desc(featuredItems.createdAt))
})
