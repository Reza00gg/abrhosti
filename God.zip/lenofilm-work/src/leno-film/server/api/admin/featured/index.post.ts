import { useDb } from '~~/server/db'
import { featuredItems, movies, series } from '~~/server/db/schema'
import { and, eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  const mediaType = String(body.mediaType || '').trim()
  const mediaId = Number(body.mediaId)
  if (!['movie', 'series'].includes(mediaType) || !mediaId || Number.isNaN(mediaId)) {
    throw createError({ statusCode: 400, statusMessage: 'اطلاعات اسلاید معتبر نیست' })
  }

  const db = useDb()
  const exists = mediaType === 'movie'
    ? await db.select({ id: movies.id }).from(movies).where(and(eq(movies.id, mediaId), eq(movies.status, 'active'))).limit(1)
    : await db.select({ id: series.id }).from(series).where(and(eq(series.id, mediaId), eq(series.status, 'active'))).limit(1)
  if (!exists.length) throw createError({ statusCode: 404, statusMessage: 'آیتم فعال پیدا نشد' })

  const already = await db.select().from(featuredItems).where(and(eq(featuredItems.mediaType, mediaType), eq(featuredItems.mediaId, mediaId))).limit(1)
  if (already[0]) return already[0]

  const [created] = await db.insert(featuredItems).values({ mediaType, mediaId }).returning()
  return created
})
