import { useDb } from '~~/server/db'
import { subscriptionDiscounts } from '~~/server/db/schema'

function code(value: unknown) { return String(value || '').trim().toUpperCase() }
function safeInt(value: unknown, fallback = 0) {
  const n = Number(value)
  return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : fallback
}
function type(value: unknown) {
  const t = String(value || 'percent')
  return t === 'fixed' ? 'fixed' : 'percent'
}

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  const normalizedCode = code(body.code)
  const normalizedType = type(body.type)
  const value = safeInt(body.value)
  if (!normalizedCode) throw createError({ statusCode: 400, statusMessage: 'کد تخفیف را وارد کنید' })
  if (!value) throw createError({ statusCode: 400, statusMessage: 'مقدار تخفیف معتبر نیست' })

  const db = useDb()
  try {
    const [created] = await db.insert(subscriptionDiscounts).values({
      code: normalizedCode,
      type: normalizedType,
      value: normalizedType === 'percent' ? Math.min(value, 100) : value,
      planId: body.planId ? Number(body.planId) : null,
      active: body.active !== false,
    }).returning()
    return created
  } catch {
    throw createError({ statusCode: 409, statusMessage: 'این کد تخفیف قبلاً ثبت شده است' })
  }
})
