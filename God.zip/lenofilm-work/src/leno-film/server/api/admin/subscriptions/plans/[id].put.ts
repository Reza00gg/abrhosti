import { useDb } from '~~/server/db'
import { subscriptionPlans } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

function safeInt(value: unknown, fallback = 0) {
  const n = Number(value)
  return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : fallback
}

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const body = await readBody(event)
  const months = safeInt(body.months)
  const price = safeInt(body.price)
  if (!months) throw createError({ statusCode: 400, statusMessage: 'مدت اشتراک معتبر نیست' })
  if (!price) throw createError({ statusCode: 400, statusMessage: 'قیمت معتبر نیست' })

  const db = useDb()
  const [updated] = await db.update(subscriptionPlans).set({
    title: String(body.title || `${months} ماهه`).trim(),
    months,
    price,
    fee: safeInt(body.fee),
    discountPercent: Math.min(safeInt(body.discountPercent), 100),
    discountAmount: safeInt(body.discountAmount),
    active: body.active !== false,
  }).where(eq(subscriptionPlans.id, id)).returning()
  if (!updated) throw createError({ statusCode: 404, statusMessage: 'پلن پیدا نشد' })
  return updated
})
