import { useDb } from '~~/server/db'
import { subscriptionPlans } from '~~/server/db/schema'
import { asc } from 'drizzle-orm'

export default defineEventHandler(async () => {
  const db = useDb()
  return await db.select().from(subscriptionPlans).orderBy(asc(subscriptionPlans.months), asc(subscriptionPlans.price))
})
