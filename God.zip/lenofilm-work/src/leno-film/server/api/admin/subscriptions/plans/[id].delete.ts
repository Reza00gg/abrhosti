import { useDb } from '~~/server/db'
import { subscriptionPlans } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const db = useDb()
  const [deleted] = await db.delete(subscriptionPlans).where(eq(subscriptionPlans.id, id)).returning()
  if (!deleted) throw createError({ statusCode: 404, statusMessage: 'پلن پیدا نشد' })
  return { success: true, id }
})
