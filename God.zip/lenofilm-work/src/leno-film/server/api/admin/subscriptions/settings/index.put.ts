import { useDb } from '~~/server/db'
import { subscriptionSettings } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  const db = useDb()
  const current = await db.select().from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1)
  await db.insert(subscriptionSettings).values({ id: 1, rialEnabled: body.rialEnabled !== false, cardEnabled: body.cardEnabled === true }).onConflictDoNothing()
  const merchant = String(body.zarinpalMerchant || '').trim()
  const updateData: any = {
    rialEnabled: body.rialEnabled !== false,
    cardEnabled: body.cardEnabled === true,
    zarinpalSandbox: body.zarinpalSandbox !== false,
    updatedAt: new Date(),
  }
  if (merchant) updateData.zarinpalMerchant = merchant
  else if (!current[0]?.zarinpalMerchant) updateData.zarinpalMerchant = null
  const [updated] = await db.update(subscriptionSettings).set(updateData).where(eq(subscriptionSettings.id, 1)).returning()
  return { ...updated, zarinpalMerchant: '', zarinpalMasked: updated.zarinpalMerchant ? `${updated.zarinpalMerchant.slice(0,4)}••••${updated.zarinpalMerchant.slice(-4)}` : '' }
})
