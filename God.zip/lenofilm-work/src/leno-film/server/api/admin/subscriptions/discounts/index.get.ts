import { useDb } from '~~/server/db'
import { subscriptionDiscounts } from '~~/server/db/schema'
import { desc } from 'drizzle-orm'

export default defineEventHandler(async () => {
  const db = useDb()
  return await db.select().from(subscriptionDiscounts).orderBy(desc(subscriptionDiscounts.createdAt))
})
