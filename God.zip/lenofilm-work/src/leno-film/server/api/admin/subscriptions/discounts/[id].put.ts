import { useDb } from '~~/server/db'
import { subscriptionDiscounts } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

function code(value: unknown) { return String(value || '').trim().toUpperCase() }
function safeInt(value: unknown, fallback = 0) {
  const n = Number(value)
  return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : fallback
}
function type(value: unknown) {
  const t = String(value || 'percent')
  return t === 'fixed' ? 'fixed' : 'percent'
}

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const body = await readBody(event)
  const normalizedCode = code(body.code)
  const normalizedType = type(body.type)
  const value = safeInt(body.value)
  if (!normalizedCode) throw createError({ statusCode: 400, statusMessage: 'کد تخفیف را وارد کنید' })
  if (!value) throw createError({ statusCode: 400, statusMessage: 'مقدار تخفیف معتبر نیست' })
  const db = useDb()
  try {
    const [updated] = await db.update(subscriptionDiscounts).set({
      code: normalizedCode,
      type: normalizedType,
      value: normalizedType === 'percent' ? Math.min(value, 100) : value,
      planId: body.planId ? Number(body.planId) : null,
      active: body.active !== false,
    }).where(eq(subscriptionDiscounts.id, id)).returning()
    if (!updated) throw createError({ statusCode: 404, statusMessage: 'کد تخفیف پیدا نشد' })
    return updated
  } catch (err: any) {
    if (err?.statusCode) throw err
    throw createError({ statusCode: 409, statusMessage: 'این کد تخفیف قبلاً ثبت شده است' })
  }
})
