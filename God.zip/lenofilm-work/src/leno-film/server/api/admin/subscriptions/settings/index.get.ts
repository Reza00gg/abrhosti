import { useDb } from '~~/server/db'
import { subscriptionSettings } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

function mask(value?: string | null) {
  if (!value) return ''
  if (value.length <= 8) return '••••'
  return `${value.slice(0, 4)}••••${value.slice(-4)}`
}

export default defineEventHandler(async () => {
  const db = useDb()
  const [settings] = await db.select().from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1)
  if (!settings) return { id: 1, rialEnabled: true, cardEnabled: false, zarinpalSandbox: true, zarinpalMasked: '' }
  return { ...settings, zarinpalMasked: mask(settings.zarinpalMerchant), zarinpalMerchant: '' }
})
