import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const permanent = ['1', 'true', 'yes'].includes(String(getQuery(event).permanent || '').toLowerCase())
  const db = useDb()

  if (permanent) {
    const [deleted] = await db.delete(users).where(eq(users.id, id)).returning()
    if (!deleted) throw createError({ statusCode: 404, statusMessage: 'کاربر پیدا نشد' })
    return { success: true, id, permanent: true }
  }

  const [updated] = await db.update(users).set({ status: 'deleted' }).where(eq(users.id, id)).returning()
  if (!updated) throw createError({ statusCode: 404, statusMessage: 'کاربر پیدا نشد' })
  return { success: true, id, permanent: false, user: updated }
})
