import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const body = await readBody(event)
  const banned = !!body.banned

  const db = useDb()
  const [updated] = await db.update(users).set({ banned }).where(eq(users.id, id)).returning()
  if (!updated) throw createError({ statusCode: 404, statusMessage: 'کاربر پیدا نشد' })
  return { success: true, banned: updated.banned }
})
