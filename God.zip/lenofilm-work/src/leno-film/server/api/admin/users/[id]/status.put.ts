import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

const STATUSES = ['active', 'deleted'] as const
type UserStatus = typeof STATUSES[number]

function normalizeStatus(value: unknown): UserStatus {
  const status = String(value || '').trim()
  if (STATUSES.includes(status as UserStatus)) return status as UserStatus
  throw createError({ statusCode: 400, statusMessage: 'وضعیت معتبر نیست' })
}

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const body = await readBody(event)
  const status = normalizeStatus(body.status)
  const db = useDb()
  const [updated] = await db.update(users).set({ status }).where(eq(users.id, id)).returning()
  if (!updated) throw createError({ statusCode: 404, statusMessage: 'کاربر پیدا نشد' })
  return updated
})
