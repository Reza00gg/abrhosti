import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { and, desc, eq, ilike, or, sql } from 'drizzle-orm'

const TABS = ['all', 'active', 'inactive', 'deleted'] as const
type UserTab = typeof TABS[number]

function safeTab(value: unknown): UserTab {
  const tab = String(value || 'all')
  return TABS.includes(tab as UserTab) ? tab as UserTab : 'all'
}

function safeLimit(value: unknown, fallback = 15) {
  const n = Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(Math.max(Math.floor(n), 1), 100)
}

function safeOffset(value: unknown) {
  const n = Number(value)
  if (!Number.isFinite(n)) return 0
  return Math.max(Math.floor(n), 0)
}

const selectFields = {
  id: users.id,
  name: users.name,
  email: users.email,
  banned: users.banned,
  status: users.status,
  createdAt: users.createdAt,
  subscriptionExpiresAt: users.subscriptionExpiresAt,
}

export default defineEventHandler(async (event) => {
  const q = getQuery(event)
  const search = (q.q as string | undefined)?.trim()
  const tab = safeTab(q.tab)
  const limit = safeLimit(q.limit, 15)
  const offset = safeOffset(q.offset)
  const db = useDb()

  const tabWhere = tab === 'deleted'
    ? eq(users.status, 'deleted')
    : tab === 'active'
      ? and(eq(users.status, 'active'), eq(users.banned, false))
      : tab === 'inactive'
        ? and(eq(users.status, 'active'), eq(users.banned, true))
        : eq(users.status, 'active')
  const searchWhere = search ? or(ilike(users.name, `%${search}%`), ilike(users.email, `%${search}%`)) : undefined
  const where = searchWhere ? and(tabWhere, searchWhere) : tabWhere

  const [totalRow, allRow, activeRow, inactiveRow, deletedRow] = await Promise.all([
    db.select({ total: sql<number>`count(*)::int` }).from(users).where(where),
    db.select({ total: sql<number>`count(*)::int` }).from(users).where(eq(users.status, 'active')),
    db.select({ total: sql<number>`count(*)::int` }).from(users).where(and(eq(users.status, 'active'), eq(users.banned, false))),
    db.select({ total: sql<number>`count(*)::int` }).from(users).where(and(eq(users.status, 'active'), eq(users.banned, true))),
    db.select({ total: sql<number>`count(*)::int` }).from(users).where(eq(users.status, 'deleted')),
  ])

  const items = await db.select(selectFields).from(users)
    .where(where)
    .orderBy(desc(users.createdAt))
    .limit(limit)
    .offset(offset)

  return {
    items,
    total: Number(totalRow[0]?.total || 0),
    counts: {
      all: Number(allRow[0]?.total || 0),
      active: Number(activeRow[0]?.total || 0),
      inactive: Number(inactiveRow[0]?.total || 0),
      deleted: Number(deletedRow[0]?.total || 0),
    },
    limit,
    offset,
    tab,
  }
})
