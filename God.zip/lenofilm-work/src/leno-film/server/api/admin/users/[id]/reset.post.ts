import { useDb } from '~~/server/db'
import { subscriptionOrders, userNotifications, users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })

  const db = useDb()
  const [user] = await db.select({ id: users.id }).from(users).where(eq(users.id, id)).limit(1)
  if (!user) throw createError({ statusCode: 404, statusMessage: 'کاربر پیدا نشد' })

  await db.delete(subscriptionOrders).where(eq(subscriptionOrders.userId, id))
  await db.delete(userNotifications).where(eq(userNotifications.userId, id))
  const [updated] = await db.update(users).set({ subscriptionExpiresAt: null }).where(eq(users.id, id)).returning({
    id: users.id,
    subscriptionExpiresAt: users.subscriptionExpiresAt,
  })

  return { success: true, user: updated }
})
