import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { and, eq, ne, or } from 'drizzle-orm'
import { readUserAuthCookie } from '~~/server/utils/user-session'
import { normalizeIdentifier } from '~~/utils/identity'

function isPrimaryMobile(value: string) {
  return /^09\d{9}$/.test(String(value || ''))
}

export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای ویرایش حساب وارد شوید' })
  const body = await readBody(event)
  const name = String(body?.name || '').trim()
  if (!name) throw createError({ statusCode: 400, statusMessage: 'نام نمایشی را وارد کنید' })
  if (name.length > 60) throw createError({ statusCode: 400, statusMessage: 'نام نمایشی خیلی طولانی است' })

  const db = useDb()
  const [current] = await db.select().from(users).where(eq(users.id, session.id)).limit(1)
  if (!current || current.status === 'deleted') throw createError({ statusCode: 404, statusMessage: 'حساب کاربری پیدا نشد' })
  if (current.banned) throw createError({ statusCode: 403, statusMessage: 'شما از طرف مدیریت مسدود شده‌اید' })

  const patch: { name: string; contactEmail?: string } = { name }
  const rawContactEmail = String(body?.contactEmail || '').trim()

  if (isPrimaryMobile(current.email)) {
    if (!current.contactEmail && rawContactEmail) {
      const normalized = normalizeIdentifier(rawContactEmail)
      if (!normalized.ok || normalized.type !== 'email') {
        throw createError({ statusCode: 400, statusMessage: normalized.ok ? 'ایمیل معتبر وارد کنید' : normalized.message })
      }
      const [duplicate] = await db.select({ id: users.id }).from(users)
        .where(and(ne(users.id, current.id), or(eq(users.email, normalized.value), eq(users.contactEmail, normalized.value))))
        .limit(1)
      if (duplicate) throw createError({ statusCode: 409, statusMessage: 'این ایمیل قبلاً ثبت شده است' })
      patch.contactEmail = normalized.value
    }
  }

  const [updated] = await db.update(users).set(patch).where(eq(users.id, current.id)).returning({
    id: users.id,
    name: users.name,
    email: users.email,
    contactEmail: users.contactEmail,
    avatarUrl: users.avatarUrl,
    avatarMime: users.avatarMime,
    subscriptionExpiresAt: users.subscriptionExpiresAt,
    createdAt: users.createdAt,
  })

  return updated
})
