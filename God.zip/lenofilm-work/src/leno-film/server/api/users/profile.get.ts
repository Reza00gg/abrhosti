import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'
import { readUserAuthCookie } from '~~/server/utils/user-session'

export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای مشاهده حساب وارد شوید' })
  const db = useDb()
  const [user] = await db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    contactEmail: users.contactEmail,
    banned: users.banned,
    status: users.status,
    avatarUrl: users.avatarUrl,
    avatarMime: users.avatarMime,
    subscriptionExpiresAt: users.subscriptionExpiresAt,
    createdAt: users.createdAt,
  }).from(users).where(eq(users.id, session.id)).limit(1)
  if (!user || user.status === 'deleted') throw createError({ statusCode: 404, statusMessage: 'حساب کاربری پیدا نشد' })
  if (user.banned) throw createError({ statusCode: 403, statusMessage: 'شما از طرف مدیریت مسدود شده‌اید' })
  return user
})
