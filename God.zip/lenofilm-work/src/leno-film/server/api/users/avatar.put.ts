import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'
import { readUserAuthCookie } from '~~/server/utils/user-session'

const MAX_AVATAR_BYTES = 900 * 1024

function parseAvatar(value: unknown) {
  const avatarUrl = String(value || '').trim()

  if (/^\/api\/avatars\/(?:24|25)$/i.test(avatarUrl)) {
    return { avatarUrl, avatarMime: 'image/jpeg' }
  }

  if (/^\/avatars\/[a-z0-9-]+\.svg$/i.test(avatarUrl)) {
    return { avatarUrl, avatarMime: 'image/svg+xml' }
  }

  const match = avatarUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\s]+)$/)
  if (!match) {
    throw createError({ statusCode: 400, statusMessage: 'آواتار انتخاب‌شده معتبر نیست' })
  }

  const mime = match[1]
  const base64 = match[2].replace(/\s/g, '')
  const bytes = Buffer.byteLength(base64, 'base64')
  if (bytes > MAX_AVATAR_BYTES) {
    throw createError({ statusCode: 400, statusMessage: 'حجم تصویر پروفایل نباید بیشتر از ۹۰۰ کیلوبایت باشد' })
  }

  return { avatarUrl: `data:${mime};base64,${base64}`, avatarMime: mime }
}

export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای تغییر تصویر پروفایل وارد حساب شوید' })

  const body = await readBody(event)
  const avatar = parseAvatar(body?.avatarUrl)
  const db = useDb()

  const [user] = await db.select({ id: users.id, banned: users.banned, status: users.status }).from(users).where(eq(users.id, session.id)).limit(1)
  if (!user || user.status === 'deleted') throw createError({ statusCode: 404, statusMessage: 'حساب کاربری پیدا نشد' })
  if (user.banned) throw createError({ statusCode: 403, statusMessage: 'شما از طرف مدیریت مسدود شده‌اید' })

  const [updated] = await db.update(users).set({
    avatarUrl: avatar.avatarUrl,
    avatarMime: avatar.avatarMime,
    avatarUpdatedAt: new Date(),
  }).where(eq(users.id, session.id)).returning({
    id: users.id,
    name: users.name,
    email: users.email,
    contactEmail: users.contactEmail,
    avatarUrl: users.avatarUrl,
    avatarMime: users.avatarMime,
    subscriptionExpiresAt: users.subscriptionExpiresAt,
    createdAt: users.createdAt,
  })

  return updated
})
