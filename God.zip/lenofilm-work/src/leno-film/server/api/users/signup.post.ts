import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { hashPassword } from '~~/server/utils/password'
import { eq, or } from 'drizzle-orm'
import { normalizeIdentifier } from '~~/utils/identity'

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  if (!body.name?.trim()) {
    throw createError({ statusCode: 400, statusMessage: 'نام نمایشی الزامی است' })
  }
  const identity = normalizeIdentifier(String(body.email ?? ''))
  if (!identity.ok) {
    throw createError({ statusCode: 400, statusMessage: identity.message })
  }
  if (!body.password) {
    throw createError({ statusCode: 400, statusMessage: 'رمز عبور الزامی است' })
  }
  if (body.password.length < 6) {
    throw createError({ statusCode: 400, statusMessage: 'رمز عبور باید حداقل ۶ کاراکتر باشد' })
  }
  const db = useDb()
  const email = identity.value
  const existing = await db.select().from(users).where(or(eq(users.email, email), eq(users.contactEmail, email))).limit(1)
  if (existing.length > 0) {
    throw createError({ statusCode: 409, statusMessage: 'ساخت حساب با این شماره موبایل یا ایمیل امکان‌پذیر نیست' })
  }
  const [user] = await db.insert(users).values({
    name: body.name.trim(),
    email,
    passwordHash: hashPassword(body.password),
  }).returning()
  return { id: user.id, name: user.name, email: user.email, contactEmail: user.contactEmail, avatarUrl: user.avatarUrl, avatarMime: user.avatarMime, subscriptionExpiresAt: user.subscriptionExpiresAt, createdAt: user.createdAt }
})
