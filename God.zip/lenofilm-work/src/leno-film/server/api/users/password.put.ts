import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'
import { hashPassword, verifyPassword } from '~~/server/utils/password'
import { readUserAuthCookie } from '~~/server/utils/user-session'

export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای تغییر رمز عبور وارد شوید' })

  const body = await readBody(event)
  const currentPassword = String(body?.currentPassword || '')
  const newPassword = String(body?.newPassword || '')
  const confirmPassword = String(body?.confirmPassword || '')

  if (!currentPassword) throw createError({ statusCode: 400, statusMessage: 'رمز عبور فعلی را وارد کنید' })
  if (!newPassword) throw createError({ statusCode: 400, statusMessage: 'رمز عبور جدید را وارد کنید' })
  if (newPassword.length < 6) throw createError({ statusCode: 400, statusMessage: 'رمز عبور جدید باید حداقل ۶ کاراکتر باشد' })
  if (newPassword !== confirmPassword) throw createError({ statusCode: 400, statusMessage: 'رمز عبور جدید و تکرار آن یکسان نیستند' })

  const db = useDb()
  const [user] = await db.select().from(users).where(eq(users.id, session.id)).limit(1)
  if (!user || user.status === 'deleted') throw createError({ statusCode: 404, statusMessage: 'حساب کاربری پیدا نشد' })
  if (user.banned) throw createError({ statusCode: 403, statusMessage: 'شما از طرف مدیریت مسدود شده‌اید' })
  if (!verifyPassword(currentPassword, user.passwordHash)) {
    throw createError({ statusCode: 401, statusMessage: 'رمز عبور فعلی اشتباه است' })
  }
  if (verifyPassword(newPassword, user.passwordHash)) {
    throw createError({ statusCode: 400, statusMessage: 'رمز عبور جدید نمی‌تواند همان رمز عبور فعلی باشد' })
  }

  await db.update(users).set({ passwordHash: hashPassword(newPassword) }).where(eq(users.id, user.id))
  return { success: true }
})
