import { useDb } from '~~/server/db'
import { userNotifications } from '~~/server/db/schema'
import { sql } from 'drizzle-orm'
import { readUserAuthCookie } from '~~/server/utils/user-session'

export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای مشاهده اعلان‌ها وارد شوید' })
  const db = useDb()
  await db.update(userNotifications).set({ status: 'read', readAt: new Date() }).where(sql`${userNotifications.userId} = ${session.id} and ${userNotifications.status} = 'unread'`)
  return { success: true }
})
