import { useDb } from '~~/server/db'
import { userNotifications } from '~~/server/db/schema'
import { desc, eq, sql } from 'drizzle-orm'
import { readUserAuthCookie } from '~~/server/utils/user-session'

export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای مشاهده اعلان‌ها وارد شوید' })
  const db = useDb()
  const [unread] = await db.select({ total: sql<number>`count(*)::int` }).from(userNotifications).where(sql`${userNotifications.userId} = ${session.id} and ${userNotifications.status} = 'unread'`)
  const items = await db.select().from(userNotifications).where(eq(userNotifications.userId, session.id)).orderBy(desc(userNotifications.createdAt)).limit(50)
  return { unread: Number(unread?.total || 0), items }
})
