import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'
import { readUserAuthCookie } from '~~/server/utils/user-session'

export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای حذف تصویر پروفایل وارد حساب شوید' })

  const db = useDb()
  const [user] = await db.select({ id: users.id, banned: users.banned, status: users.status }).from(users).where(eq(users.id, session.id)).limit(1)
  if (!user || user.status === 'deleted') throw createError({ statusCode: 404, statusMessage: 'حساب کاربری پیدا نشد' })
  if (user.banned) throw createError({ statusCode: 403, statusMessage: 'شما از طرف مدیریت مسدود شده‌اید' })

  const [updated] = await db.update(users).set({
    avatarUrl: null,
    avatarMime: null,
    avatarUpdatedAt: new Date(),
  }).where(eq(users.id, session.id)).returning({
    id: users.id,
    name: users.name,
    email: users.email,
    contactEmail: users.contactEmail,
    avatarUrl: users.avatarUrl,
    avatarMime: users.avatarMime,
    subscriptionExpiresAt: users.subscriptionExpiresAt,
    createdAt: users.createdAt,
  })

  return updated
})
