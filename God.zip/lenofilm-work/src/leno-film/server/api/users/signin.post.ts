import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { verifyPassword } from '~~/server/utils/password'
import { eq, or } from 'drizzle-orm'
import { normalizeIdentifier } from '~~/utils/identity'

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  const identity = normalizeIdentifier(String(body.email ?? ''))
  if (!identity.ok) {
    throw createError({ statusCode: 400, statusMessage: identity.message })
  }
  if (!body.password) {
    throw createError({ statusCode: 400, statusMessage: 'رمز عبور را وارد کنید' })
  }
  const db = useDb()
  const email = identity.value
  const [user] = await db.select().from(users).where(or(eq(users.email, email), eq(users.contactEmail, email))).limit(1)
  if (!user || user.status === 'deleted') {
    throw createError({ statusCode: 404, statusMessage: 'حسابی با این شماره موبایل یا ایمیل وجود ندارد' })
  }
  if (user.banned) {
    throw createError({ statusCode: 403, statusMessage: 'شما از طرف مدیریت مسدود شده‌اید' })
  }
  if (!verifyPassword(body.password, user.passwordHash)) {
    throw createError({ statusCode: 401, statusMessage: 'رمز عبور اشتباه است' })
  }
  return { id: user.id, name: user.name, email: user.email, contactEmail: user.contactEmail, avatarUrl: user.avatarUrl, avatarMime: user.avatarMime, subscriptionExpiresAt: user.subscriptionExpiresAt, createdAt: user.createdAt }
})
