const avatarSources: Record<string, string> = {
  '24': 'aHR0cHM6Ly9tZWRpYS5sb29rYXBvLnRvcC9hdmF0YXJzLzI0LmpwZw==',
  '25': 'aHR0cHM6Ly9tZWRpYS5sb29rYXBvLnRvcC9hdmF0YXJzLzI1LmpwZw==',
}

export default defineEventHandler((event) => {
  const id = String(getRouterParam(event, 'id') || '')
  const encoded = avatarSources[id]
  if (!encoded) throw createError({ statusCode: 404, statusMessage: 'آواتار پیدا نشد' })

  const source = Buffer.from(encoded, 'base64').toString('utf8')
  setHeader(event, 'cache-control', 'public, max-age=86400, s-maxage=604800')
  return sendRedirect(event, source, 302)
})
