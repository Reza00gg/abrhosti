import crypto from 'node:crypto'
import { eq } from 'drizzle-orm'
import { useDb } from '~~/server/db'
import { subscriptionOrders, users } from '~~/server/db/schema'
import { addMonths } from '~~/server/utils/subscription'

function bridgeSecret() {
  return process.env.LENO_ABRAHOST_PAYMENT_SECRET || ''
}

function sign(raw: string) {
  return crypto.createHmac('sha256', bridgeSecret()).update(raw).digest('hex')
}

function safeEqual(a: string, b: string) {
  const left = Buffer.from(a || '', 'hex')
  const right = Buffer.from(b || '', 'hex')
  return left.length === right.length && left.length > 0 && crypto.timingSafeEqual(left, right)
}

export default defineEventHandler(async (event) => {
  const secret = bridgeSecret()
  if (!secret) throw createError({ statusCode: 500, statusMessage: 'کلید اتصال ابرهاست تنظیم نشده است' })

  const raw = await readRawBody(event, 'utf8')
  if (!raw) throw createError({ statusCode: 400, statusMessage: 'درخواست معتبر نیست' })
  const signature = getHeader(event, 'x-abrahost-signature') || ''
  if (!safeEqual(signature, sign(raw))) throw createError({ statusCode: 401, statusMessage: 'امضای ابرهاست معتبر نیست' })

  let body: any
  try { body = JSON.parse(raw) } catch { throw createError({ statusCode: 400, statusMessage: 'بدنه درخواست معتبر نیست' }) }

  const orderId = Number(body.orderId)
  const status = String(body.status || '')
  const amountToman = Number(body.amountToman)
  const authority = String(body.authority || '')
  const refId = String(body.refId || '')
  const message = String(body.message || '')

  if (!orderId || !Number.isFinite(orderId)) throw createError({ statusCode: 400, statusMessage: 'شناسه سفارش معتبر نیست' })
  if (!['paid', 'failed'].includes(status)) throw createError({ statusCode: 400, statusMessage: 'وضعیت پرداخت معتبر نیست' })

  const db = useDb()
  const [order] = await db.select().from(subscriptionOrders).where(eq(subscriptionOrders.id, orderId)).limit(1)
  if (!order) throw createError({ statusCode: 404, statusMessage: 'سفارش پیدا نشد' })
  if (Number(order.finalAmount) !== amountToman) throw createError({ statusCode: 409, statusMessage: 'مبلغ پرداخت با سفارش همخوانی ندارد' })
  if (order.authority && authority && order.authority !== authority) throw createError({ statusCode: 409, statusMessage: 'شناسه پرداخت با سفارش همخوانی ندارد' })
  if (order.status === 'paid') return { ok: true, alreadyPaid: true }

  if (status === 'failed') {
    await db.update(subscriptionOrders).set({
      status: 'failed',
      failureMessage: message || 'پرداخت ناموفق یا لغو شده است',
      verifyPayload: raw,
      updatedAt: new Date(),
    }).where(eq(subscriptionOrders.id, order.id))
    return { ok: true }
  }

  if (!authority || !refId) throw createError({ statusCode: 400, statusMessage: 'اطلاعات پرداخت کامل نیست' })
  const paidAt = new Date()
  const [user] = await db.select().from(users).where(eq(users.id, order.userId)).limit(1)
  if (!user || user.status === 'deleted' || user.banned) throw createError({ statusCode: 403, statusMessage: 'حساب کاربر معتبر نیست' })
  const base = user.subscriptionExpiresAt && new Date(user.subscriptionExpiresAt).getTime() > Date.now() ? new Date(user.subscriptionExpiresAt) : paidAt
  const subscriptionExpiresAt = addMonths(base, order.months)

  await db.update(subscriptionOrders).set({
    status: 'paid',
    authority,
    refId,
    paidAt,
    verifyPayload: raw,
    updatedAt: new Date(),
  }).where(eq(subscriptionOrders.id, order.id))
  await db.update(users).set({ subscriptionExpiresAt }).where(eq(users.id, order.userId))

  return { ok: true, subscriptionExpiresAt }
})
