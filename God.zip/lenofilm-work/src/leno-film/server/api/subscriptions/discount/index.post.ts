import { useDb } from '~~/server/db'
import { subscriptionDiscounts, subscriptionPlans } from '~~/server/db/schema'
import { and, eq } from 'drizzle-orm'

function normalizeCode(value: unknown) {
  return String(value || '').trim().toUpperCase()
}

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  const code = normalizeCode(body.code)
  const planId = Number(body.planId)
  if (!code) throw createError({ statusCode: 400, statusMessage: 'کد تخفیف را وارد کنید' })
  if (!planId || Number.isNaN(planId)) throw createError({ statusCode: 400, statusMessage: 'پلن معتبر نیست' })

  const db = useDb()
  const [plan] = await db.select().from(subscriptionPlans).where(and(eq(subscriptionPlans.id, planId), eq(subscriptionPlans.active, true))).limit(1)
  if (!plan) throw createError({ statusCode: 404, statusMessage: 'پلن پیدا نشد' })

  const [discount] = await db.select().from(subscriptionDiscounts).where(eq(subscriptionDiscounts.code, code)).limit(1)
  if (!discount || !discount.active) throw createError({ statusCode: 404, statusMessage: 'کد تخفیف معتبر نیست' })
  if (discount.planId && discount.planId !== planId) throw createError({ statusCode: 400, statusMessage: 'این کد برای پلن انتخابی نیست' })

  const base = Math.max(0, plan.price + plan.fee)
  const amount = discount.type === 'fixed'
    ? Math.min(base, discount.value)
    : Math.min(base, Math.floor(base * discount.value / 100))

  return { success: true, code: discount.code, type: discount.type, value: discount.value, amount }
})
