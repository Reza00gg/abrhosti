import { useDb } from '~~/server/db'
import { subscriptionPlans, subscriptionSettings } from '~~/server/db/schema'
import { asc, eq } from 'drizzle-orm'
import { planFinalPrice } from '~~/server/utils/subscription'

export default defineEventHandler(async () => {
  const db = useDb()
  const [settings] = await db.select({
    id: subscriptionSettings.id,
    rialEnabled: subscriptionSettings.rialEnabled,
    cardEnabled: subscriptionSettings.cardEnabled,
  }).from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1)
  const plans = await db.select().from(subscriptionPlans)
    .where(eq(subscriptionPlans.active, true))
    .orderBy(asc(subscriptionPlans.months), asc(subscriptionPlans.price))

  return {
    settings: settings || { rialEnabled: true, cardEnabled: false },
    plans: plans.map(plan => ({ ...plan, finalPrice: planFinalPrice(plan) })),
  }
})
