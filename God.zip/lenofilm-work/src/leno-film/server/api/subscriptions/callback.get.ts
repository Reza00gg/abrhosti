import { useDb } from '~~/server/db'
import { subscriptionOrders, subscriptionSettings, users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'
import { addMonths } from '~~/server/utils/subscription'
import { zarinpalVerifyPayment } from '~~/server/utils/zarinpal'

function merchantFor(settings: { zarinpalMerchant?: string | null; zarinpalSandbox?: boolean }) {
  if (settings.zarinpalMerchant) return settings.zarinpalMerchant
  if (settings.zarinpalSandbox) return '00000000-0000-0000-0000-000000000000'
  return ''
}
function resultUrl(event: any, id?: number, status = 'failed') {
  const origin = getRequestURL(event).origin
  return `${origin}/account/subscription?orderId=${id || ''}&payment=${status}`
}

export default defineEventHandler(async (event) => {
  const query = getQuery(event)
  const authority = String(query.Authority || query.authority || '')
  const status = String(query.Status || query.status || '')
  const db = useDb()
  if (!authority) return sendRedirect(event, resultUrl(event, undefined, 'failed'), 302)

  const [order] = await db.select().from(subscriptionOrders).where(eq(subscriptionOrders.authority, authority)).limit(1)
  if (!order) return sendRedirect(event, resultUrl(event, undefined, 'failed'), 302)
  if (order.status === 'paid') return sendRedirect(event, resultUrl(event, order.id, 'success'), 302)

  if (status !== 'OK') {
    await db.update(subscriptionOrders).set({ status: 'failed', failureMessage: `پرداخت ناموفق یا لغو شده. Status=${status}`, verifyPayload: JSON.stringify(query), updatedAt: new Date() }).where(eq(subscriptionOrders.id, order.id))
    return sendRedirect(event, resultUrl(event, order.id, 'failed'), 302)
  }

  const [settings] = await db.select().from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1)
  const merchantId = settings ? merchantFor(settings) : ''
  if (!merchantId) {
    await db.update(subscriptionOrders).set({ status: 'failed', failureMessage: 'مرچنت زرین‌پال تنظیم نشده است', updatedAt: new Date() }).where(eq(subscriptionOrders.id, order.id))
    return sendRedirect(event, resultUrl(event, order.id, 'failed'), 302)
  }

  const verify = await zarinpalVerifyPayment({ merchantId, amountToman: order.finalAmount, authority, sandbox: settings?.zarinpalSandbox })
  if (!verify.ok) {
    await db.update(subscriptionOrders).set({ status: 'failed', failureMessage: verify.message, verifyPayload: JSON.stringify({ callback: query, verify: verify.data }), updatedAt: new Date() }).where(eq(subscriptionOrders.id, order.id))
    return sendRedirect(event, resultUrl(event, order.id, 'failed'), 302)
  }

  const paidAt = new Date()
  const refId = String(verify.data?.data?.ref_id || '')
  const [user] = await db.select().from(users).where(eq(users.id, order.userId)).limit(1)
  const base = user?.subscriptionExpiresAt && new Date(user.subscriptionExpiresAt).getTime() > Date.now() ? new Date(user.subscriptionExpiresAt) : paidAt
  const subscriptionExpiresAt = addMonths(base, order.months)

  await db.update(subscriptionOrders).set({
    status: 'paid',
    refId,
    paidAt,
    verifyPayload: JSON.stringify({ callback: query, verify: verify.data }),
    updatedAt: new Date(),
  }).where(eq(subscriptionOrders.id, order.id))
  await db.update(users).set({ subscriptionExpiresAt }).where(eq(users.id, order.userId))

  return sendRedirect(event, resultUrl(event, order.id, 'success'), 302)
})
