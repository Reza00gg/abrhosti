import { useDb } from '~~/server/db'
import { subscriptionOrders } from '~~/server/db/schema'
import { desc, eq } from 'drizzle-orm'
import { readUserAuthCookie } from '~~/server/utils/user-session'

export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای مشاهده سوابق خرید وارد شوید' })
  const db = useDb()
  const items = await db.select().from(subscriptionOrders)
    .where(eq(subscriptionOrders.userId, session.id))
    .orderBy(desc(subscriptionOrders.createdAt))
    .limit(50)
  return { items }
})
