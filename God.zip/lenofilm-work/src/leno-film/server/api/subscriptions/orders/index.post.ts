import { useDb } from '~~/server/db'
import { subscriptionDiscounts, subscriptionOrders, subscriptionPlans, subscriptionSettings, users } from '~~/server/db/schema'
import crypto from 'node:crypto'
import { and, eq } from 'drizzle-orm'
import { readUserAuthCookie } from '~~/server/utils/user-session'
import { planBaseDiscountAmount, planFinalPrice } from '~~/server/utils/subscription'

function normalizeCode(value: unknown) { return String(value || '').trim().toUpperCase() }
function bridgeSecret() {
  return process.env.LENO_ABRAHOST_PAYMENT_SECRET || ''
}
function abrahostBaseUrl() {
  return (process.env.ABRAHOST_PAYMENT_BASE_URL || 'https://lnupro.sbs').replace(/\/$/, '')
}
function lenofilmBaseUrl(event: any) {
  return (process.env.LENOFILM_BASE_URL || getRequestURL(event).origin).replace(/\/$/, '')
}
function bridgeSignature(raw: string) {
  return crypto.createHmac('sha256', bridgeSecret()).update(raw).digest('hex')
}
async function createAbrahostPayment(payload: Record<string, unknown>) {
  const secret = bridgeSecret()
  if (!secret) throw createError({ statusCode: 500, statusMessage: 'کلید اتصال ابرهاست تنظیم نشده است' })
  const raw = JSON.stringify(payload)
  const response = await fetch(`${abrahostBaseUrl()}/api/lenofilm/subscriptions/start`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-leno-signature': bridgeSignature(raw) },
    body: raw,
  })
  const text = await response.text()
  let data: any = null
  try { data = text ? JSON.parse(text) : null } catch {}
  if (!response.ok || data?.ok === false) {
    const message = data?.error?.message || data?.message || text || 'ساخت پرداخت در ابرهاست انجام نشد'
    throw createError({ statusCode: response.status || 502, statusMessage: message })
  }
  return data?.data || data
}


export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای خرید اشتراک وارد شوید' })
  const body = await readBody(event)
  const planId = Number(body.planId)
  const discountCode = normalizeCode(body.discountCode)
  if (!planId || Number.isNaN(planId)) throw createError({ statusCode: 400, statusMessage: 'پلن معتبر نیست' })

  const db = useDb()
  const [user] = await db.select().from(users).where(eq(users.id, session.id)).limit(1)
  if (!user || user.status === 'deleted') throw createError({ statusCode: 404, statusMessage: 'حساب کاربری پیدا نشد' })
  if (user.banned) throw createError({ statusCode: 403, statusMessage: 'شما از طرف مدیریت مسدود شده‌اید' })

  const [settings] = await db.select().from(subscriptionSettings).where(eq(subscriptionSettings.id, 1)).limit(1)
  if (!settings?.rialEnabled) throw createError({ statusCode: 400, statusMessage: 'درگاه ریالی غیرفعال است' })

  const [plan] = await db.select().from(subscriptionPlans).where(and(eq(subscriptionPlans.id, planId), eq(subscriptionPlans.active, true))).limit(1)
  if (!plan) throw createError({ statusCode: 404, statusMessage: 'پلن پیدا نشد' })

  const basePrice = Number(plan.price)
  const fee = Number(plan.fee || 0)
  const planDiscountAmount = planBaseDiscountAmount(plan)
  let couponDiscountAmount = 0
  let couponCode: string | null = null
  if (discountCode) {
    const [discount] = await db.select().from(subscriptionDiscounts).where(eq(subscriptionDiscounts.code, discountCode)).limit(1)
    if (!discount || !discount.active) throw createError({ statusCode: 404, statusMessage: 'کد تخفیف معتبر نیست' })
    if (discount.planId && discount.planId !== plan.id) throw createError({ statusCode: 400, statusMessage: 'این کد برای پلن انتخابی نیست' })
    const afterPlanDiscount = planFinalPrice(plan)
    couponDiscountAmount = discount.type === 'fixed' ? Math.min(afterPlanDiscount, discount.value) : Math.min(afterPlanDiscount, Math.floor(afterPlanDiscount * discount.value / 100))
    couponCode = discount.code
  }
  const finalAmount = Math.max(0, planFinalPrice(plan) - couponDiscountAmount)
  if (finalAmount < 1000) throw createError({ statusCode: 400, statusMessage: 'مبلغ پرداخت معتبر نیست' })

  const expiresAt = new Date(Date.now() + 2 * 60 * 60 * 1000)
  const [order] = await db.insert(subscriptionOrders).values({
    userId: user.id,
    planId: plan.id,
    planTitle: plan.title,
    months: plan.months,
    basePrice,
    fee,
    planDiscountAmount,
    couponCode,
    couponDiscountAmount,
    finalAmount,
    status: 'pending',
    gateway: 'zarinpal',
    expiresAt,
  }).returning()

  const publicBase = lenofilmBaseUrl(event)
  const bridgePayload = {
    orderId: order.id,
    amountToman: finalAmount,
    title: `اشتراک ${plan.title} لنوفیلم`,
    description: `خرید اشتراک ${plan.title} لنوفیلم`,
    userEmail: user.contactEmail || (user.email.includes('@') ? user.email : undefined),
    userMobile: /^09\d{9}$/.test(user.email) ? user.email : undefined,
    notifyUrl: `${publicBase}/api/subscriptions/abrahost-callback`,
    returnSuccessUrl: `${publicBase}/account/subscription?orderId=${order.id}&payment=success`,
    returnFailedUrl: `${publicBase}/account/subscription?orderId=${order.id}&payment=failed`,
  }

  try {
    const bridge = await createAbrahostPayment(bridgePayload)
    const authority = String(bridge.authority || '')
    const gatewayUrl = String(bridge.gatewayUrl || '')
    if (!gatewayUrl) throw createError({ statusCode: 502, statusMessage: 'لینک درگاه از ابرهاست دریافت نشد' })
    await db.update(subscriptionOrders).set({
      authority: authority || null,
      requestPayload: JSON.stringify({ bridge: { paymentId: bridge.paymentId, authority, gatewayUrl }, payload: bridgePayload }),
      updatedAt: new Date(),
    }).where(eq(subscriptionOrders.id, order.id))
    return { orderId: order.id, gatewayUrl }
  } catch (err: any) {
    const message = err?.data?.statusMessage || err?.statusMessage || err?.message || 'شروع پرداخت انجام نشد'
    await db.update(subscriptionOrders).set({ status: 'failed', failureMessage: message, requestPayload: JSON.stringify({ bridgePayload, error: message }), updatedAt: new Date() }).where(eq(subscriptionOrders.id, order.id))
    throw createError({ statusCode: err?.statusCode || 502, statusMessage: message })
  }
})
