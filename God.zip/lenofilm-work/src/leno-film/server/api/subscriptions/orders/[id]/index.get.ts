import { useDb } from '~~/server/db'
import { subscriptionOrders, users } from '~~/server/db/schema'
import { and, eq } from 'drizzle-orm'
import { readUserAuthCookie } from '~~/server/utils/user-session'

export default defineEventHandler(async (event) => {
  const session = readUserAuthCookie(event)
  if (!session) throw createError({ statusCode: 401, statusMessage: 'برای مشاهده سفارش وارد شوید' })
  const id = Number(getRouterParam(event, 'id'))
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const db = useDb()
  const [order] = await db.select().from(subscriptionOrders).where(and(eq(subscriptionOrders.id, id), eq(subscriptionOrders.userId, session.id))).limit(1)
  if (!order) throw createError({ statusCode: 404, statusMessage: 'سفارش پیدا نشد' })
  const [user] = await db.select({ subscriptionExpiresAt: users.subscriptionExpiresAt }).from(users).where(eq(users.id, session.id)).limit(1)
  return { order, subscriptionExpiresAt: user?.subscriptionExpiresAt || null }
})
