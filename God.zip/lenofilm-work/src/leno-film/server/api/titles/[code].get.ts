import { useDb } from '~~/server/db'
import { movies, series } from '~~/server/db/schema'
import { eq, and } from 'drizzle-orm'

function imageUrl(kind: 'movies' | 'series', id: number, value: string, field: 'poster' | 'cover', createdAt: Date | string) {
  if (!value) return ''
  if (value.startsWith('data:image/')) {
    const version = new Date(createdAt).getTime() || Date.now()
    return `/api/${kind}/${id}/${field}?v=${version}`
  }
  return value
}

export default defineEventHandler(async (event) => {
  const code = Number(getRouterParam(event, 'code'))
  if (!Number.isFinite(code) || code < 1) {
    throw createError({ statusCode: 404, statusMessage: 'عنوان پیدا نشد' })
  }

  const db = useDb()
  const [movie] = await db.select().from(movies).where(and(eq(movies.titleCode, code), eq(movies.status, 'active'))).limit(1)
  if (movie) {
    return {
      type: 'movie',
      id: movie.id,
      titleCode: movie.titleCode,
      titleFa: movie.titleFa,
      titleEn: movie.titleEn,
      year: movie.year,
      releaseDate: movie.releaseDate,
      rating: movie.rating,
      duration: movie.duration,
      durationLabel: `${movie.duration} دقیقه`,
      description: movie.description,
      posterUrl: imageUrl('movies', movie.id, movie.posterUrl, 'poster', movie.createdAt),
      coverUrl: imageUrl('movies', movie.id, movie.coverUrl, 'cover', movie.createdAt),
    }
  }

  const [row] = await db.select().from(series).where(and(eq(series.titleCode, code), eq(series.status, 'active'))).limit(1)
  if (row) {
    return {
      type: 'series',
      id: row.id,
      titleCode: row.titleCode,
      titleFa: row.titleFa,
      titleEn: row.titleEn,
      year: row.year,
      releaseDate: row.releaseDate,
      rating: row.rating,
      duration: 0,
      durationLabel: `${row.seasons} فصل | ${row.episodes} قسمت`,
      seasons: row.seasons,
      episodes: row.episodes,
      description: row.description,
      posterUrl: imageUrl('series', row.id, row.posterUrl, 'poster', row.createdAt),
      coverUrl: imageUrl('series', row.id, row.coverUrl, 'cover', row.createdAt),
    }
  }

  throw createError({ statusCode: 404, statusMessage: 'عنوان پیدا نشد' })
})
