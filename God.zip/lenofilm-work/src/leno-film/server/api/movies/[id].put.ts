import { useDb } from '~~/server/db'
import { movies } from '~~/server/db/schema'

function normalizeImageSource(value: unknown) {
  const source = String(value || '').trim()
  if (!source) return ''
  if (source.startsWith('data:image/')) return source
  if (/^https?:\/\//i.test(source)) return source
  throw createError({ statusCode: 400, statusMessage: 'آدرس یا فایل عکس معتبر نیست' })
}
import { eq } from 'drizzle-orm'
import { normalizeReleaseDate, releaseYear } from '~~/server/utils/release-date'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  const body = await readBody(event)
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const releaseDate = normalizeReleaseDate(body.releaseDate, body.year)
  const year = releaseYear(releaseDate)
  const db = useDb()
  const [updated] = await db.update(movies).set({
    titleFa: String(body.titleFa),
    titleEn: String(body.titleEn),
    duration: Number(body.duration),
    year,
    releaseDate,
    rating: Number(body.rating),
    posterUrl: normalizeImageSource(body.posterUrl),
    coverUrl: normalizeImageSource(body.coverUrl),
    description: String(body.description || ''),
  }).where(eq(movies.id, id)).returning()
  if (!updated) throw createError({ statusCode: 404, statusMessage: 'فیلم پیدا نشد' })
  return updated
})
