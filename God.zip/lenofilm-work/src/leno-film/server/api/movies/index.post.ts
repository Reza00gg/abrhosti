import { useDb } from '~~/server/db'
import { movies } from '~~/server/db/schema'
import { normalizeReleaseDate, releaseYear } from '~~/server/utils/release-date'
import { nextTitleCode } from '~~/server/utils/title-code'

function normalizeImageSource(value: unknown) {
  const source = String(value || '').trim()
  if (!source) return ''
  if (source.startsWith('data:image/')) return source
  if (/^https?:\/\//i.test(source)) return source
  throw createError({ statusCode: 400, statusMessage: 'آدرس یا فایل عکس معتبر نیست' })
}

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  if (!body.titleFa || !body.titleEn || !body.duration || !body.year || body.rating == null) {
    throw createError({ statusCode: 400, statusMessage: 'اطلاعات فیلم ناقص است' })
  }
  const releaseDate = normalizeReleaseDate(body.releaseDate, body.year)
  const year = releaseYear(releaseDate)
  const db = useDb()
  const titleCode = await nextTitleCode(db)
  const [movie] = await db.insert(movies).values({
    titleCode,
    titleFa: String(body.titleFa),
    titleEn: String(body.titleEn),
    duration: Number(body.duration),
    year,
    releaseDate,
    rating: Number(body.rating),
    posterUrl: normalizeImageSource(body.posterUrl),
    coverUrl: normalizeImageSource(body.coverUrl),
    description: String(body.description || ''),
  }).returning()
  return movie
})
