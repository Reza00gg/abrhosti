import { useDb } from '~~/server/db'
import { movies } from '~~/server/db/schema'
import { and, desc, eq, ilike, or, sql } from 'drizzle-orm'

function publicPosterUrl(id: number, posterUrl: string, createdAt: Date | string) {
  if (!posterUrl) return ''
  if (posterUrl.startsWith('data:image/')) {
    const version = new Date(createdAt).getTime() || Date.now()
    return `/api/movies/${id}/poster?v=${version}`
  }
  return posterUrl
}

function safeLimit(value: unknown, fallback: number) {
  const n = Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(Math.max(Math.floor(n), 1), 60)
}

function safeOffset(value: unknown) {
  const n = Number(value)
  if (!Number.isFinite(n)) return 0
  return Math.max(Math.floor(n), 0)
}

export default defineEventHandler(async (event) => {
  const q = getQuery(event)
  const search = (q.q as string | undefined)?.trim()
  const limit = safeLimit(q.limit, search ? 50 : 20)
  const offset = safeOffset(q.offset)
  const db = useDb()
  const releaseOrder = sql`coalesce(${movies.releaseDate}, make_date(${movies.year}, 1, 1))`

  const selectFields = {
    id: movies.id,
    titleCode: movies.titleCode,
    titleFa: movies.titleFa,
    titleEn: movies.titleEn,
    duration: movies.duration,
    year: movies.year,
    releaseDate: movies.releaseDate,
    rating: movies.rating,
    posterUrl: movies.posterUrl,
    createdAt: movies.createdAt,
  }

  const activeWhere = eq(movies.status, 'active')
  const searchWhere = search ? or(ilike(movies.titleFa, `%${search}%`), ilike(movies.titleEn, `%${search}%`)) : undefined
  const rows = searchWhere
    ? await db.select(selectFields).from(movies)
      .where(and(activeWhere, searchWhere))
      .orderBy(desc(releaseOrder), desc(movies.createdAt))
      .limit(limit)
      .offset(offset)
    : await db.select(selectFields).from(movies).where(activeWhere).orderBy(desc(releaseOrder), desc(movies.createdAt)).limit(limit).offset(offset)

  return rows.map((movie) => ({
    ...movie,
    posterUrl: publicPosterUrl(movie.id, movie.posterUrl, movie.createdAt),
    coverUrl: '',
    description: '',
  }))
})
