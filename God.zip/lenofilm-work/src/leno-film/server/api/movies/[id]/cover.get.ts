import { useDb } from '~~/server/db'
import { movies } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'
import { mediaImageResponse } from '~~/server/utils/media-image'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || Number.isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const db = useDb()
  const [movie] = await db.select({ coverUrl: movies.coverUrl, createdAt: movies.createdAt }).from(movies).where(eq(movies.id, id)).limit(1)
  return mediaImageResponse(event, movie?.coverUrl || '', `movie-cover-${id}`, movie?.createdAt || new Date())
})
