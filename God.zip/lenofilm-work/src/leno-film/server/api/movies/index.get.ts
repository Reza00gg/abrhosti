import { useDb } from '~~/server/db'
import { movies } from '~~/server/db/schema'
import { and, desc, eq, ilike, or, sql } from 'drizzle-orm'

const STATUSES = ['active', 'archived', 'deleted'] as const
type MediaStatus = typeof STATUSES[number]

function safeStatus(value: unknown): MediaStatus {
  const status = String(value || 'active')
  return STATUSES.includes(status as MediaStatus) ? status as MediaStatus : 'active'
}

function safeLimit(value: unknown, fallback = 15) {
  const n = Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(Math.max(Math.floor(n), 1), 100)
}

function safeOffset(value: unknown) {
  const n = Number(value)
  if (!Number.isFinite(n)) return 0
  return Math.max(Math.floor(n), 0)
}

export default defineEventHandler(async (event) => {
  const q = getQuery(event)
  const search = (q.q as string | undefined)?.trim()
  const status = safeStatus(q.status)
  const limit = safeLimit(q.limit, 15)
  const offset = safeOffset(q.offset)
  const db = useDb()
  const searchWhere = search ? or(ilike(movies.titleFa, `%${search}%`), ilike(movies.titleEn, `%${search}%`)) : undefined
  const where = searchWhere ? and(eq(movies.status, status), searchWhere) : eq(movies.status, status)

  const [totalRow, activeRow, archivedRow, deletedRow] = await Promise.all([
    db.select({ total: sql<number>`count(*)::int` }).from(movies).where(where),
    db.select({ total: sql<number>`count(*)::int` }).from(movies).where(eq(movies.status, 'active')),
    db.select({ total: sql<number>`count(*)::int` }).from(movies).where(eq(movies.status, 'archived')),
    db.select({ total: sql<number>`count(*)::int` }).from(movies).where(eq(movies.status, 'deleted')),
  ])

  const items = await db.select().from(movies)
    .where(where)
    .orderBy(desc(movies.createdAt))
    .limit(limit)
    .offset(offset)

  return {
    items,
    total: Number(totalRow[0]?.total || 0),
    counts: {
      active: Number(activeRow[0]?.total || 0),
      archived: Number(archivedRow[0]?.total || 0),
      deleted: Number(deletedRow[0]?.total || 0),
    },
    limit,
    offset,
    status,
  }
})
