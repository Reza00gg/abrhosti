<template>
  <div class="min-h-screen">
    <AdminHeader />
    <main class="pt-[60px] min-h-screen pb-10">
      <div class="px-4 sm:px-6 py-6 max-w-6xl mx-auto">
        <div class="flex items-center justify-between mb-5">
          <div>
            <h1 class="text-[18px] font-semibold tracking-tight text-[#fafafa]">سریال ها</h1>
            <p class="mt-1 text-[11px] text-[#71717a]">مدیریت سریال‌های سایت</p>
          </div>
          <button v-wave="{ color: 'rgba(0,0,0,0.12)' }" @click="openAddForm" class="flex items-center gap-2 h-10 px-4 rounded-xl bg-[#fafafa] text-[#0a0a0a] text-[13px] font-medium hover:bg-[#e4e4e7] transition-colors">
            <Icon icon="lucide:plus" class="text-[18px]" />
            <span>افزودن سریال</span>
          </button>
        </div>

        <div class="mb-5 grid grid-cols-3 overflow-hidden rounded-xl border border-[#1f1f1f] bg-[#0a0a0a] p-1">
          <button
            v-for="tab in tabs"
            :key="tab.status"
            v-wave
            type="button"
            @click="selectStatus(tab.status)"
            class="flex h-9 items-center justify-center gap-1.5 rounded-lg text-[12px] font-medium transition-colors"
            :class="currentStatus === tab.status ? 'bg-[#18181b] text-[#fafafa]' : 'text-[#71717a] hover:text-[#fafafa]'"
          >
            <span>{{ tab.label }}</span>
            <span class="rounded-full bg-[#27272a] px-1.5 py-0.5 text-[10px] text-[#a1a1aa]">{{ tab.count }}</span>
          </button>
        </div>

        <div class="mb-5">
          <div class="relative">
            <Icon icon="lucide:search" class="absolute right-3 top-1/2 -translate-y-1/2 text-[14px] text-[#71717a] pointer-events-none" />
            <input v-model="searchModel" type="text" placeholder="جستجو..." class="w-full h-10 ps-9 pe-3 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
          </div>
        </div>
        <div v-if="loading && seriesItems.length === 0" class="text-center py-12">
          <Icon icon="lucide:loader-2" class="text-[32px] text-[#52525b] mx-auto animate-spin" />
        </div>
        <div v-else-if="seriesItems.length === 0" class="text-center py-16">
          <Icon icon="lucide:monitor-play" class="text-[36px] text-[#52525b] mx-auto" />
          <p class="mt-3 text-[14px] text-[#71717a]">{{ searchModel ? 'نتیجه‌ای یافت نشد' : emptyText }}</p>
        </div>
        <ul v-else class="space-y-2">
          <li v-for="item in seriesItems" :key="item.id" class="p-3.5 rounded-xl bg-[#18181b] border border-[#1f1f1f] flex items-center gap-3.5">
            <div class="w-10 h-14 rounded-md overflow-hidden bg-[#0a0a0a] shrink-0 flex items-center justify-center">
              <img v-if="item.posterUrl" :src="item.posterUrl" :alt="item.titleFa" draggable="false" class="w-full h-full object-cover select-none pointer-events-none" @error="(e: any) => e.target.style.display = 'none'" />
              <Icon v-else icon="lucide:monitor-play" class="text-[18px] text-[#52525b]" />
            </div>
            <div class="flex-1 min-w-0">
              <h3 class="text-[13px] font-semibold text-[#fafafa] truncate">{{ item.titleFa }}</h3>
              <p class="text-[11px] text-[#71717a] truncate" dir="ltr">{{ item.titleEn }}</p>
              <div class="mt-1 flex items-center gap-2.5 text-[10px] text-[#52525b]">
                <span class="flex items-center gap-1"><Icon icon="lucide:star" class="text-[11px] text-yellow-400" /><span class="text-[#fafafa] font-medium">{{ item.rating.toFixed(1) }}</span></span>
                <span>{{ item.year }}</span>
                <span>{{ item.seasons }} فصل</span>
                <span>{{ item.episodes }} قسمت</span>
              </div>
            </div>
            <div class="flex items-center gap-1 shrink-0">
              <button v-if="currentStatus !== 'deleted'" v-wave @click="openEditForm(item)" class="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] text-[#a1a1aa] hover:text-[#fafafa] transition-colors" title="ویرایش"><Icon icon="lucide:pencil" class="text-[15px]" /></button>
              <button v-if="currentStatus !== 'deleted'" v-wave @click="confirmDelete(item)" class="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] text-[#a1a1aa] hover:text-[#ef4444] transition-colors" title="حذف"><Icon icon="lucide:trash-2" class="text-[15px]" /></button>
              <AdminFeaturedMenu media-type="series" :media-id="item.id" :status="currentStatus" :is-featured="featuredKeys.has(`series-${item.id}`)" @changed="onFeaturedChanged" @action="handleMenuAction(item, $event.action)" />
            </div>
          </li>
        </ul>

        <div v-if="totalPages > 1" class="mt-6 flex items-center justify-center gap-2">
          <button v-wave @click="prevPage" :disabled="page === 1" class="flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[12px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
            <Icon icon="lucide:chevron-right" class="text-[16px]" />
            قبلی
          </button>
          <span class="text-[12px] text-[#71717a] px-3">صفحه {{ page }} از {{ totalPages }}</span>
          <button v-wave @click="nextPage" :disabled="page === totalPages" class="flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[12px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
            بعدی
            <Icon icon="lucide:chevron-left" class="text-[16px]" />
          </button>
        </div>
      </div>
    </main>
    <AdminDrawer />
    <SeriesForm v-model="formOpen" :series="editingSeries" @saved="onSeriesSaved" />
  </div>
</template>

<script setup lang="ts">
import type { Series } from '~~/server/db/schema'
type MediaStatus = 'active' | 'archived' | 'deleted'
type MenuAction = 'archive' | 'restore' | 'delete' | 'permanent-delete'
definePageMeta({ layout: 'admin', middleware: 'admin-auth' })
const toast = useToastStore()
const adminStore = useAdminPanelStore()
const state = computed(() => adminStore.media.series)
const seriesItems = computed(() => state.value.items as Series[])
const loading = computed(() => state.value.loading)
const page = computed(() => state.value.page)
const totalPages = computed(() => Math.max(1, Math.ceil(state.value.total / 15)))
const currentStatus = computed(() => state.value.status)
const tabs = computed(() => [
  { status: 'active' as MediaStatus, label: 'سریال ها', count: state.value.counts.active },
  { status: 'archived' as MediaStatus, label: 'آرشیو شده', count: state.value.counts.archived },
  { status: 'deleted' as MediaStatus, label: 'حذف شده', count: state.value.counts.deleted },
])
const emptyText = computed(() => currentStatus.value === 'archived' ? 'سریال آرشیو شده‌ای وجود ندارد' : currentStatus.value === 'deleted' ? 'سریال حذف شده‌ای وجود ندارد' : 'هنوز سریالی اضافه نشده')
const searchModel = computed({
  get: () => state.value.search,
  set: (value: string) => {
    adminStore.setMediaSearch('series', value)
    scheduleSearchFetch()
  }
})

const formOpen = ref(false)
const editingSeries = ref<Series | null>(null)
const featuredKeys = ref(new Set<string>())
let searchTimer: ReturnType<typeof setTimeout> | null = null

function scheduleSearchFetch() {
  if (searchTimer) clearTimeout(searchTimer)
  searchTimer = setTimeout(() => adminStore.fetchMedia('series', true), 180)
}

async function selectStatus(status: MediaStatus) {
  adminStore.setMediaStatus('series', status)
  await adminStore.fetchMedia('series')
}

async function fetchFeatured() {
  try {
    const rows = await $fetch<Array<{ mediaType: string; mediaId: number }>>('/api/admin/featured')
    featuredKeys.value = new Set(rows.map(item => `${item.mediaType}-${item.mediaId}`))
  } catch { featuredKeys.value = new Set() }
}

function onFeaturedChanged(payload: { mediaType: 'movie' | 'series'; mediaId: number; featured: boolean }) {
  const next = new Set(featuredKeys.value)
  const key = `${payload.mediaType}-${payload.mediaId}`
  if (payload.featured) next.add(key)
  else next.delete(key)
  featuredKeys.value = next
}

function openAddForm() { editingSeries.value = null; formOpen.value = true }
function openEditForm(item: Series) { editingSeries.value = item; formOpen.value = true }

async function onSeriesSaved() {
  adminStore.clearMediaCache('series')
  adminStore.setMediaStatus('series', 'active')
  await adminStore.fetchMedia('series', true)
}

async function setSeriesStatus(item: Series, status: MediaStatus, message: string) {
  const updated = await $fetch<Series>(`/api/series/${item.id}/status`, { method: 'PUT', body: { status } })
  adminStore.changeMediaStatusLocal('series', item, status)
  if (status !== 'active') onFeaturedChanged({ mediaType: 'series', mediaId: item.id, featured: false })
  toast.success(message)
  return updated
}

async function confirmDelete(item: Series) {
  if (!confirm(`آیا از حذف «${item.titleFa}» مطمئن هستید؟`)) return
  try { await setSeriesStatus(item, 'deleted', 'سریال به حذف شده‌ها منتقل شد') }
  catch { toast.error('خطا در حذف سریال') }
}

async function handleMenuAction(item: Series, action: MenuAction) {
  try {
    if (action === 'archive') return await setSeriesStatus(item, 'archived', 'سریال آرشیو شد')
    if (action === 'restore') return await setSeriesStatus(item, 'active', 'سریال بازیابی شد')
    if (action === 'delete') return await setSeriesStatus(item, 'deleted', 'سریال به حذف شده‌ها منتقل شد')
    if (action === 'permanent-delete') {
      if (!confirm(`«${item.titleFa}» برای همیشه از پایگاه داده حذف شود؟`)) return
      await $fetch(`/api/series/${item.id}`, { method: 'DELETE', params: { permanent: 1 } })
      adminStore.removeMediaPermanentLocal('series', item)
      onFeaturedChanged({ mediaType: 'series', mediaId: item.id, featured: false })
      toast.success('سریال کامل حذف شد')
    }
  } catch { toast.error('خطا در انجام عملیات') }
}

function prevPage() { if (page.value > 1) { adminStore.setMediaPage('series', page.value - 1); adminStore.fetchMedia('series') } }
function nextPage() { if (page.value < totalPages.value) { adminStore.setMediaPage('series', page.value + 1); adminStore.fetchMedia('series') } }

onMounted(() => { if (!state.value.loaded) adminStore.fetchMedia('series'); fetchFeatured() })
onBeforeUnmount(() => { if (searchTimer) clearTimeout(searchTimer) })
</script>
