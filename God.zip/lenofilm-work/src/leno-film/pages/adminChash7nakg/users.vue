<template>
  <div class="min-h-screen">
    <AdminHeader />
    <main class="pt-[60px] min-h-screen pb-10">
      <div class="px-4 sm:px-6 py-6 max-w-6xl mx-auto">
        <div class="flex items-center justify-between mb-5">
          <div>
            <h1 class="text-[18px] font-semibold tracking-tight text-[#fafafa]">کاربران</h1>
            <p class="mt-1 text-[11px] text-[#71717a]">مدیریت کاربران سایت</p>
          </div>
          <div class="text-[11px] text-[#71717a]">{{ total }} کاربر</div>
        </div>

        <div class="mb-5 grid grid-cols-4 overflow-hidden rounded-xl border border-[#1f1f1f] bg-[#0a0a0a] p-1">
          <button
            v-for="tab in tabs"
            :key="tab.tab"
            v-wave
            type="button"
            @click="selectTab(tab.tab)"
            class="flex h-9 items-center justify-center gap-1 rounded-lg text-[11px] font-medium transition-colors sm:gap-1.5 sm:text-[12px]"
            :class="currentTab === tab.tab ? 'bg-[#18181b] text-[#fafafa]' : 'text-[#71717a] hover:text-[#fafafa]'"
          >
            <span class="truncate">{{ tab.label }}</span>
            <span class="rounded-full bg-[#27272a] px-1.5 py-0.5 text-[10px] text-[#a1a1aa]">{{ tab.count }}</span>
          </button>
        </div>

        <div class="mb-5">
          <div class="relative">
            <Icon icon="lucide:search" class="absolute right-3 top-1/2 -translate-y-1/2 text-[14px] text-[#71717a] pointer-events-none" />
            <input v-model="searchModel" type="text" placeholder="جستجو..." class="w-full h-10 ps-9 pe-3 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
          </div>
        </div>

        <div v-if="loading && users.length === 0" class="text-center py-12">
          <Icon icon="lucide:loader-2" class="text-[32px] text-[#52525b] mx-auto animate-spin" />
        </div>

        <div v-else-if="users.length === 0" class="text-center py-16">
          <Icon icon="lucide:users" class="text-[36px] text-[#52525b] mx-auto" />
          <p class="mt-3 text-[14px] text-[#71717a]">{{ searchModel ? 'نتیجه‌ای یافت نشد' : emptyText }}</p>
        </div>

        <ul v-else class="space-y-2">
          <li v-for="u in users" :key="u.id" class="p-3.5 rounded-xl bg-[#18181b] border border-[#1f1f1f] flex items-center gap-3.5">
            <div class="w-10 h-10 rounded-full bg-[#0a0a0a] border border-[#1f1f1f] flex items-center justify-center shrink-0">
              <Icon icon="lucide:user" class="text-[18px] text-[#52525b]" />
            </div>

            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2">
                <h3 class="text-[13px] font-semibold text-[#fafafa] truncate">{{ u.name }}</h3>
                <span v-if="u.status === 'deleted'" class="text-[10px] px-1.5 py-0.5 rounded bg-[#ef4444]/15 text-[#ef4444] border border-[#ef4444]/20">حذف شده</span>
                <span v-else-if="u.banned" class="text-[10px] px-1.5 py-0.5 rounded bg-[#f59e0b]/15 text-[#f59e0b] border border-[#f59e0b]/20">غیرفعال</span>
                <span v-else class="text-[10px] px-1.5 py-0.5 rounded bg-[#22c55e]/15 text-[#22c55e] border border-[#22c55e]/20">فعال</span>
              </div>
              <p class="text-[11px] text-[#71717a] truncate" dir="ltr">{{ u.email }}</p>
              <div class="mt-1 flex flex-wrap items-center gap-1.5">
                <p class="text-[10px] text-[#52525b]">عضو از {{ formatDate(u.createdAt) }}</p>
                <span class="rounded-full px-1.5 py-0.5 text-[10px]" :class="hasSubscription(u) ? 'bg-[#22c55e]/15 text-[#22c55e]' : 'bg-[#27272a] text-[#71717a]'">
                  {{ hasSubscription(u) ? 'اشتراک فعال' : 'بدون اشتراک' }}
                </span>
              </div>
            </div>

            <div class="flex items-center gap-1 shrink-0">
              <AdminUserMenu :user="u" :tab="currentTab" @action="handleUserAction" />
            </div>
          </li>
        </ul>

        <div v-if="totalPages > 1" class="mt-6 flex items-center justify-center gap-2">
          <button v-wave @click="prevPage" :disabled="page === 1"
            class="flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[12px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
            <Icon icon="lucide:chevron-right" class="text-[16px]" />
            قبلی
          </button>
          <span class="text-[12px] text-[#71717a] px-3">صفحه {{ page }} از {{ totalPages }}</span>
          <button v-wave @click="nextPage" :disabled="page === totalPages"
            class="flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[12px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
            بعدی
            <Icon icon="lucide:chevron-left" class="text-[16px]" />
          </button>
        </div>
      </div>
    </main>
    <AdminDrawer />
  </div>
</template>

<script setup lang="ts">
type UserTab = 'all' | 'active' | 'inactive' | 'deleted'
type UserAction = 'ban' | 'unban' | 'reset' | 'delete' | 'restore' | 'permanent-delete'
interface AdminUser {
  id: number
  name: string
  email: string
  banned: boolean
  status?: 'active' | 'deleted'
  subscriptionExpiresAt?: string | null
  createdAt: string
}

definePageMeta({ layout: 'admin', middleware: 'admin-auth' })
const toast = useToastStore()
const adminStore = useAdminPanelStore()
const state = computed(() => adminStore.users)
const users = computed(() => state.value.items as AdminUser[])
const total = computed(() => state.value.total)
const loading = computed(() => state.value.loading)
const page = computed(() => state.value.page)
const totalPages = computed(() => Math.max(1, Math.ceil(state.value.total / 15)))
const currentTab = computed(() => state.value.tab as UserTab)
const tabs = computed(() => [
  { tab: 'all' as UserTab, label: 'کاربران', count: state.value.counts.all },
  { tab: 'active' as UserTab, label: 'فعال', count: state.value.counts.active },
  { tab: 'inactive' as UserTab, label: 'غیرفعال', count: state.value.counts.inactive },
  { tab: 'deleted' as UserTab, label: 'حذف شده ها', count: state.value.counts.deleted },
])
const emptyText = computed(() => currentTab.value === 'deleted' ? 'کاربر حذف شده‌ای وجود ندارد' : currentTab.value === 'active' ? 'کاربر فعالی وجود ندارد' : currentTab.value === 'inactive' ? 'کاربر غیرفعالی وجود ندارد' : 'هنوز کاربری ثبت‌نام نکرده')
const searchModel = computed({
  get: () => state.value.search,
  set: (value: string) => {
    adminStore.setUserSearch(value)
    scheduleSearchFetch()
  }
})
let searchTimer: ReturnType<typeof setTimeout> | null = null

function scheduleSearchFetch() {
  if (searchTimer) clearTimeout(searchTimer)
  searchTimer = setTimeout(() => adminStore.fetchUsers(true), 180)
}

async function selectTab(tab: UserTab) {
  adminStore.setUserTab(tab)
  await adminStore.fetchUsers()
}

function notifyUserStatusChanged() {
  if (import.meta.client) localStorage.setItem('leno-user-status-changed', String(Date.now()))
}

async function toggleBan(u: AdminUser, banned: boolean) {
  const res = await $fetch<{ success: boolean; banned: boolean }>(`/api/admin/users/${u.id}/ban`, {
    method: 'PUT',
    body: { banned }
  })
  adminStore.updateUserBanLocal(u.id, res.banned)
  toast.success(res.banned ? 'کاربر غیرفعال شد' : 'کاربر فعال شد')
  notifyUserStatusChanged()
}


async function resetUser(u: AdminUser) {
  if (!confirm(`سوابق خرید، اعلان‌ها و اشتراک «${u.name}» ریست شود؟`)) return
  await $fetch(`/api/admin/users/${u.id}/reset`, { method: 'POST' })
  adminStore.resetUserLocal(u.id)
  toast.success('اطلاعات کاربر ریست شد')
  notifyUserStatusChanged()
}

async function softDeleteUser(u: AdminUser) {
  if (!confirm(`آیا از حذف «${u.name}» مطمئن هستید؟`)) return
  await $fetch(`/api/admin/users/${u.id}`, { method: 'DELETE' })
  adminStore.changeUserStatusLocal(u, 'deleted')
  toast.success('کاربر به حذف شده‌ها منتقل شد')
  notifyUserStatusChanged()
}

async function restoreUser(u: AdminUser) {
  const updated = await $fetch<AdminUser>(`/api/admin/users/${u.id}/status`, { method: 'PUT', body: { status: 'active' } })
  adminStore.changeUserStatusLocal({ ...u, banned: updated.banned }, 'active')
  toast.success('کاربر بازیابی شد')
  notifyUserStatusChanged()
}

async function permanentDeleteUser(u: AdminUser) {
  if (!confirm(`«${u.name}» برای همیشه از پایگاه داده حذف شود؟`)) return
  await $fetch(`/api/admin/users/${u.id}`, { method: 'DELETE', params: { permanent: 1 } })
  adminStore.removeUserPermanentLocal(u)
  toast.success('کاربر کامل حذف شد')
  notifyUserStatusChanged()
}

async function handleUserAction(payload: { action: UserAction; user: AdminUser }) {
  try {
    if (payload.action === 'ban') return await toggleBan(payload.user, true)
    if (payload.action === 'unban') return await toggleBan(payload.user, false)
    if (payload.action === 'reset') return await resetUser(payload.user)
    if (payload.action === 'delete') return await softDeleteUser(payload.user)
    if (payload.action === 'restore') return await restoreUser(payload.user)
    if (payload.action === 'permanent-delete') return await permanentDeleteUser(payload.user)
  } catch {
    toast.error('خطا در انجام عملیات کاربر')
  }
}

function prevPage() { if (page.value > 1) { adminStore.setUserPage(page.value - 1); adminStore.fetchUsers() } }
function nextPage() { if (page.value < totalPages.value) { adminStore.setUserPage(page.value + 1); adminStore.fetchUsers() } }

function hasSubscription(u: AdminUser) {
  return !!u.subscriptionExpiresAt && new Date(u.subscriptionExpiresAt).getTime() > Date.now()
}

function formatDate(iso: string): string { return new Date(iso).toLocaleDateString('fa-IR') }

onMounted(() => { if (!state.value.loaded) adminStore.fetchUsers() })
onBeforeUnmount(() => { if (searchTimer) clearTimeout(searchTimer) })
</script>
