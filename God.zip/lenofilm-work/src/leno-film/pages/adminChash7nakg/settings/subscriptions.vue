<template>
  <div class="min-h-screen">
    <AdminHeader />
    <main class="pt-[60px] min-h-screen pb-10">
      <div class="px-4 sm:px-6 py-6 max-w-6xl mx-auto">
        <div class="flex items-center justify-between mb-5">
          <div>
            <h1 class="text-[18px] font-semibold tracking-tight text-[#fafafa]">اشتراک ها</h1>
            <p class="mt-1 text-[11px] text-[#71717a]">مدیریت پلن‌ها، کدهای تخفیف و درگاه‌ها</p>
          </div>
          <button v-if="activeTab !== 'settings'" v-wave="{ color: 'rgba(0,0,0,0.12)' }" @click="openAdd" class="flex items-center gap-2 h-10 px-4 rounded-xl bg-[#fafafa] text-[#0a0a0a] text-[13px] font-medium hover:bg-[#e4e4e7] transition-colors">
            <Icon icon="lucide:plus" class="text-[18px]" />
            <span>{{ activeTab === 'plans' ? 'افزودن اشتراک' : 'افزودن کد' }}</span>
          </button>
        </div>

        <div class="mb-5 grid grid-cols-3 overflow-hidden rounded-xl border border-[#1f1f1f] bg-[#0a0a0a] p-1">
          <button v-for="tab in tabs" :key="tab.key" v-wave type="button" @click="activeTab = tab.key" class="flex h-9 items-center justify-center gap-1.5 rounded-lg text-[12px] font-medium transition-colors" :class="activeTab === tab.key ? 'bg-[#18181b] text-[#fafafa]' : 'text-[#71717a] hover:text-[#fafafa]'">
            <span>{{ tab.label }}</span>
            <span v-if="tab.count !== null" class="rounded-full bg-[#27272a] px-1.5 py-0.5 text-[10px] text-[#a1a1aa]">{{ tab.count }}</span>
          </button>
        </div>

        <div v-if="activeTab !== 'settings'" class="mb-5">
          <div class="relative">
            <Icon icon="lucide:search" class="absolute right-3 top-1/2 -translate-y-1/2 text-[14px] text-[#71717a] pointer-events-none" />
            <input v-model="search" type="text" placeholder="جستجو..." class="w-full h-10 ps-9 pe-3 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
          </div>
        </div>

        <div v-if="loading" class="text-center py-12">
          <Icon icon="lucide:loader-2" class="text-[32px] text-[#52525b] mx-auto animate-spin" />
        </div>

        <template v-else>
          <div v-if="activeTab === 'plans'">
            <div v-if="filteredPlans.length === 0" class="text-center py-16">
              <Icon icon="lucide:badge-dollar-sign" class="text-[36px] text-[#52525b] mx-auto" />
              <p class="mt-3 text-[14px] text-[#71717a]">{{ search ? 'نتیجه‌ای یافت نشد' : 'هنوز اشتراکی اضافه نشده' }}</p>
            </div>
            <ul v-else class="space-y-2">
              <li v-for="plan in filteredPlans" :key="plan.id" class="p-3.5 rounded-xl bg-[#18181b] border border-[#1f1f1f] flex items-center gap-3.5">
                <div class="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-[#0a0a0a]">
                  <Icon icon="lucide:calendar-days" class="text-[22px] text-[#a1a1aa]" />
                </div>
                <div class="flex-1 min-w-0">
                  <h3 class="truncate text-[13px] font-semibold text-[#fafafa]">{{ plan.title }} · {{ plan.months }} ماه</h3>
                  <p class="mt-1 truncate text-[11px] text-[#71717a]">{{ money(plan.price) }} · کارمزد {{ planFeeText(plan) }} · تخفیف {{ planDiscountText(plan) }}</p>
                </div>
                <span class="rounded-full px-2 py-1 text-[10px]" :class="plan.active ? 'bg-emerald-500/15 text-emerald-400' : 'bg-rose-500/15 text-rose-400'">{{ plan.active ? 'فعال' : 'غیرفعال' }}</span>
                <button v-wave @click="openEditPlan(plan)" class="grid h-8 w-8 place-items-center rounded-lg text-[#a1a1aa] hover:bg-[#0a0a0a] hover:text-[#fafafa]"><Icon icon="lucide:pencil" /></button>
                <button v-wave @click="deletePlan(plan)" class="grid h-8 w-8 place-items-center rounded-lg text-[#a1a1aa] hover:bg-[#0a0a0a] hover:text-[#ef4444]"><Icon icon="lucide:trash-2" /></button>
              </li>
            </ul>
          </div>

          <div v-else-if="activeTab === 'discounts'">
            <div v-if="filteredDiscounts.length === 0" class="text-center py-16">
              <Icon icon="lucide:badge-percent" class="text-[36px] text-[#52525b] mx-auto" />
              <p class="mt-3 text-[14px] text-[#71717a]">{{ search ? 'نتیجه‌ای یافت نشد' : 'هنوز کد تخفیفی اضافه نشده' }}</p>
            </div>
            <ul v-else class="space-y-2">
              <li v-for="d in filteredDiscounts" :key="d.id" class="p-3.5 rounded-xl bg-[#18181b] border border-[#1f1f1f] flex items-center gap-3.5">
                <div class="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-[#0a0a0a]">
                  <Icon icon="lucide:badge-percent" class="text-[22px] text-[#a1a1aa]" />
                </div>
                <div class="flex-1 min-w-0">
                  <h3 class="truncate text-left text-[13px] font-semibold text-[#fafafa]" dir="ltr">{{ d.code }}</h3>
                  <p class="mt-1 truncate text-[11px] text-[#71717a]">{{ d.type === 'percent' ? `${d.value}٪` : money(d.value) }} · {{ planName(d.planId) }}</p>
                </div>
                <span class="rounded-full px-2 py-1 text-[10px]" :class="d.active ? 'bg-emerald-500/15 text-emerald-400' : 'bg-rose-500/15 text-rose-400'">{{ d.active ? 'فعال' : 'غیرفعال' }}</span>
                <button v-wave @click="openEditDiscount(d)" class="grid h-8 w-8 place-items-center rounded-lg text-[#a1a1aa] hover:bg-[#0a0a0a] hover:text-[#fafafa]"><Icon icon="lucide:pencil" /></button>
                <button v-wave @click="deleteDiscount(d)" class="grid h-8 w-8 place-items-center rounded-lg text-[#a1a1aa] hover:bg-[#0a0a0a] hover:text-[#ef4444]"><Icon icon="lucide:trash-2" /></button>
              </li>
            </ul>
          </div>

          <div v-else class="space-y-3">
            <label class="flex items-center justify-between rounded-xl bg-[#18181b] border border-[#1f1f1f] px-4 py-4 text-[13px] text-[#fafafa]">
              <span class="font-semibold">درگاه ریالی</span>
              <input v-model="settings.rialEnabled" type="checkbox" class="h-5 w-5 accent-[#8166d5]" @change="saveSettings" />
            </label>
            <label class="flex items-center justify-between rounded-xl bg-[#18181b] border border-[#1f1f1f] px-4 py-4 text-[13px] text-[#fafafa]">
              <span class="font-semibold">کارت به کارت</span>
              <input v-model="settings.cardEnabled" type="checkbox" class="h-5 w-5 accent-[#8166d5]" @change="saveSettings" />
            </label>
            <label class="flex items-center justify-between rounded-xl bg-[#18181b] border border-[#1f1f1f] px-4 py-4 text-[13px] text-[#fafafa]">
              <span class="font-semibold">حالت آزمایشی زرین‌پال</span>
              <input v-model="settings.zarinpalSandbox" type="checkbox" class="h-5 w-5 accent-[#8166d5]" @change="saveSettings" />
            </label>
            <div class="rounded-xl bg-[#18181b] border border-[#1f1f1f] p-4">
              <label class="admin-label">مرچنت زرین‌پال <span v-if="settings.zarinpalMasked" class="text-[#71717a]">(فعلی: {{ settings.zarinpalMasked }})</span></label>
              <div class="flex gap-2">
                <input v-model="settings.zarinpalMerchant" dir="ltr" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" class="admin-input flex-1" />
                <button v-wave type="button" @click="saveSettings" class="h-10 rounded-lg bg-[#fafafa] px-4 text-[12px] font-bold text-[#0a0a0a]">ذخیره</button>
              </div>
              <p class="mt-2 text-[11px] leading-6 text-[#71717a]">در حالت آزمایشی اگر مرچنت خالی باشد از مرچنت تستی استفاده می‌شود.</p>
            </div>
          </div>
        </template>
      </div>
    </main>
    <AdminDrawer />

    <Teleport to="body">
      <Transition name="backdrop"><div v-if="modalOpen" @click="closeModal" class="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"></div></Transition>
      <Transition name="modal">
        <div v-if="modalOpen" class="fixed inset-x-0 bottom-0 sm:inset-0 z-50 flex items-end sm:items-center justify-center pointer-events-none">
          <div @click.stop class="pointer-events-auto w-full sm:max-w-lg max-h-[92vh] bg-[#0a0a0a] border-t sm:border border-[#1f1f1f] sm:rounded-2xl rounded-t-2xl flex flex-col overflow-hidden">
            <header class="px-5 py-4 border-b border-[#1f1f1f] flex items-center justify-between shrink-0">
              <h2 class="text-[15px] font-semibold text-[#fafafa]">{{ modalTitle }}</h2>
              <button v-wave @click="closeModal" class="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-[#18181b] text-[#a1a1aa] hover:text-[#fafafa] transition-colors"><Icon icon="lucide:x" class="text-[20px]" /></button>
            </header>

            <form v-if="modalType === 'plan'" @submit.prevent="savePlan" class="flex-1 overflow-y-auto p-5 space-y-3">
              <div><label class="admin-label">زمان اشتراک برحسب ماه</label><input v-model.number="planForm.months" type="number" min="1" max="12" required class="admin-input" /></div>
              <div><label class="admin-label">قیمت</label><input v-model.number="planForm.price" type="number" min="0" required class="admin-input" /></div>
              <div class="grid grid-cols-2 gap-3"><div><label class="admin-label">نوع کارمزد</label><select v-model="planForm.feeType" class="admin-input"><option value="fixed">مبلغی</option><option value="percent">درصدی</option></select></div><div><label class="admin-label">مقدار کارمزد</label><input v-model.number="planForm.feeValue" type="number" min="0" class="admin-input" /></div></div>
              <div class="grid grid-cols-2 gap-3"><div><label class="admin-label">نوع تخفیف اشتراک</label><select v-model="planForm.discountType" class="admin-input"><option value="none">بدون تخفیف</option><option value="percent">درصدی</option><option value="fixed">مبلغی</option></select></div><div><label class="admin-label">مقدار تخفیف</label><input v-model.number="planForm.discountValue" type="number" min="0" class="admin-input" :disabled="planForm.discountType === 'none'" /></div></div>
              <div><label class="flex items-center gap-2 text-[12px] text-[#a1a1aa]"><input v-model="planForm.active" type="checkbox" class="accent-[#8166d5]" /> فعال باشد</label></div>
            </form>

            <form v-else @submit.prevent="saveDiscount" class="flex-1 overflow-y-auto p-5 space-y-3">
              <div><label class="admin-label">کد تخفیف</label><div class="flex gap-2"><input v-model="discountForm.code" dir="ltr" required class="admin-input flex-1 uppercase" /><button type="button" v-wave @click="generateCode" class="h-10 rounded-lg bg-[#18181b] px-3 text-[12px] font-bold text-[#fafafa]">ساخت خودکار</button></div></div>
              <div class="grid grid-cols-2 gap-3"><div><label class="admin-label">نوع تخفیف</label><select v-model="discountForm.type" class="admin-input"><option value="percent">درصدی</option><option value="fixed">مبلغی</option></select></div><div><label class="admin-label">مقدار</label><input v-model.number="discountForm.value" type="number" min="0" required class="admin-input" /></div></div>
              <div><label class="admin-label">اعمال روی</label><select v-model.number="discountForm.planId" class="admin-input"><option :value="0">همه پلن‌ها</option><option v-for="p in plans" :key="p.id" :value="p.id">{{ p.title }}</option></select></div>
              <div><label class="flex items-center gap-2 text-[12px] text-[#a1a1aa]"><input v-model="discountForm.active" type="checkbox" class="accent-[#8166d5]" /> فعال باشد</label></div>
            </form>

            <footer class="px-5 py-3 border-t border-[#1f1f1f] flex items-center gap-3 shrink-0">
              <button v-wave @click="closeModal" type="button" class="flex-1 h-10 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[13px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors">لغو</button>
              <button v-wave="{ color: 'rgba(0,0,0,0.12)' }" @click="modalType === 'plan' ? savePlan() : saveDiscount()" type="button" class="flex-1 h-10 rounded-lg bg-[#fafafa] text-[#0a0a0a] text-[13px] font-medium">ذخیره</button>
            </footer>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'admin', middleware: 'admin-auth' })
const toast = useToastStore()
type TabKey = 'plans' | 'discounts' | 'settings'
type Plan = { id: number; title: string; months: number; price: number; fee: number; discountPercent: number; discountAmount: number; active: boolean }
type Discount = { id: number; code: string; type: 'percent' | 'fixed'; value: number; planId?: number | null; active: boolean }
const plans = ref<Plan[]>([])
const discounts = ref<Discount[]>([])
const settings = reactive({ rialEnabled: true, cardEnabled: false, zarinpalSandbox: true, zarinpalMerchant: '', zarinpalMasked: '' })
const activeTab = ref<TabKey>('plans')
const search = ref('')
const loading = ref(true)
const modalOpen = ref(false)
const modalType = ref<'plan' | 'discount'>('plan')
const editingId = ref<number | null>(null)
const planForm = reactive({ months: 1, price: 0, feeType: 'fixed' as 'fixed' | 'percent', feeValue: 0, discountType: 'none' as 'none' | 'fixed' | 'percent', discountValue: 0, active: true })
const discountForm = reactive({ code: '', type: 'percent' as 'percent' | 'fixed', value: 0, planId: 0, active: true })
const tabs = computed(() => [
  { key: 'plans' as TabKey, label: 'اشتراک ها', count: plans.value.length },
  { key: 'discounts' as TabKey, label: 'کد تخفیف', count: discounts.value.length },
  { key: 'settings' as TabKey, label: 'تنظیمات', count: null },
])
const filteredPlans = computed(() => !search.value.trim() ? plans.value : plans.value.filter(p => `${p.title} ${p.months}`.includes(search.value.trim())))
const filteredDiscounts = computed(() => !search.value.trim() ? discounts.value : discounts.value.filter(d => d.code.toLowerCase().includes(search.value.trim().toLowerCase()) || planName(d.planId).includes(search.value.trim())))
const modalTitle = computed(() => modalType.value === 'plan' ? (editingId.value ? 'ویرایش اشتراک' : 'افزودن اشتراک') : (editingId.value ? 'ویرایش کد تخفیف' : 'افزودن کد تخفیف'))
function money(value: number) { return `${new Intl.NumberFormat('fa-IR').format(Number(value || 0))} تومان` }
function planName(id?: number | null) { return id ? (plans.value.find(p => p.id === id)?.title || 'پلن حذف شده') : 'همه پلن‌ها' }
function planFeeText(plan: Plan) { return money(plan.fee) }
function planDiscountText(plan: Plan) {
  if (plan.discountPercent) return `${plan.discountPercent}٪`
  if (plan.discountAmount) return money(plan.discountAmount)
  return 'ندارد'
}
function resetPlanForm() { editingId.value = null; Object.assign(planForm, { months: 1, price: 0, feeType: 'fixed', feeValue: 0, discountType: 'none', discountValue: 0, active: true }) }
function resetDiscountForm() { editingId.value = null; Object.assign(discountForm, { code: '', type: 'percent', value: 0, planId: 0, active: true }) }
function openAdd() { if (activeTab.value === 'plans') { modalType.value = 'plan'; resetPlanForm() } else { modalType.value = 'discount'; resetDiscountForm() }; modalOpen.value = true }
function closeModal() { modalOpen.value = false }
function openEditPlan(plan: Plan) {
  modalType.value = 'plan'
  editingId.value = plan.id
  Object.assign(planForm, {
    months: plan.months,
    price: plan.price,
    feeType: 'fixed',
    feeValue: plan.fee,
    discountType: plan.discountPercent ? 'percent' : plan.discountAmount ? 'fixed' : 'none',
    discountValue: plan.discountPercent || plan.discountAmount || 0,
    active: plan.active,
  })
  modalOpen.value = true
}
function openEditDiscount(d: Discount) { modalType.value = 'discount'; editingId.value = d.id; Object.assign(discountForm, { code: d.code, type: d.type, value: d.value, planId: d.planId || 0, active: d.active }); modalOpen.value = true }
function generateCode() { discountForm.code = `LENO${Math.random().toString(36).slice(2, 8).toUpperCase()}` }
function planPayload() {
  const fee = planForm.feeType === 'percent' ? Math.floor(planForm.price * planForm.feeValue / 100) : planForm.feeValue
  const discountPercent = planForm.discountType === 'percent' ? Math.min(Number(planForm.discountValue || 0), 100) : 0
  const discountAmount = planForm.discountType === 'fixed' ? Number(planForm.discountValue || 0) : 0
  return { title: `${planForm.months} ماهه`, months: planForm.months, price: planForm.price, fee, discountPercent, discountAmount, active: planForm.active }
}
async function loadAll() { loading.value = true; try { const [p, d, s] = await Promise.all([$fetch<Plan[]>('/api/admin/subscriptions/plans'), $fetch<Discount[]>('/api/admin/subscriptions/discounts'), $fetch<any>('/api/admin/subscriptions/settings')]); plans.value = p; discounts.value = d; Object.assign(settings, s) } finally { loading.value = false } }
async function saveSettings() { await $fetch('/api/admin/subscriptions/settings', { method: 'PUT', body: settings }); toast.success('تنظیمات ذخیره شد') }
async function savePlan() { const body = planPayload(); if (editingId.value) await $fetch(`/api/admin/subscriptions/plans/${editingId.value}`, { method: 'PUT', body }); else await $fetch('/api/admin/subscriptions/plans', { method: 'POST', body }); toast.success('اشتراک ذخیره شد'); closeModal(); await loadAll() }
async function deletePlan(plan: Plan) { if (!confirm(`اشتراک «${plan.title}» حذف شود؟`)) return; await $fetch(`/api/admin/subscriptions/plans/${plan.id}`, { method: 'DELETE' }); toast.success('اشتراک حذف شد'); await loadAll() }
async function saveDiscount() { const body = { ...discountForm, planId: discountForm.planId || null }; if (editingId.value) await $fetch(`/api/admin/subscriptions/discounts/${editingId.value}`, { method: 'PUT', body }); else await $fetch('/api/admin/subscriptions/discounts', { method: 'POST', body }); toast.success('کد تخفیف ذخیره شد'); closeModal(); await loadAll() }
async function deleteDiscount(d: Discount) { if (!confirm(`کد «${d.code}» حذف شود؟`)) return; await $fetch(`/api/admin/subscriptions/discounts/${d.id}`, { method: 'DELETE' }); toast.success('کد تخفیف حذف شد'); await loadAll() }
onMounted(loadAll)
</script>

<style scoped>
.admin-input { width: 100%; height: 40px; border-radius: 10px; background: #0a0a0a; border: 1px solid #1f1f1f; padding: 0 12px; color: #fafafa; font-size: 12px; outline: none; transition: border-color .25s ease; }
.admin-input:focus { border-color: #3f3f46; }
.admin-label { display: block; margin-bottom: 6px; font-size: 12px; color: #a1a1aa; }
.backdrop-enter-active, .backdrop-leave-active { transition: opacity .3s ease; }
.backdrop-enter-from, .backdrop-leave-to { opacity: 0; }
.modal-enter-active, .modal-leave-active { transition: transform .32s cubic-bezier(.16,1,.3,1), opacity .22s ease; }
.modal-enter-from, .modal-leave-to { transform: translateY(18px); opacity: 0; }
</style>
