<template>
  <div class="min-h-screen flex items-center justify-center px-6 py-10">
    <div class="w-full max-w-[360px]">

      <!-- عنوان -->
      <div class="text-center mb-10">
        <h1 class="text-[22px] font-semibold tracking-tight text-[#fafafa]">
          لنوفیلم
        </h1>
        <p class="mt-2 text-[14px] text-[#71717a]">
          پنل مدیریت
        </p>
      </div>

      <!-- فرم ورود -->
      <form @submit.prevent="handleLogin" class="space-y-4">
        <!-- ایمیل -->
        <div>
          <input
            v-model="email"
            type="email"
            placeholder="ایمیل"
            required
            autocomplete="username"
            class="w-full h-12 px-5 rounded-2xl bg-[#0a0a0a] border border-[#1f1f1f] text-[15px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out"
          />
        </div>

        <!-- رمز عبور -->
        <div>
          <input
            v-model="password"
            type="password"
            placeholder="رمز عبور"
            required
            autocomplete="current-password"
            class="w-full h-12 px-5 rounded-2xl bg-[#0a0a0a] border border-[#1f1f1f] text-[15px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out"
          />
        </div>

        <!-- دکمه ورود -->
        <button
          type="submit"
          :disabled="loading || !email || !password"
          class="btn-press w-full h-12 rounded-2xl bg-[#fafafa] text-[#0a0a0a] text-[15px] font-medium flex items-center justify-center gap-2 transition-opacity duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <svg v-if="loading" class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" opacity="0.25" />
            <path d="M12 2a10 10 0 0110 10" stroke="currentColor" stroke-width="3" stroke-linecap="round" />
          </svg>
          <span v-if="!loading">ورود</span>
          <span v-else>در حال ورود...</span>
        </button>
      </form>

    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({
  layout: 'admin',
})

const auth = useAuthStore()
const toast = useToastStore()
const router = useRouter()

const email = ref('')
const password = ref('')
const loading = ref(false)

async function handleLogin() {
  if (loading.value) return
  loading.value = true

  await new Promise(resolve => setTimeout(resolve, 1500))

  const result = auth.login(email.value.trim(), password.value)

  if (result.success) {
    toast.success('با موفقیت وارد شدید')
    router.push('/adminChash7nakg/dashboard')
  } else {
    toast.error(result.error || 'خطایی رخ داد')
  }

  loading.value = false
}

onMounted(() => {
  if (auth.isAuthenticated) {
    router.push('/adminChash7nakg/dashboard')
  }
})
</script>
