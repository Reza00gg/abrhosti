<template>
  <div class="pb-8">
    <FeaturedSlider />
    <div class="pt-3 sm:pt-4">
    <section>
      <div
        v-wave="appWave"
        style="color: var(--ripple)"
        class="mb-4 flex h-9 w-full cursor-pointer select-none items-center justify-between gap-3 overflow-hidden pe-2 ps-4 sm:pe-4 sm:ps-6"
        @click="openLatest('/list/new-films')"
      >
        <h1 class="truncate text-[16px] font-extrabold tracking-tight text-ink-50">جدیدترین فیلم ها</h1>
        <span class="pointer-events-none grid h-9 w-9 shrink-0 place-items-center text-ink-300" aria-hidden="true">
          <Icon icon="lucide:chevron-left" class="text-[20px]" />
        </span>
      </div>
    </section>

    <div v-if="showMoviesSkeleton" class="movie-rail-scroll flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2 sm:px-6">
      <div v-for="i in 8" :key="i" class="w-[132px] shrink-0 snap-start snap-always sm:w-[154px] md:w-[170px]">
        <div class="aspect-[2/3] animate-pulse rounded-xl bg-ink-900/70"></div>
        <div class="mt-2 h-3 w-4/5 animate-pulse rounded bg-ink-900/70"></div>
      </div>
    </div>

    <div v-else-if="movies.length === 0" class="px-4 sm:px-6 text-center py-16">
      <Icon icon="lucide:clapperboard" class="text-[40px] text-ink-600 mx-auto" />
      <p class="mt-4 text-base text-ink-300 font-medium">بزودی فیلم/سریال اضافه میشود</p>
    </div>

    <div
      v-else
      ref="railRef"
      :class="['movie-rail-scroll flex cursor-grab select-none gap-3 overflow-x-auto px-4 pb-2 sm:px-6 active:cursor-grabbing', isRailDragging ? 'snap-none scroll-auto' : 'snap-x snap-mandatory scroll-smooth']"
      @pointerdown="startRailDrag"
    >
      <MovieCard v-for="(movie, index) in movies" :key="`movie-${movie.id}`" :movie="movie" :eager="index < eagerPosterCount" variant="rail" />
    </div>

    <section v-if="showSeriesSkeleton" class="mt-8">
      <div
        v-wave="appWave"
        style="color: var(--ripple)"
        class="mb-4 flex h-9 w-full cursor-pointer select-none items-center justify-between gap-3 overflow-hidden pe-2 ps-4 sm:pe-4 sm:ps-6"
        @click="openLatest('/list/new-series')"
      >
        <h2 class="truncate text-[16px] font-extrabold tracking-tight text-ink-50">جدیدترین سریال ها</h2>
        <span class="pointer-events-none grid h-9 w-9 shrink-0 place-items-center text-ink-300" aria-hidden="true">
          <Icon icon="lucide:chevron-left" class="text-[20px]" />
        </span>
      </div>
      <div class="movie-rail-scroll flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2 sm:px-6">
        <div v-for="i in 8" :key="i" class="w-[132px] shrink-0 snap-start snap-always sm:w-[154px] md:w-[170px]">
          <div class="aspect-[2/3] animate-pulse rounded-xl bg-ink-900/70"></div>
          <div class="mt-2 h-3 w-4/5 animate-pulse rounded bg-ink-900/70"></div>
        </div>
      </div>
    </section>

    <section v-else-if="seriesItems.length" class="mt-8">
      <div
        v-wave="appWave"
        style="color: var(--ripple)"
        class="mb-4 flex h-9 w-full cursor-pointer select-none items-center justify-between gap-3 overflow-hidden pe-2 ps-4 sm:pe-4 sm:ps-6"
        @click="openLatest('/list/new-series')"
      >
        <h2 class="truncate text-[16px] font-extrabold tracking-tight text-ink-50">جدیدترین سریال ها</h2>
        <span class="pointer-events-none grid h-9 w-9 shrink-0 place-items-center text-ink-300" aria-hidden="true">
          <Icon icon="lucide:chevron-left" class="text-[20px]" />
        </span>
      </div>
      <div
        ref="seriesRailRef"
        :class="['movie-rail-scroll flex cursor-grab select-none gap-3 overflow-x-auto px-4 pb-2 sm:px-6 active:cursor-grabbing', isSeriesRailDragging ? 'snap-none scroll-auto' : 'snap-x snap-mandatory scroll-smooth']"
        @pointerdown="startSeriesRailDrag"
      >
        <SeriesCard v-for="(item, index) in seriesItems" :key="`series-${item.id}`" :movie="item" :eager="index < eagerPosterCount" variant="rail" />
      </div>
    </section>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ title: 'خانه' })
const appWave = useAppWave()
const moviesStore = useMoviesStore()
const movies = computed(() => moviesStore.latest)
const seriesItems = computed(() => moviesStore.latestSeries)
const showMoviesSkeleton = computed(() => !moviesStore.latestLoaded && !movies.value.length)
const showSeriesSkeleton = computed(() => !moviesStore.latestSeriesLoaded && !seriesItems.value.length)
const eagerPosterCount = 4

function openLatest(path: string) {
  navigateTo(path)
}
const railRef = ref<HTMLElement | null>(null)
const seriesRailRef = ref<HTMLElement | null>(null)
const isRailDragging = ref(false)
const isSeriesRailDragging = ref(false)
let dragging = false
let lastDragX = 0
let lastDragAt = 0
let dragVelocity = 0
let dragPointerId: number | null = null
let inertiaFrame = 0
let draggedDistance = 0

function startDrag(event: PointerEvent, rail: HTMLElement | null, draggingRef: Ref<boolean>) {
  if (event.pointerType === 'touch' || !rail || event.button !== 0) return false
  if ((event.target as HTMLElement)?.closest?.('a[href^="/title/"]')) return false
  event.preventDefault()
  dragging = true
  draggingRef.value = true
  dragPointerId = event.pointerId
  cancelAnimationFrame(inertiaFrame)
  lastDragX = event.clientX
  lastDragAt = performance.now()
  dragVelocity = 0
  draggedDistance = 0
  activeRail = rail
  activeDraggingRef = draggingRef
  window.addEventListener('pointermove', moveRailDrag, { passive: false })
  window.addEventListener('pointerup', endRailDrag)
  window.addEventListener('pointercancel', endRailDrag)
  return true
}

let activeRail: HTMLElement | null = null
let activeDraggingRef: Ref<boolean> | null = null
function startRailDrag(event: PointerEvent) { startDrag(event, railRef.value, isRailDragging) }
function startSeriesRailDrag(event: PointerEvent) { startDrag(event, seriesRailRef.value, isSeriesRailDragging) }

function moveRailDrag(event: PointerEvent) {
  if (!dragging || !activeRail) return
  event.preventDefault()
  const now = performance.now()
  const delta = event.clientX - lastDragX
  const dt = Math.max(16, now - lastDragAt)
  draggedDistance += Math.abs(delta)
  dragVelocity = delta / dt
  lastDragX = event.clientX
  lastDragAt = now
  activeRail.scrollLeft -= delta
}

function endRailDrag() {
  if (!dragging || !activeRail) return
  dragging = false
  dragPointerId = null
  window.removeEventListener('pointermove', moveRailDrag)
  window.removeEventListener('pointerup', endRailDrag)
  window.removeEventListener('pointercancel', endRailDrag)

  if (draggedDistance < 4 || Math.abs(dragVelocity) < 0.02) {
    if (activeDraggingRef) activeDraggingRef.value = false
    activeRail = null
    activeDraggingRef = null
    return
  }

  let velocity = dragVelocity * 16
  const rail = activeRail
  const draggingRef = activeDraggingRef
  const startedAt = performance.now()
  const step = () => {
    rail.scrollLeft -= velocity
    velocity *= 0.92
    if (Math.abs(velocity) > 0.25 && performance.now() - startedAt < 520) {
      inertiaFrame = requestAnimationFrame(step)
    } else {
      if (draggingRef) draggingRef.value = false
      activeRail = null
      activeDraggingRef = null
    }
  }
  inertiaFrame = requestAnimationFrame(step)
}

function resetHomeScroll() {
  if (!import.meta.client) return
  window.scrollTo({ top: 0, left: 0, behavior: 'auto' })
  document.documentElement.scrollTop = 0
  document.body.scrollTop = 0
  document.scrollingElement?.scrollTo?.({ top: 0, left: 0, behavior: 'auto' })
}

function scheduleHomeScrollReset() {
  resetHomeScroll()
  requestAnimationFrame(() => {
    resetHomeScroll()
    requestAnimationFrame(resetHomeScroll)
  })
  window.setTimeout(resetHomeScroll, 120)
  window.setTimeout(resetHomeScroll, 360)
  window.setTimeout(resetHomeScroll, 720)
}

async function loadHomeContent() {
  // نمایش اسکلت هر دو بخش از همان ابتدا؛ اما دریافت واقعی به‌ترتیب از بالا به پایین انجام می‌شود.
  await moviesStore.fetchLatest()
  await moviesStore.fetchLatestSeries()
  scheduleHomeScrollReset()
}

onMounted(() => {
  scheduleHomeScrollReset()
  loadHomeContent()
})
onActivated(scheduleHomeScrollReset)
onBeforeUnmount(() => {
  window.removeEventListener('pointermove', moveRailDrag)
  window.removeEventListener('pointerup', endRailDrag)
  window.removeEventListener('pointercancel', endRailDrag)
  cancelAnimationFrame(inertiaFrame)
})
</script>
