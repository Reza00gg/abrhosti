<template>
  <div class="min-h-[60vh]">
    <div class="search-mobile-view md:hidden">
      <div class="px-4 pt-6 sm:pt-8 pb-3">
        <div class="relative">
          <Icon icon="lucide:search" class="absolute right-4 top-1/2 -translate-y-1/2 text-[20px] text-ink-500 pointer-events-none transition-colors duration-200" :class="query ? 'text-ink-300' : ''" />
          <input ref="mobileSearchInput" v-model="query" type="text" placeholder="جستجو در هزاران فیلم و سریال" class="w-full h-12 pe-12 ps-12 rounded-2xl focus:rounded-3xl bg-ink-950 text-ink-50 placeholder:text-ink-500 text-[15px] border border-[color:var(--hairline)] focus:border-[color:var(--input-border-focus)] outline-none focus:ring-0 transition-[border-color,border-radius] duration-300 ease-out" />
          <button v-if="query" v-wave="appWave" style="color: var(--ripple)" @click="clearSearch" class="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 flex items-center justify-center rounded-full hover:bg-ink-900 transition-colors" aria-label="پاک کردن">
            <Icon icon="lucide:x" class="text-[18px] text-ink-400" />
          </button>
        </div>
      </div>
      <div class="px-4 sm:px-6 pt-4 pb-8">
        <div v-if="!query.trim()" class="text-center pt-16 animate-fade-up">
          <Icon icon="lucide:search" class="text-[40px] text-ink-600 mx-auto" />
          <p class="mt-4 text-base text-ink-400">جستجو کنید</p>
          <p class="mt-1 text-sm text-ink-600">نام فیلم، سریال، کارگردان یا بازیگر</p>
        </div>
        <div v-else-if="loading" class="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 sm:gap-4 animate-fade-in">
          <div v-for="i in 8" :key="i" class="overflow-hidden rounded-xl">
            <div class="aspect-[2/3] rounded-xl bg-ink-900 animate-pulse"></div>
            <div class="pt-2"><div class="h-2.5 bg-ink-900 rounded animate-pulse"></div></div>
          </div>
        </div>
        <div v-else-if="results.length === 0" class="text-center pt-16 animate-fade-up">
          <Icon icon="lucide:search-x" class="text-[40px] text-ink-600 mx-auto" />
          <p class="mt-4 text-base text-ink-400 font-medium">نتیجه‌ای یافت نشد</p>
          <p class="mt-2 text-sm text-ink-600">برای «{{ query }}» نتیجه‌ای پیدا نشد</p>
          <button v-wave="appWave" style="color: var(--ripple)" @click="clearSearch" class="btn-press mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-ink-900 border border-[color:var(--hairline)] text-sm text-ink-300 hover:text-ink-50 hover:border-[color:var(--input-border-focus)] transition-colors">
            <Icon icon="lucide:arrow-right" class="text-[16px]" />
            بازگشت
          </button>
        </div>
        <div v-else class="animate-fade-in">
          <p class="text-[12px] text-ink-500 mb-3">{{ results.length }} نتیجه برای «{{ query }}»</p>
          <div class="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 sm:gap-4">
            <component :is="isSeriesResult(movie) ? SeriesCard : MovieCard" v-for="(movie, index) in results" :key="`${isSeriesResult(movie) ? 'series' : 'movie'}-${movie.id}`" :movie="movie" :eager="index < 6" />
          </div>
        </div>
      </div>
    </div>

    <div class="search-tablet-view hidden md:grid" dir="rtl">
      <aside class="search-tablet-filters">
        <section v-for="(filter, index) in tabletFilters" :key="filter.title" class="search-filter-section" :class="index === 0 && tabletNameOpen ? 'is-open' : ''">
          <button type="button" class="search-filter-section__head" @click="index === 0 ? toggleTabletNameFilter() : undefined">
            <Icon :icon="index === 0 && tabletNameOpen ? 'lucide:chevron-up' : 'lucide:chevron-down'" class="text-[19px]" />
            <span>{{ filter.title }}</span>
          </button>
          <Transition name="search-filter-slide">
            <div v-if="index === 0 && tabletNameOpen" class="search-filter-section__body">
              <input ref="tabletSearchInput" v-model="query" type="text" placeholder="جستجو..." />
            </div>
          </Transition>
        </section>
      </aside>

      <main class="search-tablet-results">
        <div v-if="!query.trim()" class="search-tablet-empty-clean">
          <Icon icon="lucide:search" class="search-tablet-empty-clean__icon" />
          <p>جستجوی فیلم و سریال</p>
        </div>
        <div v-else-if="loading" class="search-tablet-card-grid animate-fade-in">
          <div v-for="i in 10" :key="i" class="overflow-hidden rounded-xl">
            <div class="aspect-[2/3] rounded-xl bg-ink-900 animate-pulse"></div>
            <div class="pt-2"><div class="h-2.5 bg-ink-900 rounded animate-pulse"></div></div>
          </div>
        </div>
        <div v-else-if="results.length === 0" class="search-tablet-empty">
          <Icon icon="lucide:search-x" class="text-[58px]" />
          <p>برای «{{ query }}» نتیجه‌ای پیدا نشد</p>
        </div>
        <div v-else class="animate-fade-in">
          <p class="mb-4 text-right text-[13px] font-bold text-[rgb(var(--text-secondary-rgb))]">{{ results.length }} نتیجه برای «{{ query }}»</p>
          <div class="search-tablet-card-grid">
            <component :is="isSeriesResult(movie) ? SeriesCard : MovieCard" v-for="(movie, index) in results" :key="`${isSeriesResult(movie) ? 'series' : 'movie'}-${movie.id}`" :movie="movie" variant="rail" :eager="index < 8" />
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
const appWave = useAppWave()
import type { Movie } from '~~/server/db/schema'
import MovieCard from '~/components/MovieCard.vue'
import SeriesCard from '~/components/SeriesCard.vue'
definePageMeta({ title: 'جستجو' })
const query = ref('')
const results = ref<Movie[]>([])
const loading = ref(false)
const tabletNameOpen = ref(true)
const mobileSearchInput = ref<HTMLInputElement | null>(null)
const tabletSearchInput = ref<HTMLInputElement | null>(null)
const tabletFilters = [
  { title: 'نام فیلم یا سریال یا کد' },
  { title: 'کلمات کلیدی' },
  { title: 'نوع اثر' },
  { title: 'ژانر' },
  { title: 'کشور' },
  { title: 'زبان' },
  { title: 'رده سنی' },
  { title: 'امتیاز IMDb' },
  { title: 'سال انتشار' },
  { title: 'مدت زمان' },
  { title: 'وضعیت انتشار' },
  { title: 'سایر ویژگی ها' },
]
let searchTimer: any = null

watch(query, (newQuery) => {
  if (searchTimer) clearTimeout(searchTimer)
  const q = newQuery.trim()
  if (!q) { results.value = []; loading.value = false; return }
  loading.value = true
  searchTimer = setTimeout(async () => {
    try {
      const [movieRows, seriesRows] = await Promise.all([
        $fetch<Movie[]>('/api/movies/public', { params: { q, limit: 50 } }),
        $fetch<Movie[]>('/api/series/public', { params: { q, limit: 50 } })
      ])
      results.value = [...movieRows, ...seriesRows]
    }
    catch { results.value = [] }
    finally { loading.value = false }
  }, 200)
})

function isSeriesResult(item: any) { return item?.type === 'series' || Number(item?.seasons) > 0 }
function toggleTabletNameFilter() { tabletNameOpen.value = !tabletNameOpen.value }
function focusActiveSearchInput() {
  if (!import.meta.client) return
  nextTick(() => {
    const isTablet = window.matchMedia('(min-width: 768px)').matches
    const input = isTablet ? tabletSearchInput.value : mobileSearchInput.value
    input?.focus?.()
  })
}
function clearSearch() {
  query.value = ''
  results.value = []
  focusActiveSearchInput()
}
onMounted(focusActiveSearchInput)
onBeforeUnmount(() => {
  if (searchTimer) clearTimeout(searchTimer)
})
</script>
