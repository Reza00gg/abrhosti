<template>
  <div class="px-4 sm:px-6 pt-6 sm:pt-10">
    <ComingSoon
      title="دیسکاور"
      subtitle="بزودی"
      description="فیلم‌ها و سریال‌های پیشنهادی بر اساس سلیقه‌ی شما، در راه هستند."
      icon="lucide:compass"
    />
  </div>
</template>

<script setup lang="ts">
definePageMeta({ title: 'دیسکاور' })
</script>
