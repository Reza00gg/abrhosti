<template>
  <div class="title-page min-h-[70vh] pb-8">
    <div v-if="loading" class="title-page-skeleton">
      <div class="title-page-skeleton__poster"></div>
      <div class="title-page-skeleton__lines">
        <span></span><span></span><span></span>
      </div>
      <div class="title-page-skeleton__button"></div>
      <div class="title-page-skeleton__actions"><span v-for="i in 4" :key="i"></span></div>
      <div class="title-page-skeleton__text"><span></span><span></span><span></span></div>
    </div>

    <div v-else-if="error" class="grid min-h-[55vh] place-items-center px-6 text-center">
      <div>
        <Icon icon="lucide:file-question" class="mx-auto text-[56px] text-ink-500" />
        <h1 class="mt-4 text-[18px] font-black text-ink-50">عنوان پیدا نشد</h1>
        <button v-wave="appWave" type="button" class="account-save-button mt-6 rounded-xl px-6 py-3 text-[13px] font-black" @click="navigateTo('/')">بازگشت به خانه</button>
      </div>
    </div>

    <article v-else-if="title" class="title-page-content animate-fade-in">
      <section class="title-hero">
        <div class="title-hero__backdrop" :style="heroStyle"></div>
        <div class="title-hero__shade"></div>
        <div class="title-hero__info">
          <div class="title-hero__meta">
            <div class="title-hero__rating">
              <span>{{ ratingText }}</span>
              <b>IMDb</b>
            </div>
            <p>{{ title.type === 'movie' ? 'فیلم' : 'سریال' }} | {{ title.year }} | {{ title.durationLabel }}</p>
          </div>
          <img v-if="title.posterUrl" :src="title.posterUrl" :alt="title.titleFa" class="title-hero__poster" draggable="false" />
        </div>
      </section>

      <section class="title-actions-wrap px-2">
        <button v-wave="{ color: 'rgba(255,255,255,.35)' }" type="button" class="title-play-button">
          <Icon icon="lucide:play" class="text-[18px]" />
          دانلود و پخش آنلاین
        </button>
        <div class="title-action-grid">
          <button v-for="action in actions" :key="action.label" v-wave="appWave" type="button" class="title-action-button" :aria-label="action.label">
            <span class="title-action-button__glow"></span>
            <span class="title-action-button__icon" v-html="action.svg"></span>
          </button>
        </div>
      </section>

      <section class="title-description px-2">
        <p><b>خلاصه داستان:</b> {{ title.description || 'توضیحاتی برای این عنوان ثبت نشده است.' }}</p>
      </section>
    </article>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ title: 'عنوان' })
const appWave = useAppWave()
const route = useRoute()
const router = useRouter()
const titleHeader = useTitleHeader()
const loading = ref(true)
const error = ref(false)
const title = ref<any>(null)
let loadVersion = 0
const actions = [
  {
    label: 'پسند',
    svg: '<svg class="size-6" fill="currentColor" viewBox="0 0 24 24"><path d="M2,21H6V9H2M22,10C22,8.89 21.1,8 20,8H14.31L15.26,3.43L15.29,3.14C15.29,2.76 15.13,2.41 14.88,2.17L13.83,1.11L7.59,7.35C7.22,7.72 7,8.23 7,8.78V19C7,20.1 7.9,21 9,21H18C18.83,21 19.54,20.5 19.84,19.78L21.86,14.27C21.95,14.04 22,13.78 22,13.5V10M9,19V9.83L13.17,5.66L12,10H20V13.5L18,19H9Z"></path></svg>'
  },
  {
    label: 'نپسند',
    svg: '<svg class="size-6" fill="currentColor" viewBox="0 0 24 24"><path d="M22,3H18V15H22M2,14C2,15.11 2.9,16 4,16H9.69L8.74,20.57L8.71,20.86C8.71,21.24 8.87,21.59 9.12,21.83L10.17,22.89L16.41,16.65C16.78,16.28 17,15.77 17,15.22V5C17,3.9 16.1,3 15,3H6C5.17,3 4.46,3.5 4.16,4.22L2.14,9.73C2.05,9.96 2,10.22 2,10.5V14M15,5V14.17L10.83,18.34L12,14H4V10.5L6,5H15Z"></path></svg>'
  },
  {
    label: 'افزودن به لیست',
    svg: '<svg class="size-6" fill="currentColor" viewBox="0 0 24 24"><path d="M3,5H14V7H3V5M3,9H14V11H3V9M3,13H10V15H3V13M17,10H19V13H22V15H19V18H17V15H14V13H17V10Z"></path></svg>'
  },
  {
    label: 'نشان کردن',
    svg: '<svg class="size-6" fill="currentColor" viewBox="0 0 24 24"><path d="M17,3H7A2,2 0 0,0 5,5V21L12,18L19,21V5A2,2 0 0,0 17,3M17,18L12,15.82L7,18V5H17V18Z"></path></svg>'
  },
]

const ratingText = computed(() => Number(title.value?.rating || 0).toFixed(1).replace(/\.0$/, ''))
const heroStyle = computed(() => ({ backgroundImage: `url('${title.value?.coverUrl || title.value?.posterUrl || ''}')` }))

function goBack() {
  if (import.meta.client && window.history.length > 1) router.back()
  else navigateTo('/')
}

async function loadTitle(codeValue: unknown) {
  const code = String(Array.isArray(codeValue) ? codeValue[0] : codeValue || '').trim()
  const version = ++loadVersion
  titleHeader.value = { titleFa: '', titleEn: '' }
  title.value = null
  error.value = false

  if (!code) {
    loading.value = false
    error.value = true
    return
  }

  loading.value = true
  try {
    const row = await $fetch(`/api/titles/${encodeURIComponent(code)}`)
    if (version !== loadVersion) return
    title.value = row
    titleHeader.value = { titleFa: title.value?.titleFa || '', titleEn: title.value?.titleEn || '' }
  } catch {
    if (version !== loadVersion) return
    error.value = true
  } finally {
    if (version === loadVersion) loading.value = false
  }
}

watch(() => route.fullPath, () => loadTitle(route.params.code), { immediate: true })

onBeforeUnmount(() => {
  titleHeader.value = { titleFa: '', titleEn: '' }
})
</script>
