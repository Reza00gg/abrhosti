<template>
  <LatestMediaList kind="series" />
</template>

<script setup lang="ts">
definePageMeta({ title: 'جدیدترین سریال ها' })
</script>
