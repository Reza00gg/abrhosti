<template>
  <LatestMediaList kind="movies" />
</template>

<script setup lang="ts">
definePageMeta({ title: 'جدیدترین فیلم ها' })
</script>
