<template>
  <AccountResponsiveShell>
    <div class="account-page-root min-h-[70vh] px-4 pb-10 pt-4 sm:px-6">
      <div class="account-page-inner mx-auto w-full max-w-[520px]">
      <div v-if="loading" class="grid min-h-[260px] place-items-center">
        <Icon icon="lucide:loader-2" class="text-[34px] text-ink-500 animate-spin" />
      </div>
      <div v-else-if="items.length === 0" class="pt-20 text-center">
        <Icon icon="lucide:bell" class="mx-auto text-[40px] text-ink-600" />
        <p class="mt-4 text-[14px] font-bold text-ink-400">اعلانی وجود ندارد</p>
      </div>
      <div v-else class="space-y-3">
        <article v-for="item in items" :key="item.id" class="rounded-xl border p-4" :class="notificationClass(item.type)">
          <div class="absolute -mt-7 rounded-lg px-2 py-1 text-[12px] font-black text-white" :class="item.type === 'subscription_failed' ? 'bg-red-600' : 'bg-emerald-600'">{{ item.title }}</div>
          <p class="pt-2 text-right text-[14px] font-black text-ink-50">{{ item.message }}</p>
          <p class="mt-2 text-right text-[12px] font-medium text-ink-400">{{ formatDate(item.createdAt) }}</p>
        </article>
      </div>
      </div>
    </div>
  </AccountResponsiveShell>
</template>
<script setup lang="ts">
definePageMeta({ title: 'اعلان ها' })
type NotificationItem = { id: number; type: string; title: string; message: string; createdAt: string }
const items = ref<NotificationItem[]>([])
const loading = ref(true)
function notificationClass(type: string) { return type === 'subscription_failed' ? 'border-red-500 bg-red-500/5' : 'border-emerald-500 bg-emerald-500/5' }
function formatDate(value: string) { return new Date(value).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' }) }
onMounted(async () => {
  try {
    const res = await $fetch<{ unread: number; items: NotificationItem[] }>('/api/users/notifications')
    items.value = res.items
    await $fetch('/api/users/notifications/read-all', { method: 'POST' })
  } finally { loading.value = false }
})
</script>
