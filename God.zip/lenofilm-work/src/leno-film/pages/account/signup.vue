<template>
  <div class="min-h-[60vh] flex items-center justify-center px-6 py-10 auth-card">
    <div class="w-full max-w-sm">
      <div class="text-center mb-10">
        <h1 class="text-[24px] font-semibold tracking-tight text-ink-50">ایجاد حساب کاربری</h1>
        <p class="mt-2 text-[13px] text-ink-500">به جمع ما بپیوندید</p>
      </div>
      <form @submit.prevent="handleSubmit" novalidate class="space-y-1">
        <FloatingInput id="signup-name" v-model="name" label="نام نمایشی" type="text" autocomplete="name" required />
        <FloatingInput id="signup-email" v-model="email" label="شماره موبایل یا ایمیل" type="text" autocomplete="username" required />
        <FloatingInput id="signup-password" v-model="password" label="رمز عبور" type="password" autocomplete="new-password" required minlength="6" />
        <FloatingInput id="signup-confirm" v-model="confirmPassword" label="تایید رمز عبور" type="password" autocomplete="new-password" required minlength="6" />
        <button v-wave="appDarkWave" type="submit" :disabled="loading"
          class="auth-primary-button mt-6 w-full h-12 rounded-2xl text-[15px] font-semibold flex items-center justify-center gap-2">
          <svg v-if="loading" class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" opacity="0.25" />
            <path d="M12 2a10 10 0 0110 10" stroke="currentColor" stroke-width="3" stroke-linecap="round" />
          </svg>
          <span>{{ loading ? 'در حال ساخت...' : 'ساخت حساب' }}</span>
        </button>
      </form>
      <div class="mt-6 text-center text-[13px]">
        <span class="text-ink-500">حسابی دارید؟ </span>
        <NuxtLink v-wave="appWave" to="/account/signin" class="text-ink-300 font-medium hover:text-ink-50 transition-colors">وارد شوید</NuxtLink>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ title: 'ثبت‌نام', pageTransition: { name: 'auth-page', mode: 'out-in' } })
import { normalizeIdentifier } from '~/utils/identity'
const auth = useUserAuthStore()
const toast = useToastStore()
const router = useRouter()
const name = ref('')
const email = ref('')
const password = ref('')
const confirmPassword = ref('')
const loading = ref(false)
const appWave = useAppWave()
const appDarkWave = useAppWave('dark')

async function handleSubmit() {
  if (loading.value) return
  if (!name.value.trim()) {
    toast.error('نام نمایشی را وارد کنید')
    return
  }
  const identity = normalizeIdentifier(email.value)
  if (!identity.ok) {
    toast.error(identity.message)
    return
  }
  if (!password.value) {
    toast.error('رمز عبور را وارد کنید')
    return
  }
  if (!confirmPassword.value) {
    toast.error('تایید رمز عبور را وارد کنید')
    return
  }
  if (password.value.length < 6) {
    toast.error('رمز عبور باید حداقل ۶ کاراکتر باشد')
    return
  }
  if (password.value !== confirmPassword.value) {
    toast.error('رمز عبور و تایید آن یکسان نیستند')
    return
  }
  loading.value = true
  await new Promise(r => setTimeout(r, 1200))
  try {
    const result = await auth.signup(name.value.trim(), identity.value, password.value)
    if (result.success) {
      toast.success('حساب شما ساخته شد!')
      await router.push('/account')
    } else {
      toast.error(result.error || 'خطا در ثبت‌نام')
    }
  } catch {
    toast.error('خطای غیرمنتظره')
  } finally {
    loading.value = false
  }
}
</script>
