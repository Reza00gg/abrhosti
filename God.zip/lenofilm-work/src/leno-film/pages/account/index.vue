<template>
  <AccountResponsiveShell>
    <div class="account-page-root min-h-[70vh] px-4 pb-8 pt-6 sm:px-6 sm:pt-8">
      <div class="account-page-inner mx-auto w-full max-w-[520px]">
        <div class="md:hidden">
      <section class="relative overflow-visible px-4 pb-5 pt-7 text-center">
        <div class="relative z-10">
          <div class="mx-auto grid h-[112px] w-[112px] place-items-center overflow-hidden rounded-full bg-ink-900 shadow-[0_14px_42px_rgba(0,0,0,.26)]">
            <img
              v-if="auth.user?.avatarUrl"
              :src="auth.user.avatarUrl"
              :alt="auth.user?.name || 'تصویر پروفایل'"
              draggable="false"
              class="h-full w-full object-cover"
            />
            <Icon v-else icon="lucide:user-round" class="text-[46px] text-ink-300" />
          </div>

          <h1 class="mt-5 text-[19px] font-black tracking-tight text-ink-50">
            {{ auth.user?.name }} خوش آمدید.
          </h1>
          <p class="mx-auto mt-5 max-w-[360px] text-[13px] font-bold leading-7 text-ink-50">
            {{ subscriptionText }}
          </p>
        </div>
      </section>

      <section class="mt-3 grid grid-cols-3 gap-1.5 sm:gap-2">
        <button
          v-for="item in panelItems"
          :key="item.key"
          v-wave="appWave"
          style="color: var(--ripple)"
          type="button"
          class="account-panel-tile relative flex min-h-[88px] select-none flex-col items-center justify-center gap-2 overflow-hidden rounded-xl bg-ink-900/55 px-2 text-center transition-colors hover:bg-ink-900/70"
          @click="handlePanelClick(item)"
        >
          <span v-if="item.badge" class="absolute right-[calc(50%+6px)] top-3 grid min-h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1.5 text-[10px] font-black leading-none text-white">
            {{ item.badge }}
          </span>
          <Icon
            :icon="item.action === 'logout' && loggingOut ? 'lucide:loader-2' : item.icon"
            class="text-[23px] text-ink-50"
            :class="item.action === 'logout' && loggingOut ? 'animate-spin' : ''"
          />
          <span class="text-[12px] font-black leading-5 text-ink-50">{{ item.label }}</span>
        </button>
      </section>
        </div>
        <AccountDashboardTablet class="hidden md:block" />
      </div>
    </div>
  </AccountResponsiveShell>
</template>

<script setup lang="ts">
const appWave = useAppWave()
definePageMeta({ title: 'حساب' })
const auth = useUserAuthStore()
const toast = useToastStore()
const router = useRouter()
const loggingOut = ref(false)
const unreadNotifications = ref(0)

const subscriptionText = computed(() => {
  const expiresAt = auth.user?.subscriptionExpiresAt
  if (!expiresAt) return 'اشتراک فعالی ندارید.'
  const ms = new Date(expiresAt).getTime() - Date.now()
  if (ms <= 0) return 'اشتراک فعالی ندارید.'
  const days = Math.max(1, Math.ceil(ms / (24 * 60 * 60 * 1000)))
  return `اشتراک شما تا ${new Intl.NumberFormat('fa-IR').format(days)} روز فعال است.`
})
const notificationBadge = computed(() => new Intl.NumberFormat('fa-IR').format(unreadNotifications.value))

const panelItems = computed(() => [
  { key: 'subscription', label: 'خرید اشتراک', icon: 'lucide:shopping-cart', to: '/account/subscription' },
  { key: 'purchases', label: 'سوابق خرید', icon: 'lucide:receipt-text', to: '/account/purchases' },
  { key: 'account', label: 'حساب کاربری', icon: 'lucide:id-card', to: '/account/profile' },
  { key: 'notifications', label: 'اعلان ها', icon: 'lucide:bell', badge: notificationBadge.value, to: '/account/notifications' },
  { key: 'likes', label: 'پسندها', icon: 'lucide:thumbs-up' },
  { key: 'watchlist', label: 'لیست تماشا', icon: 'lucide:bookmark', badge: '۰' },
  { key: 'comments', label: 'نظرات', icon: 'lucide:messages-square', badge: '۰' },
  { key: 'history', label: 'آخرین بازدیدها', icon: 'lucide:history' },
  { key: 'playback', label: 'تنظیمات پخش', icon: 'lucide:settings' },
  { key: 'logout', label: 'خروج از حساب', icon: 'lucide:log-out', action: 'logout' },
])

onMounted(async () => {
  try {
    const res = await $fetch<{ unread: number }>('/api/users/notifications')
    unreadNotifications.value = Number(res.unread || 0)
  } catch { unreadNotifications.value = 0 }
})

function handlePanelClick(item: any) {
  if (item.action === 'logout') return handleLogout()
  if (item.to) return navigateTo(item.to)
}

async function handleLogout() {
  if (loggingOut.value) return
  loggingOut.value = true
  await new Promise(resolve => setTimeout(resolve, 450))
  auth.logout()
  await router.push('/account/signin')
}
</script>
