<template>
  <AccountResponsiveShell>
    <div class="account-page-root min-h-[70vh] px-4 pb-10 pt-4 sm:px-6">
      <div class="account-page-inner mx-auto w-full max-w-[520px]">
      <div v-if="loading" class="grid min-h-[260px] place-items-center">
        <Icon icon="lucide:loader-2" class="text-[34px] text-ink-500 animate-spin" />
      </div>
      <div v-else-if="orders.length === 0" class="pt-20 text-center">
        <Icon icon="lucide:receipt-text" class="mx-auto text-[40px] text-ink-600" />
        <p class="mt-4 text-[14px] font-bold text-ink-400">هنوز خریدی ثبت نشده است</p>
      </div>
      <div v-else class="space-y-5 pt-3">
        <article
          v-for="order in orders"
          :key="order.id"
          class="relative min-h-[128px] rounded-lg border-2 px-4 py-4 text-right"
          :class="isSuccess(order) ? 'border-emerald-500 bg-emerald-500/5' : 'border-red-500 bg-red-500/5'"
        >
          <div class="absolute inset-x-0 -top-3 flex justify-center">
            <span class="rounded-md px-2.5 py-1 text-[12px] font-black text-white" :class="isSuccess(order) ? 'bg-emerald-600' : 'bg-red-600'">
              {{ isSuccess(order) ? 'تراکنش موفق' : 'تراکنش ناموفق' }}
            </span>
          </div>
          <div class="space-y-1 pt-3 text-[15px] font-black leading-7 text-ink-50">
            <p>{{ order.planTitle }}</p>
            <p>{{ money(order.finalAmount) }}</p>
            <p>خرید از سایت</p>
            <p>{{ formatDate(order.paidAt || order.createdAt) }}</p>
          </div>
        </article>
      </div>
      </div>
    </div>
  </AccountResponsiveShell>
</template>

<script setup lang="ts">
definePageMeta({ title: 'سوابق خرید' })
type Order = { id: number; planTitle: string; finalAmount: number; status: string; createdAt: string; paidAt?: string | null }
const loading = ref(true)
const orders = ref<Order[]>([])
function isSuccess(order: Order) { return order.status === 'paid' }
function money(value: number) { return `${new Intl.NumberFormat('fa-IR').format(Number(value || 0))} تومان` }
function formatDate(value: string) { return new Date(value).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' }) }
onMounted(async () => {
  try {
    const res = await $fetch<{ items: Order[] }>('/api/subscriptions/orders')
    orders.value = res.items
  } finally { loading.value = false }
})
</script>
