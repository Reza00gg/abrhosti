<template>
  <AccountResponsiveShell>
    <div class="account-page-root min-h-[70vh] px-4 pb-10 pt-4 sm:px-6">
      <div class="account-page-inner mx-auto w-full max-w-[520px]">
      <div v-if="loading" class="grid min-h-[260px] place-items-center">
        <Icon icon="lucide:loader-2" class="text-[34px] text-ink-500 animate-spin" />
      </div>

      <div v-else class="space-y-4 animate-fade-in">
        <template v-if="paymentResult">
          <section class="rounded-lg border-2 p-4 text-right" :class="paymentResult.success ? 'border-emerald-500 bg-emerald-500/5' : 'border-red-500 bg-red-500/5'">
            <div class="-mt-8 mb-3 flex justify-center">
              <span class="rounded-lg px-3 py-1 text-[13px] font-black text-white" :class="paymentResult.success ? 'bg-emerald-600' : 'bg-red-600'">
                {{ paymentResult.success ? 'تراکنش موفق' : 'تراکنش ناموفق' }}
              </span>
            </div>
            <div class="space-y-1 text-[15px] font-black text-ink-50">
              <p>{{ paymentResult.order.planTitle }}</p>
              <p>{{ money(paymentResult.order.finalAmount) }}</p>
              <p>خرید از سایت</p>
              <p>{{ formatDate(paymentResult.order.paidAt || paymentResult.order.createdAt) }}</p>
            </div>
            <p class="mt-4 text-[13px] font-bold leading-7" :class="paymentResult.success ? 'text-emerald-400' : 'text-red-400'">
              {{ paymentResult.success ? 'خرید شما با موفقیت انجام شد و اشتراک برای شما فعال شد.' : 'پرداخت انجام نشد یا توسط کاربر لغو شد.' }}
            </p>
          </section>
          <button v-wave="{ color: 'rgba(255,255,255,.35)' }" type="button" class="account-save-button flex h-12 w-full items-center justify-center rounded-lg text-[14px] font-black" @click="navigateTo('/account')">
            بازگشت به داشبورد
          </button>
        </template>

        <template v-else-if="!confirming">
          <div class="subscription-method-tabs grid grid-cols-2 gap-1 rounded-full bg-ink-900/60 p-1">
            <button
              v-wave="{ color: 'var(--ripple)' }"
              type="button"
              class="h-9 rounded-full text-[13px] font-black transition-colors"
              :class="settings.rialEnabled ? 'bg-[color:var(--color-accent,#5b46ad)] text-white' : 'text-ink-500 opacity-60'"
            >
              درگاه ریالی
            </button>
            <button
              type="button"
              disabled
              class="h-9 cursor-not-allowed rounded-full text-[13px] font-black text-ink-500 opacity-75"
            >
              کارت به کارت
            </button>
          </div>

          <div v-if="!settings.rialEnabled && !settings.cardEnabled" class="rounded-2xl bg-ink-900/55 p-8 text-center">
            <Icon icon="lucide:circle-off" class="mx-auto text-[38px] text-ink-500" />
            <p class="mt-4 text-[14px] font-black text-ink-50">امکان خرید اشتراک وجود ندارد</p>
            <p class="mt-2 text-[12px] font-medium text-ink-500">فعلاً همه روش‌های پرداخت غیرفعال هستند.</p>
          </div>

          <template v-else>
            <div class="space-y-3">
              <button
                v-for="plan in plans"
                :key="plan.id"
                v-wave="appWave"
                style="color: var(--ripple)"
                type="button"
                class="flex min-h-[58px] w-full items-center justify-between rounded-xl border px-4 text-right transition-colors"
                :class="selectedPlanId === plan.id ? 'border-[color:var(--input-border-focus)] bg-ink-900/75' : 'border-[color:var(--hairline)] bg-ink-900/20'"
                @click="selectPlan(plan.id)"
              >
                <div class="flex items-center gap-2">
                  <span class="grid h-5 w-5 place-items-center rounded-full border-2" :class="selectedPlanId === plan.id ? 'border-[color:var(--color-accent,#8d7cff)]' : 'border-ink-500'">
                    <span v-if="selectedPlanId === plan.id" class="h-2.5 w-2.5 rounded-full bg-[color:var(--color-accent,#8d7cff)]"></span>
                  </span>
                  <span class="text-[15px] font-black text-ink-50">{{ plan.title || `${toFa(plan.months)} ماهه` }}</span>
                </div>
                <div class="text-left">
                  <div v-if="plan.discountPercent || plan.discountAmount" class="mb-1 flex items-center justify-end gap-1.5">
                    <span v-if="plan.discountPercent" class="rounded-full bg-red-600 px-2 py-0.5 text-[10px] font-black text-white">٪{{ toFa(plan.discountPercent) }}</span>
                    <span class="text-[11px] font-bold text-ink-500 line-through">{{ money(plan.price + plan.fee) }}</span>
                  </div>
                  <p class="text-[14px] font-black text-ink-50">{{ money(plan.finalPrice) }}</p>
                </div>
              </button>
            </div>

            <div class="flex items-end gap-2 pt-2">
              <button
                v-wave="{ color: 'rgba(255,255,255,.35)' }"
                type="button"
                :disabled="discountChecking"
                class="h-10 shrink-0 rounded-lg bg-blue-700 px-4 text-[13px] font-black text-white disabled:opacity-60"
                @click="checkDiscount"
              >
                {{ discountChecking ? '...' : 'بررسی کد' }}
              </button>
              <div class="relative flex-1 pt-2">
                <input v-model="discountCode" class="account-profile-input px-3" placeholder="کد خود را وارد کنید" dir="ltr" />
                <label class="absolute right-3 top-0 rounded-full bg-ink-950 px-1.5 text-[11px] font-black text-ink-50">کد تخفیف</label>
              </div>
            </div>
            <p v-if="discountMessage" class="text-right text-[12px] font-bold" :class="discountValid ? 'text-emerald-400' : 'text-rose-400'">{{ discountMessage }}</p>

            <button
              v-wave="{ color: 'rgba(255,255,255,.35)' }"
              type="button"
              class="account-save-button flex h-12 w-full items-center justify-center gap-2 rounded-lg text-[14px] font-black"
              @click="submitOrder"
            >
              <Icon icon="lucide:shopping-cart" class="text-[20px]" />
              ثبت
            </button>
          </template>
        </template>

        <template v-else>
          <div class="subscription-validity-box rounded-lg px-4 py-3 text-center text-[13px] font-black leading-7">
            حساب شما تا تاریخ {{ expiryText }} دارای اعتبار می‌باشد و در صورت خرید اشتراک جدید، به این مدت زمان اضافه خواهد شد.
          </div>

          <section class="pt-1 text-right">
            <h2 class="mb-3 text-[17px] font-black text-ink-50">نکات مهم خرید اشتراک:</h2>
            <ul class="space-y-2 text-[13px] font-bold leading-7 text-ink-50">
              <li class="flex gap-2"><span>•</span><span>خرید اشتراک بلافاصله بعد خرید از طریق درگاه ریالی فعال میشود و تاخیری در زمان فعال سازی وجود ندارد</span></li>
              <li class="flex gap-2"><span>•</span><span>در صورت کسر از موجودی حساب بانکی و عدم فعال شدن اشتراک، مبلغ پرداخت شده به صورت خودکار توسط بانک عودت داده میشود در غیر این صورت با پشتیبانی پیگیری کنید</span></li>
              <li class="flex gap-2"><span>•</span><span>پس از پرداخت به طور خودکار به همین صفحه بازگردانده میشوید</span></li>
            </ul>
          </section>

          <section class="subscription-summary-card rounded-lg p-4">
            <div class="flex items-center gap-3 pb-5">
              <Icon icon="lucide:circle-user-round" class="shrink-0 text-[22px] text-ink-400" />
              <div class="min-w-0 flex-1 text-right">
                <p class="truncate text-[17px] font-black text-ink-50" dir="ltr">{{ accountIdentity }}</p>
                <p class="mt-1 text-[12px] font-medium text-ink-500">حساب کاربری</p>
              </div>
            </div>

            <div class="flex items-center gap-3 pb-5">
              <Icon icon="lucide:shopping-cart" class="shrink-0 text-[24px] text-ink-400" />
              <div class="min-w-0 flex-1 text-right">
                <p class="truncate text-[21px] font-black text-ink-50">{{ selectedPlanTitle }}</p>
                <p class="mt-1 text-[12px] font-medium text-ink-500">اشتراک انتخابی</p>
              </div>
            </div>

            <div v-if="discountValid && appliedDiscountAmount > 0" class="flex items-center gap-3 pb-5">
              <Icon icon="lucide:badge-percent" class="shrink-0 text-[24px] text-ink-400" />
              <div class="min-w-0 flex-1 text-right">
                <p class="truncate text-[18px] font-black text-emerald-400">{{ money(appliedDiscountAmount) }}</p>
                <p class="mt-1 text-[12px] font-medium text-ink-500">تخفیف اعمال شده</p>
              </div>
            </div>

            <div class="flex items-center gap-3">
              <Icon icon="lucide:banknote" class="shrink-0 text-[24px] text-ink-400" />
              <div class="min-w-0 flex-1 text-right">
                <p class="truncate text-[21px] font-black text-ink-50">{{ money(payableAmount) }}</p>
                <p class="mt-1 text-[12px] font-medium text-ink-500">مبلغ خرید اشتراک</p>
              </div>
            </div>
          </section>

          <div class="grid grid-cols-[1fr_132px] gap-2">
            <button
              v-wave="{ color: 'rgba(255,255,255,.35)' }"
              type="button"
              :disabled="paymentLoading"
              class="account-save-button flex h-12 items-center justify-center gap-2 rounded-lg text-[14px] font-black disabled:cursor-not-allowed disabled:opacity-60"
              @click="pay"
            >
              <Icon :icon="paymentLoading ? 'lucide:loader-2' : 'lucide:credit-card'" class="text-[19px]" :class="paymentLoading ? 'animate-spin' : ''" />
              {{ paymentLoading ? 'در حال انتقال...' : 'پرداخت' }}
            </button>
            <button
              v-wave="{ color: 'rgba(255,255,255,.32)' }"
              type="button"
              class="flex h-12 items-center justify-center gap-2 rounded-lg bg-orange-600 text-[14px] font-black text-white"
              @click="goBackToPlans"
            >
              بازگشت
              <Icon icon="lucide:arrow-left" class="text-[19px]" />
            </button>
          </div>
        </template>
      </div>
      </div>
    </div>
  </AccountResponsiveShell>
</template>

<script setup lang="ts">
definePageMeta({ title: 'خرید اشتراک' })
const appWave = useAppWave()
const toast = useToastStore()
const auth = useUserAuthStore()
const route = useRoute()

type Plan = { id: number; title: string; months: number; price: number; fee: number; discountPercent: number; discountAmount: number; active: boolean; finalPrice: number }
type Settings = { rialEnabled: boolean; cardEnabled: boolean }
type OrderResult = { order: { id: number; planTitle: string; finalAmount: number; status: string; createdAt: string; paidAt?: string | null }; success: boolean }

const loading = ref(true)
const plans = ref<Plan[]>([])
const settings = reactive<Settings>({ rialEnabled: true, cardEnabled: false })
const selectedPlanId = ref<number | null>(null)
const discountCode = ref('')
const discountChecking = ref(false)
const discountMessage = ref('')
const discountValid = ref(false)
const appliedDiscountAmount = ref(0)
const confirming = ref(false)
const paymentLoading = ref(false)
const paymentResult = ref<OrderResult | null>(null)
const returnedFromPayment = ref(false)

const selectedPlan = computed(() => plans.value.find(plan => plan.id === selectedPlanId.value) || null)
const selectedPlanTitle = computed(() => selectedPlan.value?.title || (selectedPlan.value ? `${toFa(selectedPlan.value.months)} ماهه` : '—'))
const payableAmount = computed(() => Math.max(0, Number(selectedPlan.value?.finalPrice || 0) - Number(appliedDiscountAmount.value || 0)))
const accountIdentity = computed(() => auth.user?.email || auth.user?.contactEmail || '—')
const expiryText = computed(() => {
  const date = new Date()
  date.setMonth(date.getMonth() + Number(selectedPlan.value?.months || 0))
  const day = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(date)
  const time = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { hour: '2-digit', minute: '2-digit', hour12: false }).format(date)
  return `${time} | ${day}`
})

function toFa(value: number) { return new Intl.NumberFormat('fa-IR').format(value) }
function money(value: number) { return `${toFa(Number(value || 0))} تومان` }
function formatDate(value: string) { return new Date(value).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' }) }
function resetDiscountState() {
  discountMessage.value = ''
  discountValid.value = false
  appliedDiscountAmount.value = 0
}
function selectPlan(id: number) {
  selectedPlanId.value = id
  resetDiscountState()
}

async function loadSubscriptions() {
  loading.value = true
  try {
    const res = await $fetch<{ settings: Settings; plans: Plan[] }>('/api/subscriptions')
    Object.assign(settings, res.settings)
    plans.value = res.plans
    selectedPlanId.value = res.plans[0]?.id || null
  } catch {
    toast.error('خطا در دریافت پلن‌های اشتراک')
  } finally {
    loading.value = false
  }
}

async function checkDiscount() {
  if (!discountCode.value.trim()) return toast.error('کد تخفیف را وارد کنید')
  if (!selectedPlanId.value) return toast.error('یک پلن انتخاب کنید')
  discountChecking.value = true
  discountMessage.value = ''
  discountValid.value = false
  appliedDiscountAmount.value = 0
  try {
    const res = await $fetch<{ success: boolean; amount: number }>('/api/subscriptions/discount', {
      method: 'POST',
      body: { code: discountCode.value, planId: selectedPlanId.value },
    })
    discountValid.value = true
    appliedDiscountAmount.value = Number(res.amount || 0)
    discountMessage.value = `کد معتبر است؛ ${money(res.amount)} تخفیف اعمال می‌شود.`
  } catch (err: any) {
    discountMessage.value = err?.data?.statusMessage || err?.statusMessage || 'کد تخفیف معتبر نیست'
  } finally {
    discountChecking.value = false
  }
}

function submitOrder() {
  if (!selectedPlan.value) return toast.error('یک پلن انتخاب کنید')
  confirming.value = true
}
function goBackToPlans() {
  confirming.value = false
}

function handleHeaderBack(event: Event) {
  if (paymentResult.value || returnedFromPayment.value) {
    event.preventDefault()
    navigateTo('/account')
    return
  }
  if (!confirming.value) return
  event.preventDefault()
  goBackToPlans()
}

async function pay() {
  if (paymentLoading.value) return
  if (!selectedPlan.value) return toast.error('یک پلن انتخاب کنید')
  paymentLoading.value = true
  try {
    const res = await $fetch<{ orderId: number; gatewayUrl: string }>('/api/subscriptions/orders', {
      method: 'POST',
      body: { planId: selectedPlan.value.id, discountCode: discountValid.value ? discountCode.value : undefined },
    })
    window.location.href = res.gatewayUrl
  } catch (err: any) {
    toast.error(err?.data?.statusMessage || err?.statusMessage || 'شروع پرداخت انجام نشد')
    paymentLoading.value = false
  }
}

async function loadPaymentResult(orderId: number) {
  const res = await $fetch<{ order: any; subscriptionExpiresAt: string | null }>(`/api/subscriptions/orders/${orderId}`)
  paymentResult.value = { order: res.order, success: res.order.status === 'paid' }
  auth.setUserPatch({ subscriptionExpiresAt: res.subscriptionExpiresAt })
}

function cleanResultUrl() {
  if (!import.meta.client) return
  window.history.replaceState(window.history.state, '', '/account/subscription')
}

async function bootPage() {
  const orderId = Number(route.query.orderId)
  const payment = String(route.query.payment || '')
  if (orderId || payment) returnedFromPayment.value = true
  const seenKey = orderId ? `leno-subscription-result-${orderId}` : ''
  const alreadySeen = seenKey && import.meta.client ? localStorage.getItem(seenKey) === '1' : false

  if (orderId && payment === 'success' && !alreadySeen) {
    try {
      await loadPaymentResult(orderId)
      if (paymentResult.value?.success) {
        if (seenKey) localStorage.setItem(seenKey, '1')
        cleanResultUrl()
        loading.value = false
        return
      }
      paymentResult.value = null
    } catch {
      // اگر سفارش متعلق به کاربر نبود یا پیدا نشد، صفحه معمولی نشان داده شود.
    }
  }

  if (orderId || payment) cleanResultUrl()
  await loadSubscriptions()
}

onMounted(async () => {
  window.addEventListener('leno-subscription-back', handleHeaderBack)
  await bootPage()
})
onBeforeUnmount(() => window.removeEventListener('leno-subscription-back', handleHeaderBack))
</script>
