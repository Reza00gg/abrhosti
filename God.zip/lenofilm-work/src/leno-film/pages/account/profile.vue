<template>
  <AccountResponsiveShell>
    <div class="account-page-root min-h-[70vh] px-4 pb-10 pt-4 sm:px-6">
      <div class="account-page-inner mx-auto w-full max-w-[520px]">
      <div v-if="loading" class="grid min-h-[260px] place-items-center">
        <Icon icon="lucide:loader-2" class="text-[34px] text-ink-500 animate-spin" />
      </div>

      <div v-else class="space-y-2 animate-fade-in">
        <section>
          <button
            v-wave="profileWave"
            type="button"
            class="flex h-14 w-full select-none items-center justify-between overflow-hidden rounded-xl px-1 text-right"
            @click="togglePanel('account')"
          >
            <span class="flex min-w-0 items-center gap-2 text-[15px] font-black text-ink-50">
              <Icon icon="lucide:id-card" class="shrink-0 text-[21px] text-ink-50" />
              <span class="truncate">اطلاعات حساب کاربری</span>
            </span>
            <Icon :icon="activePanel === 'account' ? 'lucide:arrow-down' : 'lucide:arrow-left'" class="shrink-0 text-[22px] text-ink-50" />
          </button>

          <Transition name="account-panel-slide">
            <div v-if="activePanel === 'account'" class="space-y-5 pb-3 pt-1">
              <div v-if="primaryIsMobile">
                <label class="mb-1 block pe-1 text-right text-[13px] font-black text-ink-50">شماره موبایل</label>
                <input :value="profile.email" disabled dir="ltr" class="account-profile-input" />
                <p class="mt-2 text-right text-[11px] font-medium leading-5 text-ink-400">امکان ویرایش شماره موبایل وجود ندارد.</p>
              </div>

              <div>
                <label class="mb-1 block pe-1 text-right text-[13px] font-black text-ink-50">آدرس ایمیل</label>
                <input v-model="contactEmail" :disabled="!canEditContactEmail" dir="ltr" class="account-profile-input" />
                <p class="mt-2 text-right text-[11px] font-medium leading-5 text-ink-400">{{ emailHelpText }}</p>
              </div>

              <div>
                <label class="mb-1 block pe-1 text-right text-[13px] font-black text-ink-50">نام نمایشی عمومی</label>
                <input v-model="displayName" dir="rtl" class="account-profile-input" />
                <p class="mt-2 text-right text-[11px] font-medium leading-5 text-ink-400">این نام در سایت و اپلیکیشن نمایش داده خواهد شد.</p>
              </div>

              <button
                v-wave="saveWave"
                type="button"
                :disabled="saving"
                class="account-save-button mt-2 flex h-12 w-full items-center justify-center gap-2 rounded-lg text-[14px] font-black disabled:cursor-not-allowed disabled:opacity-60"
                @click="saveProfile"
              >
                <Icon v-if="saving" icon="lucide:loader-2" class="text-[17px] animate-spin" />
                <span>{{ saving ? 'در حال ذخیره...' : 'ذخیره' }}</span>
              </button>
            </div>
          </Transition>
        </section>

        <section>
          <button
            v-wave="profileWave"
            type="button"
            class="flex h-14 w-full select-none items-center justify-between overflow-hidden rounded-xl px-1 text-right"
            @click="togglePanel('avatar')"
          >
            <span class="flex min-w-0 items-center gap-2 text-[15px] font-black text-ink-50">
              <Icon icon="lucide:user-circle" class="shrink-0 text-[21px] text-ink-50" />
              <span class="truncate">انتخاب پروفایل</span>
            </span>
            <Icon :icon="activePanel === 'avatar' ? 'lucide:arrow-down' : 'lucide:arrow-left'" class="shrink-0 text-[22px] text-ink-50" />
          </button>

          <Transition name="account-panel-slide">
            <div v-if="activePanel === 'avatar'" class="grid grid-cols-4 justify-items-center gap-y-3 pb-3 pt-2">
              <button
                v-for="avatar in avatarOptions"
                :key="avatar.src"
                v-wave="avatarWave"
                type="button"
                :disabled="avatarSaving"
                class="relative h-[74px] w-[74px] overflow-hidden rounded-full bg-ink-900/70 disabled:opacity-60 sm:h-[84px] sm:w-[84px]"
                :class="selectedAvatar === avatar.src ? 'ring-4 ring-rose-500' : ''"
                :aria-label="avatar.label"
                @click="selectAvatar(avatar.src)"
              >
                <span v-if="!loadedAvatars[avatar.src]" class="absolute inset-0 grid place-items-center">
                  <Icon icon="lucide:image" class="pointer-events-none text-[24px] text-ink-300" />
                </span>
                <img
                  :src="avatar.src"
                  :alt="avatar.label"
                  draggable="false"
                  class="pointer-events-none absolute inset-0 h-full w-full object-cover transition-opacity duration-300"
                  :class="loadedAvatars[avatar.src] ? 'opacity-100' : 'opacity-0'"
                  @load="loadedAvatars[avatar.src] = true"
                />
                <span v-if="avatarSaving && savingAvatarSrc === avatar.src" class="absolute inset-0 grid place-items-center bg-black/35">
                  <Icon icon="lucide:loader-2" class="text-[26px] text-white animate-spin" />
                </span>
              </button>
            </div>
          </Transition>
        </section>

        <section>
          <button
            v-wave="profileWave"
            type="button"
            class="flex h-14 w-full select-none items-center justify-between overflow-hidden rounded-xl px-1 text-right"
            @click="togglePanel('password')"
          >
            <span class="flex min-w-0 items-center gap-2 text-[15px] font-black text-ink-50">
              <Icon icon="lucide:lock" class="shrink-0 text-[21px] text-ink-50" />
              <span class="truncate">تغییر رمز عبور</span>
            </span>
            <Icon :icon="activePanel === 'password' ? 'lucide:arrow-down' : 'lucide:arrow-left'" class="shrink-0 text-[22px] text-ink-50" />
          </button>

          <Transition name="account-panel-slide">
            <div v-if="activePanel === 'password'" class="space-y-5 pb-3 pt-1">
              <div>
                <label class="mb-1 block pe-1 text-right text-[13px] font-black text-ink-50">رمز فعلی</label>
                <input v-model="currentPassword" type="password" autocomplete="current-password" class="account-profile-input" />
              </div>

              <div>
                <label class="mb-1 block pe-1 text-right text-[13px] font-black text-ink-50">رمز جدید</label>
                <input v-model="newPassword" type="password" autocomplete="new-password" class="account-profile-input" />
              </div>

              <div>
                <label class="mb-1 block pe-1 text-right text-[13px] font-black text-ink-50">تکرار رمز</label>
                <input v-model="confirmPassword" type="password" autocomplete="new-password" class="account-profile-input" />
              </div>

              <button
                v-wave="saveWave"
                type="button"
                :disabled="passwordSaving"
                class="account-save-button mt-2 flex h-12 w-full items-center justify-center gap-2 rounded-lg text-[14px] font-black disabled:cursor-not-allowed disabled:opacity-60"
                @click="changePassword"
              >
                <Icon v-if="passwordSaving" icon="lucide:loader-2" class="text-[17px] animate-spin" />
                <span>{{ passwordSaving ? 'در حال تغییر...' : 'تغییر رمز عبور' }}</span>
              </button>
            </div>
          </Transition>
        </section>
      </div>
      </div>
    </div>
  </AccountResponsiveShell>
</template>

<script setup lang="ts">
definePageMeta({ title: 'حساب کاربری' })
const appWave = useAppWave()
const profileWave = {
  color: 'var(--ripple)',
  initialOpacity: 0.42,
  finalOpacity: 0.04,
  duration: 0.72,
  dissolveDuration: 0.18,
  easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
}
const avatarWave = {
  color: 'rgba(255,255,255,.42)',
  initialOpacity: 0.48,
  finalOpacity: 0.06,
  duration: 0.62,
  dissolveDuration: 0.16,
  easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
}
const saveWave = {
  color: 'currentColor',
  initialOpacity: 0.52,
  finalOpacity: 0.08,
  duration: 0.72,
  dissolveDuration: 0.18,
  easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
}
const auth = useUserAuthStore()
const toast = useToastStore()

type ProfileResponse = {
  id: number
  name: string
  email: string
  contactEmail?: string | null
  avatarUrl?: string | null
  avatarMime?: string | null
  subscriptionExpiresAt?: string | Date | null
  createdAt?: string | Date | null
}
type PanelName = 'account' | 'avatar' | 'password'

const loading = ref(true)
const saving = ref(false)
const passwordSaving = ref(false)
const avatarSaving = ref(false)
const savingAvatarSrc = ref('')
const activePanel = ref<PanelName | null>(null)
const profile = reactive<ProfileResponse>({ id: 0, name: '', email: '', contactEmail: '', avatarUrl: '' })
const displayName = ref('')
const contactEmail = ref('')
const currentPassword = ref('')
const newPassword = ref('')
const confirmPassword = ref('')
const loadedAvatars = reactive<Record<string, boolean>>({})
const avatarOptions = [
  { src: '/api/avatars/24', label: 'آواتار لنوفیلم ۱' },
  { src: '/api/avatars/25', label: 'آواتار لنوفیلم ۲' },
]

const selectedAvatar = computed(() => profile.avatarUrl || auth.user?.avatarUrl || '')
const primaryIsMobile = computed(() => /^09\d{9}$/.test(profile.email || ''))
const canEditContactEmail = computed(() => primaryIsMobile.value && !profile.contactEmail)
const emailHelpText = computed(() => {
  if (!primaryIsMobile.value) return 'امکان ویرایش ایمیل وجود ندارد.'
  if (profile.contactEmail) return 'ایمیل ثبت شده است و امکان ویرایش آن وجود ندارد.'
  return 'ایمیل در زمان فراموشی رمز عبور استفاده خواهد شد. پس از ثبت ایمیل می‌توانید به عنوان نام کاربری نیز از آن استفاده کنید.'
})

function togglePanel(panel: PanelName) {
  activePanel.value = activePanel.value === panel ? null : panel
}

async function loadProfile() {
  loading.value = true
  try {
    const startedAt = Date.now()
    const row = await $fetch<ProfileResponse>('/api/users/profile')
    Object.assign(profile, row)
    displayName.value = row.name || ''
    contactEmail.value = row.contactEmail || (!/^09\d{9}$/.test(row.email || '') ? row.email : '')
    auth.setUserPatch({ name: row.name, email: row.email, contactEmail: row.contactEmail, avatarUrl: row.avatarUrl, avatarMime: row.avatarMime, createdAt: row.createdAt })
    const elapsed = Date.now() - startedAt
    if (elapsed < 280) await new Promise(resolve => setTimeout(resolve, 280 - elapsed))
  } catch (err: any) {
    toast.error(err?.data?.statusMessage || err?.statusMessage || 'خطا در دریافت اطلاعات حساب')
  } finally {
    loading.value = false
  }
}

async function saveProfile() {
  if (saving.value) return
  saving.value = true
  try {
    const result = await auth.updateProfile({ name: displayName.value, contactEmail: canEditContactEmail.value ? contactEmail.value : undefined })
    if (!result.success) {
      toast.error(result.error || 'خطا در ذخیره اطلاعات حساب')
      return
    }
    profile.name = displayName.value.trim()
    if (canEditContactEmail.value && contactEmail.value.trim()) profile.contactEmail = contactEmail.value.trim().toLowerCase()
    toast.success('اطلاعات حساب ذخیره شد')
  } finally {
    saving.value = false
  }
}


async function changePassword() {
  if (passwordSaving.value) return
  if (!currentPassword.value) return toast.error('رمز عبور فعلی را وارد کنید')
  if (!newPassword.value) return toast.error('رمز عبور جدید را وارد کنید')
  if (newPassword.value.length < 6) return toast.error('رمز عبور جدید باید حداقل ۶ کاراکتر باشد')
  if (newPassword.value !== confirmPassword.value) return toast.error('رمز عبور جدید و تکرار آن یکسان نیستند')

  passwordSaving.value = true
  try {
    await $fetch('/api/users/password', {
      method: 'PUT',
      body: {
        currentPassword: currentPassword.value,
        newPassword: newPassword.value,
        confirmPassword: confirmPassword.value,
      }
    })
    currentPassword.value = ''
    newPassword.value = ''
    confirmPassword.value = ''
    toast.success('رمز عبور تغییر کرد')
  } catch (err: any) {
    toast.error(err?.data?.statusMessage || err?.statusMessage || 'خطا در تغییر رمز عبور')
  } finally {
    passwordSaving.value = false
  }
}

async function selectAvatar(src: string) {
  if (avatarSaving.value || selectedAvatar.value === src) return
  avatarSaving.value = true
  savingAvatarSrc.value = src
  try {
    const result = await auth.updateAvatar(src)
    if (!result.success) {
      toast.error(result.error || 'خطا در ذخیره آواتار')
      return
    }
    profile.avatarUrl = src
    profile.avatarMime = 'image/jpeg'
    toast.success('آواتار ذخیره شد')
  } finally {
    avatarSaving.value = false
    savingAvatarSrc.value = ''
  }
}

onMounted(loadProfile)
</script>
