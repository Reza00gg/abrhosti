# 🎬 لنوفیلم - LenoFilm

> پلتفرم حرفه‌ای تماشای فیلم و سریال - Web Application

[![Nuxt](https://img.shields.io/badge/Nuxt-4.0-00DC82?logo=nuxt.js)](https://nuxt.com)
[![Vue](https://img.shields.io/badge/Vue-3.5-4FC08D?logo=vue.js)](https://vuejs.org)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.7-3178C6?logo=typescript)](https://www.typescriptlang.org)
[![TailwindCSS](https://img.shields.io/badge/TailwindCSS-3.4-38B2AC?logo=tailwind-css)](https://tailwindcss.com)
[![Vercel](https://img.shields.io/badge/Deployed_on-Vercel-000?logo=vercel)](https://vercel.com)

## ✨ ویژگی‌ها

- 🎨 **UI/UX مدرن** - طراحی الهام‌گرفته از اپلیکیشن‌های موبایل
- 📱 **کاملاً Responsive** - موبایل، تبلت و دسکتاپ
- ⚡ **SPA Mode** - بدون رفرش هنگام تغییر صفحه
- 🌟 **Bottom Navigation** - منوی پایین با ریپل افکت
- 🔍 **ریسپانسیو حرفه‌ای** - تجربه‌ی یکپارچه در همه دستگاه‌ها
- 🎭 **انیمیشن‌های نرم** - با CSS keyframes سفارشی
- 🌙 **Dark Theme** - طراحی مدرن و شیک
- 🇮🇷 **فارسی RTL** - با فونت وزیرمتن

## 🛠️ تکنولوژی‌ها

| لایه | تکنولوژی |
|------|----------|
| Framework | Nuxt 4 (Vue 3 + Vite) |
| Language | TypeScript |
| Styling | TailwindCSS 3.4 |
| State | Pinia |
| Icons | Iconify (Lucide) + Material Symbols |
| Animations | v-wave + Custom Ripple CSS |
| Font | Vazirmatn |
| Backend | Nuxt Nitro (Server) |
| DB | PostgreSQL (Neon) - فاز بعدی |
| Auth | Lucia / Sidebase - فاز بعدی |
| Payment | ZarinPal + Zibal - فاز بعدی |
| Deployment | Vercel |

## 📂 ساختار پروژه

```
leno-film/
├── app.vue                    # ریشه اپ
├── layouts/
│   └── default.vue            # Layout اصلی (هدر + محتوا + منو)
├── pages/
│   ├── index.vue              # خانه
│   ├── search.vue             # جستجو
│   ├── discover.vue           # دیسکاور
│   └── account.vue            # حساب
├── components/
│   ├── AppHeader.vue          # هدر بالا (منو + لوگو + تم)
│   ├── BottomNav.vue          # منوی پایین
│   └── ComingSoon.vue         # کامپوننت بزودی
├── assets/
│   └── css/main.css           # استایل‌های全局 + Ripple + Glass
├── public/
│   └── favicon.svg
├── nuxt.config.ts             # پیکربندی Nuxt
├── tailwind.config.js         # پیکربندی Tailwind
└── package.json
```

## 🚈 دستورات

```bash
# نصب وابستگی‌ها
npm install --legacy-peer-deps

# اجرای Development Server
npm run dev          # → http://localhost:3000

# بیلد Production
npm run build        # → .vercel/output/

# Preview
npm run preview
```

## 🎯 نقشه راه

- [x] **فاز 1** - راه‌اندازی + UI پایه (هدر، منو، صفحات بزودی)
- [ ] **فاز 2** - اتصال به TMDB API + نمایش فیلم‌ها
- [ ] **فاز 3** - صفحه جزئیات فیلم + پخش
- [ ] **فاز 4** - احراز هویت (SMS + Email)
- [ ] **فاز 5** - سیستم اشتراک + پرداخت (ZarinPal/Zibal)
- [ ] **فاز 6** - پنل مدیریت (`/adminChash7nakg`)
- [ ] **فاز 7** - نظرات + امتیازدهی
- [ ] **فاز 8** - دیتابیس PostgreSQL (Neon)
- [ ] **فاز 9** - بهینه‌سازی + SEO + PWA

## 🌐 لینک‌ها

- 🌟 **Production**: https://leno-film.vercel.app
- 🛠️ **Vercel Dashboard**: https://vercel.com/dashboard
- 📦 **Repo**: (بعد از اضافه کردن Git)

---

ساخته شده با ❤️ توسط **Arena.ai Agent**
