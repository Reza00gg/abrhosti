const { chromium } = require('playwright')
;(async () => {
const base = 'https://leno-film.vercel.app'
const browser = await chromium.launch({ headless: true })
const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true })
function log(name, value) { console.log(`${name}=${value}`) }
await page.goto(base, { waitUntil: 'networkidle', timeout: 60000 })
const slider = page.locator('section').filter({ hasText: 'تماشا آنلاین' }).first()
const sliderVisible = await slider.isVisible().catch(() => false)
log('SLIDER_VISIBLE', sliderVisible)
if (!sliderVisible) { await browser.close(); return }
const titleLocator = slider.locator('h2').first()
await titleLocator.waitFor({ state: 'visible', timeout: 10000 })
const title0 = (await titleLocator.textContent()).trim()
log('INITIAL_TITLE', title0)
await page.waitForTimeout(2500)
const titleAfter25 = (await titleLocator.textContent()).trim()
log('TITLE_AFTER_2_5S', titleAfter25)
log('NO_EARLY_AUTOPLAY', titleAfter25 === title0)
await page.waitForTimeout(3600)
const titleAfter61 = (await titleLocator.textContent()).trim()
log('TITLE_AFTER_6_1S', titleAfter61)
const slideCount = await page.evaluate(async () => (await (await fetch('/api/featured')).json()).length)
log('FEATURED_COUNT', slideCount)
log('AUTOPLAY_MOVED_WHEN_MULTIPLE', slideCount > 1 ? titleAfter61 !== title0 : true)
const box = await slider.boundingBox(); if (!box) throw new Error('No slider bounding box')
const y = box.y + box.height / 2
const xStart = box.x + box.width * 0.30
const xEnd = box.x + box.width * 0.78
await page.mouse.move(xStart, y); await page.mouse.down(); await page.mouse.move(xEnd, y, { steps: 12 }); await page.mouse.up(); await page.waitForTimeout(900)
const titleAfterSwipeRight = (await titleLocator.textContent()).trim()
log('TITLE_AFTER_SWIPE_RIGHT', titleAfterSwipeRight)
log('SWIPE_RIGHT_CHANGED_WHEN_MULTIPLE', slideCount > 1 ? titleAfterSwipeRight !== titleAfter61 : true)
await page.mouse.move(xEnd, y); await page.mouse.down(); await page.mouse.move(xStart, y, { steps: 12 }); await page.mouse.up(); await page.waitForTimeout(900)
const titleAfterSwipeLeft = (await titleLocator.textContent()).trim()
log('TITLE_AFTER_SWIPE_LEFT', titleAfterSwipeLeft)
log('SWIPE_LEFT_CHANGED_WHEN_MULTIPLE', slideCount > 1 ? titleAfterSwipeLeft !== titleAfterSwipeRight : true)
for (let i = 0; i < 4; i++) { await page.mouse.move(xStart, y); await page.mouse.down(); await page.mouse.move(xEnd, y, { steps: 8 }); await page.mouse.up(); await page.waitForTimeout(650) }
const titleAfterRapid = (await titleLocator.textContent()).trim()
log('TITLE_AFTER_RAPID_SWIPES', titleAfterRapid)
log('NOT_LOCKED_AFTER_RAPID_SWIPES', Boolean(titleAfterRapid))
await browser.close()
})().catch(async e => { console.error(e); process.exit(1) })
