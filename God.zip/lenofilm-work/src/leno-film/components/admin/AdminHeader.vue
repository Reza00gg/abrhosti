<template>
  <header class="fixed top-0 inset-x-0 z-30 h-[60px] bg-[#0a0a0a] border-b border-[#1f1f1f]">
    <div class="h-full max-w-screen-2xl mx-auto px-4 flex items-center justify-between">

      <!-- Right: Hamburger -->
      <button
        v-wave
        style="color: rgba(255, 255, 255, 0.45)"
        @click="ui.toggleAdminDrawer()"
        class="btn-press group w-10 h-10 flex items-center justify-center rounded-lg hover:bg-[#18181b] transition-colors"
        aria-label="منو"
      >
        <Icon icon="lucide:menu" class="text-[22px] text-[#a1a1aa] group-hover:text-[#fafafa] transition-colors" />
      </button>

      <!-- Center: Title (only on dashboard) -->
      <div class="absolute left-1/2 -translate-x-1/2 text-sm font-medium text-[#fafafa]">
        پنل مدیریت
      </div>

      <!-- Left: Logout -->
      <button
        v-wave
        style="color: rgba(255, 255, 255, 0.45)"
        @click="handleLogout"
        class="btn-press group flex items-center gap-2 h-10 px-3 rounded-lg hover:bg-[#18181b] transition-colors"
        aria-label="خروج"
      >
        <Icon icon="lucide:log-out" class="text-[18px] text-[#a1a1aa] group-hover:text-[#ef4444] transition-colors" />
        <span class="text-[13px] text-[#a1a1aa] group-hover:text-[#fafafa] transition-colors hidden sm:inline">خروج</span>
      </button>

    </div>
  </header>
</template>

<script setup lang="ts">
const auth = useAuthStore()
const ui = useUIStore()
const toast = useToastStore()
const router = useRouter()

function handleLogout() {
  auth.logout()
  ui.closeAdminDrawer()
  toast.info('با موفقیت خارج شدید')
  router.push('/adminChash7nakg')
}
</script>
