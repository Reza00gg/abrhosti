<template>
  <div ref="menuRef" class="relative shrink-0">
    <button
      v-wave
      type="button"
      title="گزینه‌ها"
      @click="open = !open"
      class="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] text-[#a1a1aa] hover:text-[#fafafa] transition-colors"
    >
      <Icon icon="lucide:more-vertical" class="text-[16px]" />
    </button>

    <Transition name="admin-user-menu">
      <div v-if="open" class="absolute left-0 top-10 z-30 w-44 overflow-hidden rounded-xl border border-[#1f1f1f] bg-[#0a0a0a] shadow-2xl">
        <button
          v-if="tab !== 'deleted'"
          v-wave
          type="button"
          @click="selectAction(user.banned ? 'unban' : 'ban')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#fafafa] transition-colors hover:bg-[#18181b]"
        >
          <Icon :icon="user.banned ? 'lucide:check-circle' : 'lucide:ban'" class="text-[15px]" />
          <span>{{ user.banned ? 'فعال کردن' : 'غیرفعال کردن' }}</span>
        </button>

        <button
          v-if="tab !== 'deleted'"
          v-wave
          type="button"
          @click="selectAction('reset')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#fafafa] transition-colors hover:bg-[#18181b]"
        >
          <Icon icon="lucide:refresh-ccw" class="text-[15px]" />
          <span>ریست</span>
        </button>

        <button
          v-if="tab !== 'deleted'"
          v-wave
          type="button"
          @click="selectAction('delete')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#fca5a5] transition-colors hover:bg-[#18181b]"
        >
          <Icon icon="lucide:trash-2" class="text-[15px]" />
          <span>حذف</span>
        </button>

        <button
          v-if="tab === 'deleted'"
          v-wave
          type="button"
          @click="selectAction('restore')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#fafafa] transition-colors hover:bg-[#18181b]"
        >
          <Icon icon="lucide:rotate-ccw" class="text-[15px]" />
          <span>بازیابی</span>
        </button>

        <button
          v-if="tab === 'deleted'"
          v-wave
          type="button"
          @click="selectAction('permanent-delete')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#ef4444] transition-colors hover:bg-[#18181b]"
        >
          <Icon icon="lucide:trash" class="text-[15px]" />
          <span>حذف کامل</span>
        </button>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
type UserTab = 'all' | 'active' | 'inactive' | 'deleted'
type UserAction = 'ban' | 'unban' | 'reset' | 'delete' | 'restore' | 'permanent-delete'
type AdminUser = { id: number; name: string; email: string; banned: boolean; status?: 'active' | 'deleted'; subscriptionExpiresAt?: string | null; createdAt: string }
const props = defineProps<{ user: AdminUser; tab: UserTab }>()
const emit = defineEmits<{ action: [payload: { action: UserAction; user: AdminUser }] }>()
const open = ref(false)
const menuRef = ref<HTMLElement | null>(null)

function selectAction(action: UserAction) {
  emit('action', { action, user: props.user })
  open.value = false
}

function onPointerDown(event: PointerEvent) {
  if (!open.value) return
  if (!menuRef.value?.contains(event.target as Node)) open.value = false
}
onMounted(() => document.addEventListener('pointerdown', onPointerDown, true))
onUnmounted(() => document.removeEventListener('pointerdown', onPointerDown, true))
</script>

<style scoped>
.admin-user-menu-enter-active,
.admin-user-menu-leave-active { transition: opacity .18s ease, transform .18s cubic-bezier(.16,1,.3,1); }
.admin-user-menu-enter-from,
.admin-user-menu-leave-to { opacity: 0; transform: translateY(-4px) scale(.98); }
</style>
