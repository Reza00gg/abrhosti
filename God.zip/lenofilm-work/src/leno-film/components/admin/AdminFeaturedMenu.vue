<template>
  <div ref="menuRef" class="relative shrink-0">
    <button
      v-wave
      type="button"
      title="گزینه‌ها"
      @click="open = !open"
      class="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] text-[#a1a1aa] hover:text-[#fafafa] transition-colors"
    >
      <Icon icon="lucide:more-vertical" class="text-[16px]" />
    </button>

    <Transition name="featured-menu">
      <div v-if="open" class="absolute left-0 top-10 z-30 w-44 overflow-hidden rounded-xl border border-[#1f1f1f] bg-[#0a0a0a] shadow-2xl">
        <button
          v-if="status === 'active'"
          v-wave
          type="button"
          :disabled="loading"
          @click="toggleFeatured"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium transition-colors disabled:opacity-50"
          :class="isFeatured ? 'text-[#fca5a5] hover:bg-[#18181b]' : 'text-[#fafafa] hover:bg-[#18181b]'"
        >
          <Icon :icon="isFeatured ? 'lucide:minus-circle' : 'lucide:badge-plus'" class="text-[15px]" />
          <span>{{ isFeatured ? 'حذف از اسلاید' : 'افزودن به اسلاید' }}</span>
        </button>

        <button
          v-if="status === 'active'"
          v-wave
          type="button"
          :disabled="loading"
          @click="selectAction('archive')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#fafafa] transition-colors hover:bg-[#18181b] disabled:opacity-50"
        >
          <Icon icon="lucide:archive" class="text-[15px]" />
          <span>آرشیو</span>
        </button>

        <button
          v-if="status === 'archived'"
          v-wave
          type="button"
          :disabled="loading"
          @click="selectAction('restore')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#fafafa] transition-colors hover:bg-[#18181b] disabled:opacity-50"
        >
          <Icon icon="lucide:rotate-ccw" class="text-[15px]" />
          <span>بازگردانی</span>
        </button>

        <button
          v-if="status === 'archived'"
          v-wave
          type="button"
          :disabled="loading"
          @click="selectAction('delete')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#fca5a5] transition-colors hover:bg-[#18181b] disabled:opacity-50"
        >
          <Icon icon="lucide:trash-2" class="text-[15px]" />
          <span>حذف</span>
        </button>

        <button
          v-if="status === 'deleted'"
          v-wave
          type="button"
          :disabled="loading"
          @click="selectAction('restore')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#fafafa] transition-colors hover:bg-[#18181b] disabled:opacity-50"
        >
          <Icon icon="lucide:rotate-ccw" class="text-[15px]" />
          <span>بازیابی</span>
        </button>

        <button
          v-if="status === 'deleted'"
          v-wave
          type="button"
          :disabled="loading"
          @click="selectAction('permanent-delete')"
          class="flex w-full items-center gap-2 px-3 py-2.5 text-right text-[12px] font-medium text-[#ef4444] transition-colors hover:bg-[#18181b] disabled:opacity-50"
        >
          <Icon icon="lucide:trash" class="text-[15px]" />
          <span>حذف کامل</span>
        </button>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
type MediaStatus = 'active' | 'archived' | 'deleted'
type MenuAction = 'archive' | 'restore' | 'delete' | 'permanent-delete'
const props = withDefaults(defineProps<{ mediaType: 'movie' | 'series'; mediaId: number; isFeatured: boolean; status?: MediaStatus }>(), { status: 'active' })
const emit = defineEmits<{
  changed: [payload: { mediaType: 'movie' | 'series'; mediaId: number; featured: boolean }]
  action: [payload: { action: MenuAction; mediaType: 'movie' | 'series'; mediaId: number }]
}>()
const toast = useToastStore()
const open = ref(false)
const loading = ref(false)
const menuRef = ref<HTMLElement | null>(null)

function selectAction(action: MenuAction) {
  emit('action', { action, mediaType: props.mediaType, mediaId: props.mediaId })
  open.value = false
}

async function toggleFeatured() {
  if (loading.value) return
  loading.value = true
  try {
    if (props.isFeatured) {
      await $fetch(`/api/admin/featured/${props.mediaType}/${props.mediaId}`, { method: 'DELETE' })
      emit('changed', { mediaType: props.mediaType, mediaId: props.mediaId, featured: false })
      toast.success('از اسلاید حذف شد')
    } else {
      await $fetch('/api/admin/featured', { method: 'POST', body: { mediaType: props.mediaType, mediaId: props.mediaId } })
      emit('changed', { mediaType: props.mediaType, mediaId: props.mediaId, featured: true })
      toast.success('به اسلاید اضافه شد')
    }
    open.value = false
  } catch (err: any) {
    toast.error(err?.statusMessage || 'خطا در تغییر وضعیت اسلاید')
  } finally {
    loading.value = false
  }
}

function onPointerDown(event: PointerEvent) {
  if (!open.value) return
  if (!menuRef.value?.contains(event.target as Node)) open.value = false
}
onMounted(() => document.addEventListener('pointerdown', onPointerDown, true))
onUnmounted(() => document.removeEventListener('pointerdown', onPointerDown, true))
</script>

<style scoped>
.featured-menu-enter-active,
.featured-menu-leave-active { transition: opacity .18s ease, transform .18s cubic-bezier(.16,1,.3,1); }
.featured-menu-enter-from,
.featured-menu-leave-to { opacity: 0; transform: translateY(-4px) scale(.98); }
</style>
