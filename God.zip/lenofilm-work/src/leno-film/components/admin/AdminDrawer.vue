<template>
  <Teleport to="body">
    <Transition name="backdrop">
      <div v-if="ui.adminDrawerOpen" @click="ui.closeAdminDrawer()" class="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"></div>
    </Transition>
    <Transition name="panel">
      <aside v-if="ui.adminDrawerOpen" class="fixed top-0 right-0 bottom-0 z-50 w-[78%] max-w-[320px] bg-[#0a0a0a] border-l border-[#1f1f1f] flex flex-col">
        <header class="px-4 h-[60px] flex items-center justify-between border-b border-[#1f1f1f] shrink-0">
          <span class="text-[15px] font-semibold text-[#fafafa]">پنل مدیریت</span>
          <button v-wave style="color: rgba(255, 255, 255, 0.45)" @click="ui.closeAdminDrawer()" class="btn-press w-9 h-9 flex items-center justify-center rounded-lg hover:bg-[#18181b] text-[#a1a1aa] hover:text-[#fafafa] transition-colors"><Icon icon="lucide:x" class="text-[20px]" /></button>
        </header>
        <nav class="flex-1 p-3 overflow-y-auto">
          <ul class="space-y-1">
            <li v-for="item in mainItems" :key="item.label">
              <NuxtLink :to="item.to" v-wave style="color: rgba(255, 255, 255, 0.45)" @click="ui.closeAdminDrawer()" class="btn-press group flex items-center gap-3 px-4 py-3 rounded-xl transition-colors" :class="isActive(item.to) ? 'bg-[#18181b] text-[#fafafa]' : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-[#fafafa]'">
                <Icon :icon="item.icon" class="text-[20px]" />
                <span class="text-[14px] font-medium">{{ item.label }}</span>
                <span v-if="isActive(item.to)" class="mr-auto w-1.5 h-1.5 rounded-full bg-[#fafafa]"></span>
              </NuxtLink>
            </li>

            <li v-for="item in disabledItems" :key="item.label">
              <button v-wave style="color: rgba(255, 255, 255, 0.45)" type="button" class="btn-press group w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#52525b] cursor-default transition-colors">
                <Icon :icon="item.icon" class="text-[20px]" />
                <span class="text-[14px] font-medium">{{ item.label }}</span>
                <span class="mr-auto text-2xs uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity duration-300">بزودی</span>
              </button>
            </li>

            <li>
              <button v-wave style="color: rgba(255, 255, 255, 0.45)" type="button" @click="settingsOpen = !settingsOpen" class="btn-press group w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors" :class="isSettingsActive ? 'bg-[#18181b] text-[#fafafa]' : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-[#fafafa]'">
                <Icon icon="lucide:settings" class="text-[20px]" />
                <span class="text-[14px] font-medium">تنظیمات</span>
                <Icon :icon="settingsOpen ? 'lucide:chevron-up' : 'lucide:chevron-down'" class="mr-auto text-[16px]" />
              </button>
              <Transition name="submenu">
                <div v-if="settingsOpen" class="mt-1 space-y-1 pe-4">
                  <NuxtLink to="/adminChash7nakg/settings/subscriptions" v-wave style="color: rgba(255, 255, 255, 0.45)" @click="ui.closeAdminDrawer()" class="btn-press flex items-center gap-3 rounded-xl px-4 py-2.5 text-[13px] transition-colors" :class="isActive('/adminChash7nakg/settings/subscriptions') ? 'bg-[#18181b] text-[#fafafa]' : 'text-[#71717a] hover:bg-[#18181b] hover:text-[#fafafa]'">
                    <Icon icon="lucide:badge-dollar-sign" class="text-[17px]" />
                    <span>اشتراک ها</span>
                  </NuxtLink>
                </div>
              </Transition>
            </li>
          </ul>
        </nav>
        <footer class="px-4 py-3 border-t border-[#1f1f1f] shrink-0">
          <p class="text-2xs text-[#52525b] text-center tracking-wider">v1.0.0 · Admin Panel</p>
        </footer>
      </aside>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
const ui = useUIStore()
const route = useRoute()
const settingsOpen = ref(route.path.startsWith('/adminChash7nakg/settings'))
const mainItems = [
  { label: 'داشبورد',  icon: 'lucide:layout-dashboard', to: '/adminChash7nakg/dashboard' },
  { label: 'فیلم ها',  icon: 'lucide:clapperboard',    to: '/adminChash7nakg/movies' },
  { label: 'سریال ها', icon: 'lucide:monitor-play',    to: '/adminChash7nakg/series' },
  { label: 'کاربران',  icon: 'lucide:users',           to: '/adminChash7nakg/users' },
]
const disabledItems = [
  { label: 'نظرات',    icon: 'lucide:message-circle' },
  { label: 'مدیریت',   icon: 'lucide:shield' },
]
const isSettingsActive = computed(() => route.path.startsWith('/adminChash7nakg/settings'))
function isActive(path: string) { return route.path === path }
watch(() => route.path, (path) => { if (path.startsWith('/adminChash7nakg/settings')) settingsOpen.value = true })
</script>

<style scoped>
.backdrop-enter-active, .backdrop-leave-active { transition: opacity 0.3s ease; }
.backdrop-enter-from, .backdrop-leave-to { opacity: 0; }
.panel-enter-active, .panel-leave-active { transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1); }
.panel-enter-from, .panel-leave-to { transform: translateX(100%); }
.submenu-enter-active, .submenu-leave-active { transition: opacity .2s ease, transform .2s cubic-bezier(.16,1,.3,1); }
.submenu-enter-from, .submenu-leave-to { opacity: 0; transform: translateY(-4px); }
</style>
