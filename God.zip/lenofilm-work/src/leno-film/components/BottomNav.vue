<template>
  <nav
    class="bottom-nav-shell fixed bottom-0 inset-x-0 z-40 bg-ink-950/95 backdrop-blur-md hairline-t"
    :style="{
      paddingBottom: 'var(--safe-bottom)',
      height: 'calc(var(--nav-h) + var(--safe-bottom))'
    }"
  >
    <div class="h-full max-w-screen-xl mx-auto px-1 sm:px-3 md:hidden">
      <ul class="h-full flex items-stretch">
        <li
          v-for="item in items"
          :key="item.to"
          class="flex-1 h-full"
        >
          <NuxtLink
            :to="item.to"
            v-slot="{ isActive, navigate, href }"
            custom
          >
            <a
              :href="href"
              @click="navigate"
              v-wave="appWave"
              style="color: var(--ripple)"
              class="btn-press group relative h-full w-full flex flex-col items-center justify-center gap-1 rounded-md text-2xs font-medium transition-colors duration-200"
              :aria-label="item.label"
              :aria-current="isActive ? 'page' : undefined"
            >
              <Icon
                :icon="item.icon"
                class="text-[22px] transition-colors duration-200"
                :class="isActive ? 'text-ink-50' : 'text-ink-500 group-hover:text-ink-200'"
              />
              <span
                class="leading-none transition-colors duration-200"
                :class="isActive ? 'text-ink-50' : 'text-ink-500 group-hover:text-ink-200'"
              >
                {{ item.label }}
              </span>
            </a>
          </NuxtLink>
        </li>
      </ul>
    </div>

    <div class="bottom-nav-tablet hidden h-full items-center justify-between px-3 md:flex">
      <button
        v-wave="{ color: 'rgba(255,255,255,.38)' }"
        type="button"
        class="bottom-nav-tablet__top"
        aria-label="رفتن به بالای صفحه"
        @click="scrollToTop"
      >
        <Icon icon="lucide:arrow-up" class="text-[22px]" />
      </button>

      <div class="bottom-nav-tablet__links">
        <button v-for="link in tabletLinks" :key="link" v-wave="appWave" type="button" class="bottom-nav-tablet__link">
          {{ link }}
        </button>
      </div>

      <div class="bottom-nav-tablet__socials">
        <button v-wave="appWave" type="button" class="bottom-nav-tablet__social" aria-label="اینستاگرام">
          <Icon icon="lucide:instagram" class="text-[22px]" />
        </button>
        <button v-wave="appWave" type="button" class="bottom-nav-tablet__social" aria-label="تلگرام">
          <svg class="bottom-nav-tablet__telegram-icon" viewBox="0 0 24 24" aria-hidden="true">
            <path fill="currentColor" d="M21.84 4.18c.33-1.08-.71-1.94-1.68-1.48L2.9 10.86c-1.1.52-1.03 2.1.12 2.51l4.4 1.57 1.68 5.36c.34 1.08 1.71 1.39 2.48.57l2.43-2.6 4.47 3.28c.92.67 2.23.16 2.48-.95l3.88-16.42ZM8.17 13.78l9.78-6.02c.48-.3.97.35.56.74l-8.08 7.75-.31 3.02-1.95-5.49Z" />
          </svg>
        </button>
      </div>
    </div>
  </nav>
</template>

<script setup lang="ts">
const appWave = useAppWave()
const items = [
  { to: '/',         label: 'خانه',    icon: 'lucide:home' },
  { to: '/search',   label: 'جستجو',   icon: 'lucide:search' },
  { to: '/discover', label: 'دیسکاور', icon: 'lucide:compass' },
  { to: '/account',  label: 'حساب',    icon: 'lucide:user-round' },
]
const tabletLinks = ['کالکشن ها', 'لیست ها', 'باکس آفیس', 'راهنما', 'تماس با ما']

function scrollToTop() {
  if (!import.meta.client) return
  window.scrollTo({ top: 0, behavior: 'smooth' })
}
</script>
