<template>
  <div
    ref="seriesCardRef"
    class="series-card-stack relative overflow-visible pt-2"
    :class="variant === 'rail' ? 'w-[132px] shrink-0 snap-start snap-always sm:w-[154px] md:w-[170px]' : 'relative'"
  >
    <div
      class="pointer-events-none absolute inset-x-3 top-0 aspect-[2/3] overflow-hidden rounded-xl bg-ink-900 transition-[transform,opacity] duration-[950ms] ease-[cubic-bezier(0.16,1,0.3,1)]"
      :class="isPreviewing ? 'translate-y-4 scale-[0.94] opacity-0' : 'translate-y-0 scale-100 opacity-60'"
    >
      <img v-if="movie.posterUrl" :src="movie.posterUrl" alt="" draggable="false" loading="lazy" decoding="async" class="absolute inset-0 h-full w-full object-cover opacity-65 blur-[1px]" />
      <div class="absolute inset-0 bg-black/30"></div>
    </div>

    <div
      class="pointer-events-none absolute inset-x-2 top-1 aspect-[2/3] overflow-hidden rounded-xl bg-ink-900 transition-[transform,opacity] duration-[950ms] ease-[cubic-bezier(0.16,1,0.3,1)]"
      :class="isPreviewing ? 'translate-y-3 scale-[0.95] opacity-0' : 'translate-y-0 scale-100 opacity-80'"
    >
      <img v-if="movie.posterUrl" :src="movie.posterUrl" alt="" draggable="false" loading="lazy" decoding="async" class="absolute inset-0 h-full w-full object-cover opacity-75 blur-[1px]" />
      <div class="absolute inset-0 bg-black/25"></div>
    </div>

    <div
      class="relative z-10"
      @pointerenter="handlePointerEnter"
      @pointerleave="handlePointerLeave"
      @pointerdown="handlePointerDown"
      @pointerup="handlePointerUp"
      @pointercancel="handlePointerUp"
    >
      <MovieCard :movie="movie" :variant="variant" :eager="eager" />
    </div>
  </div>
</template>

<script setup lang="ts">
import type { Movie, Series } from '~~/server/db/schema'
type SeriesCardItem = (Series | Movie) & { type?: 'series'; durationLabel?: string }
const props = withDefaults(defineProps<{ movie: SeriesCardItem; variant?: 'grid' | 'rail'; eager?: boolean }>(), { variant: 'grid', eager: false })
const seriesCardRef = ref<HTMLElement | null>(null)
const seriesCardId = `series-card-${Math.random().toString(36).slice(2)}`
const isHovering = ref(false)
const isTouchPreviewing = ref(false)
const isPreviewing = computed(() => isHovering.value || isTouchPreviewing.value)

function handlePointerEnter(event: PointerEvent) { if (event.pointerType === 'mouse') isHovering.value = true }
function handlePointerLeave() { isHovering.value = false }
function handlePointerDown(event: PointerEvent) {
  if (event.pointerType === 'mouse') return
  window.dispatchEvent(new CustomEvent('leno-series-card-preview', { detail: seriesCardId }))
  isTouchPreviewing.value = true
}
function handlePointerUp() {}
function handleSeriesPreviewEvent(event: Event) {
  const detail = (event as CustomEvent<string>).detail
  if (detail !== seriesCardId) isTouchPreviewing.value = false
}
function handleOutsidePointer(event: PointerEvent) {
  if (event.pointerType === 'mouse') return
  if (!seriesCardRef.value?.contains(event.target as Node)) isTouchPreviewing.value = false
}

onMounted(() => {
  window.addEventListener('leno-series-card-preview', handleSeriesPreviewEvent as EventListener)
  document.addEventListener('pointerdown', handleOutsidePointer, true)
})

onUnmounted(() => {
  window.removeEventListener('leno-series-card-preview', handleSeriesPreviewEvent as EventListener)
  document.removeEventListener('pointerdown', handleOutsidePointer, true)
})
</script>
