<template>
  <section v-if="slides.length" class="relative mb-2 overflow-hidden bg-ink-950" dir="ltr">
    <div
      ref="sliderRef"
      class="flex select-none touch-none will-change-transform"
      :class="transitionEnabled ? 'transition-transform duration-[520ms] ease-[cubic-bezier(0.16,1,0.3,1)]' : ''"
      :style="trackStyle"
      @transitionend="handleTransitionEnd"
      @pointerdown="startDrag"
      @pointermove="moveDrag"
      @pointerup="endDrag"
      @pointercancel="endDrag"
    >
      <article
        v-for="(slide, index) in trackSlides"
        :key="`${slide.id}-${activeIndex}-${index}`"
        class="relative h-[330px] w-full shrink-0 overflow-hidden sm:h-[410px] md:h-[460px]"
        dir="rtl"
      >
        <img
          v-if="slide.coverUrl"
          :src="slide.coverUrl"
          :alt="slide.titleFa"
          draggable="false"
          :loading="index === 1 ? 'eager' : 'lazy'"
          :fetchpriority="index === 1 ? 'high' : 'auto'"
          decoding="async"
          class="featured-slide-img absolute inset-0 h-full w-full object-cover select-none"
          @dragstart.prevent
        />
        <div v-else class="absolute inset-0 grid place-items-center bg-gradient-to-br from-ink-900 via-ink-950 to-black">
          <Icon icon="lucide:clapperboard" class="text-[66px] text-ink-700" />
        </div>

        <div class="absolute inset-0 bg-gradient-to-b from-black/10 via-black/10 to-black/90"></div>
        <div class="absolute inset-x-0 bottom-6 px-5 text-center sm:bottom-8">
          <h2 class="text-[19px] font-black leading-7 text-white drop-shadow-[0_3px_14px_rgba(0,0,0,.75)] sm:text-[23px]">{{ slide.titleFa }}</h2>
          <p class="mt-0.5 text-[13px] font-bold text-white/95 drop-shadow-[0_2px_10px_rgba(0,0,0,.7)]" dir="ltr">{{ slide.titleEn }} ({{ slide.year }})</p>
          <button
            type="button"
            class="mt-3 h-9 rounded-xl border border-white/85 px-3.5 text-[12px] font-black text-white transition-colors duration-200 hover:bg-white hover:text-black active:bg-white active:text-black"
          >
            تماشا آنلاین
          </button>
        </div>
      </article>
    </div>
  </section>
</template>

<script setup lang="ts">
const SLIDE_MS = 520
const AUTOPLAY_MS = 5000
const DRAG_THRESHOLD = 45

type SlideDirection = 'next' | 'prev' | null

const featured = useFeaturedStore()
const slides = computed(() => featured.items)
const activeIndex = ref(0)
const trackPosition = ref(1)
const dragOffset = ref(0)
const transitionEnabled = ref(false)
const sliderRef = ref<HTMLElement | null>(null)
const trackStyle = computed(() => ({ transform: `translate3d(calc(-${trackPosition.value * 100}% + ${dragOffset.value}px), 0, 0)` }))
const trackSlides = computed(() => {
  const list = slides.value
  if (list.length <= 1) return list
  return [getSlide(activeIndex.value + 1), getSlide(activeIndex.value), getSlide(activeIndex.value - 1)]
})

let autoplayTimer: ReturnType<typeof setTimeout> | null = null
let fallbackTimer: ReturnType<typeof setTimeout> | null = null
let dragging = false
let transitioning = false
let targetDirection: SlideDirection = null
let startX = 0
let currentX = 0
let activePointerId: number | null = null

function normalize(index: number) {
  const length = slides.value.length
  if (!length) return 0
  return (index + length) % length
}

function getSlide(index: number) {
  return slides.value[normalize(index)]
}

function stopAutoplay() {
  if (autoplayTimer) clearTimeout(autoplayTimer)
  autoplayTimer = null
}

function clearFallback() {
  if (fallbackTimer) clearTimeout(fallbackTimer)
  fallbackTimer = null
}

function scheduleAutoplay() {
  stopAutoplay()
  if (slides.value.length <= 1 || dragging || transitioning) return
  autoplayTimer = setTimeout(() => goNext(), AUTOPLAY_MS)
}

function resetToCenter() {
  transitionEnabled.value = false
  dragOffset.value = 0
  trackPosition.value = 1
  requestAnimationFrame(() => {
    requestAnimationFrame(() => { transitionEnabled.value = true })
  })
}

function completeTransition() {
  if (!transitioning) return
  clearFallback()
  if (targetDirection === 'next') activeIndex.value = normalize(activeIndex.value + 1)
  if (targetDirection === 'prev') activeIndex.value = normalize(activeIndex.value - 1)
  transitioning = false
  targetDirection = null
  resetToCenter()
  scheduleAutoplay()
}

function animate(direction: Exclude<SlideDirection, null>) {
  if (slides.value.length <= 1 || transitioning) return
  stopAutoplay()
  clearFallback()
  targetDirection = direction
  transitioning = true
  dragOffset.value = 0
  transitionEnabled.value = true
  trackPosition.value = direction === 'next' ? 0 : 2
  fallbackTimer = setTimeout(completeTransition, SLIDE_MS + 100)
}

function goNext() { animate('next') }
function goPrev() { animate('prev') }

function beginManualDrag(event: PointerEvent) {
  if (slides.value.length <= 1) return false
  if (transitioning) completeTransition()
  stopAutoplay()
  clearFallback()
  dragging = true
  activePointerId = event.pointerId
  startX = event.clientX
  currentX = event.clientX
  dragOffset.value = 0
  transitionEnabled.value = false
  sliderRef.value?.setPointerCapture?.(event.pointerId)
  return true
}

function updateManualDrag(event: PointerEvent) {
  if (!dragging || activePointerId !== event.pointerId) return
  event.preventDefault()
  currentX = event.clientX
  const delta = currentX - startX
  const width = sliderRef.value?.clientWidth || 1
  const maxOffset = width * 0.94
  dragOffset.value = Math.max(-maxOffset, Math.min(maxOffset, delta))
}

function finishManualDrag(event?: PointerEvent) {
  if (!dragging) return
  if (event && activePointerId !== event.pointerId) return
  if (event) sliderRef.value?.releasePointerCapture?.(event.pointerId)
  dragging = false
  activePointerId = null
  const delta = currentX - startX
  transitionEnabled.value = true

  if (Math.abs(delta) > DRAG_THRESHOLD) {
    // تعریف نهایی: کشیدن به راست = اسلاید بعدی، کشیدن به چپ = اسلاید قبلی.
    if (delta > 0) goNext()
    else goPrev()
    return
  }

  targetDirection = null
  transitioning = true
  dragOffset.value = 0
  fallbackTimer = setTimeout(completeTransition, SLIDE_MS + 100)
}

function startDrag(event: PointerEvent) {
  if (!beginManualDrag(event)) return
}

function moveDrag(event: PointerEvent) {
  updateManualDrag(event)
}

function endDrag(event: PointerEvent) {
  finishManualDrag(event)
}

function handleTransitionEnd(event: TransitionEvent) {
  if (event.target !== sliderRef.value || event.propertyName !== 'transform') return
  completeTransition()
}

function resetSlider() {
  stopAutoplay()
  clearFallback()
  activeIndex.value = 0
  targetDirection = null
  transitioning = false
  dragging = false
  resetToCenter()
  requestAnimationFrame(scheduleAutoplay)
}

watch(() => slides.value.length, resetSlider)

onMounted(async () => {
  await featured.fetchFeatured()
  resetSlider()
})

onBeforeUnmount(() => {
  stopAutoplay()
  clearFallback()
})
</script>
