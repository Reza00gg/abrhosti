<template>
  <Teleport to="body">
    <div class="fixed bottom-[calc(var(--nav-h)+var(--safe-bottom)+14px)] inset-x-0 z-[60] flex flex-col items-center gap-2 px-4 pointer-events-none">
      <TransitionGroup name="toast">
        <div
          v-for="t in toasts.toasts"
          :key="t.id"
          class="pointer-events-auto max-w-sm w-full flex items-center gap-3 rounded-2xl px-4 py-3 shadow-2xl backdrop-blur-xl"
          :class="variant === 'app' ? appClass(t.type) : adminClass"
        >
          <span
            class="grid h-9 w-9 shrink-0 place-items-center rounded-xl"
            :class="variant === 'app' ? appIconClass(t.type) : adminIconBg(t.type)"
          >
            <Icon
              :icon="t.type === 'success' ? 'lucide:check' : t.type === 'error' ? 'lucide:triangle-alert' : 'lucide:info'"
              class="text-[18px]"
            />
          </span>
          <p class="flex-1 text-[13px] font-medium leading-6" :class="variant === 'app' ? 'text-ink-50' : 'text-[#fafafa]'">{{ t.message }}</p>
          <button v-wave="variant === 'app' ? appWave : {}" type="button" @click="toasts.remove(t.id)" class="grid h-8 w-8 shrink-0 place-items-center rounded-xl text-ink-500 transition hover:bg-ink-900/30 hover:text-ink-50" aria-label="بستن اعلان">
            <Icon icon="lucide:x" class="text-[15px]" />
          </button>
        </div>
      </TransitionGroup>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
withDefaults(defineProps<{ variant?: 'app' | 'admin' }>(), { variant: 'admin' })
const toasts = useToastStore()
const appWave = useAppWave()
const adminClass = 'bg-[#0a0a0a]/95 border border-[#1f1f1f]'
function appClass(type: 'success' | 'error' | 'info') {
  if (type === 'success') return 'bg-emerald-500/15 border border-emerald-400/25 text-emerald-50'
  if (type === 'error') return 'bg-rose-500/15 border border-rose-400/25 text-rose-50'
  return 'bg-ink-900/95 border border-[color:var(--hairline)] text-ink-50'
}
function appIconClass(type: 'success' | 'error' | 'info') {
  if (type === 'success') return 'bg-emerald-400/20 text-emerald-500'
  if (type === 'error') return 'bg-rose-400/20 text-rose-500'
  return 'bg-white/10 text-ink-300'
}
function adminIconBg(type: 'success' | 'error' | 'info') {
  if (type === 'success') return 'bg-[#22c55e]/12 text-[#22c55e]'
  if (type === 'error') return 'bg-[#ef4444]/12 text-[#ef4444]'
  return 'bg-white/10 text-[#a1a1aa]'
}
</script>

<style scoped>
.toast-enter-active,
.toast-leave-active,
.toast-move {
  transition: all 0.32s cubic-bezier(0.16, 1, 0.3, 1);
}
.toast-enter-from,
.toast-leave-to {
  opacity: 0;
  transform: translateY(18px) scale(0.96);
}
.toast-leave-active { position: absolute; }
</style>
