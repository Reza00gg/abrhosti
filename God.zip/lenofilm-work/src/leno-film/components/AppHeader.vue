<template>
  <header
    class="fixed top-0 inset-x-0 z-40 bg-ink-950/90 backdrop-blur-md hairline-b"
    :style="{
      paddingTop: 'var(--safe-top)',
      height: 'calc(var(--header-h) + var(--safe-top))'
    }"
  >
    <div class="h-full max-w-screen-2xl mx-auto px-3 sm:px-5 flex items-center justify-between md:hidden">

      <!-- Right: Hamburger / contextual back -->
      <div v-if="isListPage" class="flex min-w-0 flex-1 items-center gap-2">
        <button
          v-wave="appWave"
          style="color: var(--ripple)"
          type="button"
          @click="goBack"
          class="btn-press group flex h-11 w-11 shrink-0 items-center justify-center rounded-lg transition-colors hover:bg-ink-900/60"
          aria-label="بازگشت"
        >
          <span class="text-ink-500 transition-colors duration-200 group-hover:text-ink-50">
            <Icon icon="lucide:arrow-right" class="text-[24px]" />
          </span>
        </button>
        <div class="min-w-0 flex-1 text-right">
          <h1 class="truncate text-[15px] font-black tracking-tight text-ink-50">
            {{ listTitle }}
          </h1>
          <p v-if="listTitleEn" class="mt-0.5 truncate text-[12px] font-bold text-ink-300" dir="ltr">{{ listTitleEn }}</p>
        </div>
      </div>

      <button
        v-else
        v-wave="appWave"
        style="color: var(--ripple)"
        @click="ui.toggleSideMenu()"
        class="btn-press group w-11 h-11 flex items-center justify-center rounded-lg hover:bg-ink-900/60 transition-colors"
        aria-label="منو"
        :aria-expanded="ui.sideMenuOpen"
      >
        <span class="text-ink-500 group-hover:text-ink-50 transition-colors duration-200">
          <Icon icon="lucide:menu" class="text-[24px]" />
        </span>
      </button>

      <!-- Center: Site Name -->
      <NuxtLink
        v-if="!isListPage"
        to="/"
        class="absolute left-1/2 -translate-x-1/2 no-select"
      >
        <span class="text-[17px] font-semibold tracking-tight text-ink-50">
          لنوفیلم
        </span>
      </NuxtLink>

      <!-- Left: Theme toggle (palette) -->
      <button
        v-if="!isListPage"
        v-wave="appWave"
        style="color: var(--ripple)"
        @click="cycleTheme"
        class="btn-press group w-11 h-11 flex items-center justify-center rounded-lg hover:bg-ink-900/60 transition-colors"
        :aria-label="`تغییر تم - فعلی: ${themeLabel}`"
        :title="`تم فعلی: ${themeLabel}`"
      >
        <span class="text-ink-500 group-hover:text-ink-50 transition-colors duration-200">
          <Icon :icon="themeIcon" class="text-[24px]" />
        </span>
      </button>

    </div>

    <div v-if="false" class="app-header-title-tablet hidden h-full w-full items-center justify-between px-3 md:flex">
      <button v-wave="appWave" type="button" class="app-header-title-tablet__back" aria-label="بازگشت" @click="goBack">
        <Icon icon="lucide:arrow-right" class="text-[26px]" />
      </button>
      <div class="app-header-title-tablet__names">
        <h1>{{ listTitle }}</h1>
        <p v-if="listTitleEn" dir="ltr">{{ listTitleEn }}</p>
      </div>
    </div>

    <div v-else class="app-header-tablet hidden h-full w-full items-center justify-between px-3 md:flex">
      <div class="app-header-tablet__right">
        <NuxtLink to="/" class="app-header-tablet__brand" aria-label="لنوفیلم">
          <img src="/favicon.svg" alt="لنوفیلم" draggable="false" class="h-8 w-8" />
          <span>لنوفیلم</span>
        </NuxtLink>
        <button v-wave="appWave" type="button" class="app-header-tablet__link" :aria-expanded="catalogCurtainOpen" @click="openCatalogCurtain">
          <svg class="app-header-tablet__grid-icon" viewBox="0 0 24 24" aria-hidden="true">
            <rect x="3" y="3" width="4" height="4" rx="0.8" fill="currentColor" />
            <rect x="10" y="3" width="4" height="4" rx="0.8" fill="currentColor" />
            <rect x="17" y="3" width="4" height="4" rx="0.8" fill="currentColor" />
            <rect x="3" y="10" width="4" height="4" rx="0.8" fill="currentColor" />
            <rect x="10" y="10" width="4" height="4" rx="0.8" fill="currentColor" />
            <rect x="17" y="10" width="4" height="4" rx="0.8" fill="currentColor" />
            <rect x="3" y="17" width="4" height="4" rx="0.8" fill="currentColor" />
            <rect x="10" y="17" width="4" height="4" rx="0.8" fill="currentColor" />
            <rect x="17" y="17" width="4" height="4" rx="0.8" fill="currentColor" />
          </svg>
          <span>فهرست</span>
        </button>
        <button v-wave="appWave" type="button" class="app-header-tablet__link">
          <span>دیسکاور</span>
        </button>
      </div>

      <div class="app-header-tablet__left" dir="ltr">
        <div
          class="app-header-tablet__account-wrap"
          @mouseenter="openHeaderAccountMenu"
          @mouseleave="scheduleHeaderAccountClose"
        >
          <button
            v-wave="appWave"
            type="button"
            class="app-header-tablet__icon app-header-tablet__icon--account"
            aria-label="حساب"
            :aria-expanded="headerAccountOpen"
            @click="handleHeaderAccountClick"
          >
            <svg class="app-header-tablet__user-icon" viewBox="0 0 24 24" aria-hidden="true">
              <circle cx="12" cy="7.4" r="4.1" fill="currentColor" />
              <path fill="currentColor" d="M4.2 20.2c.65-4.2 3.55-6.55 7.8-6.55s7.15 2.35 7.8 6.55c.08.52-.33.98-.86.98H5.06c-.53 0-.94-.46-.86-.98Z" />
            </svg>
          </button>

          <Transition name="header-account-popover">
            <div
              v-if="headerAccountOpen && userAuth.isAuthenticated"
              class="app-header-account-popover"
              dir="rtl"
              @mouseenter="cancelHeaderAccountClose"
              @mouseleave="scheduleHeaderAccountClose"
            >
              <button v-for="item in headerAccountItems" :key="item.to" v-wave="appWave" type="button" class="app-header-account-popover__item" @click="goHeaderAccountItem(item.to)">
                <Icon :icon="item.icon" class="text-[19px]" />
                <span>{{ item.label }}</span>
              </button>
              <button v-wave="appWave" type="button" class="app-header-account-popover__item app-header-account-popover__item--logout" @click="logoutFromHeader">
                <Icon icon="lucide:log-out" class="text-[19px]" />
                <span>خروج از حساب</span>
              </button>
            </div>
          </Transition>
        </div>
        <button v-if="userAuth.isAuthenticated" v-wave="appWave" type="button" class="app-header-tablet__icon" aria-label="لیست تماشا">
          <Icon icon="lucide:bookmark" class="text-[23px]" />
        </button>
        <button v-if="userAuth.isAuthenticated" v-wave="appWave" type="button" class="app-header-tablet__icon" aria-label="آخرین بازدیدها">
          <Icon icon="lucide:history" class="text-[22px]" />
        </button>
        <button v-wave="appWave" type="button" class="app-header-tablet__icon" :aria-label="`تم فعلی: ${themeLabel}`" @click="cycleTheme">
          <Icon :icon="themeIcon" class="text-[24px]" />
        </button>
        <button v-wave="appWave" type="button" class="app-header-tablet__icon" aria-label="جستجو" @click="navigateTo('/search')">
          <Icon icon="lucide:search" class="text-[23px]" />
        </button>
      </div>
    </div>
  </header>

  <Transition name="catalog-curtain">
    <section v-if="catalogCurtainOpen" class="catalog-curtain hidden md:block" dir="rtl" aria-label="فهرست لنوفیلم">
      <div class="catalog-curtain__top">
        <button v-wave="{ color: 'rgba(255,255,255,.35)' }" type="button" class="catalog-curtain__close" aria-label="بستن فهرست" @click="closeCatalogCurtain">
          <Icon icon="lucide:x" class="text-[30px]" />
        </button>
        <div class="catalog-curtain__brand">
          <strong>لنوفیلم</strong>
          <span>نسخه: {{ siteVersion }}</span>
        </div>
      </div>

      <div class="catalog-curtain__grid">
        <section v-for="group in catalogGroups" :key="group.title" class="catalog-curtain__group">
          <h2>
            <span>{{ group.title }}</span>
            <Icon :icon="group.icon" class="text-[31px]" />
          </h2>
          <div class="catalog-curtain__tags">
            <a v-for="tag in group.tags" :key="tag" href="#" @click.prevent>{{ tag }}</a>
          </div>
        </section>
      </div>
    </section>
  </Transition>

</template>

<script setup lang="ts">
const appWave = useAppWave()
const ui = useUIStore()
const themeStore = useThemeStore()
const userAuth = useUserAuthStore()
const titleHeader = useTitleHeader()
const route = useRoute()
const router = useRouter()
const isTabletViewport = ref(false)
const headerAccountOpen = ref(false)
const catalogCurtainOpen = ref(false)
const siteVersion = '۱.۰.۰'
let headerAccountCloseTimer: ReturnType<typeof setTimeout> | null = null
const headerAccountItems = [
  { label: 'پنل کاربری', icon: 'lucide:layout-dashboard', to: '/account' },
  { label: 'خرید اشتراک', icon: 'lucide:shopping-cart', to: '/account/subscription' },
  { label: 'سوابق خرید', icon: 'lucide:receipt-text', to: '/account/purchases' },
]
const catalogGroups = [
  {
    title: 'فیلم‌ها',
    icon: 'lucide:clapperboard',
    tags: ['جدیدترین فیلم‌ها', 'جدول باکس آفیس', 'کالکشن‌ها', '۲۵۰ فیلم برتر IMDb', 'فیلم‌های کره‌ای', 'فیلم‌های هندی', 'فیلم‌های دوبله فارسی', 'فیلم‌های زیرنویس فارسی', 'فیلم‌های زیرنویس انگلیسی'],
  },
  {
    title: 'سریال‌ها',
    icon: 'lucide:tv',
    tags: ['جدیدترین سریال‌ها', 'مینی سریال', 'انیمه سریالی', '۲۵۰ سریال برتر IMDb', 'سریال‌های پایان یافته', 'سریال‌های لغو شده', 'سریال‌های دوبله فارسی', 'سریال‌های زیرنویس فارسی', 'سریال‌های زیرنویس انگلیسی'],
  },
  {
    title: 'هنرمندان',
    icon: 'lucide:users-round',
    tags: ['هنرمندان', 'محبوب‌ترین بازیگران مرد', 'محبوب‌ترین بازیگران زن', 'محبوب‌ترین کارگردانان'],
  },
  {
    title: 'بخش‌ها',
    icon: 'lucide:list',
    tags: ['پیشنهادها', 'دیسکاور', 'معرفی بلاگرها', 'مقالات', 'لیست‌های پیشنهادی', 'جستجو پیشرفته'],
  },
]

function updateTabletViewport() {
  if (!import.meta.client) return
  const isTablet = window.innerWidth >= 768
  isTabletViewport.value = isTablet
  if (!isTablet && catalogCurtainOpen.value) closeCatalogCurtain()
}

onMounted(() => {
  updateTabletViewport()
  window.addEventListener('resize', updateTabletViewport, { passive: true })
})
onBeforeUnmount(() => {
  if (import.meta.client) window.removeEventListener('resize', updateTabletViewport)
  if (headerAccountCloseTimer) clearTimeout(headerAccountCloseTimer)
  setCatalogScrollLock(false)
})


function setCatalogScrollLock(locked: boolean) {
  if (!import.meta.client) return
  document.body.style.overflow = locked ? 'hidden' : ''
}

function openCatalogCurtain() {
  if (!isTabletViewport.value) return
  headerAccountOpen.value = false
  catalogCurtainOpen.value = true
  setCatalogScrollLock(true)
}

function closeCatalogCurtain() {
  catalogCurtainOpen.value = false
  setCatalogScrollLock(false)
}

function cancelHeaderAccountClose() {
  if (!headerAccountCloseTimer) return
  clearTimeout(headerAccountCloseTimer)
  headerAccountCloseTimer = null
}

function openHeaderAccountMenu() {
  if (!userAuth.isAuthenticated) return
  cancelHeaderAccountClose()
  headerAccountOpen.value = true
}

function scheduleHeaderAccountClose() {
  cancelHeaderAccountClose()
  headerAccountCloseTimer = setTimeout(() => {
    headerAccountOpen.value = false
    headerAccountCloseTimer = null
  }, 160)
}

function handleHeaderAccountClick() {
  if (!userAuth.isAuthenticated) {
    headerAccountOpen.value = false
    navigateTo('/account/signin')
    return
  }
  cancelHeaderAccountClose()
  headerAccountOpen.value = !headerAccountOpen.value
}

function goHeaderAccountItem(to: string) {
  headerAccountOpen.value = false
  closeCatalogCurtain()
  navigateTo(to)
}

async function logoutFromHeader() {
  headerAccountOpen.value = false
  closeCatalogCurtain()
  userAuth.logout()
  await router.push('/account/signin')
}

const accountTabletWithoutContextHeader = computed(() => (
  isTabletViewport.value &&
  route.path.startsWith('/account/') &&
  route.path !== '/account/signin' &&
  route.path !== '/account/signup'
))

const isTitleRoute = computed(() => route.path.startsWith('/title/'))
const listTitleEn = computed(() => isTitleRoute.value ? titleHeader.value.titleEn : '')
const listTitle = computed(() => {
  if (isTitleRoute.value) return titleHeader.value.titleFa || 'عنوان'
  if (route.path === '/list/new-films') return 'جدیدترین فیلم ها'
  if (route.path === '/list/new-series') return 'جدیدترین سریال ها'
  if (route.path === '/account/profile') return 'حساب کاربری'
  if (route.path === '/account/subscription') return 'خرید اشتراک'
  if (route.path === '/account/notifications') return 'اعلان ها'
  if (route.path === '/account/purchases') return 'سوابق خرید'
  return ''
})
const isListPage = computed(() => (Boolean(listTitle.value) && !accountTabletWithoutContextHeader.value) || isTitleRoute.value)

function goBack() {
  if (isTitleRoute.value) {
    router.replace('/')
    return
  }
  if (import.meta.client && route.path === '/account/subscription') {
    const handledByPage = !window.dispatchEvent(new CustomEvent('leno-subscription-back', { cancelable: true }))
    if (handledByPage) return
  }
  if (import.meta.client && window.history.length > 1) router.back()
  else router.push('/')
}

// آیکون بر اساس تم فعلی
const themeIcon = computed(() => {
  switch (themeStore.current) {
    case 'ink':    return 'lucide:palette'
    case 'light':  return 'lucide:sun'
    case 'blue':   return 'lucide:droplet'
    case 'purple': return 'lucide:sparkles'
    default:       return 'lucide:palette'
  }
})

// برچسب فارسی تم فعلی
const themeLabel = computed(() => {
  switch (themeStore.current) {
    case 'ink':    return 'مشکی'
    case 'light':  return 'سفید'
    case 'blue':   return 'آبی'
    case 'purple': return 'بنفش'
    default:       return 'مشکی'
  }
})

function cycleTheme() {
  themeStore.next()
}
</script>
