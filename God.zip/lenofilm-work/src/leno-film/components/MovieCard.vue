<template>
  <div
    ref="cardRef"
    v-wave="appCardWave"
    style="color: rgba(255, 255, 255, 0.4)"
    class="movie-card-shell group relative cursor-pointer select-none overflow-hidden rounded-[15px]"
    @pointerenter="handlePointerEnter"
    @pointerleave="handlePointerLeave"
    @pointerdown="handlePointerDown"
    @pointerup="handlePointerUp"
    @pointercancel="handlePointerUp"
    :class="variant === 'rail' ? 'w-[132px] shrink-0 snap-start snap-always sm:w-[154px] md:w-[170px]' : 'relative'"
  >
    <div class="relative aspect-[2/3] overflow-hidden rounded-xl bg-ink-950">
      <div v-if="!loaded && !error" class="absolute inset-0 flex items-center justify-center bg-ink-950">
        <Icon icon="lucide:film" class="text-[40px] text-ink-800" />
      </div>

      <div v-if="error" class="absolute inset-0 flex items-center justify-center bg-ink-950">
        <Icon icon="lucide:image-off" class="text-[32px] text-ink-700" />
      </div>

      <img
        v-if="movie.posterUrl"
        :src="movie.posterUrl"
        :alt="movie.titleEn"
        draggable="false"
        :loading="eager ? 'eager' : 'lazy'"
        :fetchpriority="eager ? 'high' : 'auto'"
        :decoding="eager ? 'sync' : 'async'"
        @load="onLoad"
        @error="onError"
        @dragstart.prevent
        class="movie-poster-img absolute inset-0 h-full w-full object-cover transition-[opacity,filter] duration-500 ease-out pointer-events-none select-none"
        :class="[loaded ? 'opacity-100' : 'opacity-0', isPreviewing ? 'blur-[2px]' : 'blur-0']"
      />

      <div class="absolute inset-0 transition-colors duration-300 ease-out" :class="isPreviewing ? 'bg-black/45' : 'bg-black/0'"></div>

      <div class="absolute inset-0 grid place-items-center transition-all duration-300 ease-out" :class="isPreviewing ? 'translate-y-0 opacity-100' : 'translate-y-1 opacity-0'">
        <p class="text-[13px] font-black text-white drop-shadow-[0_2px_10px_rgba(0,0,0,.75)]">{{ displayDuration }}</p>
      </div>

      <div v-if="loaded" class="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/75 via-black/25 to-transparent transition-opacity duration-300" :class="isPreviewing ? 'opacity-0' : 'opacity-100'"></div>
      <div v-if="loaded" class="absolute bottom-1.5 left-1.5 flex items-center gap-1.5 px-1 text-[11px] font-extrabold text-white/95 drop-shadow-[0_2px_8px_rgba(0,0,0,.85)] transition-opacity duration-300" :class="isPreviewing ? 'opacity-0' : 'opacity-100'" dir="ltr">
        <span class="text-[14px] leading-none text-yellow-400">★</span>
        <span>{{ ratingText }}</span>
        <span class="h-1 w-1 rounded-full bg-white/55"></span>
        <span>{{ movie.year }}</span>
      </div>
    </div>

    <div class="pointer-events-none select-none px-1 pt-2">
      <h3 class="block truncate text-left text-[12px] font-bold leading-5 text-ink-50" dir="ltr">{{ movie.titleEn }}</h3>
    </div>

    <NuxtLink
      v-if="titlePath"
      :to="titlePath"
      class="absolute inset-0 z-20 rounded-[15px]"
      :aria-label="`مشاهده ${movie.titleFa || movie.titleEn}`"
      draggable="false"
      @dragstart.prevent
    />
  </div>
</template>

<script setup lang="ts">
import type { Movie } from '~~/server/db/schema'
type MediaCardItem = Movie & { titleCode?: number | null; durationLabel?: string; type?: 'movie' | 'series'; seasons?: number }
const props = withDefaults(defineProps<{ movie: MediaCardItem; variant?: 'grid' | 'rail'; eager?: boolean }>(), { variant: 'grid', eager: false })
const { movie, eager } = toRefs(props)
const appCardWave = useAppWave('card')

const loaded = ref(false)
const error = ref(false)
const cardRef = ref<HTMLElement | null>(null)
const cardId = `movie-card-${Math.random().toString(36).slice(2)}`
const isHovering = ref(false)
const isTouchPreviewing = ref(false)
const isPreviewing = computed(() => isHovering.value || isTouchPreviewing.value)

function onLoad() { loaded.value = true; error.value = false }
function onError() { error.value = true; loaded.value = false }
function handlePointerEnter(event: PointerEvent) { if (event.pointerType === 'mouse') isHovering.value = true }
function handlePointerLeave() { isHovering.value = false }
function handlePointerDown(event: PointerEvent) {
  if (event.pointerType === 'mouse') return
  window.dispatchEvent(new CustomEvent('leno-movie-card-preview', { detail: cardId }))
  isTouchPreviewing.value = true
}
function handlePointerUp() {}
const titlePath = computed(() => {
  const code = Number((movie.value as any).titleCode)
  return Number.isFinite(code) && code > 0 ? `/title/${code}` : ''
})
function handlePreviewEvent(event: Event) {
  const detail = (event as CustomEvent<string>).detail
  if (detail !== cardId) isTouchPreviewing.value = false
}
function handleOutsidePointer(event: PointerEvent) {
  if (event.pointerType === 'mouse') return
  if (!cardRef.value?.contains(event.target as Node)) isTouchPreviewing.value = false
}
const mediaItem = computed(() => movie.value as any)
const ratingText = computed(() => Number(movie.value.rating).toFixed(1).replace(/\.0$/, ''))
const displayDuration = computed(() => {
  const item = mediaItem.value
  if (item.durationLabel) return item.durationLabel
  if (Number(item.duration) > 0) return `${toFa(Number(item.duration))} دقیقه`
  return 'سریال'
})
function toFa(value: number) { return new Intl.NumberFormat('fa-IR').format(value) }

watch(() => movie.value.posterUrl, () => {
  loaded.value = false
  error.value = false
})

onMounted(() => {
  window.addEventListener('leno-movie-card-preview', handlePreviewEvent as EventListener)
  document.addEventListener('pointerdown', handleOutsidePointer, true)
})

onUnmounted(() => {
  window.removeEventListener('leno-movie-card-preview', handlePreviewEvent as EventListener)
  document.removeEventListener('pointerdown', handleOutsidePointer, true)
})
</script>
