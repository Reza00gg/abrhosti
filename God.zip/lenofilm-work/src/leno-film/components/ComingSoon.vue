<template>
  <div class="max-w-xl mx-auto min-h-[60vh] flex flex-col items-center justify-center text-center animate-fade-up px-4">

    <!-- Minimal icon -->
    <div class="mb-6">
      <Icon :icon="icon" class="text-[40px] text-ink-400" />
    </div>

    <!-- Title -->
    <h1 class="text-2xl sm:text-3xl font-semibold text-ink-50 tracking-tight">
      {{ title }}
    </h1>

    <!-- Subtitle - Coming Soon -->
    <p class="mt-2 text-base sm:text-lg font-medium text-ink-400">
      {{ subtitle }}
    </p>

    <!-- Description -->
    <p v-if="description" class="mt-6 text-sm text-ink-500 max-w-md leading-6">
      {{ description }}
    </p>

    <!-- Minimal loader line -->
    <div class="mt-10 w-12 h-px bg-ink-800 overflow-hidden">
      <div class="h-full w-full bg-ink-400 animate-[loader_1.5s_ease-in-out_infinite]"></div>
    </div>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  title: string
  subtitle?: string
  description?: string
  icon?: string
}>()
</script>

<style scoped>
@keyframes loader {
  0%   { transform: translateX(-100%); }
  50%  { transform: translateX(0%); }
  100% { transform: translateX(100%); }
}
</style>
