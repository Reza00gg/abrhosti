<template>
  <aside class="account-tablet-menu" dir="rtl" aria-label="منوی حساب کاربری">
    <nav class="account-tablet-menu__panel">
      <button
        v-for="item in items"
        :key="item.key"
        v-wave="appWave"
        type="button"
        class="account-tablet-menu__item"
        :class="[
          activeKey === item.key ? 'account-tablet-menu__item--active' : '',
          item.action === 'logout' ? 'account-tablet-menu__item--logout' : ''
        ]"
        @click="$emit('select', item)"
      >
        <Icon
          :icon="item.action === 'logout' && loggingOut ? 'lucide:loader-2' : item.icon"
          class="account-tablet-menu__icon"
          :class="item.action === 'logout' && loggingOut ? 'animate-spin' : ''"
        />
        <span class="account-tablet-menu__label">{{ item.label }}</span>
        <span v-if="item.badge" class="account-tablet-menu__badge">{{ item.badge }}</span>
      </button>
    </nav>
  </aside>
</template>

<script setup lang="ts">
type AccountMenuItem = {
  key: string
  label: string
  icon: string
  to?: string
  action?: 'logout'
  badge?: string
}

defineProps<{
  items: AccountMenuItem[]
  activeKey: string
  loggingOut?: boolean
}>()

defineEmits<{
  select: [item: AccountMenuItem]
}>()

const appWave = useAppWave()
</script>
