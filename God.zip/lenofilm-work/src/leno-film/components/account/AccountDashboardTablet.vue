<template>
  <section class="account-tablet-dashboard animate-fade-in">
    <div class="account-tablet-hero">
      <div class="account-tablet-hero__content">
        <h1 class="text-[28px] font-black leading-tight text-white lg:text-[31px]">
          {{ displayName }}
        </h1>
        <p class="mt-2 text-[14px] font-bold text-white/90">خوش آمدید.</p>
      </div>
    </div>

    <div class="account-tablet-subscription-alert" :class="hasActiveSubscription ? 'account-tablet-subscription-alert--active' : 'account-tablet-subscription-alert--empty'">
      {{ subscriptionText }}
    </div>

    <div class="account-tablet-stat-grid">
      <article class="account-tablet-stat-card">
        <Icon icon="lucide:user-check" class="account-tablet-stat-card__icon" />
        <div class="min-w-0 text-left">
          <p class="account-tablet-stat-card__value">{{ membershipDate }}</p>
          <p class="account-tablet-stat-card__label">تاریخ عضویت</p>
        </div>
      </article>

      <article v-if="hasActiveSubscription" class="account-tablet-stat-card">
        <Icon icon="lucide:calendar-check" class="account-tablet-stat-card__icon" />
        <div class="min-w-0 text-left">
          <p class="account-tablet-stat-card__value">{{ subscriptionEndDate }}</p>
          <p class="account-tablet-stat-card__label">تاریخ پایان اشتراک</p>
        </div>
      </article>

      <article class="account-tablet-stat-card">
        <Icon icon="lucide:bell" class="account-tablet-stat-card__icon" />
        <div class="min-w-0 text-left">
          <p class="account-tablet-stat-card__value">{{ toFa(unreadNotifications) }}</p>
          <p class="account-tablet-stat-card__label">اعلان های خوانده نشده</p>
        </div>
      </article>

      <article v-if="hasActiveSubscription" class="account-tablet-stat-card">
        <Icon icon="lucide:timer" class="account-tablet-stat-card__icon" />
        <div class="min-w-0 text-left">
          <p class="account-tablet-stat-card__value">{{ toFa(remainingDays) }}</p>
          <p class="account-tablet-stat-card__label">روزهای باقی مانده اشتراک</p>
        </div>
      </article>

      <article class="account-tablet-stat-card">
        <Icon icon="lucide:bookmark" class="account-tablet-stat-card__icon" />
        <div class="min-w-0 text-left">
          <p class="account-tablet-stat-card__value">۰</p>
          <p class="account-tablet-stat-card__label">تعداد نشان ها</p>
        </div>
      </article>

      <article class="account-tablet-stat-card">
        <Icon icon="lucide:messages-square" class="account-tablet-stat-card__icon" />
        <div class="min-w-0 text-left">
          <p class="account-tablet-stat-card__value">۰</p>
          <p class="account-tablet-stat-card__label">تعداد نظرات</p>
        </div>
      </article>
    </div>
  </section>
</template>

<script setup lang="ts">
const auth = useUserAuthStore()
const unreadNotifications = ref(0)

type ProfileResponse = {
  name: string
  email: string
  contactEmail?: string | null
  avatarUrl?: string | null
  avatarMime?: string | null
  subscriptionExpiresAt?: string | Date | null
  createdAt?: string | Date | null
}

const displayName = computed(() => auth.user?.name || 'کاربر لنوفیلم')
const subscriptionExpiresAt = computed(() => auth.user?.subscriptionExpiresAt || null)
const createdAt = computed(() => auth.user?.createdAt || auth.user?.loggedInAt || null)

const remainingDays = computed(() => {
  if (!subscriptionExpiresAt.value) return 0
  const ms = new Date(subscriptionExpiresAt.value).getTime() - Date.now()
  if (ms <= 0) return 0
  return Math.max(1, Math.ceil(ms / (24 * 60 * 60 * 1000)))
})
const hasActiveSubscription = computed(() => remainingDays.value > 0)
const subscriptionText = computed(() => {
  if (!hasActiveSubscription.value) return 'اشتراک فعالی ندارید.'
  return `اشتراک شما تا ${toFa(remainingDays.value)} روز فعال است.`
})
const membershipDate = computed(() => formatDate(createdAt.value))
const subscriptionEndDate = computed(() => formatDate(subscriptionExpiresAt.value))

function toFa(value: number) {
  return new Intl.NumberFormat('fa-IR').format(Number(value || 0))
}
function formatDate(value: string | Date | number | null | undefined) {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '—'
  return new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(date)
}

async function refreshDashboardData() {
  try {
    const [profile, notifications] = await Promise.all([
      $fetch<ProfileResponse>('/api/users/profile'),
      $fetch<{ unread: number }>('/api/users/notifications'),
    ])
    auth.setUserPatch({
      name: profile.name,
      email: profile.email,
      contactEmail: profile.contactEmail,
      avatarUrl: profile.avatarUrl,
      avatarMime: profile.avatarMime,
      subscriptionExpiresAt: profile.subscriptionExpiresAt,
      createdAt: profile.createdAt,
    })
    unreadNotifications.value = Number(notifications.unread || 0)
  } catch {
    unreadNotifications.value = 0
  }
}

onMounted(refreshDashboardData)
</script>
