<template>
  <div class="account-responsive-shell">
    <div class="account-responsive-shell__grid" dir="ltr">
      <section class="account-responsive-shell__content" dir="rtl">
        <div v-if="tabletContentTitle" class="account-tablet-content-title hidden md:flex">
          <Icon :icon="tabletContentIcon" class="text-[23px]" />
          <h1>{{ tabletContentTitle }}</h1>
        </div>
        <slot />
      </section>

      <AccountSideMenu
        class="hidden md:block"
        :items="menuItems"
        :active-key="activeKey"
        :logging-out="loggingOut"
        @select="handleMenuSelect"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
type AccountMenuItem = {
  key: string
  label: string
  icon: string
  to?: string
  action?: 'logout'
  badge?: string
}

const auth = useUserAuthStore()
const router = useRouter()
const route = useRoute()
const loggingOut = ref(false)
const unreadNotifications = ref(0)

const tabletContentTitle = computed(() => {
  if (route.path === '/account/subscription') return 'خرید اشتراک'
  if (route.path === '/account/purchases') return 'سوابق خرید'
  if (route.path === '/account/profile') return 'حساب کاربری'
  if (route.path === '/account/notifications') return 'اعلان ها'
  return ''
})
const tabletContentIcon = computed(() => {
  if (route.path === '/account/subscription') return 'lucide:shopping-cart'
  if (route.path === '/account/purchases') return 'lucide:receipt-text'
  if (route.path === '/account/profile') return 'lucide:id-card'
  if (route.path === '/account/notifications') return 'lucide:bell'
  return 'lucide:circle'
})

const activeKey = computed(() => {
  if (route.path === '/account') return 'dashboard'
  if (route.path === '/account/subscription') return 'subscription'
  if (route.path === '/account/purchases') return 'purchases'
  if (route.path === '/account/profile') return 'account'
  if (route.path === '/account/notifications') return 'notifications'
  return ''
})

const notificationBadge = computed(() => new Intl.NumberFormat('fa-IR').format(unreadNotifications.value))

const menuItems = computed<AccountMenuItem[]>(() => [
  { key: 'dashboard', label: 'پنل کاربری', icon: 'lucide:layout-dashboard', to: '/account' },
  { key: 'subscription', label: 'خرید اشتراک', icon: 'lucide:shopping-cart', to: '/account/subscription' },
  { key: 'purchases', label: 'سوابق خرید', icon: 'lucide:receipt-text', to: '/account/purchases' },
  { key: 'account', label: 'حساب کاربری', icon: 'lucide:id-card', to: '/account/profile' },
  { key: 'notifications', label: 'اعلان ها', icon: 'lucide:bell', badge: notificationBadge.value, to: '/account/notifications' },
  { key: 'likes', label: 'پسندها', icon: 'lucide:thumbs-up' },
  { key: 'watchlist', label: 'لیست تماشا', icon: 'lucide:bookmark', badge: '۰' },
  { key: 'comments', label: 'نظرات', icon: 'lucide:messages-square', badge: '۰' },
  { key: 'history', label: 'آخرین بازدیدها', icon: 'lucide:history' },
  { key: 'playback', label: 'تنظیمات پخش', icon: 'lucide:settings' },
  { key: 'logout', label: 'خروج از حساب', icon: 'lucide:log-out', action: 'logout' },
])

async function loadUnreadNotifications() {
  try {
    const res = await $fetch<{ unread: number }>('/api/users/notifications')
    unreadNotifications.value = Number(res.unread || 0)
  } catch {
    unreadNotifications.value = 0
  }
}

function handleMenuSelect(item: AccountMenuItem) {
  if (item.action === 'logout') return handleLogout()
  if (!item.to || item.to === route.path) return
  navigateTo(item.to)
}

async function handleLogout() {
  if (loggingOut.value) return
  loggingOut.value = true
  await new Promise(resolve => setTimeout(resolve, 350))
  auth.logout()
  await router.push('/account/signin')
}

onMounted(loadUnreadNotifications)
</script>
