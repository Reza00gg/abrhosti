<template>
  <div class="relative pt-2">
    <input
      :id="id"
      :type="type"
      :value="modelValue"
      @input="onInput"
      @focus="focused = true"
      @blur="focused = false"
      :required="required"
      :autocomplete="autocomplete"
      :dir="dir"
      class="peer h-13 w-full border bg-transparent px-4 pb-2 pt-4 text-[15px] text-ink-50 outline-none transition-[border-color,background-color,box-shadow,border-radius] duration-[340ms] ease-out placeholder:text-transparent"
      :class="focused ? 'rounded-3xl border-[color:var(--input-border-focus)] bg-white/[0.025]' : 'rounded-2xl border-[color:var(--hairline)]'"
      placeholder=" "
    />
    <label
      :for="id"
      class="absolute right-3 pointer-events-none rounded-full px-1.5 transition-all duration-300 ease-out"
      :class="floating
        ? 'top-0 translate-y-0 bg-ink-950 text-[11px] text-ink-300'
        : 'top-1/2 -translate-y-[35%] text-[15px] text-ink-500'"
    >
      {{ label }}
    </label>
  </div>
</template>

<script setup lang="ts">
const props = defineProps<{
  modelValue?: string
  label: string
  type?: string
  required?: boolean
  autocomplete?: string
  id: string
  dir?: 'ltr' | 'rtl' | 'auto'
}>()

const emit = defineEmits<{ 'update:modelValue': [v: string] }>()
const focused = ref(false)
const floating = computed(() => focused.value || !!props.modelValue)
function onInput(e: Event) { emit('update:modelValue', (e.target as HTMLInputElement).value) }
</script>
