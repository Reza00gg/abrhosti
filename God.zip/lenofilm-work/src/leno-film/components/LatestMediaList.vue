<template>
  <div class="min-h-[70vh] px-4 pt-5 pb-10 sm:px-6 sm:pt-6">
    <div v-if="initialLoading" class="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 sm:gap-4">
      <div v-for="i in 18" :key="i" class="overflow-hidden rounded-xl">
        <div class="aspect-[2/3] animate-pulse rounded-xl bg-ink-900/80"></div>
        <div class="pt-2">
          <div class="h-2.5 w-4/5 animate-pulse rounded bg-ink-900/80"></div>
        </div>
      </div>
    </div>

    <div v-else-if="items.length === 0 && error" class="pt-16 text-center animate-fade-up">
      <Icon icon="lucide:wifi-off" class="mx-auto text-[42px] text-ink-600" />
      <p class="mt-4 text-base font-bold text-ink-300">{{ error }}</p>
      <button
        v-wave="appWave"
        style="color: var(--ripple)"
        type="button"
        class="btn-press mt-6 inline-flex items-center gap-2 rounded-xl border border-[color:var(--hairline)] bg-ink-900 px-5 py-2.5 text-sm font-bold text-ink-300 transition-colors hover:border-[color:var(--input-border-focus)] hover:text-ink-50"
        @click="retry"
      >
        <Icon icon="lucide:refresh-cw" class="text-[16px]" />
        تلاش دوباره
      </button>
    </div>

    <div v-else-if="items.length === 0" class="pt-16 text-center animate-fade-up">
      <Icon :icon="emptyIcon" class="mx-auto text-[42px] text-ink-600" />
      <p class="mt-4 text-base font-bold text-ink-300">{{ emptyText }}</p>
    </div>

    <div v-else class="animate-fade-in">
      <div class="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 sm:gap-4">
        <component
          :is="cardComponent"
          v-for="(item, index) in items"
          :key="`${isSeries ? 'series' : 'movie'}-${item.id}`"
          :movie="item"
          :eager="index < 9"
        />
      </div>

      <div ref="sentinelRef" class="h-12"></div>

      <div v-if="loadingMore" class="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 sm:gap-4">
        <div v-for="i in 6" :key="i" class="overflow-hidden rounded-xl">
          <div class="aspect-[2/3] animate-pulse rounded-xl bg-ink-900/80"></div>
          <div class="pt-2">
            <div class="h-2.5 w-4/5 animate-pulse rounded bg-ink-900/80"></div>
          </div>
        </div>
      </div>

      <div v-else-if="error" class="py-7 text-center">
        <p class="text-sm font-medium text-ink-400">{{ error }}</p>
        <button
          v-wave="appWave"
          style="color: var(--ripple)"
          type="button"
          class="btn-press mt-3 inline-flex items-center gap-2 rounded-xl bg-ink-900 px-4 py-2 text-xs font-bold text-ink-300 transition-colors hover:text-ink-50"
          @click="loadMore"
        >
          <Icon icon="lucide:refresh-cw" class="text-[14px]" />
          ادامه بده
        </button>
      </div>

      <p v-else-if="!hasMore" class="py-7 text-center text-xs font-medium text-ink-600">
        پایان لیست
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { Movie, Series } from '~~/server/db/schema'
import MovieCard from '~/components/MovieCard.vue'
import SeriesCard from '~/components/SeriesCard.vue'

type MediaItem = (Movie | Series) & { type?: 'movie' | 'series'; durationLabel?: string }

const props = defineProps<{ kind: 'movies' | 'series' }>()
const appWave = useAppWave()
const PAGE_SIZE = 30
const items = ref<MediaItem[]>([])
const loading = ref(false)
const hasMore = ref(true)
const error = ref('')
const sentinelRef = ref<HTMLElement | null>(null)
let observer: IntersectionObserver | null = null

const isSeries = computed(() => props.kind === 'series')
const endpoint = computed(() => isSeries.value ? '/api/series/public' : '/api/movies/public')
const cardComponent = computed(() => isSeries.value ? SeriesCard : MovieCard)
const emptyText = computed(() => isSeries.value ? 'فعلاً سریالی برای نمایش وجود ندارد' : 'فعلاً فیلمی برای نمایش وجود ندارد')
const emptyIcon = computed(() => isSeries.value ? 'lucide:layers-3' : 'lucide:clapperboard')
const initialLoading = computed(() => loading.value && items.value.length === 0)
const loadingMore = computed(() => loading.value && items.value.length > 0)

async function loadMore() {
  if (loading.value || !hasMore.value) return
  loading.value = true
  error.value = ''
  try {
    const rows = await $fetch<MediaItem[]>(endpoint.value, {
      params: { limit: PAGE_SIZE, offset: items.value.length }
    })
    const mediaType = (isSeries.value ? 'series' : 'movie') as 'movie' | 'series'
    const normalized = rows.map(row => ({ ...row, type: mediaType }))
    items.value.push(...normalized)
    hasMore.value = rows.length === PAGE_SIZE
  } catch (err: any) {
    error.value = err?.statusMessage || err?.message || 'خطا در دریافت لیست'
  } finally {
    loading.value = false
  }
}

function retry() {
  items.value = []
  hasMore.value = true
  loadMore()
}

onMounted(() => {
  window.scrollTo(0, 0)
  loadMore()
  observer = new IntersectionObserver((entries) => {
    if (entries.some(entry => entry.isIntersecting)) loadMore()
  }, { rootMargin: '900px 0px' })
  if (sentinelRef.value) observer.observe(sentinelRef.value)
})

watch(sentinelRef, (el, oldEl) => {
  if (!observer) return
  if (oldEl) observer.unobserve(oldEl)
  if (el) observer.observe(el)
})

onBeforeUnmount(() => {
  observer?.disconnect()
})
</script>
