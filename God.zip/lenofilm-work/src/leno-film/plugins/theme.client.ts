// اعمال تم روی document.documentElement قبل از mount شدن Vue
// این کار باعث می‌شه فلش رنگ نداشته باشیم
export default defineNuxtPlugin(() => {
  if (import.meta.client) {
    const themeStore = useThemeStore()

    // اعمال فوری قبل از mount
    document.documentElement.setAttribute('data-theme', themeStore.current)

    // وقتی تم تغییر کرد، data-theme رو update کن
    watch(
      () => themeStore.current,
      (newTheme) => {
        document.documentElement.setAttribute('data-theme', newTheme)
      }
    )
  }
})
