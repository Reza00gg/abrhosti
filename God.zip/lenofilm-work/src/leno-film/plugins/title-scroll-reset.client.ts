export default defineNuxtPlugin(() => {
  if ('scrollRestoration' in window.history) window.history.scrollRestoration = 'manual'
  const router = useRouter()

  function resetScroll() {
    window.scrollTo(0, 0)
    document.documentElement.scrollTop = 0
    document.body.scrollTop = 0
    document.scrollingElement?.scrollTo?.(0, 0)
  }

  function scheduleReset() {
    resetScroll()
    requestAnimationFrame(() => {
      resetScroll()
      requestAnimationFrame(resetScroll)
    })
    window.setTimeout(resetScroll, 80)
    window.setTimeout(resetScroll, 220)
    window.setTimeout(resetScroll, 520)
  }

  window.addEventListener('pageshow', scheduleReset, { passive: true })

  router.beforeEach((_to, _from, next) => {
    resetScroll()
    next()
  })

  router.afterEach(() => {
    scheduleReset()
  })
})
