export default defineNuxtPlugin(() => {
  const auth = useUserAuthStore()
  const toast = useToastStore()
  const router = useRouter()
  const route = useRoute()
  let checking = false

  function isAdminRoute() {
    return route.path.startsWith('/adminChash7nakg')
  }

  async function checkUserStatus() {
    if (isAdminRoute() || !auth.isAuthenticated || !auth.user?.id || checking) return
    checking = true
    try {
      const status = await $fetch<{ exists: boolean; banned: boolean; name?: string; email?: string; contactEmail?: string | null; avatarUrl?: string | null; avatarMime?: string | null; subscriptionExpiresAt?: string | Date | null; createdAt?: string | Date | null }>('/api/users/check', {
        method: 'POST',
        body: { id: auth.user.id },
      })
      if (!status.exists) {
        auth.logout()
        toast.error('حساب شما دیگر در سیستم وجود ندارد')
        await router.push('/')
        return
      }
      if (status.banned) {
        auth.logout()
        toast.error('شما از طرف مدیریت مسدود شده‌اید')
        await router.push('/')
        return
      }
      auth.setUserPatch({ name: status.name, email: status.email, contactEmail: status.contactEmail, avatarUrl: status.avatarUrl, avatarMime: status.avatarMime, subscriptionExpiresAt: status.subscriptionExpiresAt, createdAt: status.createdAt })
    } catch {
      // silent: network/db hiccups should not log users out
    } finally {
      checking = false
    }
  }

  function handleStorage(event: StorageEvent) {
    if (event.key === 'leno-user-status-changed') checkUserStatus()
  }

  const timer = window.setInterval(checkUserStatus, 2500)
  window.addEventListener('focus', checkUserStatus)
  window.addEventListener('storage', handleStorage)

  if (import.meta.hot) {
    import.meta.hot.dispose(() => {
      window.clearInterval(timer)
      window.removeEventListener('focus', checkUserStatus)
      window.removeEventListener('storage', handleStorage)
    })
  }
})
