import VWave from 'v-wave'

export default defineNuxtPlugin((nuxtApp) => {
  nuxtApp.vueApp.use(VWave, {
    // ریپل از currentColor استفاده می‌کنه - هر دکمه می‌تونه رنگ ریپل خودش رو داشته باشه
    color: 'currentColor',
    initialOpacity: 0.65,
    finalOpacity: 0,
    duration: 0.5,
    dissolveDuration: 0.15,
    easing: 'ease-out',
    cancelTouchEnd: false,
  })
})
