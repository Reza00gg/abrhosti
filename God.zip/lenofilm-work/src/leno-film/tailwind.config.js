/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./components/**/*.{js,vue,ts}",
    "./layouts/**/*.vue",
    "./pages/**/*.vue",
    "./plugins/**/*.{js,ts}",
    "./app.vue",
    "./error.vue",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Vazirmatn', 'system-ui', 'sans-serif'],
      },
      colors: {
        // هر رنگ به یک CSS Variable متصل است - تغییر تم = تغییر خودکار
        ink: {
          DEFAULT: 'rgb(var(--text-rgb) / <alpha-value>)',
          50:  'rgb(var(--text-rgb) / <alpha-value>)',
          100: 'rgb(var(--text-rgb) / <alpha-value>)',
          200: 'rgb(var(--text-secondary-rgb) / <alpha-value>)',
          300: 'rgb(var(--text-secondary-rgb) / <alpha-value>)',
          400: 'rgb(var(--text-tertiary-rgb) / <alpha-value>)',
          500: 'rgb(var(--text-tertiary-rgb) / <alpha-value>)',
          600: 'rgb(var(--text-muted-rgb) / <alpha-value>)',
          700: 'rgb(var(--text-muted-rgb) / <alpha-value>)',
          800: 'rgb(var(--surface-rgb) / <alpha-value>)',
          900: 'rgb(var(--bg-alt-rgb) / <alpha-value>)',
          950: 'rgb(var(--bg-rgb) / <alpha-value>)',
        },
      },
      fontSize: {
        '2xs': ['10px', { lineHeight: '14px' }],
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-out',
        'fade-up': 'fadeUp 0.4s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
}
