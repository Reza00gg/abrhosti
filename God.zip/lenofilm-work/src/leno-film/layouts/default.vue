<template>
  <div class="min-h-screen bg-ink-950 text-ink-50">
    <AppHeader />
    <main class="pt-[calc(var(--header-h)+var(--safe-top))] pb-[calc(var(--nav-h)+var(--safe-bottom))] min-h-screen">
      <slot />
    </main>
    <BottomNav />
    <SideMenu />
    <ToastContainer variant="app" />
  </div>
</template>

<script setup lang="ts">
</script>
