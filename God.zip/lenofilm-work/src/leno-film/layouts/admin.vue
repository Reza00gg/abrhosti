<template>
  <!-- پنل مدیریت - طراحی مستقل از سایت اصلی -->
  <div class="min-h-screen bg-[#0a0a0a] text-[#fafafa]" style="font-family: 'Vazirmatn', system-ui, sans-serif;">
    <slot />

    <!-- Toast Container -->
    <ToastContainer />
  </div>
</template>

<script setup lang="ts">
// Admin layout - no theme switching, hardcoded dark theme
</script>
