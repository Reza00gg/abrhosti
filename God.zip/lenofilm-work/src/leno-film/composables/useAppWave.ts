export function useAppWave(kind: 'light' | 'dark' | 'current' | 'card' = 'current') {
  const color = kind === 'dark' ? 'rgba(0,0,0,.34)' : kind === 'light' || kind === 'card' ? 'rgba(255,255,255,.42)' : 'currentColor'
  return {
    color,
    initialOpacity: kind === 'card' ? 0.34 : 0.5,
    finalOpacity: kind === 'card' ? 0.06 : 0.1,
    duration: kind === 'card' ? 1.05 : 0.58,
    dissolveDuration: kind === 'card' ? 0.18 : 0.08,
    easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
  }
}
