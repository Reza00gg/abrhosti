export function useTitleHeader() {
  return useState<{ titleFa: string; titleEn: string }>('title-header', () => ({ titleFa: '', titleEn: '' }))
}
