import { defineStore } from 'pinia'
import type { Movie, Series } from '~~/server/db/schema'

type MediaItem = (Movie | Series) & { type?: 'movie' | 'series'; durationLabel?: string }

const preloadedPosters = new Set<string>()

function warmPosterCache(items: MediaItem[], count = 8) {
  if (!import.meta.client) return
  window.requestIdleCallback?.(() => preloadPosters(items, count)) ?? window.setTimeout(() => preloadPosters(items, count), 0)
}

function preloadPosters(items: MediaItem[], count = 8) {
  for (const item of items.slice(0, count)) {
    const src = item.posterUrl
    if (!src || preloadedPosters.has(src)) continue
    preloadedPosters.add(src)
    const image = new Image()
    image.decoding = 'async'
    image.loading = 'eager'
    image.src = src
  }
}

export const useMoviesStore = defineStore('movies', () => {
  const latest = ref<MediaItem[]>([])
  const latestSeries = ref<MediaItem[]>([])
  const latestLoading = ref(false)
  const latestSeriesLoading = ref(false)
  const latestLoaded = ref(false)
  const latestSeriesLoaded = ref(false)
  const latestError = ref('')
  const latestSeriesError = ref('')
  const latestFetchedAt = ref<number | null>(null)
  const latestSeriesFetchedAt = ref<number | null>(null)

  async function fetchLatest(force = false) {
    if (latestLoading.value) return
    if (latestLoaded.value && !force) return

    latestLoading.value = true
    latestError.value = ''
    try {
      const rows = await $fetch<MediaItem[]>('/api/movies/public', { params: { limit: 20 } })
      warmPosterCache(rows)
      latest.value = rows.map(row => ({ ...row, type: 'movie' }))
      latestLoaded.value = true
      latestFetchedAt.value = Date.now()
    } catch (err: any) {
      latestError.value = err?.statusMessage || err?.message || 'خطا در دریافت فیلم‌ها'
      if (!latest.value.length) latestLoaded.value = false
    } finally {
      latestLoading.value = false
    }
  }

  async function fetchLatestSeries(force = false) {
    if (latestSeriesLoading.value) return
    if (latestSeriesLoaded.value && !force) return

    latestSeriesLoading.value = true
    latestSeriesError.value = ''
    try {
      const rows = await $fetch<MediaItem[]>('/api/series/public', { params: { limit: 20 } })
      warmPosterCache(rows)
      latestSeries.value = rows.map(row => ({ ...row, type: 'series' }))
      latestSeriesLoaded.value = true
      latestSeriesFetchedAt.value = Date.now()
    } catch (err: any) {
      latestSeriesError.value = err?.statusMessage || err?.message || 'خطا در دریافت سریال‌ها'
      if (!latestSeries.value.length) latestSeriesLoaded.value = false
    } finally {
      latestSeriesLoading.value = false
    }
  }

  function clearLatest() {
    latest.value = []
    latestSeries.value = []
    latestLoaded.value = false
    latestSeriesLoaded.value = false
    latestError.value = ''
    latestSeriesError.value = ''
    latestFetchedAt.value = null
    latestSeriesFetchedAt.value = null
  }

  return { latest, latestSeries, latestLoading, latestSeriesLoading, latestLoaded, latestSeriesLoaded, latestError, latestSeriesError, latestFetchedAt, latestSeriesFetchedAt, fetchLatest, fetchLatestSeries, clearLatest }
})
