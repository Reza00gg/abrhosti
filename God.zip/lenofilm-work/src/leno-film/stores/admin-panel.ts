import { defineStore } from 'pinia'
import type { Movie, Series } from '~~/server/db/schema'

type MediaKind = 'movies' | 'series'
type MediaStatus = 'active' | 'archived' | 'deleted'
type UserTab = 'all' | 'active' | 'inactive' | 'deleted'
type UserStatus = 'active' | 'deleted'
type MediaItem = (Movie | Series) & { status?: MediaStatus }
type Counts = Record<MediaStatus, number>
type UserCounts = Record<UserTab, number>
type AdminListResponse<T> = { items: T[]; total: number; counts?: Counts; limit: number; offset: number; status?: MediaStatus }
type AdminUserListResponse<T> = { items: T[]; total: number; counts?: UserCounts; limit: number; offset: number; tab?: UserTab }
type AdminUser = { id: number; name: string; email: string; banned: boolean; status?: UserStatus; subscriptionExpiresAt?: string | null; createdAt: string }

type MediaState = {
  items: MediaItem[]
  total: number
  counts: Counts
  page: number
  search: string
  status: MediaStatus
  loading: boolean
  loaded: boolean
  cache: Record<string, { items: MediaItem[]; total: number; counts: Counts }>
}

type UserState = {
  items: AdminUser[]
  total: number
  counts: UserCounts
  page: number
  search: string
  tab: UserTab
  loading: boolean
  loaded: boolean
  cache: Record<string, { items: AdminUser[]; total: number; counts: UserCounts }>
}

const PAGE_SIZE = 15
const emptyCounts = (): Counts => ({ active: 0, archived: 0, deleted: 0 })
const emptyUserCounts = (): UserCounts => ({ all: 0, active: 0, inactive: 0, deleted: 0 })
const createMediaState = (): MediaState => ({ items: [], total: 0, counts: emptyCounts(), page: 1, search: '', status: 'active', loading: false, loaded: false, cache: {} })
const createUserState = (): UserState => ({ items: [], total: 0, counts: emptyUserCounts(), page: 1, search: '', tab: 'all', loading: false, loaded: false, cache: {} })

function mediaKey(state: MediaState) { return `${state.status}|${state.search.trim()}|${state.page}` }
function userKey(state: UserState) { return `${state.tab}|${state.search.trim()}|${state.page}` }
function uniqueById<T extends { id: number }>(items: T[]) {
  const map = new Map<number, T>()
  for (const item of items) map.set(item.id, item)
  return [...map.values()]
}
function matchMedia(item: any, q: string) { return String(item.titleFa || '').toLowerCase().includes(q) || String(item.titleEn || '').toLowerCase().includes(q) }
function matchUser(item: AdminUser, q: string) { return item.name.toLowerCase().includes(q) || item.email.toLowerCase().includes(q) }
function userBelongsToTab(item: AdminUser, tab: UserTab) {
  if (tab === 'deleted') return item.status === 'deleted'
  if (item.status === 'deleted') return false
  if (tab === 'active') return !item.banned
  if (tab === 'inactive') return item.banned
  return true
}

export const useAdminPanelStore = defineStore('admin-panel', () => {
  const media = reactive<Record<MediaKind, MediaState>>({ movies: createMediaState(), series: createMediaState() })
  const users = reactive<UserState>(createUserState())

  function applyMediaCache(kind: MediaKind) {
    const state = media[kind]
    const cached = state.cache[mediaKey(state)]
    if (!cached) return false
    state.items = cached.items
    state.total = cached.total
    state.counts = cached.counts
    state.loaded = true
    return true
  }

  function applyUserCache() {
    const cached = users.cache[userKey(users)]
    if (!cached) return false
    users.items = cached.items
    users.total = cached.total
    users.counts = cached.counts
    users.loaded = true
    return true
  }

  async function fetchMedia(kind: MediaKind, force = false) {
    const state = media[kind]
    if (!force && applyMediaCache(kind)) return
    if (state.loading) return
    state.loading = true
    try {
      const res = await $fetch<AdminListResponse<MediaItem>>(`/api/${kind}`, {
        params: { status: state.status, q: state.search.trim() || undefined, limit: PAGE_SIZE, offset: (state.page - 1) * PAGE_SIZE }
      })
      state.items = res.items
      state.total = res.total
      state.counts = res.counts || state.counts
      state.loaded = true
      state.cache[mediaKey(state)] = { items: res.items, total: res.total, counts: state.counts }
    } finally { state.loading = false }
  }

  async function fetchUsers(force = false) {
    if (!force && applyUserCache()) return
    if (users.loading) return
    users.loading = true
    try {
      const res = await $fetch<AdminUserListResponse<AdminUser>>('/api/admin/users', {
        params: { tab: users.tab, q: users.search.trim() || undefined, limit: PAGE_SIZE, offset: (users.page - 1) * PAGE_SIZE }
      })
      users.items = res.items
      users.total = res.total
      users.counts = res.counts || users.counts
      users.loaded = true
      users.cache[userKey(users)] = { items: res.items, total: res.total, counts: users.counts }
    } finally { users.loading = false }
  }

  function setMediaStatus(kind: MediaKind, status: MediaStatus) {
    const state = media[kind]
    state.status = status
    state.page = 1
    state.search = ''
    if (!applyMediaCache(kind)) { state.items = []; state.total = 0 }
  }

  function setUserTab(tab: UserTab) {
    users.tab = tab
    users.page = 1
    users.search = ''
    if (!applyUserCache()) { users.items = []; users.total = 0 }
  }

  function setMediaPage(kind: MediaKind, page: number) { media[kind].page = Math.max(1, page) }
  function setUserPage(page: number) { users.page = Math.max(1, page) }

  function setMediaSearch(kind: MediaKind, value: string) {
    const state = media[kind]
    state.search = value
    state.page = 1
    const q = value.trim().toLowerCase()
    if (!q) { applyMediaCache(kind); return }
    const cached = uniqueById(Object.entries(state.cache).filter(([key]) => key.startsWith(`${state.status}|`)).flatMap(([, value]) => value.items)).filter(item => matchMedia(item, q))
    state.items = cached.slice(0, PAGE_SIZE)
    state.total = cached.length
  }

  function setUserSearch(value: string) {
    users.search = value
    users.page = 1
    const q = value.trim().toLowerCase()
    if (!q) { applyUserCache(); return }
    const cached = uniqueById(Object.entries(users.cache).filter(([key]) => key.startsWith(`${users.tab}|`)).flatMap(([, value]) => value.items)).filter(item => matchUser(item, q))
    users.items = cached.slice(0, PAGE_SIZE)
    users.total = cached.length
  }

  function clearMediaCache(kind: MediaKind) { media[kind].cache = {}; media[kind].loaded = false }
  function clearUserCache() { users.cache = {}; users.loaded = false }

  function changeMediaStatusLocal(kind: MediaKind, item: MediaItem, to: MediaStatus) {
    const state = media[kind]
    const from = (item.status || state.status || 'active') as MediaStatus
    const updated = { ...item, status: to }
    for (const key of Object.keys(state.cache)) {
      const cached = state.cache[key]
      cached.items = cached.items.filter(row => row.id !== item.id)
      if (key.startsWith(`${to}|`) && key.endsWith('|1')) cached.items = [updated, ...cached.items].slice(0, PAGE_SIZE)
      if (key.startsWith(`${from}|`)) cached.total = Math.max(0, cached.total - 1)
      if (key.startsWith(`${to}|`)) cached.total += 1
      cached.counts = { ...cached.counts, [from]: Math.max(0, (cached.counts[from] || 0) - 1), [to]: (cached.counts[to] || 0) + 1 }
    }
    state.items = state.items.filter(row => row.id !== item.id)
    state.total = Math.max(0, state.total - 1)
    state.counts = { ...state.counts, [from]: Math.max(0, (state.counts[from] || 0) - 1), [to]: (state.counts[to] || 0) + 1 }
  }

  function removeMediaPermanentLocal(kind: MediaKind, item: MediaItem) {
    const state = media[kind]
    const from = (item.status || state.status || 'deleted') as MediaStatus
    for (const key of Object.keys(state.cache)) {
      const cached = state.cache[key]
      cached.items = cached.items.filter(row => row.id !== item.id)
      if (key.startsWith(`${from}|`)) cached.total = Math.max(0, cached.total - 1)
      cached.counts = { ...cached.counts, [from]: Math.max(0, (cached.counts[from] || 0) - 1) }
    }
    state.items = state.items.filter(row => row.id !== item.id)
    state.total = Math.max(0, state.total - 1)
    state.counts = { ...state.counts, [from]: Math.max(0, (state.counts[from] || 0) - 1) }
  }

  function changeUserStatusLocal(item: AdminUser, status: UserStatus) {
    const wasDeleted = item.status === 'deleted'
    const updated = { ...item, status }
    const deltas: Partial<UserCounts> = {}
    if (status === 'deleted' && !wasDeleted) {
      deltas.all = -1; deltas.deleted = 1; deltas[item.banned ? 'inactive' : 'active'] = -1
    } else if (status === 'active' && wasDeleted) {
      deltas.all = 1; deltas.deleted = -1; deltas[item.banned ? 'inactive' : 'active'] = 1
    }
    for (const key of Object.keys(users.cache)) {
      const cached = users.cache[key]
      const tab = key.split('|')[0] as UserTab
      cached.items = cached.items.filter(row => row.id !== item.id)
      if (userBelongsToTab(updated, tab) && key.endsWith('|1')) cached.items = [updated, ...cached.items].slice(0, PAGE_SIZE)
      if (userBelongsToTab(item, tab) && !userBelongsToTab(updated, tab)) cached.total = Math.max(0, cached.total - 1)
      if (!userBelongsToTab(item, tab) && userBelongsToTab(updated, tab)) cached.total += 1
      cached.counts = { ...cached.counts }
      for (const [name, delta] of Object.entries(deltas)) cached.counts[name as UserTab] = Math.max(0, (cached.counts[name as UserTab] || 0) + Number(delta))
    }
    users.items = users.items.filter(row => row.id !== item.id)
    if (userBelongsToTab(item, users.tab) && !userBelongsToTab(updated, users.tab)) users.total = Math.max(0, users.total - 1)
    if (!userBelongsToTab(item, users.tab) && userBelongsToTab(updated, users.tab)) users.total += 1
    users.counts = { ...users.counts }
    for (const [name, delta] of Object.entries(deltas)) users.counts[name as UserTab] = Math.max(0, (users.counts[name as UserTab] || 0) + Number(delta))
  }

  function removeUserPermanentLocal(item: AdminUser) {
    for (const key of Object.keys(users.cache)) {
      const cached = users.cache[key]
      if (cached.items.some(row => row.id === item.id)) cached.total = Math.max(0, cached.total - 1)
      cached.items = cached.items.filter(row => row.id !== item.id)
      cached.counts = { ...cached.counts, deleted: Math.max(0, cached.counts.deleted - 1) }
    }
    users.items = users.items.filter(row => row.id !== item.id)
    users.total = Math.max(0, users.total - 1)
    users.counts = { ...users.counts, deleted: Math.max(0, users.counts.deleted - 1) }
  }


  function resetUserLocal(id: number) {
    const update = (rows: AdminUser[]) => rows.map(row => row.id === id ? { ...row, subscriptionExpiresAt: null } : row)
    users.items = update(users.items)
    for (const key of Object.keys(users.cache)) users.cache[key].items = update(users.cache[key].items)
  }

  function updateUserBanLocal(id: number, banned: boolean) {
    let old: AdminUser | undefined
    for (const row of users.items) if (row.id === id) old = row
    if (!old) {
      for (const cached of Object.values(users.cache)) {
        old = cached.items.find(row => row.id === id)
        if (old) break
      }
    }
    if (!old || old.status === 'deleted') return
    const updated = { ...old, banned }
    const deltaActive = banned ? -1 : 1
    const deltaInactive = banned ? 1 : -1
    for (const key of Object.keys(users.cache)) {
      const cached = users.cache[key]
      const tab = key.split('|')[0] as UserTab
      cached.items = cached.items.filter(row => row.id !== id)
      if (userBelongsToTab(updated, tab) && key.endsWith('|1')) cached.items = [updated, ...cached.items].slice(0, PAGE_SIZE)
      if (userBelongsToTab(old, tab) && !userBelongsToTab(updated, tab)) cached.total = Math.max(0, cached.total - 1)
      if (!userBelongsToTab(old, tab) && userBelongsToTab(updated, tab)) cached.total += 1
      cached.counts = { ...cached.counts, active: Math.max(0, cached.counts.active + deltaActive), inactive: Math.max(0, cached.counts.inactive + deltaInactive) }
    }
    users.items = users.items.filter(row => row.id !== id)
    if (userBelongsToTab(updated, users.tab) && users.tab === 'all') users.items = users.items.map(row => row.id === id ? updated : row)
    if (userBelongsToTab(old, users.tab) && !userBelongsToTab(updated, users.tab)) users.total = Math.max(0, users.total - 1)
    if (!userBelongsToTab(old, users.tab) && userBelongsToTab(updated, users.tab)) users.total += 1
    if (users.tab === 'all') users.items = [updated, ...users.items.filter(row => row.id !== id)].slice(0, PAGE_SIZE)
    users.counts = { ...users.counts, active: Math.max(0, users.counts.active + deltaActive), inactive: Math.max(0, users.counts.inactive + deltaInactive) }
  }

  return {
    media,
    users,
    fetchMedia,
    fetchUsers,
    setMediaStatus,
    setUserTab,
    setMediaPage,
    setUserPage,
    setMediaSearch,
    setUserSearch,
    clearMediaCache,
    clearUserCache,
    changeMediaStatusLocal,
    removeMediaPermanentLocal,
    changeUserStatusLocal,
    removeUserPermanentLocal,
    resetUserLocal,
    updateUserBanLocal,
  }
})
