import { defineStore } from 'pinia'

function apiErrorMessage(err: any, fallback: string) {
  return err?.data?.statusMessage || err?.statusMessage || err?.message || fallback
}

interface User {
  id: number
  name: string
  email: string
  contactEmail?: string | null
  avatarUrl?: string | null
  avatarMime?: string | null
  subscriptionExpiresAt?: string | Date | null
  createdAt?: string | Date | null
  loggedInAt: number
}

type AuthUserResponse = { id: number; name: string; email: string; contactEmail?: string | null; avatarUrl?: string | null; avatarMime?: string | null; subscriptionExpiresAt?: string | Date | null; createdAt?: string | Date | null }

export const useUserAuthStore = defineStore('user-auth', () => {
  const cookie = useCookie<User | null>('user-auth', {
    default: () => null,
    maxAge: 60 * 60 * 24 * 7,
    sameSite: 'lax',
  })

  const user = computed(() => cookie.value)
  const isAuthenticated = computed(() => !!cookie.value)

  function setUserPatch(patch: Partial<User>) {
    if (!cookie.value) return
    cookie.value = { ...cookie.value, ...patch }
  }

  async function login(email: string, password: string): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await $fetch<AuthUserResponse>('/api/users/signin', {
        method: 'POST',
        body: { email, password },
      })
      cookie.value = { ...res, loggedInAt: Date.now() }
      return { success: true }
    } catch (err: any) {
      return { success: false, error: apiErrorMessage(err, 'خطا در ورود') }
    }
  }

  async function signup(name: string, email: string, password: string): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await $fetch<AuthUserResponse>('/api/users/signup', {
        method: 'POST',
        body: { name, email, password },
      })
      cookie.value = { ...res, loggedInAt: Date.now() }
      return { success: true }
    } catch (err: any) {
      return { success: false, error: apiErrorMessage(err, 'خطا در ثبت‌نام') }
    }
  }

  async function updateProfile(payload: { name: string; contactEmail?: string }): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await $fetch<AuthUserResponse>('/api/users/profile', {
        method: 'PUT',
        body: payload,
      })
      setUserPatch({ name: res.name, contactEmail: res.contactEmail, subscriptionExpiresAt: res.subscriptionExpiresAt, createdAt: res.createdAt })
      return { success: true }
    } catch (err: any) {
      return { success: false, error: apiErrorMessage(err, 'خطا در ذخیره اطلاعات حساب') }
    }
  }

  async function updateAvatar(avatarUrl: string): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await $fetch<AuthUserResponse>('/api/users/avatar', {
        method: 'PUT',
        body: { avatarUrl },
      })
      setUserPatch({ avatarUrl: res.avatarUrl, avatarMime: res.avatarMime, subscriptionExpiresAt: res.subscriptionExpiresAt, createdAt: res.createdAt })
      return { success: true }
    } catch (err: any) {
      return { success: false, error: apiErrorMessage(err, 'خطا در ذخیره تصویر پروفایل') }
    }
  }

  async function deleteAvatar(): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await $fetch<AuthUserResponse>('/api/users/avatar', { method: 'DELETE' })
      setUserPatch({ avatarUrl: res.avatarUrl, avatarMime: res.avatarMime, subscriptionExpiresAt: res.subscriptionExpiresAt, createdAt: res.createdAt })
      return { success: true }
    } catch (err: any) {
      return { success: false, error: apiErrorMessage(err, 'خطا در حذف تصویر پروفایل') }
    }
  }

  function logout() {
    cookie.value = null
  }

  return { user, isAuthenticated, login, signup, updateProfile, updateAvatar, deleteAvatar, setUserPatch, logout }
})
