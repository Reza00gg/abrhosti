import { defineStore } from 'pinia'

interface Toast {
  id: number
  message: string
  type: 'success' | 'error' | 'info'
}

export const useToastStore = defineStore('toast', () => {
  const toasts = ref<Toast[]>([])
  let nextId = 1
  const timers = new Map<number, ReturnType<typeof setTimeout>>()

  function remove(id: number) {
    const timer = timers.get(id)
    if (timer) clearTimeout(timer)
    timers.delete(id)
    const idx = toasts.value.findIndex(t => t.id === id)
    if (idx > -1) toasts.value.splice(idx, 1)
  }

  function show(message: string, type: 'success' | 'error' | 'info' = 'info', duration = 3200) {
    const text = String(message || '').trim()
    if (!text) return

    const duplicate = toasts.value.find(t => t.message === text && t.type === type)
    if (duplicate) {
      remove(duplicate.id)
    }

    while (toasts.value.length >= 3) {
      remove(toasts.value[0].id)
    }

    const id = nextId++
    toasts.value.push({ id, message: text, type })

    if (duration > 0) {
      timers.set(id, setTimeout(() => remove(id), duration))
    }
  }

  function success(message: string, duration = 3200) { show(message, 'success', duration) }
  function error(message: string, duration = 3800) { show(message, 'error', duration) }
  function info(message: string, duration = 3200) { show(message, 'info', duration) }
  function clear() { toasts.value.slice().forEach(t => remove(t.id)) }

  return { toasts, show, remove, success, error, info, clear }
})
