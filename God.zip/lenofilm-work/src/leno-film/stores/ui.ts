import { defineStore } from 'pinia'

export const useUIStore = defineStore('ui', () => {
  // منوی اصلی سایت
  const sideMenuOpen = ref(false)

  function openSideMenu() {
    sideMenuOpen.value = true
  }

  function closeSideMenu() {
    sideMenuOpen.value = false
  }

  function toggleSideMenu() {
    sideMenuOpen.value = !sideMenuOpen.value
  }

  // منوی پنل مدیریت
  const adminDrawerOpen = ref(false)

  function openAdminDrawer() {
    adminDrawerOpen.value = true
  }

  function closeAdminDrawer() {
    adminDrawerOpen.value = false
  }

  function toggleAdminDrawer() {
    adminDrawerOpen.value = !adminDrawerOpen.value
  }

  return {
    sideMenuOpen,
    openSideMenu,
    closeSideMenu,
    toggleSideMenu,
    adminDrawerOpen,
    openAdminDrawer,
    closeAdminDrawer,
    toggleAdminDrawer,
  }
})
