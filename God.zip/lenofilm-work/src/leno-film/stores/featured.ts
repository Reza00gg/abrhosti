import { defineStore } from 'pinia'

export type FeaturedSlide = {
  id: string
  mediaType: 'movie' | 'series'
  mediaId: number
  titleFa: string
  titleEn: string
  year: number
  coverUrl: string
  posterUrl: string
}

export const useFeaturedStore = defineStore('featured', () => {
  const items = ref<FeaturedSlide[]>([])
  const loading = ref(false)
  const loaded = ref(false)
  const error = ref('')

  async function fetchFeatured(force = false) {
    if (loading.value) return
    if (loaded.value && !force) return
    loading.value = true
    error.value = ''
    try {
      items.value = await $fetch<FeaturedSlide[]>('/api/featured')
      loaded.value = true
    } catch (err: any) {
      error.value = err?.statusMessage || err?.message || 'خطا در دریافت اسلایدها'
      if (!items.value.length) loaded.value = false
    } finally {
      loading.value = false
    }
  }

  function clearFeatured() {
    items.value = []
    loaded.value = false
    error.value = ''
  }

  return { items, loading, loaded, error, fetchFeatured, clearFeatured }
})
