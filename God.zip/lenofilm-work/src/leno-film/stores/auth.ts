import { defineStore } from 'pinia'

interface AdminUser {
  email: string
  loggedInAt: number
}

export const useAuthStore = defineStore('admin-auth', () => {
  // ذخیره در کوکی - ۷ روز
  const cookie = useCookie<AdminUser | null>('admin-auth', {
    default: () => null,
    maxAge: 60 * 60 * 24 * 7,
    sameSite: 'lax',
  })

  const user = computed(() => cookie.value)
  const isAuthenticated = computed(() => !!cookie.value)

  function login(email: string, password: string): { success: boolean; error?: string } {
    // اعتبار سنجی ساده برای توسعه
    if (email === 'admin@lenofilm.com' && password === 'admin123') {
      cookie.value = {
        email,
        loggedInAt: Date.now(),
      }
      return { success: true }
    }
    return { success: false, error: 'ایمیل یا رمز عبور اشتباه است' }
  }

  function logout() {
    cookie.value = null
  }

  return { user, isAuthenticated, login, logout }
})
