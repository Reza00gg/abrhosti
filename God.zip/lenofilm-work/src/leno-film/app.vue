<template>
  <NuxtLayout>
    <NuxtPage :transition="false" />
  </NuxtLayout>
</template>

<script setup lang="ts">
const route = useRoute()
const accountTabletBodyClass = computed(() => {
  const classes: string[] = []
  const isAccountPanel = route.path.startsWith('/account') && route.path !== '/account/signin' && route.path !== '/account/signup'
  if (isAccountPanel) classes.push('account-tablet-route')
  if (route.path.startsWith('/title/')) classes.push('title-route')
  return classes.join(' ')
})
useHead(() => ({
  htmlAttrs: { lang: 'fa', dir: 'rtl' },
  bodyAttrs: { class: accountTabletBodyClass.value },
}))
</script>
