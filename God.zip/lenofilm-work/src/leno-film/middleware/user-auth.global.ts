export default defineNuxtRouteMiddleware(async (to) => {
  if (!to.path.startsWith('/account')) return

  const auth = useUserAuthStore()

  // مسیرهای حساب به جز ورود/ثبت‌نام نیاز به ورود دارند
  const isAuthPage = to.path === '/account/signin' || to.path === '/account/signup'
  if (!isAuthPage && !auth.isAuthenticated) {
    return navigateTo('/account/signin')
  }

  // /account/signin یا /account/signup → اگه لاگین هست، بره به /account
  if (isAuthPage && auth.isAuthenticated) {
    return navigateTo('/account')
  }

  // اگه لاگین هست و می‌خواد بره /account، چک کن بن شده یا نه
  if (!isAuthPage && auth.isAuthenticated && auth.user?.id) {
    try {
      const status = await $fetch<{ exists: boolean; banned: boolean }>('/api/users/check', {
        method: 'POST',
        body: { id: auth.user.id }
      })
      if (!status.exists) {
        auth.logout()
        return navigateTo('/account/signin')
      }
      if (status.banned) {
        auth.logout()
        return navigateTo('/account/signin')
      }
    } catch {
      // ignore
    }
  }
})
