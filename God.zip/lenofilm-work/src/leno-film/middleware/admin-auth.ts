// محافظت از route های پنل مدیریت
export default defineNuxtRouteMiddleware((to) => {
  // فقط برای route های admin
  if (!to.path.startsWith('/adminChash7nakg')) return

  // صفحه‌ی ورود عمومی است
  if (to.path === '/adminChash7nakg' || to.path === '/adminChash7nakg/') return

  // بقیه route ها نیاز به احراز هویت دارن
  const auth = useAuthStore()
  if (!auth.isAuthenticated) {
    return navigateTo('/adminChash7nakg')
  }
})
