<template>
  <div
    v-wave
    style="color: rgba(255, 255, 255, 0.4)"
    class="btn-press group relative rounded-2xl overflow-hidden bg-ink-900/40 border border-[color:var(--hairline)] hover:border-[color:var(--input-border-focus)] transition-colors duration-300 ease-out cursor-pointer"
  >
    <!-- پوستر -->
    <div class="aspect-[2/3] relative overflow-hidden bg-ink-950">
      <img
        v-if="movie.posterUrl"
        :src="movie.posterUrl"
        :alt="movie.titleEn"
        class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
        @error="onImageError"
      />
      <div v-else class="absolute inset-0 flex items-center justify-center">
        <Icon icon="lucide:film" class="text-[40px] text-ink-700" />
      </div>

      <!-- رتبه IMDb -->
      <div class="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 rounded-md bg-black/70 backdrop-blur-sm text-[11px] font-medium text-white">
        <Icon icon="lucide:star" class="text-[12px] fill-current text-yellow-400" />
        <span>{{ movie.rating.toFixed(1) }}</span>
      </div>
    </div>

    <!-- اطلاعات -->
    <div class="p-3">
      <h3 class="text-[13px] font-semibold text-ink-50 truncate" dir="ltr">
        {{ movie.titleEn }}
      </h3>
      <div class="mt-1 flex items-center gap-2 text-[11px] text-ink-500">
        <span>{{ movie.year }}</span>
        <span class="w-1 h-1 rounded-full bg-ink-600"></span>
        <span>{{ movie.duration }} دقیقه</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { Movie } from '~~/server/db/schema'

defineProps<{
  movie: Movie
}>()

function onImageError(e: Event) {
  ;(e.target as HTMLImageElement).style.display = 'none'
}
</script>
