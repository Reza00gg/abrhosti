import { pgTable, serial, text, integer, real, timestamp } from 'drizzle-orm/pg-core'

export const movies = pgTable('movies', {
  id: serial('id').primaryKey(),
  titleFa: text('title_fa').notNull(),
  titleEn: text('title_en').notNull(),
  duration: integer('duration').notNull(),
  year: integer('year').notNull(),
  rating: real('rating').notNull(),
  posterUrl: text('poster_url').notNull(),
  coverUrl: text('cover_url').notNull(),
  description: text('description').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export type Movie = typeof movies.$inferSelect
export type NewMovie = typeof movies.$inferInsert
