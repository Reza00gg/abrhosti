import { useDb } from '~~/server/db'
import { movies } from '~~/server/db/schema'
import { count } from 'drizzle-orm'

export default defineEventHandler(async () => {
  const db = useDb()

  const [moviesCount] = await db.select({ count: count() }).from(movies)

  return {
    movies: moviesCount?.count ?? 0,
    series: 0,
    users: 1,
    comments: 0,
  }
})
