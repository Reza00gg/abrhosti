import { movies } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  const body = await readBody(event)

  if (!id || isNaN(id)) {
    throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  }

  const db = useDb()
  const [updated] = await db.update(movies)
    .set({
      titleFa: String(body.titleFa),
      titleEn: String(body.titleEn),
      duration: Number(body.duration),
      year: Number(body.year),
      rating: Number(body.rating),
      posterUrl: String(body.posterUrl || ''),
      coverUrl: String(body.coverUrl || ''),
      description: String(body.description || ''),
    })
    .where(eq(movies.id, id))
    .returning()

  if (!updated) {
    throw createError({ statusCode: 404, statusMessage: 'فیلم پیدا نشد' })
  }

  return updated
})
