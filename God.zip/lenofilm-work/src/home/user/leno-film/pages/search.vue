<template>
  <div class="min-h-[60vh]">

    <!-- Search Header -->
    <div class="px-4 pt-6 sm:pt-8 pb-3">
      <div class="relative">
        <Icon
          icon="lucide:search"
          class="absolute right-4 top-1/2 -translate-y-1/2 text-[20px] text-ink-500 pointer-events-none transition-colors duration-200"
          :class="query ? 'text-ink-300' : ''"
        />
        <input
          ref="searchInput"
          v-model="query"
          type="text"
          placeholder="جستجو در هزاران فیلم و سریال"
          class="w-full h-12 pe-12 ps-12 rounded-2xl focus:rounded-3xl bg-ink-950 text-ink-50 placeholder:text-ink-500 text-[15px] border border-[color:var(--hairline)] focus:border-[color:var(--input-border-focus)] outline-none focus:ring-0 transition-[border-color,border-radius] duration-300 ease-out"
        />
        <button
          v-if="query"
          v-wave
          style="color: var(--ripple)"
          @click="clearSearch"
          class="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 flex items-center justify-center rounded-full hover:bg-ink-900 transition-colors"
          aria-label="پاک کردن جستجو"
        >
          <Icon icon="lucide:x" class="text-[18px] text-ink-400" />
        </button>
      </div>
    </div>

    <!-- Content -->
    <div class="px-4 sm:px-6 pt-4 pb-8">

      <!-- حالت بدون متن -->
      <div v-if="!query.trim()" class="text-center pt-16 animate-fade-up">
        <Icon icon="lucide:search" class="text-[40px] text-ink-600 mx-auto" />
        <p class="mt-4 text-base text-ink-400">
          جستجو کنید
        </p>
        <p class="mt-1 text-sm text-ink-600">
          نام فیلم، سریال، کارگردان یا بازیگر
        </p>
      </div>

      <!-- اسکلتون -->
      <div v-else-if="loading" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4 animate-fade-in">
        <div
          v-for="i in 6"
          :key="i"
          class="rounded-2xl overflow-hidden bg-ink-900/40 border border-[color:var(--hairline)]"
        >
          <div class="aspect-[2/3] bg-ink-900 animate-pulse"></div>
          <div class="p-3 space-y-2">
            <div class="h-3 bg-ink-900 rounded animate-pulse"></div>
            <div class="h-2 bg-ink-900 rounded w-2/3 animate-pulse"></div>
          </div>
        </div>
      </div>

      <!-- حالت بدون نتیجه -->
      <div v-else-if="results.length === 0" class="text-center pt-16 animate-fade-up">
        <Icon icon="lucide:search-x" class="text-[40px] text-ink-600 mx-auto" />
        <p class="mt-4 text-base text-ink-400 font-medium">
          نتیجه‌ای یافت نشد
        </p>
        <p class="mt-2 text-sm text-ink-600">
          برای «{{ query }}» نتیجه‌ای پیدا نشد
        </p>
        <button
          v-wave
          style="color: var(--ripple)"
          @click="clearSearch"
          class="btn-press mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-ink-900 border border-[color:var(--hairline)] text-sm text-ink-300 hover:text-ink-50 hover:border-[color:var(--input-border-focus)] transition-colors"
        >
          <Icon icon="lucide:arrow-right" class="text-[16px]" />
          بازگشت
        </button>
      </div>

      <!-- نتایج -->
      <div v-else class="animate-fade-in">
        <p class="text-[12px] text-ink-500 mb-4">
          {{ results.length }} نتیجه برای «{{ query }}»
        </p>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          <MovieCard
            v-for="movie in results"
            :key="movie.id"
            :movie="movie"
          />
        </div>
      </div>

    </div>
  </div>
</template>

<script setup lang="ts">
import type { Movie } from '~~/server/db/schema'

definePageMeta({ title: 'جستجو' })

const query = ref('')
const results = ref<Movie[]>([])
const loading = ref(false)
const searchInput = ref<HTMLInputElement | null>(null)

let searchTimer: ReturnType<typeof setTimeout> | null = null

watch(query, (newQuery) => {
  if (searchTimer) clearTimeout(searchTimer)

  const q = newQuery.trim()
  if (!q) {
    results.value = []
    loading.value = false
    return
  }

  // کمی تاخیر برای حس بهتر (debounce)
  loading.value = true
  searchTimer = setTimeout(async () => {
    try {
      results.value = await $fetch<Movie[]>('/api/movies', {
        params: { q }
      })
    } catch (err) {
      results.value = []
    } finally {
      loading.value = false
    }
  }, 200)
})

function clearSearch() {
  query.value = ''
  results.value = []
  searchInput.value?.focus()
}

onMounted(() => {
  searchInput.value?.focus()
})
</script>
