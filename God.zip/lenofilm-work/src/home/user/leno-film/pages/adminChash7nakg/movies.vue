<template>
  <div class="min-h-screen">
    <AdminHeader />

    <main class="pt-[60px] min-h-screen pb-10">
      <div class="px-4 sm:px-6 py-6 max-w-6xl mx-auto">

        <!-- عنوان و دکمه افزودن -->
        <div class="flex items-center justify-between mb-6">
          <div>
            <h1 class="text-[20px] font-semibold tracking-tight text-[#fafafa]">
              فیلم ها
            </h1>
            <p class="mt-1 text-[12px] text-[#71717a]">
              مدیریت فیلم‌های سایت
            </p>
          </div>
          <button
            v-wave
            style="color: rgba(255, 255, 255, 0.45)"
            @click="openAddForm"
            class="btn-press flex items-center gap-2 h-10 px-4 rounded-xl bg-[#fafafa] text-[#0a0a0a] text-[13px] font-medium"
          >
            <Icon icon="lucide:plus" class="text-[18px]" />
            <span class="hidden sm:inline">افزودن فیلم</span>
          </button>
        </div>

        <!-- جستجو -->
        <div class="mb-6">
          <div class="relative">
            <Icon icon="lucide:search" class="absolute right-4 top-1/2 -translate-y-1/2 text-[18px] text-[#71717a] pointer-events-none" />
            <input
              v-model="search"
              type="text"
              placeholder="جستجو در فیلم‌ها..."
              class="w-full h-11 pe-11 ps-4 rounded-xl bg-[#18181b] border border-[#1f1f1f] text-[14px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out"
            />
          </div>
        </div>

        <!-- لیست فیلم‌ها -->
        <div v-if="loading" class="text-center py-12">
          <Icon icon="lucide:loader-2" class="text-[32px] text-[#52525b] mx-auto animate-spin" />
        </div>

        <div v-else-if="filteredMovies.length === 0" class="text-center py-16">
          <Icon icon="lucide:film" class="text-[36px] text-[#52525b] mx-auto" />
          <p class="mt-3 text-[14px] text-[#71717a]">
            {{ search ? 'نتیجه‌ای یافت نشد' : 'هنوز فیلمی اضافه نشده' }}
          </p>
        </div>

        <ul v-else class="space-y-2">
          <li
            v-for="movie in filteredMovies"
            :key="movie.id"
            class="p-4 rounded-2xl bg-[#18181b] border border-[#1f1f1f] flex items-center gap-4"
          >
            <!-- پوستر -->
            <div class="w-12 h-16 rounded-lg overflow-hidden bg-[#0a0a0a] shrink-0 flex items-center justify-center">
              <img
                v-if="movie.posterUrl"
                :src="movie.posterUrl"
                :alt="movie.titleFa"
                class="w-full h-full object-cover"
                @error="(e: any) => e.target.style.display = 'none'"
              />
              <Icon v-else icon="lucide:film" class="text-[20px] text-[#52525b]" />
            </div>

            <!-- اطلاعات -->
            <div class="flex-1 min-w-0">
              <h3 class="text-[14px] font-semibold text-[#fafafa] truncate">
                {{ movie.titleFa }}
              </h3>
              <p class="text-[12px] text-[#71717a] truncate" dir="ltr">
                {{ movie.titleEn }}
              </p>
              <div class="mt-1.5 flex items-center gap-3 text-[11px] text-[#52525b]">
                <span class="flex items-center gap-1">
                  <Icon icon="lucide:star" class="text-[12px] text-[#fafafa]" />
                  <span class="text-[#fafafa] font-medium">{{ movie.rating.toFixed(1) }}</span>
                </span>
                <span>{{ movie.year }}</span>
                <span>{{ movie.duration }} دقیقه</span>
              </div>
            </div>

            <!-- اکشن‌ها -->
            <div class="flex items-center gap-1 shrink-0">
              <button
                v-wave
                style="color: rgba(255, 255, 255, 0.45)"
                @click="openEditForm(movie)"
                class="btn-press w-9 h-9 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] text-[#a1a1aa] hover:text-[#fafafa] transition-colors"
                title="ویرایش"
              >
                <Icon icon="lucide:pencil" class="text-[16px]" />
              </button>
              <button
                v-wave
                style="color: rgba(239, 68, 68, 0.45)"
                @click="confirmDelete(movie)"
                class="btn-press w-9 h-9 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] text-[#a1a1aa] hover:text-[#ef4444] transition-colors"
                title="حذف"
              >
                <Icon icon="lucide:trash-2" class="text-[16px]" />
              </button>
            </div>
          </li>
        </ul>

      </div>
    </main>

    <AdminDrawer />

    <!-- فرم افزودن/ویرایش -->
    <MovieForm
      v-model="formOpen"
      :movie="editingMovie"
      @saved="onMovieSaved"
    />
  </div>
</template>

<script setup lang="ts">
import type { Movie } from '~~/server/db/schema'

definePageMeta({
  layout: 'admin',
  middleware: 'admin-auth',
})

const toast = useToastStore()

const movies = ref<Movie[]>([])
const search = ref('')
const loading = ref(false)

const formOpen = ref(false)
const editingMovie = ref<Movie | null>(null)

const filteredMovies = computed(() => {
  if (!search.value.trim()) return movies.value
  const q = search.value.trim().toLowerCase()
  return movies.value.filter(m =>
    m.titleFa.toLowerCase().includes(q) ||
    m.titleEn.toLowerCase().includes(q)
  )
})

async function fetchMovies() {
  loading.value = true
  try {
    movies.value = await $fetch<Movie[]>('/api/movies')
  } catch (err: any) {
    toast.error('خطا در بارگذاری فیلم‌ها')
    movies.value = []
  } finally {
    loading.value = false
  }
}

function openAddForm() {
  editingMovie.value = null
  formOpen.value = true
}

function openEditForm(movie: Movie) {
  editingMovie.value = movie
  formOpen.value = true
}

async function onMovieSaved() {
  await fetchMovies()
}

async function confirmDelete(movie: Movie) {
  if (!confirm(`آیا از حذف «${movie.titleFa}» مطمئن هستید؟`)) return

  try {
    await $fetch(`/api/movies/${movie.id}`, { method: 'DELETE' })
    toast.success('فیلم حذف شد')
    await fetchMovies()
  } catch (err: any) {
    toast.error('خطا در حذف فیلم')
  }
}

onMounted(() => {
  fetchMovies()
})
</script>
