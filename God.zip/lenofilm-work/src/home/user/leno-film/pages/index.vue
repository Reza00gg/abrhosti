<template>
  <div class="px-4 sm:px-6 pt-6 sm:pt-8 pb-8">
    <!-- عنوان -->
    <div class="mb-6">
      <h1 class="text-[20px] font-semibold tracking-tight text-ink-50">
        فیلم‌ها
      </h1>
      <p class="mt-1 text-[12px] text-ink-500">
        {{ loading ? 'در حال بارگذاری...' : `${movies.length} فیلم` }}
      </p>
    </div>

    <!-- اسکلتون لودینگ -->
    <div v-if="loading" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
      <div
        v-for="i in 10"
        :key="i"
        class="rounded-2xl overflow-hidden bg-ink-900/40 border border-[color:var(--hairline)]"
      >
        <div class="aspect-[2/3] bg-ink-900 animate-pulse"></div>
        <div class="p-3 space-y-2">
          <div class="h-3 bg-ink-900 rounded animate-pulse"></div>
          <div class="h-2 bg-ink-900 rounded w-2/3 animate-pulse"></div>
        </div>
      </div>
    </div>

    <!-- حالت خالی -->
    <div v-else-if="movies.length === 0" class="text-center py-16">
      <Icon icon="lucide:film" class="text-[40px] text-ink-600 mx-auto" />
      <p class="mt-4 text-[14px] text-ink-400">
        هنوز فیلمی اضافه نشده
      </p>
      <p class="mt-1 text-[12px] text-ink-600">
        از پنل مدیریت فیلم اضافه کنید
      </p>
    </div>

    <!-- گرید فیلم‌ها -->
    <div v-else class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
      <MovieCard
        v-for="movie in movies"
        :key="movie.id"
        :movie="movie"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import type { Movie } from '~~/server/db/schema'

definePageMeta({ title: 'خانه' })

const movies = ref<Movie[]>([])
const loading = ref(true)

async function fetchMovies() {
  try {
    movies.value = await $fetch<Movie[]>('/api/movies')
  } catch (err) {
    movies.value = []
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  fetchMovies()
})
</script>
