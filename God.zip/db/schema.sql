create table if not exists users (
  id text primary key,
  name text not null,
  email text not null unique,
  password_hash text not null,
  role text not null default 'user',
  email_verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists products (
  id text primary key,
  category text not null,
  country text,
  title text not null,
  subtitle text not null,
  price_monthly integer not null,
  currency text not null,
  badge text not null,
  specs jsonb not null default '{}'::jsonb,
  features jsonb not null default '[]'::jsonb,
  route text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists orders (
  id text primary key,
  order_number text not null unique,
  user_id text not null references users(id) on delete cascade,
  status text not null default 'paid_mock',
  payment_status text not null default 'paid_mock',
  provision_status text not null default 'queued',
  total_amount integer not null,
  currency text not null default 'تومان',
  domain_name text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists order_items (
  id text primary key,
  order_id text not null references orders(id) on delete cascade,
  product_id text not null,
  title text not null,
  category text not null,
  quantity integer not null default 1,
  unit_amount integer not null,
  cycle text not null default 'monthly',
  product_snapshot jsonb not null,
  created_at timestamptz not null default now()
);

create table if not exists audit_events (
  id text primary key,
  user_id text references users(id) on delete set null,
  event text not null,
  ip text,
  user_agent text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_orders_user_id on orders(user_id);
create index if not exists idx_order_items_order_id on order_items(order_id);
create index if not exists idx_audit_events_user_id on audit_events(user_id);

alter table orders add column if not exists payment_method text;
alter table orders add column if not exists payment_token text;
alter table orders add column if not exists admin_note text;
alter table orders add column if not exists approved_by text references users(id) on delete set null;
alter table orders add column if not exists approved_at timestamptz;

create table if not exists payment_sessions (
  id text primary key,
  token_hash text not null unique,
  order_id text not null references orders(id) on delete cascade,
  user_id text not null references users(id) on delete cascade,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists payment_receipts (
  id text primary key,
  order_id text not null references orders(id) on delete cascade,
  user_id text not null references users(id) on delete cascade,
  amount integer not null,
  payer_name text not null,
  tracking_number text,
  receipt_file_name text not null,
  receipt_mime text not null,
  receipt_size integer not null,
  receipt_data text not null,
  status text not null default 'pending_review',
  admin_note text,
  reviewed_by text references users(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists app_settings (
  key text primary key,
  value jsonb not null,
  updated_by text references users(id) on delete set null,
  updated_at timestamptz not null default now()
);

create table if not exists admin_login_attempts (
  id text primary key,
  email text not null,
  ip text,
  attempts integer not null default 0,
  locked_until timestamptz,
  last_attempt_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists idx_payment_sessions_order_id on payment_sessions(order_id);
create index if not exists idx_payment_sessions_user_id on payment_sessions(user_id);
create index if not exists idx_payment_receipts_order_id on payment_receipts(order_id);
create index if not exists idx_payment_receipts_user_id on payment_receipts(user_id);
create index if not exists idx_admin_login_attempts_email_ip on admin_login_attempts(email, ip);

insert into app_settings (key, value)
values ('card_to_card', '{"bank":"بانک ملت","cardNumber":"6104-3377-0000-0000","iban":"IR00 0000 0000 0000 0000 0000 00","ownerName":"ابرهاست","description":"پس از واریز، تصویر فیش یا رسید پرداخت را در همین صفحه بارگذاری کنید."}'::jsonb)
on conflict (key) do nothing;

alter table users add column if not exists banned_at timestamptz;
alter table users add column if not exists banned_reason text;

create table if not exists user_wallets (
  user_id text primary key references users(id) on delete cascade,
  balance integer not null default 0,
  currency text not null default 'تومان',
  updated_at timestamptz not null default now()
);

create table if not exists wallet_topups (
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  amount integer not null,
  currency text not null default 'تومان',
  status text not null default 'pending_payment',
  payment_status text not null default 'awaiting_card_to_card',
  admin_note text,
  approved_by text references users(id) on delete set null,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists wallet_transactions (
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  type text not null,
  amount integer not null,
  currency text not null default 'تومان',
  balance_after integer not null,
  reference_type text,
  reference_id text,
  description text,
  created_at timestamptz not null default now()
);

alter table payment_sessions alter column order_id drop not null;
alter table payment_sessions add column if not exists topup_id text references wallet_topups(id) on delete cascade;
alter table payment_sessions add column if not exists purpose text not null default 'service_order';

alter table payment_receipts alter column order_id drop not null;
alter table payment_receipts add column if not exists topup_id text references wallet_topups(id) on delete cascade;
alter table payment_receipts add column if not exists purpose text not null default 'service_order';

create index if not exists idx_wallet_topups_user_id on wallet_topups(user_id);
create index if not exists idx_wallet_transactions_user_id on wallet_transactions(user_id);
create index if not exists idx_payment_sessions_topup_id on payment_sessions(topup_id);
create index if not exists idx_payment_receipts_topup_id on payment_receipts(topup_id);

alter table users add column if not exists deleted_at timestamptz;
alter table users add column if not exists deleted_reason text;

create table if not exists user_oauth_accounts (
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  provider text not null,
  provider_user_id text not null,
  email text not null,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, provider_user_id),
  unique (provider, email)
);

create index if not exists idx_user_oauth_accounts_user_id on user_oauth_accounts(user_id);

create table if not exists notifications (
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  type text not null default 'info',
  title text not null,
  message text not null,
  read_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_notifications_user_id_created_at on notifications(user_id, created_at desc);
create index if not exists idx_notifications_user_id_read_at on notifications(user_id, read_at);

create table if not exists tickets (
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  subject text not null,
  priority text not null default 'medium',
  status text not null default 'open_review',
  closed_by text references users(id) on delete set null,
  closed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists ticket_messages (
  id text primary key,
  ticket_id text not null references tickets(id) on delete cascade,
  sender_id text not null references users(id) on delete cascade,
  sender_role text not null,
  message text not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_tickets_user_id_created_at on tickets(user_id, created_at desc);
create index if not exists idx_tickets_status_created_at on tickets(status, created_at desc);
create index if not exists idx_ticket_messages_ticket_id_created_at on ticket_messages(ticket_id, created_at asc);

create table if not exists gateway_payments (
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  topup_id text not null references wallet_topups(id) on delete cascade,
  payment_session_id text references payment_sessions(id) on delete set null,
  provider text not null,
  amount integer not null,
  fee_amount integer not null default 0,
  payable_amount integer not null,
  currency text not null default 'تومان',
  status text not null default 'created',
  track_id text,
  authority text,
  reference_id text,
  gateway_url text,
  callback_url text,
  request_payload jsonb not null default '{}'::jsonb,
  verify_payload jsonb not null default '{}'::jsonb,
  failure_message text,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists idx_gateway_payments_provider_track_id on gateway_payments(provider, track_id) where track_id is not null;
create index if not exists idx_gateway_payments_user_id on gateway_payments(user_id);
create index if not exists idx_gateway_payments_topup_id on gateway_payments(topup_id);
create index if not exists idx_gateway_payments_status on gateway_payments(status);

alter table users add column if not exists phone text;
alter table users add column if not exists phone_verified_at timestamptz;

create table if not exists phone_verifications (
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  phone text not null,
  code_hash text not null,
  provider text not null default 'smsir',
  sms_message_id text,
  attempts integer not null default 0,
  expires_at timestamptz not null,
  verified_at timestamptz,
  ip text,
  user_agent text,
  created_at timestamptz not null default now()
);

create index if not exists idx_phone_verifications_user_id_created_at on phone_verifications(user_id, created_at desc);
create index if not exists idx_phone_verifications_phone_created_at on phone_verifications(phone, created_at desc);
create unique index if not exists idx_users_verified_phone_unique on users(phone) where phone_verified_at is not null;

create table if not exists email_verifications (
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  email text not null,
  code_hash text not null,
  token_hash text not null unique,
  attempts integer not null default 0,
  expires_at timestamptz not null,
  used_at timestamptz,
  verified_at timestamptz,
  ip text,
  user_agent text,
  created_at timestamptz not null default now()
);

create index if not exists idx_email_verifications_user_id_created_at on email_verifications(user_id, created_at desc);
create index if not exists idx_email_verifications_email_created_at on email_verifications(email, created_at desc);

alter table users add column if not exists country text;
alter table users add column if not exists province text;
alter table users add column if not exists city text;
alter table users add column if not exists address text;
alter table users add column if not exists postal_code text;

create table if not exists lenofilm_subscription_payments (
  id text primary key,
  lenofilm_order_id integer not null unique,
  amount_toman integer not null,
  title text not null,
  description text not null,
  user_email text,
  user_mobile text,
  notify_url text not null,
  return_success_url text not null,
  return_failed_url text not null,
  status text not null default 'created',
  authority text unique,
  ref_id text,
  gateway_url text,
  request_payload jsonb not null default '{}'::jsonb,
  verify_payload jsonb not null default '{}'::jsonb,
  notify_payload jsonb not null default '{}'::jsonb,
  failure_message text,
  merchant_encrypted text,
  sandbox boolean not null default false,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_lenofilm_subscription_payments_status on lenofilm_subscription_payments(status);
alter table lenofilm_subscription_payments add column if not exists merchant_encrypted text;
alter table lenofilm_subscription_payments add column if not exists sandbox boolean not null default false;
create index if not exists idx_lenofilm_subscription_payments_authority on lenofilm_subscription_payments(authority);
