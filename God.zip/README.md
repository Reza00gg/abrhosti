# ابرهاست — Web App فروش هاست، VPS و دامنه

یک وب‌اپ فارسی/RTL با Next.js + TypeScript + PostgreSQL برای فروش:

- هاست اشتراکی، ابری و اختصاصی
- سرور مجازی VPS با کشورهای آمریکا، آلمان، فرانسه، انگلیس، هلند و کانادا
- دامنه‌های .com، .ir و .net
- ثبت‌نام، ورود، خروج، داشبورد، لیست سرویس‌ها و فاکتورها
- ثبت سفارش واقعی در PostgreSQL با پرداخت شبیه‌سازی‌شده

## تکنولوژی‌ها

- Next.js App Router
- React + TypeScript
- PostgreSQL با پکیج `pg`
- احراز هویت ایمیل/رمز عبور
- هش رمز عبور با PBKDF2 + Salt
- Session Cookie امن با HttpOnly + HMAC

## راه‌اندازی سریع

### 1) نصب وابستگی‌ها

```bash
npm install
```

### 2) اجرای PostgreSQL با Docker

```bash
docker compose up -d
```

### 3) ساخت فایل محیطی

```bash
cp .env.example .env.local
```

مقدار `AUTH_SECRET` را امن کنید:

```bash
openssl rand -hex 32
```

نمونه `.env.local`:

```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/abrhost"
AUTH_SECRET="یک-رشته-طولانی-و-امن"
NEXT_PUBLIC_SITE_URL="http://localhost:3000"
```

### 4) ساخت جدول‌ها و seed محصولات

اسکریپت‌ها فایل `.env.local` را به‌صورت خودکار می‌خوانند:

```bash
npm run db:reset
```

### 5) اجرا

```bash
npm run dev
```

سپس باز کنید:

```txt
http://localhost:3000
```

## مسیرهای مهم

- `/` صفحه اصلی
- `/hosting/shared` هاست اشتراکی
- `/hosting/cloud` هاست ابری
- `/hosting/dedicated` هاست اختصاصی
- `/vps` لیست سرورهای مجازی
- `/vps/us`, `/vps/de`, `/vps/fr`, `/vps/uk`, `/vps/nl`, `/vps/ca`
- `/domains` ثبت دامنه
- `/auth/register` ثبت‌نام
- `/auth/login` ورود
- `/dashboard` داشبورد
- `/dashboard/services` سرویس‌ها
- `/dashboard/billing` مالی
- `/dashboard/profile` پروفایل و امنیت

## APIها

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/products`
- `POST /api/domain/check`
- `GET /api/orders`
- `POST /api/orders`

## نکته پرداخت

درگاه پرداخت فعلاً mock است اما سفارش، آیتم سفارش، وضعیت پرداخت، وضعیت تحویل و audit event واقعاً در PostgreSQL ذخیره می‌شود. برای اتصال زرین‌پال/زیبال/نکست‌پی، کافی است مرحله پرداخت mock در `/api/orders` به ایجاد تراکنش و verify callback تبدیل شود.
