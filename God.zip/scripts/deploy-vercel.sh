#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${VERCEL_TOKEN:-}" ]]; then
  echo "❌ VERCEL_TOKEN تنظیم نشده است." >&2
  exit 1
fi
if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "❌ DATABASE_URL تنظیم نشده است." >&2
  exit 1
fi
if [[ -z "${AUTH_SECRET:-}" ]]; then
  echo "❌ AUTH_SECRET تنظیم نشده است." >&2
  exit 1
fi

PROJECT_NAME="${VERCEL_PROJECT_NAME:-abrhost-webapp}"
SITE_URL="${NEXT_PUBLIC_SITE_URL:-https://${PROJECT_NAME}.vercel.app}"

npm run build
npm run db:reset

npx vercel link --yes --project "$PROJECT_NAME" --token "$VERCEL_TOKEN"

# اگر env قبلاً وجود داشته باشد، Vercel خطا می‌دهد. در آن حالت env را از پنل ویرایش/حذف کنید یا با CLI remove کنید.
printf "%s" "$DATABASE_URL" | npx vercel env add DATABASE_URL production --token "$VERCEL_TOKEN" || true
printf "%s" "$AUTH_SECRET" | npx vercel env add AUTH_SECRET production --token "$VERCEL_TOKEN" || true
printf "%s" "$SITE_URL" | npx vercel env add NEXT_PUBLIC_SITE_URL production --token "$VERCEL_TOKEN" || true

npx vercel deploy --prod --token "$VERCEL_TOKEN"
