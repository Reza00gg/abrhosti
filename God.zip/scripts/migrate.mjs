import fs from 'node:fs/promises';
import path from 'node:path';
import pg from 'pg';
import { loadLocalEnv } from './env.mjs';

loadLocalEnv();

const { Pool } = pg;
const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.error('DATABASE_URL تنظیم نشده است. یک فایل .env.local بسازید یا متغیر را قبل از اجرای اسکریپت export کنید.');
  process.exit(1);
}

const pool = new Pool({ connectionString });
const schema = await fs.readFile(path.join(process.cwd(), 'db/schema.sql'), 'utf8');

try {
  await pool.query(schema);
  console.log('✅ Database migrated successfully.');
} finally {
  await pool.end();
}
