import fs from 'node:fs/promises';
import path from 'node:path';
import pg from 'pg';
import { loadLocalEnv } from './env.mjs';

loadLocalEnv();

const { Pool } = pg;
const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.error('DATABASE_URL تنظیم نشده است.');
  process.exit(1);
}

const pool = new Pool({ connectionString });
const products = JSON.parse(await fs.readFile(path.join(process.cwd(), 'data/products.json'), 'utf8'));

try {
  for (const product of products) {
    await pool.query(
      `insert into products (id, category, country, title, subtitle, price_monthly, currency, badge, specs, features, route, active)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,true)
       on conflict (id) do update set
         category = excluded.category,
         country = excluded.country,
         title = excluded.title,
         subtitle = excluded.subtitle,
         price_monthly = excluded.price_monthly,
         currency = excluded.currency,
         badge = excluded.badge,
         specs = excluded.specs,
         features = excluded.features,
         route = excluded.route,
         active = true,
         updated_at = now()`,
      [
        product.id,
        product.category,
        product.country ?? null,
        product.title,
        product.subtitle,
        product.priceMonthly,
        product.currency,
        product.badge,
        JSON.stringify({ cpu: product.cpu, ram: product.ram, storage: product.storage, bandwidth: product.bandwidth }),
        JSON.stringify(product.features),
        product.route
      ]
    );
  }
  console.log(`✅ Seeded ${products.length} products.`);
} finally {
  await pool.end();
}
