# Deploy روی Vercel + Neon PostgreSQL

## پیش‌نیازها

1. اکانت Vercel
2. دیتابیس PostgreSQL روی Neon
3. متغیرهای زیر:

```env
DATABASE_URL="postgresql://..."
AUTH_SECRET="یک مقدار طولانی و امن"
NEXT_PUBLIC_SITE_URL="https://your-domain.vercel.app"
```

## ساخت دیتابیس Neon

در Neon یک Project بسازید و Connection String را کپی کنید. بهتر است گزینه pooled connection را برای اپلیکیشن‌های serverless استفاده کنید.

## اجرای migration و seed

روی سیستم خودتان یا هر محیطی که به دیتابیس Neon دسترسی دارد:

```bash
export DATABASE_URL="postgresql://...neon..."
npm run db:reset
```

## Deploy با Vercel CLI

```bash
npm i -g vercel
vercel login
vercel link
vercel env add DATABASE_URL production
vercel env add AUTH_SECRET production
vercel env add NEXT_PUBLIC_SITE_URL production
vercel deploy --prod
```

بعد از اولین deploy، لینک production را در `NEXT_PUBLIC_SITE_URL` قرار دهید و دوباره deploy کنید اگر لازم بود.

## Deploy غیرتعاملی با Token

اگر `VERCEL_TOKEN` دارید:

```bash
npx vercel link --yes --project abrhost-webapp --token "$VERCEL_TOKEN"
printf "%s" "$DATABASE_URL" | npx vercel env add DATABASE_URL production --token "$VERCEL_TOKEN"
printf "%s" "$AUTH_SECRET" | npx vercel env add AUTH_SECRET production --token "$VERCEL_TOKEN"
printf "%s" "$NEXT_PUBLIC_SITE_URL" | npx vercel env add NEXT_PUBLIC_SITE_URL production --token "$VERCEL_TOKEN"
npx vercel deploy --prod --token "$VERCEL_TOKEN"
```
