'use client';

import { useEffect, useRef, useState } from 'react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function NotificationsPagination({ page, totalPages, total }: { page: number; totalPages: number; total: number }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const shouldScroll = useRef(false);
  const [loadingPage, setLoadingPage] = useState<number | null>(null);

  function go(target: number) {
    if (target < 1 || target > totalPages || target === page) return;
    shouldScroll.current = true;
    setLoadingPage(target);
    const params = new URLSearchParams(searchParams.toString());
    params.set('page', String(target));
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  }

  useEffect(() => {
    if (!shouldScroll.current) return;
    const timer = window.setTimeout(() => {
      document.getElementById('notifications-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      shouldScroll.current = false;
      setLoadingPage(null);
    }, 120);
    return () => window.clearTimeout(timer);
  }, [searchParams]);

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-3 text-sm font-bold text-slate-600 shadow-sm sm:flex-row sm:items-center sm:justify-between">
      <span>صفحه {page.toLocaleString('fa-IR')} از {totalPages.toLocaleString('fa-IR')} • {total.toLocaleString('fa-IR')} اعلان</span>
      <div className="flex gap-2">
        <Button type="button" size="sm" variant="secondary" onClick={() => go(page - 1)} disabled={page <= 1 || loadingPage !== null}>
          <ChevronRight size={15} /> قبلی
        </Button>
        <Button type="button" size="sm" variant="secondary" onClick={() => go(page + 1)} disabled={page >= totalPages || loadingPage !== null}>
          بعدی <ChevronLeft size={15} />
        </Button>
      </div>
    </div>
  );
}
