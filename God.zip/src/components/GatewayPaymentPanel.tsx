'use client';
import { useMemo, useState } from 'react';
import { ArrowLeft, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatPrice } from '@/lib/products';

type Provider = 'zarinpal' | 'zibal';
function ZibalLogo() { return <span className="grid h-9 w-9 place-items-center rounded-xl bg-white ring-1 ring-slate-200"><img src="https://zibal.ir/favicon.ico" alt="زیبال" className="h-6 w-6 object-contain" /></span>; }
function ZarinpalLogo() { return <span className="grid h-9 w-9 place-items-center rounded-xl bg-white ring-1 ring-slate-200"><img src="https://www.zarinpal.com/favicon.ico" alt="زرین‌پال" className="h-6 w-6 object-contain" /></span>; }

export function GatewayPaymentPanel({ token, amount, feeAmount, payableAmount, onlineAllowed, gatewayEnabled, zibalEnabled, zarinpalEnabled }: { token: string; amount: number; feeAmount: number; payableAmount: number; onlineAllowed: boolean; gatewayEnabled: boolean; zibalEnabled: boolean; zarinpalEnabled: boolean }) {
  const initialProvider = zarinpalEnabled ? 'zarinpal' : zibalEnabled ? 'zibal' : 'zarinpal';
  const [provider, setProvider] = useState<Provider>(initialProvider);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const providers = useMemo(() => [
    { key: 'zarinpal' as Provider, title: 'زرین‌پال', subtitle: 'پرداخت آنلاین', enabled: zarinpalEnabled, Logo: ZarinpalLogo, soon: false },
    { key: 'zibal' as Provider, title: 'زیبال', subtitle: 'پرداخت آنلاین', enabled: zibalEnabled, Logo: ZibalLogo, soon: false }
  ].sort((a, b) => Number(b.enabled) - Number(a.enabled)), [zibalEnabled, zarinpalEnabled]);
  async function pay() {
    setLoading(true); setError('');
    const res = await fetch('/api/wallet/topup/gateway/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token, provider }) });
    const json = await res.json(); setLoading(false);
    if (!res.ok || !json.ok) return setError(json?.error?.message ?? 'شروع پرداخت انجام نشد.');
    window.location.href = json.data.gatewayUrl;
  }
  if (!onlineAllowed) return <div className="rounded-3xl border border-slate-200 bg-slate-50 p-5 text-sm leading-8 text-slate-500">پرداخت آنلاین فقط روی دامنه اصلی <strong className="dir-ltr">lnupro.sbs</strong> فعال است.</div>;
  if (!gatewayEnabled) return <div className="rounded-3xl border border-red-100 bg-red-50 p-5 text-sm leading-8 text-red-600">پرداخت آنلاین در حال حاضر توسط مدیریت غیرفعال شده است.</div>;
  const selectedEnabled = provider === 'zarinpal' ? zarinpalEnabled : zibalEnabled;
  return <div className="grid gap-5"><div><h2 className="text-2xl font-black text-slate-950">درگاه پرداخت</h2><p className="mt-2 text-sm leading-7 text-slate-500">درگاه را انتخاب کنید و به صفحه پرداخت بانکی منتقل شوید.</p></div><div className="grid gap-3 sm:grid-cols-2">{providers.map(({ key, title, subtitle, enabled, Logo }) => <button key={key} type="button" disabled={!enabled} onClick={()=>setProvider(key)} className={`rounded-3xl border p-4 text-right transition ${provider===key?'border-slate-950 bg-slate-50':'border-slate-200 bg-white'} ${!enabled?'opacity-50':''}`}><div className="flex items-center gap-3"><Logo/><div><div className="flex items-center gap-2"><strong className="block text-slate-950">{title}</strong>{!enabled?<span className="rounded-md bg-red-100 px-2 py-0.5 text-[10px] font-black text-red-600">غیرفعال</span>:null}</div><span className="text-xs font-bold text-slate-500">{subtitle}</span></div></div></button>)}</div><div className="rounded-3xl border border-slate-200 bg-slate-50 p-4 text-sm"><div className="flex justify-between border-b border-slate-200 py-3"><span className="font-bold text-slate-500">مبلغ افزایش موجودی</span><strong>{formatPrice(amount)}</strong></div><div className="flex justify-between border-b border-slate-200 py-3"><span className="font-bold text-slate-500">کارمزد</span><strong>{formatPrice(feeAmount)}</strong></div><div className="flex justify-between py-3"><span className="font-bold text-slate-500">مبلغ پرداخت</span><strong className="text-lg">{formatPrice(payableAmount)}</strong></div></div>{error?<div className="alert error">{error}</div>:null}<Button onClick={pay} disabled={loading || !selectedEnabled}>{loading?'در حال انتقال...': provider === 'zarinpal' ? 'پرداخت از طریق زرین‌پال' : 'پرداخت از طریق زیبال'} <ArrowLeft size={17}/></Button><div className="rounded-2xl bg-sky-50 p-4 text-xs leading-7 text-sky-800"><CreditCard className="mb-1 h-4 w-4"/> موجودی فقط بعد از تایید واقعی تراکنش توسط درگاه پرداخت اضافه می‌شود.</div></div>;
}
