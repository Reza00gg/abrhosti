import Link from 'next/link';
import { ArrowLeft, CheckCircle2, Database, Gauge, Globe2, Server, ShieldCheck, Sparkles } from 'lucide-react';
import { Product, formatPrice } from '@/lib/products';
import { ProductCard } from '@/components/ProductCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export function ProductLanding({
  eyebrow,
  title,
  description,
  products,
  visual = 'cloud'
}: {
  eyebrow: string;
  title: string;
  description: string;
  products: Product[];
  visual?: 'cloud' | 'vps' | 'domain' | 'dedicated' | 'shared';
}) {
  const first = products[0];
  const Icon = visual === 'domain' ? Globe2 : visual === 'dedicated' ? Server : visual === 'vps' ? Gauge : Database;

  return (
    <>
      <section className="border-b border-slate-200 bg-white">
        <div className="shell grid gap-8 py-12 lg:grid-cols-[1fr_.9fr] lg:items-center lg:py-16">
          <div>
            <Badge variant="secondary" className="mb-5 border-sky-100 bg-sky-50 text-sky-700"><Sparkles size={13} className="ml-1" /> {eyebrow}</Badge>
            <h1 className="text-balance text-4xl font-black leading-[1.15] tracking-tight text-slate-950 md:text-6xl">{title}</h1>
            <p className="mt-5 max-w-2xl text-base leading-9 text-slate-500">{description}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              {first ? <Button asChild size="lg"><Link href={`/checkout/${first.id}`}>شروع سفارش <ArrowLeft size={18} /></Link></Button> : null}
              <Button asChild size="lg" variant="secondary"><Link href="#plans">مقایسه پلن‌ها</Link></Button>
            </div>
          </div>
          <Card className="overflow-hidden p-5">
            <div className="flex items-center justify-between rounded-3xl bg-slate-950 p-5 text-white">
              <div>
                <div className="text-sm font-black">وضعیت سرویس</div>
                <div className="mt-1 text-xs font-bold text-slate-400">مانیتورینگ، تحویل و سفارش آنلاین</div>
              </div>
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/10"><Icon size={24} /></span>
            </div>
            <div className="mt-4 grid gap-3">
              {['SLA آماده', 'بکاپ و Snapshot', 'داشبورد کاربر', 'ثبت سفارش واقعی'].map((item) => (
                <div key={item} className="flex items-center justify-between rounded-2xl border border-slate-100 bg-slate-50 p-4">
                  <span className="flex items-center gap-2 text-sm font-extrabold text-slate-700"><CheckCircle2 size={18} className="text-emerald-500" />{item}</span>
                  <Badge variant="success">فعال</Badge>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </section>

      <section id="plans" className="py-12">
        <div className="shell">
          <Tabs defaultValue="cards">
            <div className="mb-7 grid gap-4 text-right md:grid-cols-[1fr_auto] md:items-end">
              <div className="text-right">
                <h2 className="text-3xl font-black tracking-tight text-slate-950">پلن‌ها و قیمت‌ها</h2>
                <p className="mt-2 text-sm leading-7 text-slate-500">بین نمایش کارت و جدول مقایسه جابه‌جا شوید.</p>
              </div>
              <TabsList className="self-start md:self-auto">
                <TabsTrigger value="cards">کارت‌ها</TabsTrigger>
                <TabsTrigger value="table">جدول مقایسه</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="cards">
              <div dir="rtl" className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                {products.map((product, index) => <ProductCard product={product} featured={index === 0} key={product.id} />)}
              </div>
            </TabsContent>
            <TabsContent value="table">
              <Card className="overflow-x-auto">
                <table dir="rtl" className="table min-w-[760px] text-right">
                  <thead><tr><th>پلن</th><th>CPU</th><th>RAM</th><th>فضا</th><th>ترافیک</th><th>قیمت</th><th></th></tr></thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product.id}>
                        <td className="text-right"><strong className="text-slate-950">{product.title}</strong><p className="mt-1 text-xs text-slate-500">{product.subtitle}</p></td>
                        <td className="text-right"><bdi dir="auto">{product.cpu}</bdi></td><td className="text-right"><bdi dir="auto">{product.ram}</bdi></td><td className="text-right"><bdi dir="auto">{product.storage}</bdi></td><td className="text-right"><bdi dir="auto">{product.bandwidth}</bdi></td>
                        <td className="font-black text-slate-950">{formatPrice(product.priceMonthly, product.currency)}</td>
                        <td><Button asChild size="sm"><Link href={`/checkout/${product.id}`}>سفارش</Link></Button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <section className="py-10">
        <div className="shell grid gap-4 md:grid-cols-3">
          <Card className="p-5"><ShieldCheck className="mb-4 h-7 w-7 text-sky-600" /><h3 className="font-black text-slate-950">امنیت پایه</h3><p className="mt-2 text-sm leading-7 text-slate-500">SSL، رویدادهای امنیتی، نشست امن و قابلیت توسعه به 2FA.</p></Card>
          <Card className="p-5"><Gauge className="mb-4 h-7 w-7 text-sky-600" /><h3 className="font-black text-slate-950">مانیتورینگ</h3><p className="mt-2 text-sm leading-7 text-slate-500">ساختار آماده برای نمایش وضعیت منابع و آپ‌تایم سرویس.</p></Card>
          <Card className="p-5"><Server className="mb-4 h-7 w-7 text-sky-600" /><h3 className="font-black text-slate-950">تحویل سرویس</h3><p className="mt-2 text-sm leading-7 text-slate-500">پس از سفارش، سرویس در داشبورد و صف تحویل قرار می‌گیرد.</p></Card>
        </div>
      </section>
    </>
  );
}
