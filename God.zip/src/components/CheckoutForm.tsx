'use client';

import { useRouter } from 'next/navigation';
import { FormEvent, useMemo, useState } from 'react';
import { ArrowLeft, CreditCard, FileText } from 'lucide-react';
import { type Product, formatPrice } from '@/lib/products';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

const cycles = {
  monthly: { label: 'ماهانه', multiplier: 1 },
  quarterly: { label: 'سه‌ماهه', multiplier: 3 },
  yearly: { label: 'سالانه', multiplier: 10 }
} as const;

export function CheckoutForm({ product }: { product: Product }) {
  const router = useRouter();
  const [cycle, setCycle] = useState<keyof typeof cycles>(product.category === 'domain' ? 'yearly' : 'monthly');
  const [domainName, setDomainName] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const total = useMemo(() => product.priceMonthly * cycles[cycle].multiplier, [product.priceMonthly, cycle]);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setLoading(true); setMessage(null);
    const res = await fetch('/api/payment-sessions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ productId: product.id, cycle, domainName, notes }) });
    const json = await res.json(); setLoading(false);
    if (res.status === 401) return router.push(`/auth/login?next=/checkout/${product.id}`);
    if (!res.ok || !json.ok) return setMessage({ type: 'error', text: json?.error?.message ?? 'ثبت سفارش انجام نشد.' });
    setMessage({ type: 'success', text: `صفحه پرداخت سفارش ${json.data.orderNumber} ساخته شد. در حال انتقال...` });
    router.push(json.data.payUrl);
  }

  return (
    <form className="grid gap-5" onSubmit={submit}>
      <div>
        <Badge variant="secondary" className="mb-3"><CreditCard size={13} className="ml-1" /> Checkout</Badge>
        <h2 className="text-2xl font-black text-slate-950">تنظیمات سفارش</h2>
        <p className="mt-2 text-sm leading-7 text-slate-500">با ثبت سفارش، یک صفحه پرداخت اختصاصی کارت‌به‌کارت با توکن امن ساخته می‌شود.</p>
      </div>

      <div className="grid gap-2">
        <Label>دوره پرداخت</Label>
        <Tabs value={cycle} onValueChange={(v) => setCycle(v as keyof typeof cycles)}>
          <TabsList className="w-full justify-start overflow-x-auto">
            {Object.entries(cycles).map(([key, item]) => <TabsTrigger key={key} value={key}>{item.label}</TabsTrigger>)}
          </TabsList>
        </Tabs>
      </div>

      {product.category === 'domain' ? (
        <div className="grid gap-2"><Label>نام دامنه</Label><Input value={domainName} onChange={(e) => setDomainName(e.target.value)} placeholder="mybrand.com" dir="ltr" className="text-left dir-ltr" required /></div>
      ) : null}

      <div className="grid gap-2">
        <Label>توضیحات سفارش</Label>
        <textarea className="textarea" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="مثلاً Ubuntu 24.04، نصب Docker، انتقال سایت فعلی..." />
      </div>

      <div className="rounded-3xl border border-slate-200 bg-slate-50 p-4">
        <div className="flex justify-between gap-4 border-b border-slate-200 py-3 text-sm"><span className="font-bold text-slate-500">محصول</span><strong className="text-slate-950">{product.title}</strong></div>
        <div className="flex justify-between gap-4 border-b border-slate-200 py-3 text-sm"><span className="font-bold text-slate-500">دوره</span><strong className="text-slate-950">{cycles[cycle].label}</strong></div>
        <div className="flex justify-between gap-4 py-3 text-sm"><span className="font-bold text-slate-500">مبلغ</span><strong className="text-lg font-black text-slate-950">{formatPrice(total, product.currency.replace('/سال', ''))}</strong></div>
      </div>

      {message ? <div className={`alert ${message.type}`}>{message.text}</div> : null}
      <Button size="lg" disabled={loading}>{loading ? 'در حال ثبت...' : 'ادامه به صفحه پرداخت'} <ArrowLeft size={18} /></Button>
      <div className="flex items-start gap-2 rounded-2xl bg-sky-50 p-4 text-xs leading-7 text-sky-800"><FileText className="mt-1 h-4 w-4 shrink-0" /> بعد از ثبت، سفارش در بخش مالی و سرویس‌های داشبورد نمایش داده می‌شود.</div>
    </form>
  );
}
