import Link from 'next/link';
import { Bell, CreditCard, Home, LifeBuoy, Plus, Server, UserRound, Wallet } from 'lucide-react';
import type { User } from '@/lib/auth';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { getUnreadNotificationCount } from '@/lib/notifications';
import { getCurrentHost, isTicketsHost, isSmsHost } from '@/lib/host';
import { getSmsSettings } from '@/lib/sms-settings';
import { PhoneVerificationGate } from '@/components/PhoneVerificationGate';
import { getEmailSettings } from '@/lib/email-settings';
import { EmailVerificationGate } from '@/components/EmailVerificationGate';

const nav = [
  { href: '/dashboard', label: 'نمای کلی', icon: Home },
  { href: '/dashboard/services', label: 'سرویس‌ها', icon: Server },
  { href: '/dashboard/billing', label: 'مالی و فاکتورها', icon: CreditCard },
  { href: '/dashboard/wallet', label: 'موجودی', icon: Wallet },
  { href: '/dashboard/notifications', label: 'اعلان‌ها', icon: Bell },
  { href: '/dashboard/profile', label: 'پروفایل و امنیت', icon: UserRound }
];

export async function DashboardShell({ user, children }: { user: User; children: React.ReactNode }) {
  const emailSettings = await getEmailSettings();
  const smsSettings = await getSmsSettings();
  const host = getCurrentHost();
  if (emailSettings.enabled && user.role !== 'admin' && !user.email_verified_at) {
    return <EmailVerificationGate userName={user.name} email={user.email} />;
  }
  if (smsSettings.enabled && isSmsHost(host) && user.role !== 'admin' && !user.phone_verified_at) {
    return <PhoneVerificationGate userName={user.name} />;
  }
  const unreadNotifications = await getUnreadNotificationCount(user.id);
  const ticketsEnabled = isTicketsHost(host);
  const visibleNav = ticketsEnabled ? [...nav.slice(0, 4), { href: '/dashboard/tickets', label: 'تیکت‌ها', icon: LifeBuoy }, ...nav.slice(4)] : nav;
  return (
    <div className="shell grid gap-5 py-8 lg:grid-cols-[280px_1fr]">
      <aside className="lg:sticky lg:top-24 lg:self-start">
        <Card className="overflow-hidden">
          <div className="bg-slate-950 p-5 text-white">
            <Badge className="bg-white/10 text-white" variant="outline">User Console</Badge>
            <h2 className="mt-4 text-xl font-black">{user.name}</h2>
            <p className="mt-1 text-left text-xs font-bold text-slate-400 dir-ltr">{user.email}</p>
          </div>
          <nav className="grid gap-1 p-3">
            {visibleNav.map((item) => {
              const Icon = item.icon;
              return <Link key={item.href} href={item.href} className="flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-extrabold text-slate-600 transition hover:bg-sky-50 hover:text-sky-700"><Icon size={18} />{item.label}{item.href === '/dashboard/notifications' && unreadNotifications ? <span className="mr-auto rounded-full bg-amber-100 px-2 py-0.5 text-[10px] text-amber-700">{unreadNotifications.toLocaleString('fa-IR')}</span> : null}</Link>;
            })}
          </nav>
          <div className="border-t border-slate-100 p-3">
            <Button asChild className="w-full"><Link href="/vps"><Plus size={17} /> سفارش سرویس</Link></Button>
          </div>
        </Card>
      </aside>
      {children}
    </div>
  );
}
