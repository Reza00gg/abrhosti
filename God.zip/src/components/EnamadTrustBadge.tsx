'use client';

import { useState } from 'react';
import { ShieldCheck } from 'lucide-react';

const ENAMAD_LOGO_URL = 'https://trustseal.enamad.ir/logo.aspx?id=736061&Code=3E5X9qQ3TUUKd3tdBH1AecZgjB1LYugz';
const AGHAYE_PARDAKHT_LOGO_URL = 'https://cdn.aqayepardakht.ir/trustlogo/1.svg';

export function EnamadTrustBadge() {
  const [enamadFailed, setEnamadFailed] = useState(false);
  const [aqayePardakhtFailed, setAqayePardakhtFailed] = useState(false);

  return (
    <div className="flex w-fit cursor-default select-none flex-wrap items-center gap-3" aria-label="نشان‌های اعتماد ابرهاست">
      {enamadFailed ? (
        <span className="flex min-h-[92px] w-[92px] flex-col rounded-2xl border border-slate-200 bg-white shadow-sm items-center justify-center gap-1 px-2 py-3 text-center text-slate-700">
          <ShieldCheck size={22} className="text-slate-500" />
          <strong className="text-[11px] font-black leading-5">نماد اعتماد</strong>
          <span className="text-[10px] font-bold leading-4 text-slate-400">ابرهاست</span>
        </span>
      ) : (
        <img
          referrerPolicy="origin"
          src={ENAMAD_LOGO_URL}
          alt="نماد اعتماد الکترونیکی ابرهاست"
          className="h-[92px] w-[92px] rounded-2xl border border-slate-200 bg-white p-2 object-contain shadow-sm"
          data-code="3E5X9qQ3TUUKd3tdBH1AecZgjB1LYugz"
          draggable={false}
          onError={() => setEnamadFailed(true)}
        />
      )}

      {aqayePardakhtFailed ? (
        <span className="flex min-h-[92px] w-[92px] flex-col rounded-2xl border border-slate-200 bg-white shadow-sm items-center justify-center gap-1 px-2 py-3 text-center text-slate-700">
          <ShieldCheck size={20} className="text-slate-500" />
          <strong className="text-[10px] font-black leading-5">آقای پرداخت</strong>
        </span>
      ) : (
        <img
          src={AGHAYE_PARDAKHT_LOGO_URL}
          alt="نشان اعتماد آقای پرداخت"
          className="h-[92px] w-[92px] rounded-2xl border border-slate-200 bg-white p-2 object-contain shadow-sm"
          draggable={false}
          onError={() => setAqayePardakhtFailed(true)}
        />
      )}
    </div>
  );
}
