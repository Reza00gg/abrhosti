'use client';
import { useRouter } from 'next/navigation';
import { CheckCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
export function MarkNotificationsReadButton() {
  const router = useRouter();
  async function mark() {
    await fetch('/api/notifications/read-all', { method: 'POST' });
    router.refresh();
  }
  return <Button variant="secondary" size="sm" onClick={mark}><CheckCheck size={15}/> خواندن همه</Button>;
}
