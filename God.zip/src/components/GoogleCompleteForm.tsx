'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { ArrowLeft, LockKeyhole, UserRound } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function GoogleCompleteForm({ defaultName, email }: { defaultName: string; email: string }) {
  const router = useRouter();
  const params = useSearchParams();
  const [name, setName] = useState(defaultName);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError('');
    const res = await fetch('/api/auth/google/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, password, confirmPassword, next: params.get('next') || '/dashboard' })
    });
    const json = await res.json();
    setLoading(false);
    if (!res.ok || !json.ok) return setError(json?.error?.message ?? 'تکمیل حساب انجام نشد.');
    router.push(json.data.next || '/dashboard');
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="grid gap-4">
      <div className="rounded-2xl bg-slate-50 p-3 text-sm font-bold text-slate-500 dir-ltr">{email}</div>
      <div className="grid gap-2">
        <Label>نام و نام خانوادگی</Label>
        <div className="relative"><UserRound className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" /><Input className="pr-10" value={name} onChange={(e) => setName(e.target.value)} required /></div>
      </div>
      <div className="grid gap-2">
        <Label>رمز عبور</Label>
        <div className="relative"><LockKeyhole className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" /><Input className="pr-10 text-left dir-ltr" dir="ltr" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required /></div>
      </div>
      <div className="grid gap-2">
        <Label>تکرار رمز عبور</Label>
        <div className="relative"><LockKeyhole className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" /><Input className="pr-10 text-left dir-ltr" dir="ltr" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required /></div>
      </div>
      {error ? <div className="alert error">{error}</div> : null}
      <Button size="lg" disabled={loading}>{loading ? 'در حال تکمیل...' : 'تکمیل حساب و ورود'} <ArrowLeft size={17} /></Button>
    </form>
  );
}
