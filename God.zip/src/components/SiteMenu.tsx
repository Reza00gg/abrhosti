'use client';

import Link from 'next/link';
import { useState } from 'react';
import { ChevronDown, Cloud, CreditCard, Globe2, LayoutDashboard, Menu, Server, ShieldCheck, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const groups = [
  { title: 'هاست و زیرساخت', items: [
    { href: '/hosting/cloud', label: 'هاست ابری', desc: 'منابع پایدار و مقیاس‌پذیر' },
    { href: '/hosting/shared', label: 'هاست اشتراکی', desc: 'اقتصادی برای شروع سایت' },
    { href: '/hosting/dedicated', label: 'سرور اختصاصی', desc: 'منابع کامل و اختصاصی' }
  ]},
  { title: 'سرور مجازی', items: [
    { href: '/vps', label: 'همه کشورها', desc: 'انتخاب VPS بر اساس لوکیشن' },
    { href: '/vps/de', label: 'آلمان', desc: 'فرانکفورت' },
    { href: '/vps/us', label: 'آمریکا', desc: 'نیویورک/دالاس' },
    { href: '/vps/uk', label: 'انگلیس', desc: 'لندن' }
  ]},
  { title: 'دامنه و حساب', items: [
    { href: '/domains', label: 'ثبت دامنه', desc: 'جستجو و سفارش دامنه' },
    { href: '/dashboard', label: 'داشبورد کاربر', desc: 'سرویس‌ها و فاکتورها' },
    { href: '/dashboard/billing', label: 'مالی', desc: 'پرداخت‌ها و فاکتورها' }
  ]}
];

export function SiteMenu() {
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState('هاست و زیرساخت');

  return (
    <>
      <Button variant="secondary" onClick={() => setOpen(true)} className="gap-2">
        <Menu size={18} /> منو
      </Button>
      {open ? (
        <div className="fixed inset-0 z-[100]">
          <button className="absolute inset-0 bg-slate-950/35 backdrop-blur-sm" aria-label="بستن منو" onClick={() => setOpen(false)} />
          <aside className="absolute right-0 top-0 h-full w-[min(420px,92vw)] overflow-y-auto bg-white shadow-[0_30px_100px_rgba(15,23,42,.25)] animate-in slide-in-from-right">
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white/95 p-5 backdrop-blur">
              <div className="flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-sky-600 text-white"><Cloud size={23} /></span>
                <div><strong className="block text-slate-950">ابرهاست</strong><span className="text-xs font-bold text-slate-500">منوی سرویس‌ها</span></div>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setOpen(false)}><X size={20} /></Button>
            </div>

            <div className="grid gap-3 p-5">
              <Link onClick={() => setOpen(false)} href="/dashboard" className="flex items-center gap-3 rounded-3xl bg-slate-950 p-4 text-white">
                <LayoutDashboard size={22} /><span><strong className="block">ورود به داشبورد</strong><span className="text-xs text-slate-300">مدیریت سرویس‌ها و فاکتورها</span></span>
              </Link>

              {groups.map((group) => (
                <div key={group.title} className="rounded-3xl border border-slate-200 bg-slate-50/70">
                  <button onClick={() => setExpanded(expanded === group.title ? '' : group.title)} className="flex w-full items-center justify-between p-4 text-right text-sm font-black text-slate-800">
                    {group.title}<ChevronDown className={`h-4 w-4 transition ${expanded === group.title ? 'rotate-180' : ''}`} />
                  </button>
                  {expanded === group.title ? (
                    <div className="grid gap-2 px-3 pb-3">
                      {group.items.map((item) => (
                        <Link onClick={() => setOpen(false)} key={item.href} href={item.href} className="flex items-center gap-3 rounded-2xl bg-white p-3 transition hover:bg-sky-50">
                          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-sky-50 text-sky-700">{item.href.includes('vps') ? <Server size={18} /> : item.href.includes('domain') ? <Globe2 size={18} /> : item.href.includes('billing') ? <CreditCard size={18} /> : <ShieldCheck size={18} />}</span>
                          <span><strong className="block text-sm text-slate-950">{item.label}</strong><span className="text-xs font-bold text-slate-500">{item.desc}</span></span>
                        </Link>
                      ))}
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
          </aside>
        </div>
      ) : null}
    </>
  );
}
