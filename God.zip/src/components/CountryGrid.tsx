import Link from 'next/link';
import { ArrowLeft, RadioTower } from 'lucide-react';
import { countries } from '@/lib/products';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function CountryGrid() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {countries.map((country) => (
        <Link href={`/vps/${country.code}`} key={country.code}>
          <Card className="group h-full overflow-hidden p-5 transition hover:-translate-y-1 hover:border-sky-200 hover:shadow-[0_24px_70px_rgba(14,165,233,.12)]">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-4xl">{country.flag}</span>
                <div>
                  <h3 className="text-lg font-black text-slate-950">VPS {country.name}</h3>
                  <p className="mt-1 text-sm font-bold text-slate-500">{country.city}</p>
                </div>
              </div>
              <ArrowLeft className="mt-2 h-5 w-5 text-slate-300 transition group-hover:text-sky-600" />
            </div>
            <div className="mt-5 flex items-center justify-between rounded-2xl bg-slate-50 p-3">
              <span className="flex items-center gap-2 text-xs font-black text-slate-500"><RadioTower size={15} /> تاخیر شبکه</span>
              <Badge variant="secondary">{country.latency}</Badge>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  );
}
