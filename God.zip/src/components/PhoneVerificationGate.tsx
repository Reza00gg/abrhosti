'use client';

import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, MessageSquareText, Phone, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

function normalize(input: string) {
  const digits = input.replace(/\D/g, '');
  if (/^09\d{9}$/.test(digits)) return digits;
  if (/^9\d{9}$/.test(digits)) return `0${digits}`;
  return '';
}

export function PhoneVerificationGate({ userName }: { userName: string }) {
  const [booting, setBooting] = useState(true);
  const [step, setStep] = useState<'phone' | 'code' | 'done'>('phone');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [timer, setTimer] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const normalizedPhone = useMemo(() => normalize(phone), [phone]);

  useEffect(() => {
    const t = window.setTimeout(() => setBooting(false), 650);
    return () => window.clearTimeout(t);
  }, []);

  useEffect(() => {
    if (timer <= 0) return;
    const t = window.setInterval(() => setTimer((v) => Math.max(0, v - 1)), 1000);
    return () => window.clearInterval(t);
  }, [timer]);

  async function sendCode() {
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/account/phone/send-code', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone: normalizedPhone }) });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.ok) return setError(json?.error?.message ?? 'ارسال کد انجام نشد.');
      setStep('code'); setTimer(json.data?.resendAfter ?? 60);
    } catch {
      setError('ارتباط با سرور برقرار نشد.');
    } finally {
      setLoading(false);
    }
  }

  async function verify() {
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/account/phone/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone: normalizedPhone, code }) });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.ok) return setError(json?.error?.message ?? 'تایید شماره انجام نشد.');
      setStep('done');
      window.setTimeout(() => window.location.reload(), 850);
    } catch {
      setError('ارتباط با سرور برقرار نشد.');
    } finally {
      setLoading(false);
    }
  }

  if (booting) {
    return <main className="min-h-screen bg-slate-50"><div className="shell grid min-h-screen place-items-center"><div className="grid gap-4 text-center"><span className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-slate-200 border-t-slate-950"/><strong className="text-slate-700">در حال بررسی حساب...</strong></div></div></main>;
  }

  return (
    <main className="min-h-screen bg-slate-50 py-10">
      <div className="shell grid min-h-[80vh] place-items-center">
        <section className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="text-center">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-slate-950 text-white"><ShieldCheck size={30}/></div>
            <h1 className="mt-5 text-2xl font-black text-slate-950">تایید شماره همراه</h1>
            <p className="mt-3 text-sm leading-8 text-slate-500">برای استفاده از خدمات ابرهاست، شماره همراه ایرانی خود را تایید کنید.</p>
          </div>

          {step === 'phone' ? <div className="mt-6 grid gap-4"><label className="grid gap-2 text-sm font-bold text-slate-700">شماره همراه<Input className="text-left dir-ltr" dir="ltr" value={phone} onChange={(e)=>setPhone(e.target.value)} placeholder="09123456789" inputMode="numeric" /></label>{error?<div className="alert error">{error}</div>:null}<Button onClick={sendCode} disabled={!normalizedPhone || loading}>{loading?'در حال ارسال...':'ارسال کد تایید'} <Phone size={17}/></Button><p className="text-xs leading-6 text-slate-400">فرمت قابل قبول: 09123456789 یا 9123456789</p></div> : null}

          {step === 'code' ? <div className="mt-6 grid gap-4"><div className="rounded-2xl bg-slate-50 p-3 text-center text-sm font-bold text-slate-500 dir-ltr">{normalizedPhone}</div><label className="grid gap-2 text-sm font-bold text-slate-700">کد تایید<Input className="text-center text-2xl tracking-[.35em] dir-ltr" dir="ltr" value={code} onChange={(e)=>setCode(e.target.value.replace(/\D/g,'').slice(0,6))} placeholder="------" inputMode="numeric" /></label>{error?<div className="alert error">{error}</div>:null}<Button onClick={verify} disabled={code.length !== 6 || loading}>{loading?'در حال تایید...':'تایید شماره'} <MessageSquareText size={17}/></Button><Button variant="secondary" disabled={timer>0 || loading} onClick={sendCode}>{timer>0 ? `ارسال مجدد تا ${timer.toLocaleString('fa-IR')} ثانیه` : 'ارسال مجدد کد'}</Button><button className="text-sm font-bold text-slate-500" onClick={()=>setStep('phone')}>تغییر شماره</button></div> : null}

          {step === 'done' ? <div className="mt-6 rounded-3xl border border-emerald-200 bg-emerald-50 p-5 text-center text-emerald-700"><CheckCircle2 className="mx-auto mb-3 h-9 w-9"/><h2 className="font-black">حساب شما تایید شد</h2><p className="mt-2 text-sm leading-7">کاربر عزیز {userName}، اکنون می‌توانید از خدمات سایت استفاده کنید.</p></div> : null}
        </section>
      </div>
    </main>
  );
}
