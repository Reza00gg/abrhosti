'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';
import { ChevronDown, Cloud, CreditCard, Globe2, LayoutDashboard, Menu, Server, ShieldCheck, X } from 'lucide-react';

import { AccountMenu } from '@/components/AccountMenu';
import { BrandMark } from '@/components/BrandMark';

type User = { name: string; email: string; balance?: number; currency?: string } | null;

const groups = [
  { title: 'هاست و زیرساخت', items: [
    { href: '/hosting/cloud', label: 'هاست ابری', desc: 'پایدار و مقیاس‌پذیر', icon: Cloud },
    { href: '/hosting/shared', label: 'هاست اشتراکی', desc: 'اقتصادی برای شروع', icon: Globe2 },
    { href: '/hosting/dedicated', label: 'سرور اختصاصی', desc: 'منابع کامل', icon: Server }
  ]},
  { title: 'سرور مجازی', items: [
    { href: '/vps', label: 'همه لوکیشن‌ها', desc: 'انتخاب کشور', icon: Server },
    { href: '/vps/de', label: 'آلمان', desc: 'Frankfurt', icon: Server },
    { href: '/vps/us', label: 'آمریکا', desc: 'US Datacenter', icon: Server },
    { href: '/vps/uk', label: 'انگلیس', desc: 'London', icon: Server }
  ]},
  { title: 'دامنه و حساب', items: [
    { href: '/domains', label: 'ثبت دامنه', desc: 'جستجو و خرید دامنه', icon: Globe2 },
    { href: '/dashboard', label: 'داشبورد', desc: 'سرویس‌ها و فاکتورها', icon: LayoutDashboard },
    { href: '/dashboard/billing', label: 'مالی', desc: 'پرداخت‌ها', icon: CreditCard }
  ]}
];

export function SiteHeaderClient({ user }: { user: User }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [closing, setClosing] = useState(false);
  const [expanded, setExpanded] = useState('هاست و زیرساخت');

  function closeMenu() {
    setClosing(true);
    window.setTimeout(() => { setOpen(false); setClosing(false); }, 220);
  }

  function openMenu() { setOpen(true); setClosing(false); }

  if (pathname?.startsWith('/adminChash7nakg')) return null;

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur-xl">
        <div className="shell flex min-h-[72px] items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button type="button" onClick={openMenu} className="inline-flex h-11 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700 shadow-sm transition hover:bg-sky-50 hover:text-sky-700">
              <Menu size={19} /> منو
            </button>
            <Link href="/" className="flex items-center gap-3">
              <BrandMark className="h-11 w-11 shrink-0" />
              <span className="leading-tight"><span className="block text-lg font-black text-slate-950">ابرهاست</span><span className="hidden text-xs font-bold text-slate-500 sm:block">Cloud Services</span></span>
            </Link>
          </div>
          <div className="flex items-center gap-2">
          <AccountMenu user={user} />
        </div>
        </div>
      </header>

      {open ? (
        <div className="fixed inset-0 z-[9999]">
          <button type="button" className={`absolute inset-0 bg-slate-950/45 backdrop-blur-sm ${closing ? 'drawer-backdrop-out' : 'drawer-backdrop-in'}`} onClick={closeMenu} aria-label="بستن" />
          <aside className={`absolute right-0 top-0 flex h-full w-[min(440px,94vw)] flex-col overflow-hidden bg-white shadow-2xl ${closing ? 'drawer-panel-out' : 'drawer-panel-in'}`}>
            <div className="flex items-center justify-between border-b border-slate-100 p-5">
              <div className="flex items-center gap-3"><BrandMark className="h-11 w-11 shrink-0" /><div><strong className="block text-slate-950">منوی ابرهاست</strong><span className="text-xs font-bold text-slate-500">سرویس‌ها و پنل کاربری</span></div></div>
              <button type="button" onClick={closeMenu} className="grid h-10 w-10 place-items-center rounded-2xl bg-slate-100 text-slate-600"><X size={20} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-5">
              <a onClick={closeMenu} href="/dashboard" className="mb-4 flex items-center gap-3 rounded-3xl bg-slate-950 p-4 text-white transition hover:bg-slate-800">
                <LayoutDashboard size={23} /><span><strong className="block">داشبورد کاربری</strong><span className="text-xs text-slate-300">سرویس‌ها، سفارش‌ها و مالی</span></span>
              </a>
              <div className="grid gap-3">
                {groups.map((group) => (
                  <section key={group.title} className="rounded-3xl border border-slate-200 bg-slate-50">
                    <button type="button" onClick={() => setExpanded(expanded === group.title ? '' : group.title)} className="flex w-full items-center justify-between p-4 text-right text-sm font-black text-slate-800">
                      {group.title}<ChevronDown className={`h-4 w-4 transition ${expanded === group.title ? 'rotate-180' : ''}`} />
                    </button>
                    {expanded === group.title ? <div className="grid gap-2 px-3 pb-3">{group.items.map((item) => { const Icon = item.icon; return <a onClick={closeMenu} key={item.href} href={item.href} className="flex items-center gap-3 rounded-2xl bg-white p-3 transition hover:bg-sky-50"><span className="grid h-10 w-10 place-items-center rounded-2xl bg-sky-50 text-sky-700"><Icon size={18} /></span><span><strong className="block text-sm text-slate-950">{item.label}</strong><span className="text-xs font-bold text-slate-500">{item.desc}</span></span></a>; })}</div> : null}
                  </section>
                ))}
              </div>
            </div>
            <div className="border-t border-slate-100 p-5 text-xs font-bold leading-6 text-slate-500"><ShieldCheck size={15} className="ml-1 inline" /> پرداخت کارت‌به‌کارت، فیش و تایید ادمین فعال است.</div>
          </aside>
        </div>
      ) : null}
    </>
  );
}
