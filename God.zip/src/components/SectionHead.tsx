import { Badge } from '@/components/ui/badge';

export function SectionHead({ eyebrow, title, description }: { eyebrow?: string; title: string; description: string }) {
  return (
    <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
      <div>
        {eyebrow ? <Badge variant="default" className="mb-3">{eyebrow}</Badge> : null}
        <h2 className="text-balance text-2xl font-black tracking-tight text-slate-950 md:text-4xl">{title}</h2>
        <p className="mt-3 max-w-2xl text-sm leading-8 text-slate-500 md:text-base">{description}</p>
      </div>
    </div>
  );
}
