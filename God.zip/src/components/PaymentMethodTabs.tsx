'use client';
import { useState } from 'react';
import { CreditCard, Landmark } from 'lucide-react';
import { ReceiptUploadForm } from '@/components/ReceiptUploadForm';
import { GatewayPaymentPanel } from '@/components/GatewayPaymentPanel';

export function PaymentMethodTabs({ token, cardNode, gatewayProps, walletOnly }: { token: string; cardNode: React.ReactNode; walletOnly: boolean; gatewayProps: { amount: number; feeAmount: number; payableAmount: number; onlineAllowed: boolean; gatewayEnabled: boolean; zibalEnabled: boolean; zarinpalEnabled: boolean } }) {
  const [tab, setTab] = useState<'card' | 'gateway'>('card');
  const gatewayDisabled = !walletOnly || !gatewayProps.onlineAllowed || !gatewayProps.gatewayEnabled;
  return <div className="grid gap-5"><div className="grid grid-cols-2 gap-2 rounded-2xl bg-slate-100 p-1"><button onClick={()=>setTab('card')} className={`flex items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-black ${tab==='card'?'bg-white text-slate-950 shadow-sm':'text-slate-500'}`}><CreditCard size={17}/> کارت‌به‌کارت</button><button disabled={gatewayDisabled} onClick={()=>setTab('gateway')} className={`flex min-h-12 items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-black ${tab==='gateway'?'bg-white text-slate-950 shadow-sm':'text-slate-500'} ${gatewayDisabled?'cursor-not-allowed opacity-45':''}`}><Landmark size={17}/> درگاه پرداخت</button></div>{tab==='card'?<>{cardNode}<ReceiptUploadForm token={token}/></>:<GatewayPaymentPanel token={token} {...gatewayProps}/>}</div>;
}
