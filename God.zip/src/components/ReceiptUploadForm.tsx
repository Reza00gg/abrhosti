'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, CheckCircle2, FileImage, Loader2, UploadCloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const allowedTypes = new Set(['image/png', 'image/jpeg', 'image/webp', 'application/pdf']);
const MAX_SIZE = 2_000_000;

export function ReceiptUploadForm({ token }: { token: string }) {
  const [payerName, setPayerName] = useState('');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [fileData, setFileData] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [preparingFile, setPreparingFile] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  function resetFile() {
    setFile(null);
    setFileData('');
    setUploadProgress(0);
    setPreparingFile(false);
  }

  function handleFileSelect(selected?: File | null) {
    setError('');
    setFileData('');
    setUploadProgress(0);

    if (!selected) {
      resetFile();
      return;
    }
    if (!allowedTypes.has(selected.type)) {
      resetFile();
      setError('فرمت فیش باید png، jpg، webp یا pdf باشد.');
      return;
    }
    if (selected.size > MAX_SIZE) {
      resetFile();
      setError('حجم فایل باید کمتر از ۲ مگابایت باشد.');
      return;
    }

    setFile(selected);
    setPreparingFile(true);
    setUploadProgress(6);

    const reader = new FileReader();
    reader.onprogress = (event) => {
      if (event.lengthComputable) {
        const progress = Math.min(95, Math.max(8, Math.round((event.loaded / event.total) * 100)));
        setUploadProgress(progress);
      } else {
        setUploadProgress((current) => Math.min(90, current + 18));
      }
    };
    reader.onerror = () => {
      resetFile();
      setError('آماده‌سازی فایل انجام نشد. دوباره انتخاب کنید.');
    };
    reader.onload = () => {
      const data = String(reader.result).split(',')[1] ?? '';
      if (!data) {
        resetFile();
        setError('فایل انتخاب‌شده معتبر نیست.');
        return;
      }
      setFileData(data);
      setUploadProgress(100);
      setPreparingFile(false);
    };
    reader.readAsDataURL(selected);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!file || !fileData) return setError('لطفاً صبر کنید تا فایل فیش کامل آماده شود.');
    setLoading(true);
    setError('');
    const res = await fetch('/api/payments/receipt', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, payerName, trackingNumber, fileName: file.name, mime: file.type, size: file.size, data: fileData })
    });
    const json = await res.json();
    setLoading(false);
    if (!res.ok || !json.ok) return setError(json?.error?.message ?? 'خطایی رخ داد.');
    setDone(true);
  }

  const fileReady = Boolean(file && fileData && uploadProgress === 100 && !preparingFile);

  if (done) {
    return <div className="rounded-3xl border border-emerald-200 bg-emerald-50 p-6"><h3 className="text-xl font-black text-emerald-800">رسید شما برای پشتیبانی ارسال شد</h3><p className="mt-3 text-sm leading-8 text-emerald-700">سفارش شما اکنون در وضعیت «در انتظار تایید» قرار دارد و پس از تایید ادمین، وضعیت آن تغییر می‌کند.</p><Button asChild className="mt-5"><Link href="/dashboard">بازگشت به داشبورد <ArrowLeft size={17} /></Link></Button></div>;
  }

  return (
    <form onSubmit={submit} className="grid gap-4">
      <div className="grid gap-2"><Label>نام واریزکننده</Label><Input value={payerName} onChange={(e) => setPayerName(e.target.value)} required placeholder="نام صاحب حساب/کارت" /></div>
      <div className="grid gap-2"><Label>شماره پیگیری / توضیح اختیاری</Label><Input value={trackingNumber} onChange={(e) => setTrackingNumber(e.target.value)} placeholder="مثلاً 123456789" /></div>
      <div className="grid gap-2">
        <Label>آپلود فیش واریزی</Label>
        <label className={`grid cursor-pointer place-items-center rounded-3xl border-2 border-dashed p-8 text-center transition ${fileReady ? 'border-emerald-200 bg-emerald-50' : 'border-slate-200 bg-slate-50 hover:border-sky-300 hover:bg-sky-50'}`}>
          {fileReady ? <CheckCircle2 className="mb-3 h-8 w-8 text-emerald-600" /> : preparingFile ? <Loader2 className="mb-3 h-8 w-8 animate-spin text-sky-600" /> : <UploadCloud className="mb-3 h-8 w-8 text-sky-600" />}
          <span className="font-black text-slate-800">{file ? file.name : 'انتخاب تصویر یا PDF فیش'}</span>
          <span className="mt-1 text-xs font-bold text-slate-500">حداکثر ۲ مگابایت</span>

          {file ? (
            <div className="mt-5 w-full max-w-sm">
              <div className="mb-2 flex items-center justify-between gap-3 text-xs font-black">
                <span className={fileReady ? 'text-emerald-700' : 'text-slate-500'}>{fileReady ? 'فایل آماده ارسال است' : 'در حال آماده‌سازی فایل...'}</span>
                <span className={fileReady ? 'text-emerald-700' : 'text-slate-500'}>{uploadProgress.toLocaleString('fa-IR')}٪</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-white ring-1 ring-slate-200">
                <div className={`h-full rounded-full transition-all duration-300 ${fileReady ? 'bg-emerald-500' : 'bg-sky-500'}`} style={{ width: `${uploadProgress}%` }} />
              </div>
              <div className="mt-3 flex items-center justify-center gap-2 text-xs font-bold text-slate-500">
                <FileImage size={14} /> {(file.size / 1024).toFixed(0)} KB
              </div>
            </div>
          ) : null}
          <input className="hidden" type="file" accept="image/png,image/jpeg,image/webp,application/pdf" onChange={(e) => handleFileSelect(e.target.files?.[0] ?? null)} />
        </label>
      </div>
      {error ? <div className="alert error">{error}</div> : null}
      <Button size="lg" disabled={loading || !fileReady}>{loading ? 'در حال ارسال...' : fileReady ? 'پرداخت کردم و فیش را ارسال می‌کنم' : 'ابتدا فیش را کامل آپلود کنید'} <ArrowLeft size={18} /></Button>
    </form>
  );
}
