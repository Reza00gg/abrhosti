'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Check, ChevronDown, Pencil, Save, Search, X } from 'lucide-react';
import type { User } from '@/lib/auth';
import { IRAN_COUNTRY, IRAN_PROVINCES, getIranCities } from '@/lib/iran-locations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

function optional(value?: string | null) {
  return value ?? '';
}

type SelectOption = {
  value: string;
  label: string;
};

function SearchableSelect({
  label,
  value,
  options,
  placeholder = 'انتخاب نشده',
  searchPlaceholder = 'جستجو...',
  disabled = false,
  onChange
}: {
  label: string;
  value: string;
  options: SelectOption[];
  placeholder?: string;
  searchPlaceholder?: string;
  disabled?: boolean;
  onChange: (value: string) => void;
}) {
  const rootRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [mounted, setMounted] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [search, setSearch] = useState('');

  const selected = options.find((option) => option.value === value);
  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return options;
    return options.filter((option) => option.label.toLowerCase().includes(term));
  }, [options, search]);

  function openDropdown() {
    if (disabled) return;
    setMounted(true);
    window.requestAnimationFrame(() => setExpanded(true));
  }

  function closeDropdown() {
    setExpanded(false);
    window.setTimeout(() => {
      setMounted(false);
      setSearch('');
    }, 160);
  }

  function toggleDropdown() {
    if (expanded) closeDropdown();
    else openDropdown();
  }

  useEffect(() => {
    if (!mounted) return;
    const timer = window.setTimeout(() => inputRef.current?.focus(), 60);
    return () => window.clearTimeout(timer);
  }, [mounted]);

  useEffect(() => {
    function handlePointerDown(event: PointerEvent) {
      if (!rootRef.current?.contains(event.target as Node)) closeDropdown();
    }
    if (mounted) document.addEventListener('pointerdown', handlePointerDown);
    return () => document.removeEventListener('pointerdown', handlePointerDown);
  }, [mounted]);

  useEffect(() => {
    if (disabled) closeDropdown();
  }, [disabled]);

  return (
    <div ref={rootRef} className="relative grid gap-2">
      <Label>{label}</Label>
      <button
        type="button"
        disabled={disabled}
        onClick={toggleDropdown}
        className="flex h-11 w-full items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-right text-sm font-bold text-slate-900 shadow-sm outline-none transition hover:border-slate-300 focus:border-sky-400 focus:ring-0 disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-400 disabled:opacity-70"
        aria-expanded={expanded}
      >
        <span className={selected ? 'text-slate-950' : 'text-slate-400'}>{selected?.label ?? placeholder}</span>
        <ChevronDown size={16} className={`shrink-0 text-slate-400 transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`} />
      </button>

      {mounted ? (
        <div
          className={`absolute right-0 top-[calc(100%+8px)] z-[70] w-full origin-top overflow-hidden rounded-2xl border border-slate-200 bg-white p-2 shadow-[0_18px_50px_rgba(15,23,42,.16)] transition-all duration-200 ease-out ${
            expanded ? 'translate-y-0 scale-100 opacity-100' : '-translate-y-1 scale-[.98] opacity-0'
          }`}
        >
          <div className="relative mb-2">
            <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              ref={inputRef}
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder={searchPlaceholder}
              className="h-10 w-full rounded-xl border border-slate-100 bg-slate-50 pr-9 pl-3 text-sm font-bold text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-sky-300 focus:bg-white focus:ring-0"
            />
          </div>

          <div className="profile-edit-scrollbar max-h-56 overflow-y-auto pl-1">
            <button
              type="button"
              onClick={() => {
                onChange('');
                closeDropdown();
              }}
              className={`flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-right text-sm font-extrabold transition hover:bg-slate-50 ${!value ? 'bg-sky-50 text-sky-700' : 'text-slate-600'}`}
            >
              <span>{placeholder}</span>
              {!value ? <Check size={15} /> : null}
            </button>

            {filtered.length ? filtered.map((option) => (
              <button
                type="button"
                key={option.value}
                onClick={() => {
                  onChange(option.value);
                  closeDropdown();
                }}
                className={`mt-1 flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-right text-sm font-extrabold transition hover:bg-slate-50 ${value === option.value ? 'bg-sky-50 text-sky-700' : 'text-slate-700'}`}
              >
                <span>{option.label}</span>
                {value === option.value ? <Check size={15} /> : null}
              </button>
            )) : (
              <div className="rounded-xl px-3 py-3 text-center text-xs font-bold text-slate-400">موردی پیدا نشد.</div>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}

export function ProfileEditForm({ user }: { user: User }) {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [visible, setVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [name, setName] = useState(user.name ?? '');
  const [country, setCountry] = useState(optional(user.country));
  const [province, setProvince] = useState(optional(user.province));
  const [city, setCity] = useState(optional(user.city));
  const [address, setAddress] = useState(optional(user.address));
  const [postalCode, setPostalCode] = useState(optional(user.postal_code));

  const countryOptions = useMemo(() => [{ value: IRAN_COUNTRY, label: IRAN_COUNTRY }], []);
  const provinceOptions = useMemo(() => IRAN_PROVINCES.map((item) => ({ value: item.name, label: item.name })), []);
  const cityOptions = useMemo(() => getIranCities(province).map((item) => ({ value: item, label: item })), [province]);

  function resetForm() {
    setName(user.name ?? '');
    setCountry(optional(user.country));
    setProvince(optional(user.province));
    setCity(optional(user.city));
    setAddress(optional(user.address));
    setPostalCode(optional(user.postal_code));
    setErr('');
    setMsg('');
  }

  function openModal() {
    setMounted(true);
    window.requestAnimationFrame(() => setVisible(true));
  }

  function closeModal(reset = true) {
    if (saving) return;
    setVisible(false);
    window.setTimeout(() => {
      setMounted(false);
      if (reset) resetForm();
    }, 220);
  }

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') closeModal();
    }
    if (mounted) document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [mounted, saving]);

  useEffect(() => {
    if (!mounted) return;
    const previousOverflow = document.body.style.overflow;
    document.documentElement.classList.add('profile-modal-open');
    document.body.style.overflow = 'hidden';

    return () => {
      document.documentElement.classList.remove('profile-modal-open');
      document.body.style.overflow = previousOverflow;
    };
  }, [mounted]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setErr('');
    setMsg('');

    const res = await fetch('/api/account/profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, country, province, city, address, postalCode })
    });
    const json = await res.json();
    setSaving(false);

    if (!res.ok || !json.ok) {
      setErr(json?.error?.message ?? 'خطا در ذخیره اطلاعات');
      return;
    }

    setMsg('اطلاعات پروفایل ذخیره شد.');
    router.refresh();
    window.setTimeout(() => closeModal(false), 450);
  }

  return (
    <>
      <Button type="button" size="sm" variant="secondary" onClick={openModal}>
        <Pencil size={15} /> ویرایش اطلاعات
      </Button>

      {mounted ? (
        <div
          className={`fixed inset-0 z-50 grid place-items-center bg-slate-950/45 p-4 backdrop-blur-sm transition-opacity duration-200 ${visible ? 'opacity-100' : 'opacity-0'}`}
          role="dialog"
          aria-modal="true"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) closeModal();
          }}
        >
          <div
            className={`profile-edit-scrollbar max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-[1.75rem] border border-slate-200 bg-white p-5 shadow-2xl transition-all duration-200 ease-out md:p-6 ${
              visible ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-4 scale-[.98] opacity-0'
            }`}
          >
            <div className="mb-5 flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-xl font-black text-slate-950">ویرایش اطلاعات کاربری</h3>
                <p className="mt-1 text-sm leading-7 text-slate-500">نام الزامی است؛ بقیه فیلدها اختیاری هستند و می‌توانید خالی بگذارید.</p>
              </div>
              <Button type="button" variant="ghost" size="icon" onClick={() => closeModal()} aria-label="بستن فرم">
                <X size={18} />
              </Button>
            </div>

            <form onSubmit={submit} className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="profile-name">نام و نام خانوادگی</Label>
                <Input id="profile-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً علی رضایی" required maxLength={80} className="focus:ring-0" />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="profile-email">ایمیل</Label>
                <Input id="profile-email" value={user.email} disabled dir="ltr" className="dir-ltr text-left focus:ring-0" />
                <span className="text-xs font-bold text-slate-400">ایمیل از این بخش قابل تغییر نیست.</span>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <SearchableSelect
                  label="کشور"
                  value={country}
                  options={countryOptions}
                  searchPlaceholder="جستجوی کشور"
                  onChange={(next) => {
                    setCountry(next);
                    if (!next) {
                      setProvince('');
                      setCity('');
                    }
                  }}
                />

                <SearchableSelect
                  label="استان"
                  value={province}
                  options={provinceOptions}
                  searchPlaceholder="جستجوی استان"
                  disabled={country !== IRAN_COUNTRY}
                  onChange={(next) => {
                    setProvince(next);
                    setCity('');
                  }}
                />

                <SearchableSelect
                  label="شهر"
                  value={city}
                  options={cityOptions}
                  searchPlaceholder="جستجوی شهر"
                  disabled={!province || country !== IRAN_COUNTRY}
                  onChange={setCity}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="profile-address">آدرس</Label>
                <textarea
                  id="profile-address"
                  className="profile-edit-scrollbar min-h-28 w-full resize-y rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm leading-8 text-slate-900 shadow-sm outline-none transition placeholder:text-slate-400 focus:border-sky-400 focus:ring-0"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="آدرس کامل را وارد کنید"
                  maxLength={500}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="profile-postal-code">کد پستی</Label>
                <Input id="profile-postal-code" value={postalCode} onChange={(e) => setPostalCode(e.target.value)} placeholder="۱۰ رقمی" inputMode="numeric" maxLength={10} className="dir-ltr text-left focus:ring-0" dir="ltr" />
              </div>

              {err ? <div className="alert error">{err}</div> : null}
              {msg ? <div className="alert success">{msg}</div> : null}

              <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
                <Button type="button" variant="secondary" onClick={() => closeModal()} disabled={saving}>انصراف</Button>
                <Button type="submit" disabled={saving}>
                  <Save size={16} /> {saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      ) : null}
    </>
  );
}
