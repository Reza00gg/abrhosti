'use client';

import { useRouter } from 'next/navigation';
import { useMemo, useState } from 'react';
import { ArrowLeft, Globe2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { formatPrice } from '@/lib/products';

export function DomainOrderForm({ domain, unitPrice }: { domain: string; unitPrice: number }) {
  const router = useRouter();
  const [years, setYears] = useState(1);
  const [registrantName, setRegistrantName] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const total = useMemo(() => unitPrice * years, [unitPrice, years]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError('');
    const res = await fetch('/api/domain/order', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain, years, registrantName, notes })
    });
    const json = await res.json();
    setLoading(false);
    if (res.status === 401) return router.push(`/auth/login?next=/domains/checkout?domain=${encodeURIComponent(domain)}`);
    if (!res.ok || !json.ok) return setError(json?.error?.message ?? 'ثبت سفارش دامنه انجام نشد.');
    router.push(json.data.payUrl);
  }

  return (
    <form onSubmit={submit} className="grid gap-5">
      <div>
        <Badge variant="secondary"><Globe2 size={13} className="ml-1" /> Domain Registration</Badge>
        <h2 className="mt-4 text-2xl font-black text-slate-950">ثبت دامنه</h2>
        <p className="mt-2 text-sm leading-7 text-slate-500">بعد از پرداخت، دامنه برای بررسی و ثبت نهایی در صف پشتیبانی قرار می‌گیرد.</p>
      </div>
      <div className="rounded-3xl border border-slate-200 bg-slate-50 p-4">
        <div className="flex justify-between gap-4 border-b border-slate-200 py-3 text-sm"><span className="font-bold text-slate-500">دامنه</span><strong className="dir-ltr text-slate-950">{domain}</strong></div>
        <div className="flex justify-between gap-4 py-3 text-sm"><span className="font-bold text-slate-500">قیمت سالانه</span><strong>{formatPrice(unitPrice)}</strong></div>
      </div>
      <div className="grid gap-2"><Label>مدت ثبت</Label><select className="select" value={years} onChange={(e) => setYears(Number(e.target.value))}>{[1,2,3,4,5].map(y => <option value={y} key={y}>{y} سال</option>)}</select></div>
      <div className="grid gap-2"><Label>نام مالک دامنه</Label><Input value={registrantName} onChange={(e) => setRegistrantName(e.target.value)} placeholder="نام شخص یا شرکت" required /></div>
      <div className="grid gap-2"><Label>توضیحات اختیاری</Label><textarea className="textarea" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="در صورت نیاز توضیح کوتاه بنویسید." /></div>
      <div className="rounded-2xl bg-slate-950 p-4 text-white"><span className="text-sm text-slate-300">مبلغ قابل پرداخت</span><strong className="mt-1 block text-2xl">{formatPrice(total)}</strong></div>
      {error ? <div className="alert error">{error}</div> : null}
      <Button size="lg" disabled={loading}>{loading ? 'در حال ساخت پرداخت...' : 'ادامه به پرداخت کارت‌به‌کارت'} <ArrowLeft size={17} /></Button>
    </form>
  );
}
