import Link from 'next/link';
import { Mail } from 'lucide-react';
import { SiteFooterClient } from '@/components/SiteFooterClient';
import { getCurrentUser } from '@/lib/auth';
import { BrandMark } from '@/components/BrandMark';
import { EnamadTrustBadge } from '@/components/EnamadTrustBadge';

export async function Footer() {
  const user = await getCurrentUser();
  return (
    <SiteFooterClient>
      <footer className="mt-14 border-t border-slate-200 bg-white">
        <div className="shell py-7">
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-start">
            <div className="max-w-md">
              <div className="flex items-center gap-3">
                <BrandMark className="h-10 w-10 shrink-0" />
                <div>
                  <h3 className="m-0 text-base font-black text-slate-950">ابرهاست</h3>
                  <p className="m-0 text-xs font-bold text-slate-500">هاست، سرور مجازی و دامنه</p>
                </div>
              </div>
              <p className="mt-4 text-sm leading-7 text-slate-500">خرید و مدیریت سرویس‌های میزبانی با پرداخت کارت‌به‌کارت و پنل کاربری.</p>
            </div>
            <div className="grid grid-cols-2 gap-8 text-sm font-bold text-slate-500 sm:grid-cols-3">
              <div className="grid gap-2">
                <strong className="text-slate-900">محصولات</strong>
                <Link className="hover:text-sky-700" href="/hosting/cloud">هاست ابری</Link>
                <Link className="hover:text-sky-700" href="/vps">VPS</Link>
                <Link className="hover:text-sky-700" href="/domains">دامنه</Link>
              </div>
              <div className="grid gap-2">
                <strong className="text-slate-900">حساب</strong>
                {user ? <Link className="hover:text-sky-700" href="/dashboard">داشبورد</Link> : <><Link className="hover:text-sky-700" href="/auth/login">ورود</Link><Link className="hover:text-sky-700" href="/auth/register">ثبت‌نام</Link></>}
                <Link className="hover:text-sky-700" href="/dashboard/billing">فاکتورها</Link>
              </div>
              <div className="grid gap-2">
                <strong className="text-slate-900">اعتماد</strong>
                <EnamadTrustBadge />
                <span className="flex items-center gap-1 dir-ltr"><Mail size={14} /> support@abrhost.local</span>
              </div>
            </div>
          </div>
          <div className="mt-6 border-t border-slate-100 pt-4 text-xs font-bold text-slate-400">© ۲۰۲۶ ابرهاست</div>
        </div>
      </footer>
    </SiteFooterClient>
  );
}
