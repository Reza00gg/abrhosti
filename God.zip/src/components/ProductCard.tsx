import Link from 'next/link';
import { ArrowLeft, Check, Cpu, HardDrive, MemoryStick, Network } from 'lucide-react';
import { type Product, formatPrice } from '@/lib/products';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

const icons = [Cpu, MemoryStick, HardDrive, Network];
const ltrRunPattern = /([A-Za-z0-9\u0660-\u0669\u06F0-\u06F9][A-Za-z0-9\u0660-\u0669\u06F0-\u06F9+./%_-]*(?:\s+[A-Za-z0-9\u0660-\u0669\u06F0-\u06F9][A-Za-z0-9\u0660-\u0669\u06F0-\u06F9+./%_-]*)*)/g;

function BidiText({ children }: { children: string }) {
  const parts = String(children).split(ltrRunPattern).filter(Boolean);

  return (
    <>
      {parts.map((part, index) =>
        /[A-Za-z0-9\u0660-\u0669\u06F0-\u06F9]/.test(part) ? (
          <bdi key={index} dir="ltr" className="unicode-bidi-isolate">
            {part}
          </bdi>
        ) : (
          <span key={index}>{part}</span>
        )
      )}
    </>
  );
}

export function ProductCard({ product, featured = false }: { product: Product; featured?: boolean }) {
  const specs = [
    ['پردازنده', product.cpu],
    ['رم', product.ram],
    ['فضا', product.storage],
    ['ترافیک', product.bandwidth]
  ];

  return (
    <Card dir="rtl" className={`relative flex h-full flex-col overflow-hidden text-right ${featured ? 'border-slate-300' : ''}`}>
      <CardHeader className="items-start pb-4 text-right">
        <div className="flex flex-wrap justify-start gap-2"><Badge variant={product.category === 'vps' ? 'warning' : 'default'} className="w-fit">{product.badge}</Badge>{featured ? <Badge variant="success">پیشنهادی</Badge> : null}</div>
        <h3 className="mt-4 w-full text-right text-xl font-black tracking-tight text-slate-950"><BidiText>{product.title}</BidiText></h3>
        <p className="min-h-[56px] w-full text-right text-sm leading-7 text-slate-500"><BidiText>{product.subtitle}</BidiText></p>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col text-right">
        <div className="rounded-2xl bg-slate-50 p-4 text-right">
          <div className="text-xs font-bold text-slate-400">شروع قیمت</div>
          <div className="mt-1 flex flex-row-reverse flex-wrap items-end justify-end gap-1 text-right">
            {product.category !== 'domain' ? <span className="pb-1 text-xs font-bold text-slate-400">ماهانه /</span> : null}
            <strong className="text-2xl font-black tracking-tight text-slate-950">{formatPrice(product.priceMonthly, product.currency)}</strong>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2">
          {specs.map(([label, value], index) => {
            const Icon = icons[index];
            return (
              <div key={label} className="rounded-2xl border border-slate-100 bg-white p-3 text-right">
                <div className="mb-2 flex flex-row-reverse items-center justify-end gap-2 text-xs font-black text-slate-400"><Icon size={14} /> {label}</div>
                <div className="text-right text-xs font-extrabold leading-6 text-slate-700"><BidiText>{value}</BidiText></div>
              </div>
            );
          })}
        </div>

        <ul className="mt-4 grid gap-2 text-right text-sm font-bold text-slate-600">
          {product.features.slice(0, 4).map((feature) => (
            <li key={feature} className="flex flex-row-reverse items-start justify-end gap-2 leading-7"><Check className="mt-1 h-4 w-4 shrink-0 text-emerald-500" /><span><BidiText>{feature}</BidiText></span></li>
          ))}
        </ul>

        <div className="mt-auto flex gap-2 pt-5">
          <Button asChild className="flex-1">
            <Link href={product.category === 'domain' ? '/domains' : `/checkout/${product.id}`}>{product.category === 'domain' ? 'جستجوی دامنه' : 'سفارش'} <ArrowLeft size={16} /></Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href={product.route}>جزئیات</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
