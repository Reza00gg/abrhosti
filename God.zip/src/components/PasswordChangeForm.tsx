'use client';
import { useState } from 'react';
import { KeyRound } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
export function PasswordChangeForm() {
  const [currentPassword, setCurrent] = useState('');
  const [newPassword, setNew] = useState('');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMsg(''); setErr('');
    const res = await fetch('/api/account/password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ currentPassword, newPassword }) });
    const json = await res.json();
    if (!res.ok || !json.ok) return setErr(json?.error?.message ?? 'خطا در تغییر رمز');
    setMsg('رمز عبور با موفقیت تغییر کرد.'); setCurrent(''); setNew('');
  }
  return <form onSubmit={submit} className="grid gap-4"><div className="grid gap-2"><Label>رمز فعلی</Label><Input type="password" className="dir-ltr text-left" dir="ltr" value={currentPassword} onChange={e=>setCurrent(e.target.value)} /></div><div className="grid gap-2"><Label>رمز جدید</Label><Input type="password" className="dir-ltr text-left" dir="ltr" value={newPassword} onChange={e=>setNew(e.target.value)} /></div>{err?<div className="alert error">{err}</div>:null}{msg?<div className="alert success">{msg}</div>:null}<Button><KeyRound size={16}/> تغییر رمز</Button></form>
}
