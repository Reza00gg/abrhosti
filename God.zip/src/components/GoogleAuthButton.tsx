'use client';

import { useSearchParams } from 'next/navigation';
import { useState } from 'react';

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.84z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06L5.84 9.9C6.71 7.3 9.14 5.38 12 5.38z" />
    </svg>
  );
}

function Spinner() {
  return <span className="h-4 w-4 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900" />;
}

export function GoogleAuthButton({ mode }: { mode: 'login' | 'register' }) {
  const params = useSearchParams();
  const [loading, setLoading] = useState(false);
  const text = mode === 'register' ? 'ساخت حساب با گوگل' : 'ورود با گوگل';

  function start() {
    setLoading(true);
    const next = params.get('next') || '/dashboard';
    window.location.href = `/api/auth/google/start?mode=${mode}&next=${encodeURIComponent(next)}`;
  }

  return (
    <button
      type="button"
      onClick={start}
      disabled={loading}
      className="flex h-11 w-full items-center justify-center gap-3 rounded-xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-800 shadow-sm transition active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60"
    >
      {loading ? <Spinner /> : <GoogleIcon />}
      {loading ? 'در حال انتقال به گوگل...' : text}
    </button>
  );
}
