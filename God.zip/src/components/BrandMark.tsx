export function BrandMark({ className = 'h-11 w-11' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <linearGradient id="abrhost-bg" x1="9" y1="7" x2="56" y2="59" gradientUnits="userSpaceOnUse">
          <stop stopColor="#38BDF8" />
          <stop offset="0.48" stopColor="#2563EB" />
          <stop offset="1" stopColor="#0F172A" />
        </linearGradient>
        <linearGradient id="abrhost-cloud" x1="15" y1="20" x2="49" y2="44" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FFFFFF" />
          <stop offset="1" stopColor="#EAF9FF" />
        </linearGradient>
        <filter id="abrhost-soft" x="5" y="5" width="54" height="54" filterUnits="userSpaceOnUse" colorInterpolationFilters="sRGB">
          <feDropShadow dx="0" dy="7" stdDeviation="7" floodColor="#0F172A" floodOpacity="0.18" />
        </filter>
      </defs>

      <rect x="4" y="4" width="56" height="56" rx="18" fill="url(#abrhost-bg)" />
      <path d="M11 46.5C18.8 53.8 31.3 55.2 42.8 50.8C51 47.7 56.2 40.2 55.4 31.6C54.5 22.2 47.2 14.9 38.2 12.7C27.8 10.1 16.8 14.2 11.2 23.7C6.9 30.9 6.6 40.1 11 46.5Z" fill="white" fillOpacity="0.08" />

      <g filter="url(#abrhost-soft)">
        <path
          d="M23.2 43.5H44.4C49.2 43.5 53 39.8 53 35.3C53 30.8 49.2 27.2 44.6 27.1C43 20.9 37.4 16.6 30.9 16.6C23.8 16.6 17.9 21.7 16.8 28.4C12.7 29.3 9.7 32.8 9.7 37C9.7 41.8 13.6 43.5 23.2 43.5Z"
          fill="url(#abrhost-cloud)"
        />
        <path
          d="M23.2 43.5H44.4C49.2 43.5 53 39.8 53 35.3C53 30.8 49.2 27.2 44.6 27.1C43 20.9 37.4 16.6 30.9 16.6C23.8 16.6 17.9 21.7 16.8 28.4C12.7 29.3 9.7 32.8 9.7 37C9.7 41.8 13.6 43.5 23.2 43.5Z"
          stroke="white"
          strokeOpacity="0.82"
          strokeWidth="1.2"
        />
      </g>

      <path d="M17.2 50.5C26.4 55.2 38.5 54.2 46.2 48.6" stroke="white" strokeOpacity="0.26" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}
