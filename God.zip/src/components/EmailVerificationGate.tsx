'use client';

import { useEffect, useState } from 'react';
import { CheckCircle2, Mail, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function EmailVerificationGate({ userName, email }: { userName: string; email: string }) {
  const [booting, setBooting] = useState(true);
  const [step, setStep] = useState<'intro' | 'code' | 'done'>('intro');
  const [code, setCode] = useState('');
  const [timer, setTimer] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const t = window.setTimeout(() => setBooting(false), 650);
    return () => window.clearTimeout(t);
  }, []);

  useEffect(() => {
    if (timer <= 0) return;
    const t = window.setInterval(() => setTimer((v) => Math.max(0, v - 1)), 1000);
    return () => window.clearInterval(t);
  }, [timer]);

  async function sendCode() {
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/account/email/send-code', { method: 'POST' });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.ok) return setError(json?.error?.message ?? 'ارسال ایمیل انجام نشد.');
      setStep('code'); setTimer(json.data?.resendAfter ?? 60);
    } catch { setError('ارتباط با سرور برقرار نشد.'); }
    finally { setLoading(false); }
  }

  async function verify() {
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/account/email/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code }) });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.ok) return setError(json?.error?.message ?? 'تایید ایمیل انجام نشد.');
      setStep('done'); window.setTimeout(() => window.location.reload(), 850);
    } catch { setError('ارتباط با سرور برقرار نشد.'); }
    finally { setLoading(false); }
  }

  if (booting) return <main className="min-h-screen bg-slate-50"><div className="shell grid min-h-screen place-items-center"><div className="grid gap-4 text-center"><span className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-slate-200 border-t-slate-950"/><strong className="text-slate-700">در حال بررسی حساب...</strong></div></div></main>;

  return (
    <main className="min-h-screen bg-slate-50 py-10">
      <div className="shell grid min-h-[80vh] place-items-center">
        <section className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="text-center">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-slate-950 text-white"><ShieldCheck size={30}/></div>
            <h1 className="mt-5 text-2xl font-black text-slate-950">تایید ایمیل</h1>
            <p className="mt-3 text-sm leading-8 text-slate-500">برای استفاده از خدمات ابرهاست، ایمیل حساب خود را تایید کنید.</p>
            <div className="mt-4 rounded-2xl bg-slate-50 p-3 text-sm font-bold text-slate-500 dir-ltr">{email}</div>
          </div>

          {step === 'intro' ? <div className="mt-6 grid gap-4">{error?<div className="alert error">{error}</div>:null}<Button onClick={sendCode} disabled={loading}>{loading?'در حال ارسال...':'ارسال کد تایید به ایمیل'} <Mail size={17}/></Button><p className="text-xs leading-6 text-slate-400">ایمیل شامل کد ۶ رقمی و لینک تایید یک‌بارمصرف خواهد بود.</p></div> : null}
          {step === 'code' ? <div className="mt-6 grid gap-4"><label className="grid gap-2 text-sm font-bold text-slate-700">کد تایید<Input className="text-center text-2xl tracking-[.35em] dir-ltr" dir="ltr" value={code} onChange={(e)=>setCode(e.target.value.replace(/\D/g,'').slice(0,6))} placeholder="------" inputMode="numeric" /></label>{error?<div className="alert error">{error}</div>:null}<Button onClick={verify} disabled={code.length !== 6 || loading}>{loading?'در حال تایید...':'تایید ایمیل'} <Mail size={17}/></Button><Button variant="secondary" disabled={timer>0 || loading} onClick={sendCode}>{timer>0 ? `ارسال مجدد تا ${timer.toLocaleString('fa-IR')} ثانیه` : 'ارسال مجدد کد'}</Button></div> : null}
          {step === 'done' ? <div className="mt-6 rounded-3xl border border-emerald-200 bg-emerald-50 p-5 text-center text-emerald-700"><CheckCircle2 className="mx-auto mb-3 h-9 w-9"/><h2 className="font-black">حساب شما تایید شد</h2><p className="mt-2 text-sm leading-7">کاربر عزیز {userName}، اکنون می‌توانید از خدمات سایت استفاده کنید.</p></div> : null}
        </section>
      </div>
    </main>
  );
}
