export function CloudIcon() {
  return (
    <svg viewBox="0 0 64 64" fill="none" aria-hidden="true">
      <path d="M22 47h24a12 12 0 0 0 1.3-23.93A18 18 0 0 0 13.15 28.1 9.8 9.8 0 0 0 22 47Z" stroke="white" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M24 35h16M32 27v16" stroke="white" strokeWidth="5" strokeLinecap="round" />
    </svg>
  );
}

export function ArrowIcon() {
  return <span aria-hidden="true">←</span>;
}
