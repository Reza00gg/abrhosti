'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { LayoutDashboard, LogOut, UserRound, Wallet } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { formatPrice } from '@/lib/products';

type User = { name: string; email: string; balance?: number; currency?: string } | null;

export function AccountMenu({ user }: { user: User }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onDown(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, []);

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    setOpen(false);
    router.push('/');
    router.refresh();
  }

  if (!user) {
    return (
      <button
        type="button"
        aria-label="حساب کاربری"
        onClick={() => router.push('/auth/login')}
        className="grid h-11 w-11 place-items-center rounded-xl border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:bg-sky-50 hover:text-sky-700"
      >
        <UserRound size={20} />
      </button>
    );
  }

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        aria-label="منوی حساب"
        onClick={() => setOpen((v) => !v)}
        className="grid h-11 w-11 place-items-center rounded-xl border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:bg-sky-50 hover:text-sky-700"
      >
        <UserRound size={20} />
      </button>
      {open ? (
        <div className="absolute left-0 top-13 z-[80] w-56 rounded-2xl border border-slate-200 bg-white p-2 shadow-[0_20px_70px_rgba(15,23,42,.16)] submenu-open">
          <div className="border-b border-slate-100 px-3 py-2">
            <strong className="block truncate text-sm text-slate-950">{user.name}</strong>
            <span className="block truncate text-xs font-bold text-slate-400 dir-ltr">{user.email}</span>
          </div>
          <Link onClick={() => setOpen(false)} href="/dashboard" className="mt-2 flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-bold text-slate-700 hover:bg-sky-50 hover:text-sky-700">
            <LayoutDashboard size={17} /> داشبورد
          </Link>
          <Link onClick={() => setOpen(false)} href="/dashboard/wallet" className="flex items-center justify-between rounded-xl px-3 py-2 text-sm font-bold text-slate-700 hover:bg-slate-50">
            <span className="flex items-center gap-2"><Wallet size={17} /> موجودی</span><strong className="text-xs">{formatPrice(user.balance ?? 0, user.currency ?? 'تومان')}</strong>
          </Link>
          <button onClick={logout} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm font-bold text-red-600 hover:bg-red-50">
            <LogOut size={17} /> خروج
          </button>
        </div>
      ) : null}
    </div>
  );
}
