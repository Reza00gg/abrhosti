import { getCurrentUser } from '@/lib/auth';
import { getWalletBalance } from '@/lib/wallet';
import { SiteHeaderClient } from '@/components/SiteHeaderClient';

export async function Header() {
  const user = await getCurrentUser();
  const wallet = user ? await getWalletBalance(user.id) : null;
  return <SiteHeaderClient user={user ? { name: user.name, email: user.email, balance: wallet?.balance ?? 0, currency: wallet?.currency ?? 'تومان' } : null} />;
}
