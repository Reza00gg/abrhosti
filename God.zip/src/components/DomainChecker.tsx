'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Globe2, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

type Result = {
  ok: boolean;
  data?: { domain: string; tld: string; available: boolean; supported: boolean; message: string; suggestions: string[]; method: string };
  error?: { message: string };
};

export function DomainChecker() {
  const [domain, setDomain] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  async function check() {
    setLoading(true);
    setResult(null);
    const res = await fetch('/api/domain/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain })
    });
    const json = await res.json();
    setLoading(false);
    setResult(json);
  }

  const available = result?.ok && result.data?.available;

  return (
    <Card className="overflow-hidden">
      <div className="grid gap-0 lg:grid-cols-[.9fr_1.1fr]">
        <div className="bg-slate-950 p-7 text-white lg:p-9">
          <Badge className="bg-white/10 text-white" variant="outline"><Globe2 size={13} className="ml-1" /> RDAP Domain Check</Badge>
          <h2 className="mt-5 text-2xl font-black tracking-tight md:text-4xl">جستجوی واقعی دامنه</h2>
          <p className="mt-4 text-sm leading-8 text-slate-300">
            آزاد بودن دامنه از طریق RDAP رجیستری بررسی می‌شود و بیش از ۲۰۰ پسوند بین‌المللی پشتیبانی می‌شود.
          </p>
          <div className="mt-6 grid grid-cols-3 gap-2 text-center text-xs font-black text-slate-300">
            <span className="rounded-2xl bg-white/10 p-3">.com</span>
            <span className="rounded-2xl bg-white/10 p-3">.app</span>
            <span className="rounded-2xl bg-white/10 p-3">.cloud</span>
          </div>
        </div>
        <div className="p-7 lg:p-9">
          <div className="flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <Input className="h-13 pr-10 text-left dir-ltr" placeholder="example.com" value={domain} onChange={(e) => setDomain(e.target.value)} dir="ltr" />
            </div>
            <Button onClick={check} disabled={loading || !domain} size="lg">{loading ? 'در حال بررسی...' : 'بررسی'}</Button>
          </div>

          {result ? (
            <div className={`mt-5 rounded-2xl border p-4 text-sm leading-8 ${available ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-red-200 bg-red-50 text-red-700'}`}>
              {result.ok ? result.data?.message : result.error?.message}
              {available ? (
                <div className="mt-3">
                  <Button asChild variant="secondary">
                    <Link href={`/domains/checkout?domain=${encodeURIComponent(result.data!.domain)}`}>ثبت این دامنه <ArrowLeft size={16} /></Link>
                  </Button>
                </div>
              ) : null}
              {result.ok && result.data?.suggestions?.length ? (
                <div className="mt-3 flex flex-wrap gap-2">
                  {result.data.suggestions.map((item) => <Badge key={item} variant="secondary" className="dir-ltr">{item}</Badge>)}
                </div>
              ) : null}
            </div>
          ) : (
            <div className="mt-5 rounded-2xl bg-slate-50 p-4 text-sm leading-8 text-slate-500">
              نمونه: <span className="font-black text-slate-800 dir-ltr">mybrand.com</span> یا <span className="font-black text-slate-800 dir-ltr">startup.app</span>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
