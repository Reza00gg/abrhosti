'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { FormEvent, useRef, useState } from 'react';
import { ArrowLeft, LockKeyhole, Mail, UserRound } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { GoogleAuthButton } from '@/components/GoogleAuthButton';

type Mode = 'login' | 'register';

export function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const params = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const formRef = useRef<HTMLFormElement>(null);
  const [fieldTip, setFieldTip] = useState<{ name: string; message: string } | null>(null);
  const googleError = params.get('google_error');
  const googleErrorMessage: Record<string, string> = {
    cancelled: 'ورود با گوگل لغو شد.',
    state: 'درخواست گوگل معتبر نیست. دوباره تلاش کنید.',
    config: 'تنظیمات ورود با گوگل کامل نیست.',
    failed: 'ورود با گوگل انجام نشد. دوباره تلاش کنید.',
    missing_code: 'پاسخ گوگل ناقص بود.',
    email_not_verified: 'ایمیل گوگل تایید نشده است.',
    banned: 'حساب شما مسدود شده است.',
    deleted: 'این حساب حذف شده است.'
  };

  function showFieldTip(name: string, message: string) {
    setFieldTip({ name, message });
    window.setTimeout(() => setFieldTip((current) => current?.name === name ? null : current), 2600);
  }

  function validateForm(form: HTMLFormElement) {
    const fields = Array.from(form.elements).filter((item): item is HTMLInputElement => item instanceof HTMLInputElement && Boolean(item.name));
    for (const field of fields) {
      if (field.name === 'name' && field.value.trim().length < 3) {
        field.focus(); showFieldTip(field.name, 'نام را کامل وارد کنید.'); return false;
      }
      if (field.name === 'email') {
        if (!field.value.trim()) { field.focus(); showFieldTip(field.name, 'ایمیل را وارد کنید.'); return false; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value.trim())) { field.focus(); showFieldTip(field.name, 'ایمیل معتبر نیست.'); return false; }
      }
      if (field.name === 'password') {
        const min = mode === 'register' ? 8 : 1;
        if (!field.value || field.value.length < min) { field.focus(); showFieldTip(field.name, mode === 'register' ? 'رمز عبور حداقل ۸ کاراکتر باشد.' : 'رمز عبور را وارد کنید.'); return false; }
      }
    }
    return true;
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!validateForm(event.currentTarget)) return;
    setLoading(true);
    setError('');
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());
    const res = await fetch(`/api/auth/${mode === 'login' ? 'login' : 'register'}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    });
    const json = await res.json();
    setLoading(false);
    if (!res.ok || !json.ok) return setError(json?.error?.message ?? 'خطایی رخ داد.');
    router.push(params.get('next') || '/dashboard');
    router.refresh();
  }

  const tip = (name: string) => fieldTip?.name === name ? <div className="field-popover" role="alert"><span>!</span>{fieldTip.message}</div> : null;

  return (
    <form ref={formRef} className="grid gap-4" onSubmit={submit} noValidate>
      {mode === 'register' ? (
        <div className="grid gap-2">
          <Label htmlFor="name">نام و نام خانوادگی</Label>
          <div className="relative"><UserRound className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" /><Input id="name" name="name" minLength={3} className="pr-10" placeholder="مثلاً علی رضایی" />{tip('name')}</div>
        </div>
      ) : null}
      <div className="grid gap-2">
        <Label htmlFor="email">ایمیل</Label>
        <div className="relative"><Mail className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" /><Input id="email" name="email" type="email" className="pr-10 text-left dir-ltr" placeholder="you@example.com" dir="ltr" />{tip('email')}</div>
      </div>
      <div className="grid gap-2">
        <Label htmlFor="password">رمز عبور</Label>
        <div className="relative"><LockKeyhole className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" /><Input id="password" name="password" type="password" minLength={mode === 'register' ? 8 : 1} className="pr-10 text-left dir-ltr" placeholder="••••••••" dir="ltr" />{tip('password')}</div>
      </div>
      {(error || googleError) ? <div className="alert error">{error || googleErrorMessage[googleError || ''] || 'ورود با گوگل انجام نشد.'}</div> : null}
      <Button size="lg" disabled={loading}>{loading ? 'در حال پردازش...' : mode === 'login' ? 'ورود به پنل' : 'ساخت حساب'} <ArrowLeft size={17} /></Button>
      <div className="flex items-center gap-3"><span className="h-px flex-1 bg-slate-200"/><span className="text-xs font-bold text-slate-400">یا</span><span className="h-px flex-1 bg-slate-200"/></div>
      <GoogleAuthButton mode={mode} />
      <p className="text-center text-sm font-bold text-slate-500">
        {mode === 'login' ? 'حساب ندارید؟ ' : 'قبلاً ثبت‌نام کرده‌اید؟ '}
        <Link className="text-sky-700" href={mode === 'login' ? '/auth/register' : '/auth/login'}>{mode === 'login' ? 'ثبت‌نام کنید' : 'وارد شوید'}</Link>
      </p>
    </form>
  );
}
