'use client';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { ArrowLeft, Wallet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { formatPrice } from '@/lib/products';

const presetsBase = [50000, 100000, 250000, 500000, 1000000, 2000000];
export function WalletTopupForm({ minAmount = 50000, maxAmount = 10000000, isAdmin = false }: { minAmount?: number; maxAmount?: number; isAdmin?: boolean }) {
  const router = useRouter();
  const presets = isAdmin ? [1000, 10000, ...presetsBase] : presetsBase;
  const [amount, setAmount] = useState(minAmount);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError('');
    const res = await fetch('/api/wallet/topup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ amount }) });
    const json = await res.json(); setLoading(false);
    if (!res.ok || !json.ok) return setError(json?.error?.message ?? 'ایجاد پرداخت انجام نشد.');
    router.push(json.data.payUrl);
  }
  return <form onSubmit={submit} className="grid gap-4"><div><h2 className="flex items-center gap-2 text-xl font-black text-slate-950"><Wallet size={22}/> افزایش موجودی</h2><p className="mt-2 text-sm leading-7 text-slate-500">مبلغ را وارد کنید و روش پرداخت را در صفحه بعد انتخاب کنید.</p></div><div className="flex flex-wrap gap-2">{presets.map(p=><button type="button" key={p} onClick={()=>setAmount(p)} className={`rounded-xl border px-3 py-2 text-sm font-bold ${amount===p?'border-slate-950 bg-slate-950 text-white':'border-slate-200 bg-white text-slate-700'}`}>{formatPrice(p)}</button>)}</div><div className="grid gap-2"><Label>مبلغ دلخواه</Label><Input type="number" min={minAmount} max={maxAmount} value={amount} onChange={e=>setAmount(Number(e.target.value))}/><span className="text-xs font-bold text-slate-400">حداقل {formatPrice(minAmount)} و حداکثر {formatPrice(maxAmount)} برای هر بار افزایش موجودی{isAdmin ? ' (حساب ادمین)' : ''}</span></div><div className="rounded-2xl bg-slate-50 p-4 text-sm"><span className="text-slate-500">مبلغ انتخابی:</span> <strong>{formatPrice(amount || 0)}</strong></div>{error?<div className="alert error">{error}</div>:null}<Button disabled={loading}>{loading?'در حال ساخت پرداخت...':'ادامه پرداخت'} <ArrowLeft size={16}/></Button></form>
}
