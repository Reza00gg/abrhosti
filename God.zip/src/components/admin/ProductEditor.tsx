'use client';

import { useRouter } from 'next/navigation';
import { useMemo, useState } from 'react';
import { Save, Trash2, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const categories = [
  { value: 'shared', label: 'هاست اشتراکی', route: '/hosting/shared' },
  { value: 'cloud', label: 'هاست ابری', route: '/hosting/cloud' },
  { value: 'dedicated', label: 'سرور اختصاصی', route: '/hosting/dedicated' },
  { value: 'vps', label: 'سرور مجازی', route: '/vps' },
  { value: 'domain', label: 'دامنه', route: '/domains' }
];
const countries = [
  { value: '', label: 'بدون کشور' },
  { value: 'de', label: 'آلمان' },
  { value: 'us', label: 'آمریکا' },
  { value: 'fr', label: 'فرانسه' },
  { value: 'uk', label: 'انگلیس' },
  { value: 'nl', label: 'هلند' },
  { value: 'ca', label: 'کانادا' }
];

function makeId(category: string, title: string, country?: string) {
  const clean = title.trim().toLowerCase().replace(/[^a-z0-9آ-ی]+/g, '-').replace(/^-|-$/g, '').slice(0, 24) || Date.now().toString();
  return `${category}${country ? `-${country}` : ''}-${clean}`;
}
function routeFor(category: string, country?: string) {
  if (category === 'vps') return country ? `/vps/${country}` : '/vps';
  return categories.find((c) => c.value === category)?.route ?? '/hosting/cloud';
}

export function ProductEditor({ product }: { product?: any }) {
  const router = useRouter();
  const [p, setP] = useState(product ?? { id: '', category: 'cloud', country: '', title: '', subtitle: '', priceMonthly: 0, currency: 'تومان', badge: 'جدید', cpu: '', ram: '', storage: '', bandwidth: '', features: '', route: '/hosting/cloud', active: true });
  const [advanced, setAdvanced] = useState(Boolean(product));
  const [message, setMessage] = useState('');
  const isVps = p.category === 'vps';
  const suggestedRoute = useMemo(() => routeFor(p.category, p.country), [p.category, p.country]);

  function update(next: any) {
    const merged = { ...p, ...next };
    if (!product && !merged.id) merged.id = makeId(merged.category, merged.title, merged.country);
    if (!advanced) merged.route = routeFor(merged.category, merged.country);
    setP(merged);
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setMessage('');
    const payload = { ...p, route: p.route || suggestedRoute, id: p.id || makeId(p.category, p.title, p.country) };
    const url = product ? `/api/admin/products/${product.id}` : '/api/admin/products';
    const method = product ? 'PATCH' : 'POST';
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    setMessage(res.ok ? 'ذخیره شد.' : 'ذخیره انجام نشد.');
    router.refresh();
  }
  async function disable() {
    if (!product || !confirm('محصول غیرفعال شود؟')) return;
    await fetch(`/api/admin/products/${product.id}`, { method: 'DELETE' });
    router.refresh();
  }
  async function hardDelete() {
    if (!product || !confirm('محصول برای همیشه حذف شود؟')) return;
    await fetch(`/api/admin/products/${product.id}?hard=1`, { method: 'DELETE' });
    router.refresh();
  }

  return (
    <form onSubmit={save} className="grid gap-4 rounded-2xl border border-slate-200 bg-white p-4">
      <div className="grid gap-3 md:grid-cols-3">
        <div className="grid gap-2 md:col-span-2"><Label>نام محصول</Label><Input placeholder="مثلاً VPS آلمان ۸ گیگ" value={p.title} onChange={(e) => update({ title: e.target.value })} required /></div>
        <div className="grid gap-2"><Label>قیمت</Label><Input placeholder="690000" type="number" value={p.priceMonthly} onChange={(e) => update({ priceMonthly: e.target.value })} required /></div>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        <div className="grid gap-2"><Label>دسته‌بندی</Label><select className="select" value={p.category} onChange={(e) => update({ category: e.target.value, country: e.target.value === 'vps' ? p.country : '' })}>{categories.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}</select></div>
        {isVps ? <div className="grid gap-2"><Label>کشور VPS</Label><select className="select" value={p.country ?? ''} onChange={(e) => update({ country: e.target.value })}>{countries.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}</select></div> : null}
        <div className="grid gap-2"><Label>برچسب</Label><Input placeholder="پرفروش" value={p.badge} onChange={(e) => update({ badge: e.target.value })} /></div>
      </div>
      <div className="grid gap-2"><Label>توضیح کوتاه</Label><Input placeholder="توضیح خیلی کوتاه برای کارت محصول" value={p.subtitle} onChange={(e) => update({ subtitle: e.target.value })} /></div>
      <div className="grid gap-3 md:grid-cols-4">
        <Input placeholder="CPU" value={p.cpu} onChange={(e) => update({ cpu: e.target.value })} />
        <Input placeholder="RAM" value={p.ram} onChange={(e) => update({ ram: e.target.value })} />
        <Input placeholder="Storage" value={p.storage} onChange={(e) => update({ storage: e.target.value })} />
        <Input placeholder="Traffic" value={p.bandwidth} onChange={(e) => update({ bandwidth: e.target.value })} />
      </div>
      <textarea className="textarea min-h-24" placeholder="ویژگی‌ها؛ هر خط یک ویژگی" value={p.features} onChange={(e) => update({ features: e.target.value })} />
      <button type="button" onClick={() => setAdvanced(!advanced)} className="w-fit text-sm font-bold text-slate-500">{advanced ? 'پنهان کردن تنظیمات پیشرفته' : 'تنظیمات پیشرفته'}</button>
      {advanced ? <div className="grid gap-3 rounded-2xl bg-slate-50 p-3 md:grid-cols-3"><Input placeholder="id" disabled={!!product} value={p.id} onChange={(e) => update({ id: e.target.value })} /><Input placeholder="currency" value={p.currency} onChange={(e) => update({ currency: e.target.value })} /><Input placeholder="route" value={p.route || suggestedRoute} onChange={(e) => update({ route: e.target.value })} /></div> : null}
      <label className="flex gap-2 text-sm font-bold"><input type="checkbox" checked={p.active} onChange={(e) => update({ active: e.target.checked })} /> فعال</label>
      {message ? <div className="alert success">{message}</div> : null}
      <div className="flex flex-wrap gap-2"><Button size="sm"><Save size={14}/> ذخیره</Button>{product ? <><Button type="button" size="sm" variant="secondary" onClick={disable}><EyeOff size={14}/> غیرفعال</Button><Button type="button" size="sm" variant="destructive" onClick={hardDelete}><Trash2 size={14}/> حذف کامل</Button></> : null}</div>
    </form>
  );
}
