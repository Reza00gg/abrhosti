'use client';
import { useState } from 'react';
import { Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function EmailSettingsForm({ initial }: { initial: any }) {
  const [form, setForm] = useState({
    enabled: Boolean(initial?.enabled),
    apiKey: '',
    apiKeyMasked: initial?.apiKeyMasked ?? '',
    fromEmail: initial?.fromEmail ?? 'no-reply@lnupro.sbs',
    fromName: initial?.fromName ?? 'ابرهاست',
    expiresMinutes: initial?.expiresMinutes ?? 10
  });
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  async function save(e: React.FormEvent) {
    e.preventDefault(); setMsg(''); setErr('');
    const res = await fetch('/api/admin/settings/email', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const json = await res.json();
    if (!res.ok || !json.ok) return setErr(json?.error?.message ?? 'ذخیره انجام نشد.');
    setMsg('تنظیمات تایید ایمیل ذخیره شد.');
    setForm((f) => ({ ...f, apiKey: '', apiKeyMasked: f.apiKey ? `${f.apiKey.slice(0, 3)}••••${f.apiKey.slice(-3)}` : f.apiKeyMasked }));
  }
  return <form onSubmit={save} className="grid gap-4"><label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={form.enabled} onChange={e=>setForm({...form,enabled:e.target.checked})}/> تایید ایمیل فعال باشد</label><div className="grid gap-2"><Label>Resend API Key {form.apiKeyMasked ? `(فعلی: ${form.apiKeyMasked})` : ''}</Label><Input className="dir-ltr text-left" dir="ltr" value={form.apiKey} onChange={e=>setForm({...form,apiKey:e.target.value})} placeholder="re_..." /></div><div className="grid gap-3 md:grid-cols-2"><div className="grid gap-2"><Label>ایمیل فرستنده</Label><Input className="dir-ltr text-left" dir="ltr" value={form.fromEmail} onChange={e=>setForm({...form,fromEmail:e.target.value})}/></div><div className="grid gap-2"><Label>نام فرستنده</Label><Input value={form.fromName} onChange={e=>setForm({...form,fromName:e.target.value})}/></div></div><div className="grid gap-2"><Label>اعتبار کد - دقیقه</Label><Input type="number" min={5} max={30} value={form.expiresMinutes} onChange={e=>setForm({...form,expiresMinutes:Number(e.target.value)})}/></div><div className="rounded-2xl bg-slate-50 p-3 text-xs leading-6 text-slate-500">ایمیل شامل کد ۶ رقمی و لینک تایید یک‌بارمصرف است. کاربران گوگل نیاز به تایید دوباره ندارند.</div>{err?<div className="alert error">{err}</div>:null}{msg?<div className="alert success">{msg}</div>:null}<Button><Save size={16}/> ذخیره تنظیمات ایمیل</Button></form>
}
