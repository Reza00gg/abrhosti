'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Ban, CheckCircle2, ChevronLeft, ChevronRight, Eye, EyeOff, Info, MoreVertical, RotateCcw, Search, Shield, Trash2, UserCheck, Wallet } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatPrice } from '@/lib/products';
import { formatTehranDateTime } from '@/lib/date';

type UserRow = {
  id: string;
  name: string;
  email: string;
  role: string;
  created_at: string;
  banned_at: string | null;
  deleted_at: string | null;
  password_hash: string;
  orders: string;
  balance: number;
  currency: string;
  last_login: string | null;
  phone: string | null;
  phone_verified_at: string | null;
  email_verified_at: string | null;
};

type Filter = 'all' | 'active' | 'inactive' | 'banned' | 'deleted';
const PAGE_SIZE = 10;

function isInactive(user: UserRow) {
  if (user.banned_at || user.deleted_at) return false;
  if (!user.last_login) return true;
  return Date.now() - new Date(user.last_login).getTime() > 1000 * 60 * 60 * 24 * 30;
}
function isActive(user: UserRow) {
  return !user.banned_at && !user.deleted_at && !isInactive(user);
}
function formatDate(value?: string | null) {
  return value ? formatTehranDateTime(value) : '—';
}
function statusBadge(user: UserRow) {
  const cls = 'rounded-md px-2 py-1 text-[11px]';
  if (user.deleted_at) return <Badge variant="secondary" className={cls}>حذف شده</Badge>;
  if (user.banned_at) return <Badge variant="warning" className={cls}>بن شده</Badge>;
  if (isInactive(user)) return <Badge variant="secondary" className={cls}>غیرفعال</Badge>;
  return <Badge variant="success" className={cls}><CheckCircle2 size={12} className="ml-1" /> فعال</Badge>;
}

function UserInfoModal({ user, onClose }: { user: UserRow; onClose: () => void }) {
  const [showHash, setShowHash] = useState(false);
  return createPortal(
    <div className="fixed inset-0 z-[10000] grid place-items-center bg-slate-950/45 p-4 drawer-backdrop-in">
      <div className="w-full max-w-lg rounded-3xl bg-white p-5 shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-xl font-black text-slate-950">اطلاعات کاربر</h3>
            <p className="mt-1 text-sm text-slate-500">جزئیات حساب و وضعیت کاربر</p>
          </div>
          <button onClick={onClose} className="rounded-xl bg-slate-100 px-3 py-2 text-sm font-bold">بستن</button>
        </div>
        <div className="mt-5 grid gap-3 text-sm">
          <div className="flex justify-between gap-4 rounded-2xl bg-slate-50 p-3"><span className="text-slate-500">نام</span><strong>{user.name}</strong></div>
          <div className="flex justify-between gap-4 rounded-2xl bg-slate-50 p-3"><span className="text-slate-500">ایمیل</span><strong className="max-w-[260px] truncate dir-ltr">{user.email}</strong></div>
          <div className="rounded-2xl bg-slate-50 p-3">
            <div className="mb-2 flex items-center justify-between"><span className="text-slate-500">رمز عبور</span><button onClick={() => setShowHash(!showHash)} className="flex items-center gap-1 text-xs font-black text-slate-700">{showHash ? <EyeOff size={14} /> : <Eye size={14} />} {showHash ? 'مخفی' : 'نمایش'}</button></div>
            <p className={`break-all rounded-xl bg-white p-3 text-left text-xs dir-ltr ${showHash ? 'text-slate-700 blur-0' : 'select-none text-slate-400 blur-[3px]'}`}>{user.password_hash}</p>
            <p className="mt-2 text-xs leading-6 text-slate-400">پسورد خام ذخیره نمی‌شود؛ فقط هش امن رمز قابل مشاهده است.</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl bg-slate-50 p-3"><span className="block text-slate-500">تاریخ عضویت</span><strong className="mt-1 block">{formatDate(user.created_at)}</strong></div>
            <div className="rounded-2xl bg-slate-50 p-3"><span className="block text-slate-500">آخرین لاگین</span><strong className="mt-1 block">{formatDate(user.last_login)}</strong></div>
            <div className="rounded-2xl bg-slate-50 p-3"><span className="block text-slate-500">موجودی</span><strong className="mt-1 block">{formatPrice(Number(user.balance ?? 0), user.currency ?? 'تومان')}</strong></div>
            <div className="rounded-2xl bg-slate-50 p-3"><span className="block text-slate-500">سفارش‌ها</span><strong className="mt-1 block">{Number(user.orders).toLocaleString('fa-IR')}</strong></div>
            <div className="rounded-2xl bg-slate-50 p-3"><span className="block text-slate-500">تایید ایمیل</span><strong className="mt-1 block">{user.email_verified_at ? 'تایید شده' : 'تایید نشده'}</strong></div><div className="rounded-2xl bg-slate-50 p-3"><span className="block text-slate-500">موبایل</span><strong className="mt-1 block dir-ltr">{user.phone ?? '—'}</strong></div>
            <div className="rounded-2xl bg-slate-50 p-3"><span className="block text-slate-500">تایید موبایل</span><strong className="mt-1 block">{user.phone_verified_at ? 'تایید شده' : 'تایید نشده'}</strong></div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}

function WalletAdjustModal({ user, onClose }: { user: UserRow; onClose: () => void }) {
  const router = useRouter();
  const [operation, setOperation] = useState<'credit' | 'debit'>('credit');
  const [amount, setAmount] = useState(100000);
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const current = Number(user.balance ?? 0);
  const delta = Number.isFinite(amount) ? amount : 0;
  const nextBalance = operation === 'credit' ? current + delta : current - delta;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError('');
    const res = await fetch(`/api/admin/users/${user.id}/wallet-adjust`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ operation, amount, note })
    });
    const json = await res.json();
    setLoading(false);
    if (!res.ok || !json.ok) return setError(json?.error?.message ?? 'تغییر موجودی انجام نشد.');
    onClose();
    router.refresh();
  }

  return createPortal(
    <div className="fixed inset-0 z-[10000] grid place-items-center bg-slate-950/45 p-4 drawer-backdrop-in">
      <form onSubmit={submit} className="w-full max-w-md rounded-3xl bg-white p-5 shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-xl font-black text-slate-950">افزایش / کاهش موجودی</h3>
            <p className="mt-1 truncate text-sm text-slate-500 dir-ltr">{user.email}</p>
          </div>
          <button type="button" onClick={onClose} className="rounded-xl bg-slate-100 px-3 py-2 text-sm font-bold">بستن</button>
        </div>

        <div className="mt-5 grid gap-4">
          <div className="grid grid-cols-2 gap-2 rounded-2xl bg-slate-100 p-1">
            <button type="button" onClick={() => setOperation('credit')} className={`rounded-xl px-3 py-2 text-sm font-black ${operation === 'credit' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-500'}`}>افزایش</button>
            <button type="button" onClick={() => setOperation('debit')} className={`rounded-xl px-3 py-2 text-sm font-black ${operation === 'debit' ? 'bg-white text-red-600 shadow-sm' : 'text-slate-500'}`}>کاهش</button>
          </div>

          <div className="grid gap-2 rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm">
            <div className="flex justify-between gap-3"><span className="text-slate-500">موجودی فعلی</span><strong>{formatPrice(current, user.currency ?? 'تومان')}</strong></div>
            <div className="flex justify-between gap-3"><span className="text-slate-500">موجودی جدید</span><strong className={nextBalance < 0 ? 'text-red-600' : 'text-slate-950'}>{formatPrice(nextBalance, user.currency ?? 'تومان')}</strong></div>
          </div>

          <label className="grid gap-2 text-sm font-bold text-slate-700">
            مبلغ
            <input className="input" type="number" min={1} value={amount} onChange={(e) => setAmount(Number(e.target.value))} placeholder="مثلاً 100000" />
          </label>
          <label className="grid gap-2 text-sm font-bold text-slate-700">
            توضیح اختیاری
            <textarea className="textarea min-h-20" value={note} onChange={(e) => setNote(e.target.value)} placeholder="مثلاً اصلاح دستی موجودی" />
          </label>
          {error ? <div className="alert error">{error}</div> : null}
          <div className="flex gap-2">
            <Button disabled={loading} className="flex-1">{loading ? 'در حال اعمال...' : 'تایید و اعمال'}</Button>
            <Button type="button" variant="secondary" onClick={onClose}>انصراف</Button>
          </div>
          {operation === 'credit' ? <p className="text-xs leading-6 text-slate-400">برای افزایش موجودی، اعلان برای کاربر ارسال می‌شود.</p> : <p className="text-xs leading-6 text-slate-400">برای کاهش موجودی، اعلان ارسال نمی‌شود و موجودی می‌تواند منفی شود.</p>}
        </div>
      </form>
    </div>,
    document.body
  );
}


function ActionsMenu({ user, open, onOpen, onClose, onInfo, onWallet }: { user: UserRow; open: boolean; onOpen: () => void; onClose: () => void; onInfo: () => void; onWallet: () => void }) {
  const router = useRouter();
  const buttonRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);
  const [pos, setPos] = useState({ top: 0, left: 0 });

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open) return;
    const update = () => {
      const rect = buttonRef.current?.getBoundingClientRect();
      if (!rect) return;
      const width = 190;
      const height = user.deleted_at ? 120 : 210;
      const left = Math.max(8, Math.min(window.innerWidth - width - 8, rect.left + rect.width - width));
      const preferTop = rect.bottom + 8;
      const top = preferTop + height > window.innerHeight ? Math.max(8, rect.top - height - 8) : preferTop;
      setPos({ top, left });
    };
    update();
    window.addEventListener('resize', update);
    window.addEventListener('scroll', update, true);
    return () => {
      window.removeEventListener('resize', update);
      window.removeEventListener('scroll', update, true);
    };
  }, [open, user.deleted_at]);

  useEffect(() => {
    if (!open) return;
    function onDown(e: MouseEvent) {
      const target = e.target as Node;
      if (buttonRef.current?.contains(target) || menuRef.current?.contains(target)) return;
      onClose();
    }
    document.addEventListener('pointerdown', onDown);
    return () => document.removeEventListener('pointerdown', onDown);
  }, [open, onClose]);

  async function call(url: string, method = 'POST', body?: any) {
    await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    onClose();
    router.refresh();
  }

  const menu = open && mounted ? createPortal(
    <div ref={menuRef} style={{ top: pos.top, left: pos.left, width: 190 }} className="fixed z-[9999] rounded-2xl border border-slate-200 bg-white p-2 shadow-[0_18px_60px_rgba(15,23,42,.18)] submenu-open">
      <button onClick={() => { onClose(); onInfo(); }} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm font-bold text-slate-700 hover:bg-slate-50"><Info size={15} /> اطلاعات</button>
      {!user.deleted_at ? <button onClick={() => { onClose(); onWallet(); }} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm font-bold text-sky-700 hover:bg-sky-50"><Wallet size={15} /> افزایش/کاهش موجودی</button> : null}
      {user.deleted_at ? <button onClick={() => call(`/api/admin/users/${user.id}/restore`)} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm font-bold text-emerald-700 hover:bg-emerald-50"><RotateCcw size={15} /> بازیابی</button> : null}
      {user.deleted_at ? <button onClick={() => confirm('این کاربر برای همیشه از دیتابیس حذف شود؟ این عملیات قابل بازگشت نیست.') && call(`/api/admin/users/${user.id}/delete?hard=1`, 'DELETE')} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm font-bold text-red-700 hover:bg-red-50"><Trash2 size={15} /> حذف کامل</button> : null}
      {!user.deleted_at && (user.banned_at ? <button onClick={() => call(`/api/admin/users/${user.id}/unban`)} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm font-bold text-emerald-700 hover:bg-emerald-50"><UserCheck size={15} /> آن‌بن</button> : <button onClick={() => call(`/api/admin/users/${user.id}/ban`, 'POST', { reason: 'مسدود شده توسط مدیر' })} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm font-bold text-amber-700 hover:bg-amber-50"><Ban size={15} /> بن</button>)}
      {!user.deleted_at ? <button onClick={() => call(`/api/admin/users/${user.id}/role`, 'POST', { role: user.role === 'admin' ? 'user' : 'admin' })} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm font-bold text-slate-700 hover:bg-slate-50"><Shield size={15} /> {user.role === 'admin' ? 'کاربر شود' : 'ادمین شود'}</button> : null}
      {!user.deleted_at ? <button onClick={() => confirm('کاربر حذف شود؟') && call(`/api/admin/users/${user.id}/delete`, 'DELETE')} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm font-bold text-red-600 hover:bg-red-50"><Trash2 size={15} /> حذف</button> : null}
    </div>,
    document.body
  ) : null;

  return (
    <>
      <button ref={buttonRef} onClick={() => (open ? onClose() : onOpen())} className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 hover:bg-slate-50">
        <MoreVertical size={18} />
      </button>
      {menu}
    </>
  );
}

export function UserDirectory({ users }: { users: UserRow[] }) {
  const [filter, setFilter] = useState<Filter>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selected, setSelected] = useState<UserRow | null>(null);
  const [walletUser, setWalletUser] = useState<UserRow | null>(null);
  const [openActionKey, setOpenActionKey] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const counts = {
    all: users.length,
    active: users.filter(isActive).length,
    inactive: users.filter(isInactive).length,
    banned: users.filter((u) => u.banned_at).length,
    deleted: users.filter((u) => u.deleted_at).length
  };
  const byFilter = users.filter((u) => filter === 'all' ? true : filter === 'active' ? isActive(u) : filter === 'inactive' ? isInactive(u) : filter === 'banned' ? Boolean(u.banned_at) : Boolean(u.deleted_at));
  const normalizedSearch = searchTerm.trim().toLowerCase();
  const filtered = byFilter.filter((u) => !normalizedSearch || u.email.toLowerCase().includes(normalizedSearch) || u.name.toLowerCase().includes(normalizedSearch));
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const visible = useMemo(() => filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE), [filtered, page]);
  const visibleRows = visible;
  const tabs: [Filter, string][] = [['all', 'کل کاربران'], ['active', 'فعال'], ['inactive', 'غیرفعال'], ['banned', 'بن شده'], ['deleted', 'حذف شده']];

  function changeFilter(next: Filter) {
    setFilter(next);
    setPage(1);
    setOpenActionKey(null);
  }
  function pagePrev() { setOpenActionKey(null); setPage((p) => Math.max(1, p - 1)); }
  function pageNext() { setOpenActionKey(null); setPage((p) => Math.min(totalPages, p + 1)); }

  return (
    <div className="grid gap-4">
      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white p-1 shadow-sm">
        <div className="flex min-w-max gap-2">
          {tabs.map(([key, label]) => <button key={key} onClick={() => changeFilter(key)} className={`rounded-xl px-3 py-2 text-sm font-black transition ${filter === key ? 'bg-slate-950 text-white' : 'text-slate-600 hover:bg-slate-50'}`}>{label} <span className="mr-1 text-xs opacity-70">{counts[key]}</span></button>)}
        </div>
      </div>

      <div className="relative rounded-2xl border border-slate-200 bg-white p-2 shadow-sm">
        <Search className="pointer-events-none absolute right-5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
        <input
          value={searchTerm}
          onChange={(e) => { setSearchTerm(e.target.value); setPage(1); setOpenActionKey(null); }}
          placeholder="جستجو با نام یا ایمیل کاربر..."
          className="h-11 w-full rounded-xl border-0 bg-slate-50 pr-11 text-sm font-bold text-slate-700 outline-none placeholder:text-slate-400 focus:bg-white focus:ring-2 focus:ring-slate-200"
        />
      </div>

      {/* Desktop table */}
      <div className="hidden rounded-3xl border border-slate-200 bg-white shadow-sm md:block">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[850px] border-collapse">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50 text-right text-xs font-black text-slate-500">
                <th className="px-4 py-3">نام</th><th className="px-4 py-3">ایمیل</th><th className="px-4 py-3">نقش</th><th className="px-4 py-3">وضعیت</th><th className="px-4 py-3">موجودی</th><th className="px-4 py-3">عضویت</th><th className="px-4 py-3 text-center">عملیات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {visibleRows.map((u) => (
                <tr key={u.id} className="text-sm transition hover:bg-slate-50/70">
                  <td className="px-4 py-3"><strong className="text-slate-950">{u.name}</strong></td>
                  <td className="px-4 py-3"><span className="block max-w-[260px] truncate font-bold text-slate-600 dir-ltr">{u.email}</span></td>
                  <td className="px-4 py-3"><Badge variant={u.role === 'admin' ? 'success' : 'secondary'} className="rounded-md px-2 py-1 text-[11px]">{u.role === 'admin' ? 'ادمین' : 'کاربر'}</Badge></td>
                  <td className="px-4 py-3">{statusBadge(u)}</td>
                  <td className="px-4 py-3 font-black text-slate-800">{formatPrice(Number(u.balance ?? 0), u.currency ?? 'تومان')}</td>
                  <td className="px-4 py-3 text-xs font-bold text-slate-500">{formatDate(u.created_at)}</td>
                  <td className="px-4 py-3 text-center"><ActionsMenu user={u} open={openActionKey === `desktop-${u.id}`} onOpen={() => setOpenActionKey(`desktop-${u.id}`)} onClose={() => setOpenActionKey(null)} onInfo={() => setSelected(u)} onWallet={() => setWalletUser(u)} /></td>
                </tr>
              ))}
              {!visible.length ? <tr><td colSpan={7} className="p-8 text-center text-sm font-bold text-slate-500">کاربری در این بخش وجود ندارد.</td></tr> : null}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile list */}
      <div className="grid gap-2 md:hidden">
        {visibleRows.map((u) => (
          <div key={u.id} className="rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <strong className="block truncate text-sm text-slate-950">{u.name}</strong>
                <span className="mt-1 block truncate text-xs font-bold text-slate-500 dir-ltr">{u.email}</span>
              </div>
              <ActionsMenu user={u} open={openActionKey === `mobile-${u.id}`} onOpen={() => setOpenActionKey(`mobile-${u.id}`)} onClose={() => setOpenActionKey(null)} onInfo={() => setSelected(u)} onWallet={() => setWalletUser(u)} />
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-xl bg-slate-50 p-2"><span className="block text-[10px] font-bold text-slate-400">نقش</span><div className="mt-1"><Badge variant={u.role === 'admin' ? 'success' : 'secondary'} className="rounded-md px-2 py-1 text-[10px]">{u.role === 'admin' ? 'ادمین' : 'کاربر'}</Badge></div></div>
              <div className="rounded-xl bg-slate-50 p-2"><span className="block text-[10px] font-bold text-slate-400">وضعیت</span><div className="mt-1">{statusBadge(u)}</div></div>
              <div className="rounded-xl bg-slate-50 p-2"><span className="block text-[10px] font-bold text-slate-400">موجودی</span><strong className="mt-1 block text-xs text-slate-900">{formatPrice(Number(u.balance ?? 0), u.currency ?? 'تومان')}</strong></div>
            </div>
            <div className="mt-2 text-xs font-bold text-slate-400">عضویت: {formatDate(u.created_at)}</div>
          </div>
        ))}
        {!visible.length ? <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center text-sm font-bold text-slate-500">کاربری در این بخش وجود ندارد.</div> : null}
      </div>

      <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-3 text-sm font-bold text-slate-600 shadow-sm sm:flex-row sm:items-center sm:justify-between">
        <span>صفحه {page.toLocaleString('fa-IR')} از {totalPages.toLocaleString('fa-IR')} • {filtered.length.toLocaleString('fa-IR')} کاربر</span>
        <div className="flex gap-2">
          <Button size="sm" variant="secondary" onClick={pagePrev} disabled={page <= 1}><ChevronRight size={15} /> قبلی</Button>
          <Button size="sm" variant="secondary" onClick={pageNext} disabled={page >= totalPages}>بعدی <ChevronLeft size={15} /></Button>
        </div>
      </div>

      {selected && mounted ? <UserInfoModal user={selected} onClose={() => setSelected(null)} /> : null}
      {walletUser && mounted ? <WalletAdjustModal user={walletUser} onClose={() => setWalletUser(null)} /> : null}
    </div>
  );
}
