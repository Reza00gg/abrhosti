'use client';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Check, X } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
export function AdminPaymentActions({ receiptId }: { receiptId: string }) { const router=useRouter(); const [loading,setLoading]=useState(''); async function act(kind:'approve'|'reject'){setLoading(kind); const res = await fetch(`/api/admin/payments/${receiptId}/${kind}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({note:'رد شده توسط مدیر'})}); setLoading(''); if(res.ok){toast.success(kind==='approve'?'پرداخت تایید شد':'پرداخت رد شد');} else {toast.error('عملیات انجام نشد');} router.refresh();} return <div className="flex gap-2"><Button size="sm" onClick={()=>act('approve')} disabled={!!loading}><Check size={14}/> تایید</Button><Button size="sm" variant="destructive" onClick={()=>act('reject')} disabled={!!loading}><X size={14}/> رد</Button></div> }
