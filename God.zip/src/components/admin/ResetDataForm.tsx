'use client';
import { useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
export function ResetDataForm() {
  const [confirm, setConfirm] = useState('');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  async function reset(e: React.FormEvent) {
    e.preventDefault();
    if (!window.confirm('همه کاربران، سفارش‌ها، فیش‌ها و محصولات ریست شوند؟')) return;
    setMsg(''); setErr('');
    const res = await fetch('/api/admin/settings/reset-data', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ confirm }) });
    const json = await res.json();
    if (!res.ok || !json.ok) return setErr(json?.error?.message ?? 'ریست انجام نشد.');
    setMsg('اطلاعات سایت ریست شد. ادمین فعلی باقی ماند و محصولات اولیه بازسازی شدند.'); setConfirm('');
  }
  return <form onSubmit={reset} className="grid gap-3"><p className="text-sm leading-7 text-slate-500">همه سفارش‌ها، فیش‌ها، کاربران عادی و محصولات حذف می‌شوند؛ سپس محصولات اولیه دوباره ساخته می‌شوند. فقط ادمین فعلی باقی می‌ماند.</p><div className="grid gap-2"><Label>برای تایید بنویسید RESET</Label><Input className="dir-ltr text-left" dir="ltr" value={confirm} onChange={e=>setConfirm(e.target.value)} /></div>{err?<div className="alert error">{err}</div>:null}{msg?<div className="alert success">{msg}</div>:null}<Button variant="destructive"><RotateCcw size={16}/> ریست اطلاعات سایت</Button></form>
}
