'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';
import { BarChart3, Boxes, CreditCard, Home, LifeBuoy, Menu, Settings, Users, X } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AdminLogoutButton } from '@/components/admin/AdminLogoutButton';

type Admin = { name: string; email: string };
const nav = [
  ['/adminChash7nakg/dashboard', 'داشبورد', Home],
  ['/adminChash7nakg/payments', 'واریزی‌ها', CreditCard],
  ['/adminChash7nakg/orders', 'سفارش‌ها', BarChart3],
  ['/adminChash7nakg/users', 'کاربران', Users],
  ['/adminChash7nakg/products', 'محصولات', Boxes],
  ['/adminChash7nakg/settings', 'تنظیمات', Settings]
] as const;
const ticketNav = ['/adminChash7nakg/tickets', 'تیکت‌ها', LifeBuoy] as const;
function NavList({ close, ticketsEnabled }: { close?: () => void; ticketsEnabled?: boolean }) {
  const pathname = usePathname();
  const items = ticketsEnabled ? [...nav.slice(0, 3), ticketNav, ...nav.slice(3)] : nav;
  return <nav className="grid gap-1 p-3">{items.map(([href,label,Icon])=><Link onClick={close} key={href} href={href} className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-extrabold transition ${pathname===href?'bg-sky-50 text-sky-700':'text-slate-600 hover:bg-sky-50 hover:text-sky-700'}`}><Icon size={18}/>{label}</Link>)}</nav>;
}
export function AdminShellClient({ admin, children, ticketsEnabled = false }: { admin: Admin; children: React.ReactNode; ticketsEnabled?: boolean }) {
  const [open,setOpen]=useState(false);
  const [closing,setClosing]=useState(false);
  function openMenu(){setOpen(true);setClosing(false)}
  function closeMenu(){setClosing(true); window.setTimeout(()=>{setOpen(false);setClosing(false)},220)}
  return <main className="min-h-screen bg-slate-100"><div className="sticky top-0 z-50 border-b border-slate-200 bg-white"><div className="shell flex min-h-[72px] items-center justify-between"><div className="flex items-center gap-3"><button onClick={openMenu} className="grid h-11 w-11 place-items-center rounded-2xl bg-slate-950 text-white lg:hidden"><Menu size={22}/></button><span className="hidden h-11 w-11 place-items-center rounded-2xl bg-slate-950 text-white lg:grid"><Menu size={22}/></span><div><strong className="block text-slate-950">پنل مدیریت ابرهاست</strong><span className="text-xs font-bold text-slate-500">کنترل کامل سایت</span></div></div><AdminLogoutButton/></div></div>{open?<div className="fixed inset-0 z-[9999] lg:hidden"><button className={`absolute inset-0 bg-slate-950/45 ${closing?'drawer-backdrop-out':'drawer-backdrop-in'}`} onClick={closeMenu}/><aside className={`absolute right-0 top-0 h-full w-[min(330px,90vw)] bg-white shadow-2xl ${closing?'drawer-panel-out':'drawer-panel-in'}`}><div className="flex items-center justify-between border-b border-slate-100 p-4"><strong>منوی مدیریت</strong><button onClick={closeMenu} className="grid h-10 w-10 place-items-center rounded-2xl bg-slate-100"><X size={20}/></button></div><NavList close={closeMenu} ticketsEnabled={ticketsEnabled}/></aside></div>:null}<div className="shell grid gap-5 py-6 lg:grid-cols-[260px_1fr]"><aside className="hidden lg:block"><Card className="overflow-hidden"><div className="bg-slate-950 p-5 text-white"><Badge className="bg-white/10 text-white" variant="outline">Admin</Badge><h2 className="mt-3 font-black">{admin.name}</h2><p className="text-left text-xs text-slate-400 dir-ltr">{admin.email}</p></div><NavList ticketsEnabled={ticketsEnabled}/></Card></aside>{children}</div></main>;
}
