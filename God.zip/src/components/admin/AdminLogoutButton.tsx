'use client';
import { useRouter } from 'next/navigation';
import { LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
export function AdminLogoutButton(){const router=useRouter(); async function logout(){await fetch('/api/admin/auth/logout',{method:'POST'}); router.push('/adminChash7nakg'); router.refresh();} return <Button variant="destructive" onClick={logout}><LogOut size={16}/> خروج</Button>}
