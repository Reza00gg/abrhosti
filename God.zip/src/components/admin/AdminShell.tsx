import type { User } from '@/lib/auth';
import { AdminShellClient } from '@/components/admin/AdminShellClient';
import { getCurrentHost, isTicketsHost } from '@/lib/host';
export function AdminShell({admin,children}:{admin:User;children:React.ReactNode}){const ticketsEnabled = isTicketsHost(getCurrentHost()); return <AdminShellClient admin={{name:admin.name,email:admin.email}} ticketsEnabled={ticketsEnabled}>{children}</AdminShellClient>}
