'use client';
import { KeyRound } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const schema = z.object({
  currentPassword: z.string().min(1, 'رمز فعلی را وارد کنید.'),
  newPassword: z.string().min(10, 'رمز جدید حداقل ۱۰ کاراکتر باشد.')
});
type FormValues = z.infer<typeof schema>;

export function AdminPasswordForm() {
  const form = useForm<FormValues>({ resolver: zodResolver(schema), defaultValues: { currentPassword: '', newPassword: '' } });
  async function save(values: FormValues) {
    const res = await fetch('/api/admin/settings/password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(values) });
    const json = await res.json();
    if (!res.ok || !json.ok) return toast.error(json?.error?.message ?? 'خطا در تغییر رمز');
    toast.success('رمز عبور ادمین تغییر کرد.');
    form.reset();
  }
  return <form onSubmit={form.handleSubmit(save)} className="grid gap-4"><div className="grid gap-2"><Label>رمز فعلی</Label><Input type="password" className="dir-ltr text-left" dir="ltr" {...form.register('currentPassword')} />{form.formState.errors.currentPassword?<p className="text-xs font-bold text-red-400">{form.formState.errors.currentPassword.message}</p>:null}</div><div className="grid gap-2"><Label>رمز جدید</Label><Input type="password" className="dir-ltr text-left" dir="ltr" {...form.register('newPassword')} />{form.formState.errors.newPassword?<p className="text-xs font-bold text-red-400">{form.formState.errors.newPassword.message}</p>:null}</div><Button disabled={form.formState.isSubmitting}><KeyRound size={16}/> {form.formState.isSubmitting?'در حال تغییر...':'تغییر رمز ادمین'}</Button></form>
}
