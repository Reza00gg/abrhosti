'use client';
import { useState } from 'react';
import { ChevronDown, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

function Section({ title, subtitle, open, onToggle, children, badge }: { title: string; subtitle: string; open: boolean; onToggle: () => void; children: React.ReactNode; badge?: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50">
      <button type="button" onClick={onToggle} className="flex w-full items-center justify-between gap-4 p-4 text-right">
        <span>
          <span className="flex items-center gap-2 font-black text-slate-950">{title}{badge}</span>
          <span className="mt-1 block text-xs font-bold text-slate-500">{subtitle}</span>
        </span>
        <ChevronDown className={`h-5 w-5 text-slate-400 transition ${open ? 'rotate-180' : ''}`} />
      </button>
      {open ? <div className="grid gap-4 border-t border-slate-200 p-4 submenu-open">{children}</div> : null}
    </div>
  );
}

function statusBadge(enabled: boolean, text = enabled ? 'فعال' : 'غیرفعال') {
  return <span className={`rounded-md px-2 py-0.5 text-[10px] ${enabled ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-600'}`}>{text}</span>;
}

export function GatewaySettingsForm({ initial }: { initial: any }) {
  const [open, setOpen] = useState<'general' | 'zibal' | 'zarinpal'>('general');
  const [form, setForm] = useState({
    gatewayEnabled: initial?.enabled ?? true,
    zibalEnabled: Boolean(initial?.zibal?.enabled),
    zibalSandbox: initial?.zibal?.sandbox ?? true,
    zibalMerchant: '',
    zibalMasked: initial?.zibalMasked ?? '',
    zarinpalEnabled: Boolean(initial?.zarinpal?.enabled),
    zarinpalSandbox: initial?.zarinpal?.sandbox ?? false,
    zarinpalMerchant: '',
    zarinpalMasked: initial?.zarinpalMasked ?? '',
    feeFixed: initial?.fee?.fixed ?? 0,
    feePercent: initial?.fee?.percent ?? 0
  });
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  async function save(e: React.FormEvent) {
    e.preventDefault(); setMsg(''); setErr('');
    const res = await fetch('/api/admin/settings/gateways', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const json = await res.json();
    if (!res.ok || !json.ok) return setErr(json?.error?.message ?? 'ذخیره انجام نشد.');
    setMsg('تنظیمات درگاه ذخیره شد.');
    setForm((f) => ({
      ...f,
      zibalMerchant: '',
      zibalMasked: f.zibalMerchant ? `${f.zibalMerchant.slice(0, 3)}••••${f.zibalMerchant.slice(-3)}` : f.zibalMasked,
      zarinpalMerchant: '',
      zarinpalMasked: f.zarinpalMerchant ? `${f.zarinpalMerchant.slice(0, 3)}••••${f.zarinpalMerchant.slice(-3)}` : f.zarinpalMasked
    }));
  }

  return (
    <form onSubmit={save} className="grid gap-4">
      <Section title="کنترل کلی درگاه" subtitle="فعال یا غیرفعال شدن تب درگاه پرداخت برای افزایش موجودی" open={open === 'general'} onToggle={() => setOpen(open === 'general' ? 'zarinpal' : 'general')} badge={statusBadge(form.gatewayEnabled)}>
        <label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={form.gatewayEnabled} onChange={e=>setForm({...form,gatewayEnabled:e.target.checked})}/> پرداخت آنلاین فعال باشد</label>
        <div className="grid gap-3 md:grid-cols-2"><div className="grid gap-2"><Label>کارمزد ثابت تومان</Label><Input type="number" value={form.feeFixed} onChange={e=>setForm({...form,feeFixed:Number(e.target.value)})}/></div><div className="grid gap-2"><Label>کارمزد درصدی</Label><Input type="number" step="0.1" value={form.feePercent} onChange={e=>setForm({...form,feePercent:Number(e.target.value)})}/></div></div>
      </Section>
      <Section title="زرین‌پال" subtitle="درگاه پیشنهادی فعلی برای پرداخت آنلاین" open={open === 'zarinpal'} onToggle={() => setOpen(open === 'zarinpal' ? 'general' : 'zarinpal')} badge={statusBadge(form.zarinpalEnabled)}>
        <label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={form.zarinpalEnabled} onChange={e=>setForm({...form,zarinpalEnabled:e.target.checked})}/> زرین‌پال فعال باشد</label>
        <label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={form.zarinpalSandbox} onChange={e=>setForm({...form,zarinpalSandbox:e.target.checked})}/> حالت سندباکس زرین‌پال</label>
        <div className="grid gap-2"><Label>مرچنت زرین‌پال {form.zarinpalMasked ? `(فعلی: ${form.zarinpalMasked})` : ''}</Label><Input className="dir-ltr text-left" dir="ltr" value={form.zarinpalMerchant} onChange={e=>setForm({...form,zarinpalMerchant:e.target.value})} placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" /></div>
      </Section>
      <Section title="زیبال" subtitle="درگاه پشتیبان؛ در صورت حل IP قابل استفاده است" open={open === 'zibal'} onToggle={() => setOpen(open === 'zibal' ? 'general' : 'zibal')} badge={statusBadge(form.zibalEnabled)}>
        <label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={form.zibalEnabled} onChange={e=>setForm({...form,zibalEnabled:e.target.checked})}/> زیبال فعال باشد</label>
        <label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={form.zibalSandbox} onChange={e=>setForm({...form,zibalSandbox:e.target.checked})}/> حالت تست زیبال</label>
        <div className="grid gap-2"><Label>مرچنت زیبال {form.zibalMasked ? `(فعلی: ${form.zibalMasked})` : ''}</Label><Input className="dir-ltr text-left" dir="ltr" value={form.zibalMerchant} onChange={e=>setForm({...form,zibalMerchant:e.target.value})} placeholder={form.zibalSandbox ? 'در تست خالی بماند = zibal' : 'merchant code'} /></div>
      </Section>
      {err?<div className="alert error">{err}</div>:null}{msg?<div className="alert success">{msg}</div>:null}<Button><Save size={16}/> ذخیره تنظیمات درگاه</Button>
    </form>
  );
}
