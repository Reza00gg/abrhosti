'use client';

import { useMemo, useState } from 'react';
import { CreditCard, Wallet } from 'lucide-react';
import { AdminPaymentActions } from '@/components/admin/AdminPaymentActions';
import { ReceiptPreview } from '@/components/admin/ReceiptPreview';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatPrice } from '@/lib/products';
import { formatTehranDateTime } from '@/lib/date';

type Row = {
  id: string;
  order_number: string | null;
  topup_ref: string | null;
  amount: number;
  payer_name: string;
  tracking_number: string | null;
  receipt_file_name: string;
  receipt_mime: string;
  status: string;
  created_at: string;
  email: string;
  purpose: 'service_order' | 'wallet_topup';
};

function label(status: string) {
  return status === 'pending_review' ? 'در انتظار تایید' : status === 'approved' ? 'تایید شده' : status === 'rejected' ? 'رد شده' : status;
}
function variant(status: string) {
  return status === 'pending_review' ? 'warning' : status === 'approved' ? 'success' : 'secondary' as any;
}

function PaymentRow({ r }: { r: Row }) {
  return (
    <Card className="p-4 shadow-sm">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div className="min-w-0">
          <div className="flex flex-wrap gap-2">
            <Badge variant={variant(r.status)}>{label(r.status)}</Badge>
            <Badge variant="secondary">{r.purpose === 'wallet_topup' ? 'افزایش موجودی' : 'سفارش'}</Badge>
          </div>
          <h3 className="mt-3 truncate font-black text-slate-950">{r.order_number ?? r.topup_ref} • {formatPrice(r.amount)}</h3>
          <p className="mt-1 text-sm text-slate-500">{r.payer_name} • <span className="dir-ltr">{r.email}</span></p>
          <p className="mt-1 text-xs text-slate-400">پیگیری: {r.tracking_number ?? '—'} • {formatTehranDateTime(r.created_at)}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <ReceiptPreview receiptId={r.id} mime={r.receipt_mime} fileName={r.receipt_file_name} />
          {r.status === 'pending_review' ? <AdminPaymentActions receiptId={r.id} /> : null}
        </div>
      </div>
    </Card>
  );
}

export function PaymentTabs({ rows }: { rows: Row[] }) {
  const [tab, setTab] = useState<'service_order' | 'wallet_topup'>('service_order');
  const serviceCount = useMemo(() => rows.filter((r) => r.purpose !== 'wallet_topup').length, [rows]);
  const walletCount = useMemo(() => rows.filter((r) => r.purpose === 'wallet_topup').length, [rows]);
  const visible = rows.filter((r) => tab === 'wallet_topup' ? r.purpose === 'wallet_topup' : r.purpose !== 'wallet_topup');

  return (
    <div className="grid gap-4">
      <div className="inline-flex w-full rounded-2xl border border-slate-200 bg-white p-1 shadow-sm md:w-fit">
        <button onClick={() => setTab('service_order')} className={`flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-black transition md:flex-none ${tab === 'service_order' ? 'bg-slate-950 text-white' : 'text-slate-600 hover:bg-slate-50'}`}>
          <CreditCard size={16} /> سفارشات <span className="rounded-full bg-white/15 px-2 text-xs">{serviceCount}</span>
        </button>
        <button onClick={() => setTab('wallet_topup')} className={`flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-black transition md:flex-none ${tab === 'wallet_topup' ? 'bg-slate-950 text-white' : 'text-slate-600 hover:bg-slate-50'}`}>
          <Wallet size={16} /> واریزی <span className="rounded-full bg-white/15 px-2 text-xs">{walletCount}</span>
        </button>
      </div>

      {visible.length ? (
        <div className="grid gap-3">
          {visible.map((row) => <PaymentRow key={row.id} r={row} />)}
        </div>
      ) : (
        <Card className="p-6 text-center text-sm font-bold text-slate-500">
          موردی برای نمایش وجود ندارد.
        </Card>
      )}
    </div>
  );
}
