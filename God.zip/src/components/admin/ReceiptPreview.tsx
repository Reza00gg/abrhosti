'use client';
import { useState } from 'react';
import { Eye, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
export function ReceiptPreview({ receiptId, mime, fileName }: { receiptId: string; mime: string; fileName: string }) {
  const [open, setOpen] = useState(false);
  const src = `/api/admin/payments/${receiptId}/file`;
  return <>
    <Button type="button" size="sm" variant="secondary" onClick={() => setOpen(true)}><Eye size={14}/> مشاهده فیش</Button>
    {open ? <div className="fixed inset-0 z-[9999] grid place-items-center bg-slate-950/60 p-4 drawer-backdrop-in"><div className="w-full max-w-3xl rounded-3xl bg-white p-4 shadow-2xl"><div className="mb-3 flex items-center justify-between"><strong className="text-sm text-slate-900">{fileName}</strong><button onClick={() => setOpen(false)} className="grid h-9 w-9 place-items-center rounded-xl bg-slate-100"><X size={18}/></button></div><div className="max-h-[75vh] overflow-auto rounded-2xl bg-slate-100 p-2">{mime === 'application/pdf' ? <iframe src={src} className="h-[70vh] w-full rounded-xl bg-white" /> : <img src={src} alt="فیش پرداخت" className="mx-auto max-h-[70vh] rounded-xl object-contain" />}</div></div></div> : null}
  </>
}
