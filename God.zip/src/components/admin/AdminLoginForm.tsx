'use client';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { LockKeyhole, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function AdminLoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{ email?: string; password?: string; general?: string }>({});
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const nextErrors: typeof errors = {};
    if (!email.trim()) nextErrors.email = 'ایمیل ادمین را وارد کنید.';
    if (!password) nextErrors.password = 'رمز عبور را وارد کنید.';
    if (nextErrors.email || nextErrors.password) return setErrors(nextErrors);
    setLoading(true); setErrors({});
    const res = await fetch('/api/admin/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
    const json = await res.json();
    setLoading(false);
    if (!res.ok || !json.ok) return setErrors({ general: json?.error?.message ?? 'ورود انجام نشد.' });
    router.push('/adminChash7nakg/dashboard'); router.refresh();
  }

  return (
    <form onSubmit={submit} className="grid gap-4" noValidate>
      <div className="grid gap-2">
        <Label>ایمیل ادمین</Label>
        <div className="relative"><Mail className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400"/><Input className="pr-10 text-left dir-ltr" dir="ltr" value={email} onChange={(e)=>{setEmail(e.target.value); setErrors((x)=>({...x,email:undefined,general:undefined}));}} /></div>
        {errors.email ? <p className="text-xs font-bold text-red-600">{errors.email}</p> : null}
      </div>
      <div className="grid gap-2">
        <Label>رمز عبور</Label>
        <div className="relative"><LockKeyhole className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400"/><Input className="pr-10 text-left dir-ltr" dir="ltr" type="password" value={password} onChange={(e)=>{setPassword(e.target.value); setErrors((x)=>({...x,password:undefined,general:undefined}));}} /></div>
        {errors.password ? <p className="text-xs font-bold text-red-600">{errors.password}</p> : null}
      </div>
      {errors.general ? <div className="alert error">{errors.general}</div> : null}
      <Button disabled={loading} size="lg" className="w-full">{loading ? 'در حال بررسی...' : 'ورود'}</Button>
    </form>
  );
}
