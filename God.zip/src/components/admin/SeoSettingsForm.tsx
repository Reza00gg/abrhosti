'use client';
import { useState } from 'react';
import { Save, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function SeoSettingsForm({ initial }: { initial: any }) {
  const [form, setForm] = useState({
    indexingEnabled: Boolean(initial?.indexingEnabled),
    siteName: initial?.siteName ?? 'ابرهاست',
    defaultTitle: initial?.defaultTitle ?? 'ابرهاست | خرید هاست، سرور مجازی و دامنه',
    defaultDescription: initial?.defaultDescription ?? 'خرید هاست ابری، هاست اشتراکی، سرور مجازی، سرور اختصاصی و ثبت دامنه با پنل کاربری حرفه‌ای.'
  });
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setMsg(''); setErr('');
    const res = await fetch('/api/admin/settings/seo', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const json = await res.json();
    if (!res.ok || !json.ok) return setErr(json?.error?.message ?? 'ذخیره انجام نشد.');
    setMsg('تنظیمات سئو ذخیره شد.');
  }

  return (
    <form onSubmit={save} className="grid gap-4">
      <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="flex items-center gap-2 font-black text-slate-950"><Search size={18}/> کنترل ایندکس</h3>
            <p className="mt-1 text-xs font-bold text-slate-500">فقط دامنه اصلی lnupro.sbs اجازه ایندکس می‌گیرد؛ داشبورد و ادمین همیشه noindex هستند.</p>
          </div>
          <label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={form.indexingEnabled} onChange={e=>setForm({...form,indexingEnabled:e.target.checked})}/> فعال</label>
        </div>
        <div className={`mt-4 rounded-xl p-3 text-sm font-bold ${form.indexingEnabled ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-600'}`}>
          {form.indexingEnabled ? 'ایندکس صفحات عمومی سایت فعال است.' : 'ایندکس صفحات عمومی سایت غیرفعال است.'}
        </div>
      </div>
      <div className="grid gap-2"><Label>نام سایت</Label><Input value={form.siteName} onChange={e=>setForm({...form,siteName:e.target.value})}/></div>
      <div className="grid gap-2"><Label>عنوان پیش‌فرض سئو</Label><Input value={form.defaultTitle} onChange={e=>setForm({...form,defaultTitle:e.target.value})}/><span className="text-xs font-bold text-slate-400">پیشنهاد: کمتر از ۶۰ کاراکتر</span></div>
      <div className="grid gap-2"><Label>توضیحات پیش‌فرض سئو</Label><textarea className="textarea" value={form.defaultDescription} onChange={e=>setForm({...form,defaultDescription:e.target.value})}/><span className="text-xs font-bold text-slate-400">پیشنهاد: بین ۱۲۰ تا ۱۶۰ کاراکتر</span></div>
      <div className="rounded-2xl bg-slate-50 p-3 text-xs leading-6 text-slate-500">
        robots.txt و sitemap.xml بر اساس همین تنظیمات ساخته می‌شوند. دامنه‌های غیر اصلی مثل Vercel همیشه noindex هستند تا محتوای تکراری ایجاد نشود.
      </div>
      {err?<div className="alert error">{err}</div>:null}{msg?<div className="alert success">{msg}</div>:null}
      <Button><Save size={16}/> ذخیره تنظیمات سئو</Button>
    </form>
  );
}
