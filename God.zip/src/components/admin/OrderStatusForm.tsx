'use client';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Save } from 'lucide-react';
import { Button } from '@/components/ui/button';

const orderStatuses = [
  ['pending_payment', 'در انتظار پرداخت'],
  ['awaiting_admin_approval', 'در انتظار تایید'],
  ['approved', 'تایید شده'],
  ['active', 'فعال'],
  ['suspended', 'تعلیق شده'],
  ['cancelled', 'لغو شده']
];
const provisionStatuses = [
  ['waiting_for_receipt', 'در انتظار فیش'],
  ['awaiting_admin_approval', 'در انتظار تایید ادمین'],
  ['queued', 'در صف تحویل'],
  ['active', 'تحویل/فعال'],
  ['on_hold', 'متوقف']
];

export function OrderStatusForm({ orderId, status, provision }: { orderId: string; status: string; provision: string }) {
  const router = useRouter();
  const [s, setS] = useState(status);
  const [p, setP] = useState(provision);
  const [saving, setSaving] = useState(false);
  async function save() {
    setSaving(true);
    await fetch(`/api/admin/orders/${orderId}/status`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: s, provisionStatus: p }) });
    setSaving(false); router.refresh();
  }
  return <div className="grid min-w-[260px] gap-2"><select className="select h-9 min-h-9 text-xs" value={s} onChange={e=>setS(e.target.value)}>{orderStatuses.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select><div className="flex gap-2"><select className="select h-9 min-h-9 text-xs" value={p} onChange={e=>setP(e.target.value)}>{provisionStatuses.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select><Button size="sm" onClick={save} disabled={saving}><Save size={14}/></Button></div></div>;
}
