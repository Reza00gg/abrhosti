'use client';
import { useState } from 'react';
import { Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function SmsSettingsForm({ initial }: { initial: any }) {
  const [form, setForm] = useState({
    enabled: Boolean(initial?.enabled),
    apiKey: '',
    apiKeyMasked: initial?.apiKeyMasked ?? '',
    verifyTemplateId: initial?.verifyTemplateId ?? '',
    verifyCodeParam: initial?.verifyCodeParam ?? 'Code',
    welcomeTemplateId: initial?.welcomeTemplateId ?? '',
    welcomeNameParam: initial?.welcomeNameParam ?? 'Name'
  });
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  async function save(e: React.FormEvent) {
    e.preventDefault(); setMsg(''); setErr('');
    const res = await fetch('/api/admin/settings/sms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const json = await res.json();
    if (!res.ok || !json.ok) return setErr(json?.error?.message ?? 'ذخیره انجام نشد.');
    setMsg('تنظیمات پیامک ذخیره شد.');
    setForm((f) => ({ ...f, apiKey: '', apiKeyMasked: f.apiKey ? `${f.apiKey.slice(0, 3)}••••${f.apiKey.slice(-3)}` : f.apiKeyMasked }));
  }
  return <form onSubmit={save} className="grid gap-4"><label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={form.enabled} onChange={e=>setForm({...form,enabled:e.target.checked})}/> تایید شماره با پیامک فعال باشد</label><div className="grid gap-2"><Label>API Key پیامک {form.apiKeyMasked ? `(فعلی: ${form.apiKeyMasked})` : ''}</Label><Input className="dir-ltr text-left" dir="ltr" value={form.apiKey} onChange={e=>setForm({...form,apiKey:e.target.value})} placeholder="SMS.ir API Key" /></div><div className="grid gap-3 md:grid-cols-2"><div className="grid gap-2"><Label>شناسه قالب تایید</Label><Input type="number" value={form.verifyTemplateId} onChange={e=>setForm({...form,verifyTemplateId:e.target.value})}/></div><div className="grid gap-2"><Label>نام پارامتر کد</Label><Input value={form.verifyCodeParam} onChange={e=>setForm({...form,verifyCodeParam:e.target.value})}/></div></div><div className="rounded-2xl bg-slate-50 p-3 text-xs leading-6 text-slate-500">قالب پیشنهادی در SMS.ir: «کد تایید جهت فعال سازی حساب شما کد: #Code# ابرهاست» و نام پارامتر: Code</div><div className="grid gap-3 md:grid-cols-2"><div className="grid gap-2"><Label>شناسه قالب خوش‌آمد اختیاری</Label><Input type="number" value={form.welcomeTemplateId} onChange={e=>setForm({...form,welcomeTemplateId:e.target.value})}/></div><div className="grid gap-2"><Label>نام پارامتر نام کاربر</Label><Input value={form.welcomeNameParam} onChange={e=>setForm({...form,welcomeNameParam:e.target.value})}/></div></div>{err?<div className="alert error">{err}</div>:null}{msg?<div className="alert success">{msg}</div>:null}<Button><Save size={16}/> ذخیره تنظیمات پیامک</Button></form>
}
