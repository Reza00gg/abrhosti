'use client';
import { useState } from 'react';
import { Edit3, Plus } from 'lucide-react';
import { ProductEditor } from '@/components/admin/ProductEditor';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatPrice } from '@/lib/products';

export function ProductManager({ products }: { products: any[] }) {
  const [mode, setMode] = useState<'list' | 'new' | string>('list');
  const current = products.find((p) => p.id === mode);

  if (mode === 'new') {
    return <div className="grid gap-4"><Button variant="secondary" onClick={() => setMode('list')}>بازگشت</Button><ProductEditor /></div>;
  }
  if (current) {
    const features = Array.isArray(current.features) ? current.features.join('\n') : '';
    return <div className="grid gap-4"><Button variant="secondary" onClick={() => setMode('list')}>بازگشت به لیست</Button><ProductEditor product={{id:current.id,category:current.category,country:current.country??'',title:current.title,subtitle:current.subtitle,priceMonthly:current.price_monthly,currency:current.currency,badge:current.badge,cpu:current.specs?.cpu??'',ram:current.specs?.ram??'',storage:current.specs?.storage??'',bandwidth:current.specs?.bandwidth??'',features,route:current.route,active:current.active}} /></div>;
  }

  return (
    <div className="grid gap-4">
      <div className="flex justify-end"><Button onClick={() => setMode('new')}><Plus size={16}/> محصول جدید</Button></div>
      <div className="grid gap-3">
        {products.map((p) => (
          <div key={p.id} className="flex flex-col justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 md:flex-row md:items-center">
            <div>
              <div className="flex flex-wrap gap-2"><Badge>{p.category}{p.country ? ` / ${p.country}` : ''}</Badge><Badge variant={p.active ? 'success' : 'secondary'}>{p.active ? 'فعال' : 'غیرفعال'}</Badge></div>
              <h3 className="mt-2 font-black text-slate-950">{p.title}</h3>
              <p className="mt-1 text-sm font-bold text-slate-500">{formatPrice(p.price_monthly, p.currency)}</p>
            </div>
            <Button variant="secondary" onClick={() => setMode(p.id)}><Edit3 size={16}/> ویرایش</Button>
          </div>
        ))}
      </div>
    </div>
  );
}
