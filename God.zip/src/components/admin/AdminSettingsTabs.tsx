'use client';

import { useState } from 'react';
import { CreditCard, KeyRound, MessageSquareText, RotateCcw, Shield, WalletCards } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { CardSettingsForm } from '@/components/admin/CardSettingsForm';
import { GatewaySettingsForm } from '@/components/admin/GatewaySettingsForm';
import { SmsSettingsForm } from '@/components/admin/SmsSettingsForm';
import { AdminPasswordForm } from '@/components/admin/AdminPasswordForm';
import { ResetDataForm } from '@/components/admin/ResetDataForm';

type Tab = 'card' | 'gateway' | 'sms' | 'security' | 'reset';

const tabs = [
  { id: 'card' as Tab, title: 'کارت‌به‌کارت', desc: 'شماره کارت و شبا', icon: CreditCard },
  { id: 'gateway' as Tab, title: 'درگاه‌ها', desc: 'زرین‌پال و زیبال', icon: WalletCards },
  { id: 'sms' as Tab, title: 'پیامک', desc: 'SMS.ir و OTP', icon: MessageSquareText },
  { id: 'security' as Tab, title: 'امنیت', desc: 'رمز ادمین', icon: KeyRound },
  { id: 'reset' as Tab, title: 'ریست', desc: 'اطلاعات سایت', icon: RotateCcw }
];

export function AdminSettingsTabs({ cardInitial, gatewayInitial, smsInitial }: { cardInitial: any; gatewayInitial: any; smsInitial: any }) {
  const [active, setActive] = useState<Tab>('card');
  return (
    <div className="grid gap-5 xl:grid-cols-[300px_1fr]">
      <Card className="h-fit p-3">
        <div className="mb-2 flex items-center gap-2 px-2 py-2 text-sm font-black text-slate-500"><Shield size={16}/> دسته‌بندی تنظیمات</div>
        <div className="grid gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = active === tab.id;
            return (
              <button key={tab.id} onClick={() => setActive(tab.id)} className={`flex items-center gap-3 rounded-xl p-3 text-right transition ${isActive ? 'bg-sky-500/12 text-sky-300 ring-1 ring-sky-400/15' : 'text-slate-400 hover:bg-white/5 hover:text-slate-100'}`}>
                <Icon size={18} />
                <span><strong className="block text-sm">{tab.title}</strong><span className="mt-1 block text-xs opacity-70">{tab.desc}</span></span>
              </button>
            );
          })}
        </div>
      </Card>
      <Card className="p-5">
        {active === 'card' ? <><h2 className="mb-4 text-xl font-black">اطلاعات کارت‌به‌کارت</h2><CardSettingsForm initial={cardInitial}/></> : null}
        {active === 'gateway' ? <><h2 className="mb-4 text-xl font-black">درگاه پرداخت آنلاین</h2><GatewaySettingsForm initial={gatewayInitial}/></> : null}
        {active === 'sms' ? <><h2 className="mb-4 text-xl font-black">تایید پیامکی</h2><SmsSettingsForm initial={smsInitial}/></> : null}
        {active === 'security' ? <><h2 className="mb-4 text-xl font-black">امنیت ادمین</h2><AdminPasswordForm/></> : null}
        {active === 'reset' ? <><h2 className="mb-4 text-xl font-black text-red-400">ریست اطلاعات سایت</h2><ResetDataForm/></> : null}
      </Card>
    </div>
  );
}
