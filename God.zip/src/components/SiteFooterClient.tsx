'use client';
import { usePathname } from 'next/navigation';
export function SiteFooterClient({ children }: { children: React.ReactNode }) { const pathname = usePathname(); if (pathname?.startsWith('/adminChash7nakg')) return null; return <>{children}</>; }
