'use client';

import { useEffect, useRef, useState } from 'react';
import { ChevronDown, Send } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const priorityOptions = [
  { value: 'low', label: 'ساده', hint: 'سوال یا درخواست معمولی' },
  { value: 'medium', label: 'متوسط', hint: 'نیازمند بررسی پشتیبانی' },
  { value: 'high', label: 'زیاد', hint: 'فوری یا اثرگذار روی سرویس' }
] as const;

type Priority = typeof priorityOptions[number]['value'];

function PrioritySelect({ value, onChange }: { value: Priority; onChange: (value: Priority) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const selected = priorityOptions.find((item) => item.value === value) ?? priorityOptions[1];

  useEffect(() => {
    function onDown(e: PointerEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('pointerdown', onDown);
    return () => document.removeEventListener('pointerdown', onDown);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="flex h-12 w-full items-center justify-between rounded-xl border border-slate-200 bg-white px-4 text-right text-sm font-black text-slate-800 shadow-sm transition active:scale-[0.99]"
      >
        <span>
          <span className="block">{selected.label}</span>
          <span className="mt-0.5 block text-xs font-bold text-slate-400">{selected.hint}</span>
        </span>
        <ChevronDown className={`h-5 w-5 text-slate-400 transition ${open ? 'rotate-180' : ''}`} />
      </button>
      {open ? (
        <div className="absolute right-0 top-[calc(100%+8px)] z-40 w-full overflow-hidden rounded-2xl border border-slate-200 bg-white p-1 shadow-[0_18px_60px_rgba(15,23,42,.14)] submenu-open">
          {priorityOptions.map((item) => (
            <button
              key={item.value}
              type="button"
              onClick={() => { onChange(item.value); setOpen(false); }}
              className={`flex w-full items-center justify-between rounded-xl px-3 py-3 text-right transition ${value === item.value ? 'bg-slate-950 text-white' : 'text-slate-700 hover:bg-slate-50'}`}
            >
              <span>
                <span className="block text-sm font-black">{item.label}</span>
                <span className={`mt-0.5 block text-xs font-bold ${value === item.value ? 'text-slate-300' : 'text-slate-400'}`}>{item.hint}</span>
              </span>
              <span className={`h-3 w-3 rounded-full border ${value === item.value ? 'border-white bg-white' : 'border-slate-300'}`} />
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export function TicketCreateForm() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [subject, setSubject] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const res = await fetch('/api/tickets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject, priority, message })
    });
    const json = await res.json();
    setLoading(false);
    if (!res.ok || !json.ok) return setError(json?.error?.message ?? 'ثبت تیکت انجام نشد.');
    setSubject('');
    setPriority('medium');
    setMessage('');
    setOpen(false);
    router.refresh();
  }

  if (!open) return <Button onClick={() => setOpen(true)}><Send size={16} /> ثبت تیکت</Button>;

  return (
    <form onSubmit={submit} className="grid gap-4 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-black">ثبت تیکت جدید</h2>
          <p className="mt-1 text-xs font-bold text-slate-400">درخواست خود را کوتاه و روشن بنویسید.</p>
        </div>
        <button type="button" onClick={() => setOpen(false)} className="rounded-xl bg-slate-100 px-3 py-2 text-sm font-bold">بستن</button>
      </div>

      <div className="grid gap-2">
        <Label>موضوع تیکت</Label>
        <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="مثلاً مشکل پرداخت یا سفارش" maxLength={160} />
      </div>

      <div className="grid gap-2">
        <Label>اهمیت تیکت</Label>
        <PrioritySelect value={priority} onChange={setPriority} />
      </div>

      <div className="grid gap-2">
        <div className="flex items-center justify-between">
          <Label>متن تیکت</Label>
          <span className="text-xs font-bold text-slate-400">{message.length.toLocaleString('fa-IR')} / ۴۰۰۰</span>
        </div>
        <textarea className="textarea min-h-36" value={message} onChange={(e) => setMessage(e.target.value.slice(0, 4000))} placeholder="پیام خود را با جزئیات لازم بنویسید..." />
      </div>

      {error ? <div className="alert error">{error}</div> : null}
      <Button disabled={loading}>{loading ? 'در حال ارسال...' : 'ارسال تیکت'} <Send size={16} /></Button>
    </form>
  );
}
