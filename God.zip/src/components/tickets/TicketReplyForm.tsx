'use client';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Send } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function TicketReplyForm({ ticketId, endpoint, disabled = false }: { ticketId: string; endpoint: string; disabled?: boolean }) {
  const router = useRouter();
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message }) });
    const json = await res.json();
    setLoading(false);
    if (!res.ok || !json.ok) return setError(json?.error?.message ?? 'ارسال پیام انجام نشد.');
    setMessage('');
    router.refresh();
  }

  if (disabled) return <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm font-bold text-slate-500">این تیکت بسته شده و امکان ارسال پیام جدید وجود ندارد.</div>;

  return (
    <form onSubmit={submit} className="grid gap-3 rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <strong className="text-sm text-slate-800">ارسال پاسخ</strong>
        <span className="text-xs font-bold text-slate-400">{message.length.toLocaleString('fa-IR')} / ۴۰۰۰</span>
      </div>
      <textarea className="textarea min-h-28" value={message} onChange={(e) => setMessage(e.target.value.slice(0, 4000))} placeholder="پیام جدید..." />
      {error ? <div className="alert error">{error}</div> : null}
      <Button disabled={loading}>{loading ? 'در حال ارسال...' : 'ارسال پیام'} <Send size={16} /></Button>
    </form>
  );
}
