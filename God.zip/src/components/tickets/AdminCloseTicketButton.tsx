'use client';
import { useRouter } from 'next/navigation';
import { Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
export function AdminCloseTicketButton({ ticketId, disabled }: { ticketId: string; disabled?: boolean }) { const router=useRouter(); async function close(){if(!confirm('تیکت بسته شود؟')) return; await fetch(`/api/admin/tickets/${ticketId}/close`, {method:'POST'}); router.refresh();} return <Button variant="destructive" onClick={close} disabled={disabled}><Lock size={16}/> بستن تیکت</Button> }
