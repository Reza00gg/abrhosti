'use client';

import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { ChevronDown, Cloud, CreditCard, Globe2, Headphones, LayoutDashboard, Menu, Server, ShieldCheck, Sparkles, X } from 'lucide-react';
import { AccountMenu } from '@/components/AccountMenu';
import { BrandMark } from '@/components/BrandMark';
import { formatPrice } from '@/lib/products';

type User = { name: string; email: string; balance?: number; currency?: string } | null;

const serviceGroups = [
  {
    title: 'هاستینگ',
    items: [
      { href: '/hosting/cloud', label: 'هاست ابری', desc: 'برای سایت‌های پرترافیک', icon: Cloud },
      { href: '/hosting/shared', label: 'هاست اشتراکی', desc: 'شروع اقتصادی و سریع', icon: Globe2 },
      { href: '/hosting/dedicated', label: 'سرور اختصاصی', desc: 'منابع کامل و قدرتمند', icon: Server }
    ]
  },
  {
    title: 'سرور مجازی',
    items: [
      { href: '/vps', label: 'همه لوکیشن‌ها', desc: 'انتخاب کشور و پلن', icon: Server },
      { href: '/vps/de', label: 'VPS آلمان', desc: 'فرانکفورت', icon: Server },
      { href: '/vps/us', label: 'VPS آمریکا', desc: 'شبکه بین‌المللی', icon: Server }
    ]
  },
  {
    title: 'دامنه و حساب',
    items: [
      { href: '/domains', label: 'ثبت دامنه', desc: 'جستجوی واقعی دامنه', icon: Globe2 },
      { href: '/dashboard', label: 'داشبورد', desc: 'سرویس‌ها و پرداخت‌ها', icon: LayoutDashboard },
      { href: '/dashboard/wallet', label: 'موجودی', desc: 'شارژ و پرداخت آنلاین', icon: CreditCard }
    ]
  }
];

export function SiteHeaderV2Client({ user }: { user: User }) {
  const pathname = usePathname();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [closing, setClosing] = useState(false);
  const [expanded, setExpanded] = useState('هاستینگ');
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  if (pathname?.startsWith('/adminChash7nakg')) return null;

  function openDrawer() {
    setDrawerOpen(true);
    setClosing(false);
  }
  function closeDrawer() {
    setClosing(true);
    window.setTimeout(() => { setDrawerOpen(false); setClosing(false); }, 220);
  }

  return (
    <>
      <header className={`sticky top-0 z-50 border-b transition-all duration-200 ${scrolled ? 'border-slate-200 bg-white/90 shadow-sm backdrop-blur-xl' : 'border-transparent bg-white'}`}>
        <div className="shell flex min-h-[70px] items-center justify-between gap-3">
          <div className="flex items-center gap-3 lg:hidden">
            <button type="button" onClick={openDrawer} className="inline-flex h-11 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-800 shadow-sm active:scale-[0.98]">
              <Menu size={19} /> منو
            </button>
          </div>

          <a href="/" className="flex items-center gap-3">
            <BrandMark className="h-11 w-11 shrink-0" />
            <span className="leading-tight">
              <span className="block text-lg font-black tracking-tight text-slate-950">ابرهاست</span>
              <span className="hidden text-xs font-bold text-slate-500 sm:block">هاست، VPS و دامنه</span>
            </span>
          </a>

          <nav className="hidden items-center gap-1 rounded-2xl border border-slate-200 bg-slate-50 p-1 lg:flex">
            <div className="group relative">
              <button className="inline-flex h-10 items-center gap-2 rounded-xl px-4 text-sm font-black text-slate-700 transition hover:bg-white hover:text-slate-950 hover:shadow-sm">
                سرویس‌ها <ChevronDown size={15} />
              </button>
              <div className="invisible absolute right-0 top-12 w-[720px] translate-y-2 rounded-3xl border border-slate-200 bg-white p-4 opacity-0 shadow-[0_25px_90px_rgba(15,23,42,.14)] transition-all group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
                <div className="grid grid-cols-3 gap-3">
                  {serviceGroups.map((group) => (
                    <div key={group.title}>
                      <h3 className="mb-3 px-2 text-xs font-black text-slate-400">{group.title}</h3>
                      <div className="grid gap-1">
                        {group.items.map((item) => {
                          const Icon = item.icon;
                          return (
                            <a href={item.href} key={item.href} className="flex items-center gap-3 rounded-2xl p-3 transition hover:bg-slate-50">
                              <span className="grid h-10 w-10 place-items-center rounded-xl bg-slate-100 text-slate-700"><Icon size={18} /></span>
                              <span>
                                <strong className="block text-sm font-black text-slate-950">{item.label}</strong>
                                <span className="mt-0.5 block text-xs font-bold text-slate-500">{item.desc}</span>
                              </span>
                            </a>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex items-center justify-between rounded-2xl bg-slate-950 p-4 text-white">
                  <span className="flex items-center gap-2 text-sm font-bold"><ShieldCheck size={18} /> خرید امن، پشتیبانی و پنل مدیریت سرویس</span>
                  <a href="/domains" className="rounded-xl bg-white px-4 py-2 text-xs font-black text-slate-950">جستجوی دامنه</a>
                </div>
              </div>
            </div>
            <a href="/hosting/cloud" className="rounded-xl px-4 py-2 text-sm font-black text-slate-700 transition hover:bg-white hover:text-slate-950 hover:shadow-sm">هاست ابری</a>
            <a href="/vps" className="rounded-xl px-4 py-2 text-sm font-black text-slate-700 transition hover:bg-white hover:text-slate-950 hover:shadow-sm">VPS</a>
            <a href="/domains" className="rounded-xl px-4 py-2 text-sm font-black text-slate-700 transition hover:bg-white hover:text-slate-950 hover:shadow-sm">دامنه</a>
          </nav>

          <div className="flex items-center gap-2">
            {user ? (
              <a href="/dashboard/wallet" className="hidden rounded-2xl border border-slate-200 bg-white px-4 py-2 text-xs font-black text-slate-700 shadow-sm lg:block">
                موجودی: {formatPrice(user.balance ?? 0, user.currency ?? 'تومان')}
              </a>
            ) : (
              <a href="/auth/register" className="hidden rounded-2xl bg-slate-950 px-4 py-2.5 text-sm font-black text-white shadow-sm lg:inline-flex">شروع کنید</a>
            )}
            <AccountMenu user={user} />
          </div>
        </div>
      </header>

      {drawerOpen ? (
        <div className="fixed inset-0 z-[9999] lg:hidden">
          <button type="button" className={`absolute inset-0 bg-slate-950/45 backdrop-blur-sm ${closing ? 'drawer-backdrop-out' : 'drawer-backdrop-in'}`} onClick={closeDrawer} aria-label="بستن" />
          <aside className={`absolute right-0 top-0 flex h-full w-[min(430px,94vw)] flex-col overflow-hidden bg-white shadow-2xl ${closing ? 'drawer-panel-out' : 'drawer-panel-in'}`}>
            <div className="flex items-center justify-between border-b border-slate-100 p-5">
              <div className="flex items-center gap-3"><BrandMark className="h-11 w-11 shrink-0" /><div><strong className="block text-slate-950">ابرهاست</strong><span className="text-xs font-bold text-slate-500">انتخاب سریع سرویس</span></div></div>
              <button type="button" onClick={closeDrawer} className="grid h-10 w-10 place-items-center rounded-2xl bg-slate-100 text-slate-600"><X size={20} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-5">
              {user ? (
                <a onClick={closeDrawer} href="/dashboard" className="mb-4 flex items-center justify-between rounded-3xl bg-slate-950 p-4 text-white">
                  <span className="flex items-center gap-3"><LayoutDashboard size={22} /><span><strong className="block">داشبورد کاربری</strong><span className="text-xs text-slate-300">سرویس‌ها و پرداخت‌ها</span></span></span>
                  <span className="text-xs font-bold text-slate-300">←</span>
                </a>
              ) : (
                <a onClick={closeDrawer} href="/auth/register" className="mb-4 flex items-center justify-between rounded-3xl bg-slate-950 p-4 text-white">
                  <span className="flex items-center gap-3"><Sparkles size={22} /><span><strong className="block">ساخت حساب</strong><span className="text-xs text-slate-300">شروع خرید و مدیریت سرویس</span></span></span>
                  <span className="text-xs font-bold text-slate-300">←</span>
                </a>
              )}

              <div className="grid gap-3">
                {serviceGroups.map((group) => (
                  <section key={group.title} className="rounded-3xl border border-slate-200 bg-slate-50">
                    <button type="button" onClick={() => setExpanded(expanded === group.title ? '' : group.title)} className="flex w-full items-center justify-between p-4 text-right text-sm font-black text-slate-800">
                      {group.title}<ChevronDown className={`h-4 w-4 transition ${expanded === group.title ? 'rotate-180' : ''}`} />
                    </button>
                    {expanded === group.title ? <div className="grid gap-2 px-3 pb-3">{group.items.map((item) => { const Icon = item.icon; return <a onClick={closeDrawer} key={item.href} href={item.href} className="flex items-center gap-3 rounded-2xl bg-white p-3 transition hover:bg-slate-50"><span className="grid h-10 w-10 place-items-center rounded-xl bg-slate-100 text-slate-700"><Icon size={18} /></span><span><strong className="block text-sm text-slate-950">{item.label}</strong><span className="text-xs font-bold text-slate-500">{item.desc}</span></span></a>; })}</div> : null}
                  </section>
                ))}
              </div>
            </div>
            <div className="border-t border-slate-100 p-5 text-xs font-bold leading-6 text-slate-500"><Headphones size={15} className="ml-1 inline" /> پشتیبانی، پرداخت و مدیریت سرویس‌ها از پنل کاربری</div>
          </aside>
        </div>
      ) : null}
    </>
  );
}
