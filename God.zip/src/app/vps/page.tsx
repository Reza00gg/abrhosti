import { Map, Server } from 'lucide-react';
import { CountryGrid } from '@/components/CountryGrid';
import { ProductLanding } from '@/components/ProductLanding';
import { getCatalogByCategory } from '@/lib/catalog';
import { Badge } from '@/components/ui/badge';

export default async function VpsPage() {
  return (
    <>
      <section className="border-b border-slate-200 bg-white py-12">
        <div className="shell">
          <Badge variant="secondary" className="mb-5 border-sky-100 bg-sky-50 text-sky-700"><Map size={13} className="ml-1" /> VPS Locations</Badge>
          <h1 className="text-balance text-4xl font-black tracking-tight text-slate-950 md:text-6xl">سرور مجازی چندکشوره با انتخاب لوکیشن</h1>
          <p className="mt-5 max-w-2xl text-base leading-9 text-slate-500">کشور را انتخاب کنید و مستقیم سفارش دهید.</p>
          <div className="mt-8"><CountryGrid /></div>
        </div>
      </section>
      <ProductLanding visual="vps" eyebrow="VPS Plans" title="همه پلن‌های سرور مجازی" description="پلن‌های VPS با IPv4 اختصاصی، KVM، کنسول وب و تحویل سریع." products={await getCatalogByCategory('vps')} />
    </>
  );
}
