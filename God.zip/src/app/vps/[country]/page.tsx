import { notFound } from 'next/navigation';
import { ProductLanding } from '@/components/ProductLanding';
import { countries } from '@/lib/products';
import { getCatalogVpsByCountry } from '@/lib/catalog';

export function generateStaticParams() {
  return countries.map((country) => ({ country: country.code }));
}

export default async function CountryVpsPage({ params }: { params: { country: string } }) {
  const country = countries.find((item) => item.code === params.country);
  if (!country) notFound();
  return <ProductLanding visual="vps" eyebrow={`${country.flag} ${country.city}`} title={`سرور مجازی ${country.name}`} description={`پلن‌های VPS لوکیشن ${country.name} با شبکه پایدار، IPv4 اختصاصی و ثبت سفارش آنلاین.`} products={await getCatalogVpsByCountry(params.country)} />;
}
