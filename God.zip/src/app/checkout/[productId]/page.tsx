import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Check, Cpu, HardDrive, MemoryStick, Network } from 'lucide-react';
import { CheckoutForm } from '@/components/CheckoutForm';
import { getCategoryLabel, formatPrice } from '@/lib/products';
import { getCatalogProductById } from '@/lib/catalog';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export default async function CheckoutPage({ params }: { params: { productId: string } }) {
  const product = await getCatalogProductById(params.productId);
  if (!product) notFound();
  const specs = [[Cpu, 'CPU', product.cpu], [MemoryStick, 'RAM', product.ram], [HardDrive, 'Storage', product.storage], [Network, 'Traffic', product.bandwidth]] as const;

  return (
    <div className="shell grid gap-6 py-10 lg:grid-cols-[.9fr_1.1fr] lg:items-start">
      <Card className="overflow-hidden">
        <div className="bg-slate-950 p-7 text-white">
          <Badge className="bg-white/10 text-white" variant="outline">{getCategoryLabel(product.category)} • {product.badge}</Badge>
          <h1 className="mt-5 text-3xl font-black tracking-tight">{product.title}</h1>
          <p className="mt-3 text-sm leading-8 text-slate-300">{product.subtitle}</p>
          <div className="mt-5 text-2xl font-black">{formatPrice(product.priceMonthly, product.currency)}</div>
        </div>
        <div className="grid gap-3 p-6">
          <div className="grid grid-cols-2 gap-3">
            {specs.map(([Icon, label, value]) => <div key={label} className="rounded-2xl border border-slate-100 bg-slate-50 p-3"><div className="mb-2 flex items-center gap-2 text-xs font-black text-slate-400"><Icon size={14} />{label}</div><div className="text-sm font-extrabold text-slate-700">{value}</div></div>)}
          </div>
          <ul className="mt-2 grid gap-2 text-sm font-bold text-slate-600">
            {product.features.map((feature) => <li className="flex gap-2 leading-7" key={feature}><Check className="mt-1 h-4 w-4 text-emerald-500" />{feature}</li>)}
          </ul>
          <Button asChild variant="secondary"><Link href={product.route}>بازگشت به محصولات</Link></Button>
        </div>
      </Card>
      <Card className="p-6"><CheckoutForm product={product} /></Card>
    </div>
  );
}
