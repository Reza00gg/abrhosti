import type { Metadata } from 'next';
import { headers } from 'next/headers';
import '@fontsource/vazirmatn/300.css';
import '@fontsource/vazirmatn/400.css';
import '@fontsource/vazirmatn/500.css';
import '@fontsource/vazirmatn/700.css';
import '@fontsource/vazirmatn/800.css';
import '@fontsource/vazirmatn/900.css';
import './globals.css';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Analytics } from '@vercel/analytics/react';
import { SpeedInsights } from '@vercel/speed-insights/next';
import { canonicalUrl, getSeoSettings, isPrimaryHost, isPrivatePath, PRIMARY_SITE_URL } from '@/lib/seo-settings';

export const dynamic = 'force-dynamic';

export async function generateMetadata(): Promise<Metadata> {
  const h = headers();
  const host = h.get('x-forwarded-host') || h.get('host');
  const pathname = h.get('x-pathname') || '/';
  const settings = await getSeoSettings();
  const canIndex = settings.indexingEnabled && isPrimaryHost(host) && !isPrivatePath(pathname);

  return {
    metadataBase: new URL(PRIMARY_SITE_URL),
    title: settings.defaultTitle,
    description: settings.defaultDescription,
    alternates: canIndex ? { canonical: canonicalUrl(pathname) } : undefined,
    robots: {
      index: canIndex,
      follow: canIndex,
      googleBot: {
        index: canIndex,
        follow: canIndex,
        'max-image-preview': 'large',
        'max-snippet': -1,
        'max-video-preview': -1
      }
    },
    openGraph: {
      type: 'website',
      locale: 'fa_IR',
      url: canonicalUrl(pathname),
      siteName: settings.siteName,
      title: settings.defaultTitle,
      description: settings.defaultDescription
    },
    twitter: {
      card: 'summary_large_image',
      title: settings.defaultTitle,
      description: settings.defaultDescription
    }
  };
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body>
        <Header />
        <main>{children}</main>
        <Footer />
        <Analytics />
        <SpeedInsights />
      </body>
    </html>
  );
}
