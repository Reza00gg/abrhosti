import { Suspense } from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { Cloud, Sparkles } from 'lucide-react';
import { AuthForm } from '@/components/AuthForm';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default async function RegisterPage() {
  const user = await getCurrentUser();
  if (user) redirect('/dashboard');

  return (
    <div className="shell grid min-h-[calc(100vh-74px)] gap-8 py-10 lg:grid-cols-[.9fr_1.1fr] lg:items-center">
      <div className="hidden lg:block">
        <Badge variant="secondary" className="mb-5 border-sky-100 bg-sky-50 text-sky-700"><Sparkles size={13} className="ml-1" /> Start Cloud</Badge>
        <h1 className="text-5xl font-black leading-tight tracking-tight text-slate-950">حساب بسازید و اولین سرویس را سفارش دهید</h1>
        <p className="mt-5 text-base leading-9 text-slate-500">ثبت‌نام، ورود و داشبورد واقعی هستند و اطلاعات در دیتابیس PostgreSQL ذخیره می‌شود.</p>
      </div>
      <Card className="mx-auto w-full max-w-md overflow-hidden">
        <div className="bg-slate-950 p-6 text-white"><Cloud className="mb-4 h-8 w-8 text-sky-300" /><h2 className="text-2xl font-black">ساخت حساب کاربری</h2><p className="mt-2 text-sm leading-7 text-slate-300">بعد از ساخت حساب مستقیم وارد پنل می‌شوید.</p></div>
        <div className="p-6"><Suspense fallback={<div className="alert">در حال آماده‌سازی فرم...</div>}><AuthForm mode="register" /></Suspense></div>
      </Card>
    </div>
  );
}
