import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { Cloud, Sparkles } from 'lucide-react';
import { GOOGLE_PENDING_COOKIE } from '@/lib/google-oauth';
import { verifySession } from '@/lib/crypto';
import { GoogleCompleteForm } from '@/components/GoogleCompleteForm';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const dynamic = 'force-dynamic';

export default function GoogleCompletePage() {
  const pending = verifySession(cookies().get(GOOGLE_PENDING_COOKIE)?.value);
  if (!pending) redirect('/auth/login?google_error=state');
  return (
    <div className="shell grid min-h-[calc(100vh-74px)] gap-8 py-10 lg:grid-cols-[.9fr_1.1fr] lg:items-center">
      <div className="hidden lg:block">
        <Badge variant="secondary" className="mb-5 border-sky-100 bg-sky-50 text-sky-700"><Sparkles size={13} className="ml-1" /> Google Account</Badge>
        <h1 className="text-5xl font-black leading-tight tracking-tight text-slate-950">حساب گوگل تایید شد</h1>
        <p className="mt-5 text-base leading-9 text-slate-500">برای تکمیل حساب، نام و رمز عبور خودتان را وارد کنید.</p>
      </div>
      <Card className="mx-auto w-full max-w-md overflow-hidden">
        <div className="bg-slate-950 p-6 text-white"><Cloud className="mb-4 h-8 w-8 text-sky-300" /><h2 className="text-2xl font-black">تکمیل حساب</h2><p className="mt-2 text-sm leading-7 text-slate-300">بعد از تکمیل، مستقیم وارد داشبورد می‌شوید.</p></div>
        <div className="p-6"><GoogleCompleteForm defaultName={pending.name} email={pending.email} /></div>
      </Card>
    </div>
  );
}
