import { notFound, redirect } from 'next/navigation';
import { query } from '@/lib/db';
import { hashEmailToken } from '@/lib/email-verification';
import { createNotification } from '@/lib/notifications';

type Verification = { id: string; user_id: string; email: string; expires_at: string; used_at: string | null; verified_at: string | null };
export const dynamic = 'force-dynamic';

export default async function EmailVerifyLinkPage({ searchParams }: { searchParams: { token?: string } }) {
  const token = String(searchParams.token ?? '');
  if (!token) notFound();
  const result = await query<Verification>('select id,user_id,email,expires_at,used_at,verified_at from email_verifications where token_hash=$1 limit 1', [hashEmailToken(token)]);
  const row = result.rows[0];
  if (!row || row.used_at || row.verified_at || new Date(row.expires_at).getTime() < Date.now()) notFound();
  await query('update email_verifications set verified_at=now(), used_at=now() where id=$1', [row.id]);
  await query('update users set email_verified_at=now(), updated_at=now() where id=$1 and lower(email)=lower($2)', [row.user_id, row.email]);
  await createNotification({ userId: row.user_id, type: 'success', title: 'ایمیل شما تایید شد', message: 'حساب شما فعال شد و اکنون می‌توانید از خدمات سایت استفاده کنید.', metadata: { email: row.email } });
  redirect('/dashboard?email_verified=1');
}
