import { Suspense } from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { Cloud, ShieldCheck } from 'lucide-react';
import { AuthForm } from '@/components/AuthForm';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect('/dashboard');

  return (
    <div className="shell grid min-h-[calc(100vh-74px)] gap-8 py-10 lg:grid-cols-[.9fr_1.1fr] lg:items-center">
      <div className="hidden lg:block">
        <Badge variant="secondary" className="mb-5 border-sky-100 bg-sky-50 text-sky-700"><ShieldCheck size={13} className="ml-1" /> Secure Console</Badge>
        <h1 className="text-5xl font-black leading-tight tracking-tight text-slate-950">ورود به کنسول مدیریت سرویس‌ها</h1>
        <p className="mt-5 text-base leading-9 text-slate-500">پس از ورود می‌توانید سفارش‌ها، سرویس‌ها، وضعیت تحویل و فاکتورها را مدیریت کنید.</p>
      </div>
      <Card className="mx-auto w-full max-w-md overflow-hidden">
        <div className="bg-slate-950 p-6 text-white"><Cloud className="mb-4 h-8 w-8 text-sky-300" /><h2 className="text-2xl font-black">ورود امن</h2><p className="mt-2 text-sm leading-7 text-slate-300">نشست شما با کوکی HttpOnly مدیریت می‌شود.</p></div>
        <div className="p-6"><Suspense fallback={<div className="alert">در حال آماده‌سازی فرم...</div>}><AuthForm mode="login" /></Suspense></div>
      </Card>
    </div>
  );
}
