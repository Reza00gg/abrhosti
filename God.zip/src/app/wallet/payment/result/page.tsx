import Link from 'next/link';
import { CheckCircle2, XCircle, Wallet } from 'lucide-react';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { formatPrice } from '@/lib/products';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

type Row = { id: string; user_id: string; provider: string; amount: number; fee_amount: number; payable_amount: number; currency: string; status: string; reference_id: string | null; failure_message: string | null; verified_at: string | null };
export const dynamic = 'force-dynamic';
export default async function WalletPaymentResult({ searchParams }: { searchParams: { paymentId?: string; status?: string } }) {
  const user = await requireUser();
  const paymentId = String(searchParams.paymentId ?? '');
  const result = paymentId ? await query<Row>('select * from gateway_payments where id=$1 and user_id=$2 limit 1', [paymentId, user.id]) : { rows: [] as Row[] };
  const payment = result.rows[0];
  const success = payment?.status === 'verified';
  return <main className="min-h-screen bg-slate-50 py-10"><div className="shell grid place-items-center"><Card className="w-full max-w-xl overflow-hidden text-center"><div className={`${success?'bg-emerald-50 text-emerald-700':'bg-red-50 text-red-600'} p-8`}><div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-white shadow-sm">{success?<CheckCircle2 size={36}/>:<XCircle size={36}/>}</div><h1 className="mt-5 text-3xl font-black">{success?'پرداخت با موفقیت تایید شد':'پرداخت ناموفق بود'}</h1><p className="mt-3 text-sm leading-8">{success?'موجودی حساب شما به صورت خودکار افزایش یافت.':'موجودی شما تغییر نکرد. در صورت کسر وجه، با پشتیبانی تماس بگیرید.'}</p></div>{payment?<div className="grid gap-3 p-6 text-sm"><div className="flex justify-between rounded-2xl bg-slate-50 p-3"><span className="text-slate-500">درگاه</span><Badge>{payment.provider === 'zibal' ? 'زیبال' : payment.provider}</Badge></div><div className="flex justify-between rounded-2xl bg-slate-50 p-3"><span className="text-slate-500">مبلغ موجودی</span><strong>{formatPrice(payment.amount, payment.currency)}</strong></div><div className="flex justify-between rounded-2xl bg-slate-50 p-3"><span className="text-slate-500">مبلغ پرداخت</span><strong>{formatPrice(payment.payable_amount, payment.currency)}</strong></div>{payment.reference_id?<div className="flex justify-between rounded-2xl bg-slate-50 p-3"><span className="text-slate-500">کد رهگیری</span><strong className="dir-ltr">{payment.reference_id}</strong></div>:null}{payment.failure_message?<div className="alert error">{payment.failure_message}</div>:null}</div>:<div className="p-6"><div className="alert error">اطلاعات پرداخت پیدا نشد.</div></div>}<div className="flex justify-center gap-3 p-6 pt-0"><Button asChild><Link href="/dashboard/wallet"><Wallet size={17}/> مشاهده موجودی</Link></Button><Button asChild variant="secondary"><Link href="/dashboard">داشبورد</Link></Button></div></Card></div></main>
}
