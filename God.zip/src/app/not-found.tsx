import Link from 'next/link';
import { ArrowRight, CloudOff, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-72px)] bg-slate-50">
      <div className="shell grid min-h-[calc(100vh-72px)] place-items-center py-12">
        <Card className="w-full max-w-xl overflow-hidden text-center">
          <div className="p-8 md:p-10">
            <div className="mx-auto grid h-28 w-28 place-items-center rounded-[2rem] bg-white shadow-[0_18px_60px_rgba(15,23,42,.08)] ring-1 ring-slate-200">
              <div className="grid h-20 w-20 place-items-center rounded-[1.5rem] bg-slate-950 text-white">
                <CloudOff size={40} strokeWidth={1.8} />
              </div>
            </div>

            <div className="mt-8 inline-flex rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-black text-slate-500">
              خطای ۴۰۴
            </div>
            <h1 className="mt-4 text-3xl font-black tracking-tight text-slate-950 md:text-4xl">
              صفحه پیدا نشد
            </h1>
            <p className="mx-auto mt-4 max-w-md text-sm leading-8 text-slate-500">
              آدرسی که وارد کرده‌اید وجود ندارد یا ممکن است جابه‌جا شده باشد.
            </p>

            <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
              <Button asChild>
                <Link href="/"><Home size={17} /> برگشت به سایت</Link>
              </Button>
              <Button asChild variant="secondary">
                <Link href="/dashboard"><ArrowRight size={17} /> داشبورد</Link>
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
