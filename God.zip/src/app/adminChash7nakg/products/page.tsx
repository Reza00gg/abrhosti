import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { AdminShell } from '@/components/admin/AdminShell';
import { Card } from '@/components/ui/card';
import { ProductManager } from '@/components/admin/ProductManager';
type Row={id:string;category:string;country:string|null;title:string;subtitle:string;price_monthly:number;currency:string;badge:string;specs:any;features:any;route:string;active:boolean};
export const dynamic='force-dynamic';
export default async function AdminProducts(){const admin=await requireAdmin(); const rows=await query<Row>('select id,category,country,title,subtitle,price_monthly,currency,badge,specs,features,route,active from products order by category,title'); return <AdminShell admin={admin}><section className="grid gap-5"><Card className="p-6"><h1 className="text-3xl font-black">محصولات</h1><p className="mt-2 text-sm text-slate-500">افزودن، ویرایش قیمت، مشخصات و فعال/غیرفعال‌سازی محصول.</p></Card><ProductManager products={rows.rows} /></section></AdminShell>}
