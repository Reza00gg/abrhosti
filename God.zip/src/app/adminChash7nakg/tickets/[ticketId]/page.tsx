import { notFound } from 'next/navigation';
import { MessageCircle } from 'lucide-react';
import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { AdminShell } from '@/components/admin/AdminShell';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TicketReplyForm } from '@/components/tickets/TicketReplyForm';
import { AdminCloseTicketButton } from '@/components/tickets/AdminCloseTicketButton';
import { formatTehranDateTime } from '@/lib/date';
import { requireTicketsHost } from '@/lib/host';
import { ticketPriorityLabel, ticketPriorityVariant, ticketStatusLabel, ticketStatusVariant } from '@/lib/ticket-labels';

type Ticket = { id: string; subject: string; priority: string; status: string; created_at: string; name: string; email: string };
type Msg = { id: string; sender_role: string; message: string; created_at: string };
export const dynamic='force-dynamic';
export default async function AdminTicketDetailPage({params}:{params:{ticketId:string}}){ if(!requireTicketsHost()) notFound(); const admin=await requireAdmin(); const ticketResult=await query<Ticket>(`select t.id,t.subject,t.priority,t.status,t.created_at,u.name,u.email from tickets t join users u on u.id=t.user_id where t.id=$1 limit 1`,[params.ticketId]); const ticket=ticketResult.rows[0]; if(!ticket) notFound(); const messages=await query<Msg>('select id,sender_role,message,created_at from ticket_messages where ticket_id=$1 order by created_at asc',[ticket.id]); return <AdminShell admin={admin}><section className="grid gap-5"><Card className="p-6"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-start"><div><Badge variant={ticketStatusVariant(ticket.status) as any}>{ticketStatusLabel(ticket.status)}</Badge><h1 className="mt-4 flex items-center gap-2 text-3xl font-black"><MessageCircle size={30}/>{ticket.subject}</h1><p className="mt-2 text-sm font-bold text-slate-500">{ticket.name} • <span className="dir-ltr">{ticket.email}</span></p><div className="mt-3 flex flex-wrap gap-2"><Badge variant={ticketPriorityVariant(ticket.priority) as any}>{ticketPriorityLabel(ticket.priority)}</Badge><span className="text-sm font-bold text-slate-400">{formatTehranDateTime(ticket.created_at)}</span></div></div><AdminCloseTicketButton ticketId={ticket.id} disabled={ticket.status==='closed'} /></div></Card><Card className="grid gap-4 bg-slate-50 p-4 md:p-5">{messages.rows.map(m=><div key={m.id} className={`max-w-[88%] rounded-3xl p-4 shadow-sm ${m.sender_role==='admin'?'ml-auto bg-slate-950 text-white':'mr-auto bg-white text-slate-900 border border-slate-200'}`}><div className="mb-2 text-xs font-black opacity-70">{m.sender_role==='admin'?'پشتیبانی':'کاربر'} • {formatTehranDateTime(m.created_at)}</div><p className="whitespace-pre-wrap text-sm leading-8">{m.message}</p></div>)}</Card><TicketReplyForm ticketId={ticket.id} endpoint={`/api/admin/tickets/${ticket.id}/reply`} disabled={ticket.status==='closed'} /></section></AdminShell> }
