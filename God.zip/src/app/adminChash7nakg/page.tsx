import { redirect } from 'next/navigation';
import { LockKeyhole } from 'lucide-react';
import { getCurrentAdmin } from '@/lib/auth';
import { AdminLoginForm } from '@/components/admin/AdminLoginForm';

export const dynamic = 'force-dynamic';

export default async function AdminLoginPage() {
  const admin = await getCurrentAdmin();
  if (admin) redirect('/adminChash7nakg/dashboard');

  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 p-4">
      <section className="w-full max-w-sm">
        <div className="mb-6 text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-950 text-white shadow-sm">
            <LockKeyhole size={22} />
          </div>
          <h1 className="mt-4 text-2xl font-black text-slate-950">ورود مدیر</h1>
          <p className="mt-2 text-sm text-slate-500">فقط کاربران مجاز امکان ورود دارند.</p>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <AdminLoginForm />
        </div>
      </section>
    </main>
  );
}
