import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { formatPrice } from '@/lib/products';
import { AdminShell } from '@/components/admin/AdminShell';
import { Card } from '@/components/ui/card';
import { OrderStatusForm } from '@/components/admin/OrderStatusForm';
import { formatTehranDateTime } from '@/lib/date';
type Row={id:string;order_number:string;email:string;status:string;payment_status:string;provision_status:string;total_amount:number;currency:string;created_at:string;items:string};
export const dynamic='force-dynamic';
export default async function AdminOrders(){const admin=await requireAdmin(); const rows=await query<Row>(`select o.*, u.email, string_agg(oi.title, '، ') as items from orders o join users u on u.id=o.user_id left join order_items oi on oi.order_id=o.id group by o.id,u.email order by o.created_at desc`); return <AdminShell admin={admin}><section className="grid gap-5"><Card className="p-6"><h1 className="text-3xl font-black">سفارش‌ها</h1><p className="mt-2 text-sm text-slate-500">لیست کامل سفارش‌ها و وضعیت پرداخت/تحویل.</p></Card><Card className="overflow-x-auto"><table className="table min-w-[900px]"><thead><tr><th>شماره</th><th>کاربر</th><th>محصول</th><th>وضعیت</th><th>پرداخت</th><th>تحویل</th><th>مبلغ</th><th>کنترل</th><th>تاریخ</th></tr></thead><tbody>{rows.rows.map(o=><tr key={o.id}><td className="dir-ltr">{o.order_number}</td><td className="dir-ltr">{o.email}</td><td>{o.items}</td><td>{o.status}</td><td>{o.payment_status}</td><td>{o.provision_status}</td><td>{formatPrice(o.total_amount,o.currency)}</td><td><OrderStatusForm orderId={o.id} status={o.status} provision={o.provision_status}/></td><td>{formatTehranDateTime(o.created_at)}</td></tr>)}</tbody></table></Card></section></AdminShell>}
