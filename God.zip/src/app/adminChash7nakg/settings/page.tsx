import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { AdminShell } from '@/components/admin/AdminShell';
import { Card } from '@/components/ui/card';
import { CardSettingsForm } from '@/components/admin/CardSettingsForm';
import { GatewaySettingsForm } from '@/components/admin/GatewaySettingsForm';
import { SmsSettingsForm } from '@/components/admin/SmsSettingsForm';
import { SeoSettingsForm } from '@/components/admin/SeoSettingsForm';
import { EmailSettingsForm } from '@/components/admin/EmailSettingsForm';
import { defaultEmailSettings } from '@/lib/email-settings';
import { defaultSeoSettings } from '@/lib/seo-settings';
import { AdminPasswordForm } from '@/components/admin/AdminPasswordForm';
import { ResetDataForm } from '@/components/admin/ResetDataForm';
import { defaultGatewaySettings } from '@/lib/gateway-settings';
import { defaultSmsSettings } from '@/lib/sms-settings';
import { maskSecret } from '@/lib/secure-settings';

type SettingRow = { value: any };
export const dynamic = 'force-dynamic';

export default async function AdminSettings() {
  const admin = await requireAdmin();
  const setting = await query<SettingRow>("select value from app_settings where key='card_to_card' limit 1");
  const initial = setting.rows[0]?.value ?? { bank: '', cardNumber: '', iban: '', ownerName: '', description: '' };

  const gatewaySetting = await query<SettingRow>("select value from app_settings where key='payment_gateways' limit 1");
  const gateways = { ...defaultGatewaySettings, ...(gatewaySetting.rows[0]?.value ?? {}) };
  const gatewayInitial = { ...gateways, zibalMasked: maskSecret(gateways.zibal?.merchantEncrypted), zarinpalMasked: maskSecret(gateways.zarinpal?.merchantEncrypted) };

  const smsSetting = await query<SettingRow>("select value from app_settings where key='sms_settings' limit 1");
  const sms = { ...defaultSmsSettings, ...(smsSetting.rows[0]?.value ?? {}) };
  const smsInitial = { ...sms, apiKeyMasked: maskSecret(sms.apiKeyEncrypted) };
  const emailSetting = await query<SettingRow>("select value from app_settings where key='email_settings' limit 1");
  const email = { ...defaultEmailSettings, ...(emailSetting.rows[0]?.value ?? {}) };
  const emailInitial = { ...email, apiKeyMasked: maskSecret(email.apiKeyEncrypted) };
  const seoSetting = await query<SettingRow>("select value from app_settings where key='seo_settings' limit 1");
  const seoInitial = { ...defaultSeoSettings, ...(seoSetting.rows[0]?.value ?? {}) };

  return (
    <AdminShell admin={admin}>
      <section className="grid gap-5">
        <Card className="p-6">
          <h1 className="text-3xl font-black">تنظیمات پرداخت</h1>
          <p className="mt-2 text-sm text-slate-500">مدیریت کارت‌به‌کارت، درگاه پرداخت، پیامک و امنیت ادمین.</p>
        </Card>
        <div className="grid gap-5 lg:grid-cols-2">
          <Card className="p-6 lg:col-span-2">
            <h2 className="mb-4 text-xl font-black">تنظیمات سئو و ایندکس</h2>
            <SeoSettingsForm initial={seoInitial} />
          </Card>
          <Card className="p-6">
            <h2 className="mb-4 text-xl font-black">اطلاعات کارت‌به‌کارت</h2>
            <CardSettingsForm initial={initial} />
          </Card>
          <Card className="p-6">
            <h2 className="mb-4 text-xl font-black">درگاه پرداخت آنلاین</h2>
            <GatewaySettingsForm initial={gatewayInitial} />
          </Card>
          <Card className="p-6">
            <h2 className="mb-4 text-xl font-black">تایید ایمیل</h2>
            <EmailSettingsForm initial={emailInitial} />
          </Card>
          <Card className="p-6">
            <h2 className="mb-4 text-xl font-black">تایید پیامکی</h2>
            <SmsSettingsForm initial={smsInitial} />
          </Card>
          <Card className="p-6">
            <h2 className="mb-4 text-xl font-black">امنیت ادمین</h2>
            <AdminPasswordForm />
          </Card>
          <Card className="p-6 lg:col-span-2">
            <h2 className="mb-4 text-xl font-black text-red-600">ریست اطلاعات سایت</h2>
            <ResetDataForm />
          </Card>
        </div>
      </section>
    </AdminShell>
  );
}
