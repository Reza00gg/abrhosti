import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { AdminShell } from '@/components/admin/AdminShell';
import { Card } from '@/components/ui/card';
import { UserDirectory } from '@/components/admin/UserDirectory';

type Row = {
  id: string;
  name: string;
  email: string;
  role: string;
  created_at: string;
  banned_at: string | null;
  deleted_at: string | null;
  password_hash: string;
  orders: string;
  balance: number;
  currency: string;
  last_login: string | null;
  phone: string | null;
  phone_verified_at: string | null;
  email_verified_at: string | null;
};
export const dynamic = 'force-dynamic';

export default async function AdminUsers() {
  const admin = await requireAdmin();
  const rows = await query<Row>(
    `select u.id, u.name, u.email, u.role, u.created_at, u.banned_at, u.deleted_at, u.password_hash, u.email_verified_at, u.phone, u.phone_verified_at,
            count(o.id)::text as orders,
            coalesce(w.balance, 0) as balance,
            coalesce(w.currency, 'تومان') as currency,
            max(a.created_at) filter (where a.event = 'auth.login') as last_login
     from users u
     left join orders o on o.user_id = u.id
     left join user_wallets w on w.user_id = u.id
     left join audit_events a on a.user_id = u.id
     group by u.id, w.balance, w.currency
     order by u.created_at desc`
  );
  return (
    <AdminShell admin={admin}>
      <section className="grid gap-5">
        <Card className="p-6">
          <h1 className="text-3xl font-black">کاربران</h1>
          <p className="mt-2 text-sm text-slate-500">مدیریت کاربران، وضعیت حساب، موجودی و دسترسی‌ها.</p>
        </Card>
        <UserDirectory users={rows.rows} />
      </section>
    </AdminShell>
  );
}
