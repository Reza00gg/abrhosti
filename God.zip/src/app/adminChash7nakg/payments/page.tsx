import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { AdminShell } from '@/components/admin/AdminShell';
import { PaymentTabs } from '@/components/admin/PaymentTabs';
import { Card } from '@/components/ui/card';

type Row = { id: string; order_number: string | null; topup_ref: string | null; amount: number; payer_name: string; tracking_number: string | null; receipt_file_name: string; receipt_mime: string; status: string; created_at: string; email: string; purpose: 'service_order' | 'wallet_topup' };
export const dynamic = 'force-dynamic';

export default async function PaymentsPage() {
  const admin = await requireAdmin();
  const rows = await query<Row>(`select pr.id, pr.amount, pr.payer_name, pr.tracking_number, pr.receipt_file_name, pr.receipt_mime, pr.status, pr.created_at, pr.purpose, o.order_number, case when wt.id is not null then 'TOPUP-' || left(wt.id, 8) else null end as topup_ref, u.email from payment_receipts pr left join orders o on o.id=pr.order_id left join wallet_topups wt on wt.id=pr.topup_id join users u on u.id=pr.user_id order by pr.created_at desc`);
  return (
    <AdminShell admin={admin}>
      <section className="grid gap-5">
        <Card className="p-6">
          <h1 className="text-3xl font-black">واریزی‌ها</h1>
          <p className="mt-2 text-sm text-slate-500">بین سفارشات و افزایش موجودی جابه‌جا شوید.</p>
        </Card>
        <PaymentTabs rows={rows.rows} />
      </section>
    </AdminShell>
  );
}
