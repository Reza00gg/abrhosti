import type { MetadataRoute } from 'next';
import { headers } from 'next/headers';
import { countries } from '@/lib/products';
import { getSeoSettings, isPrimaryHost, PRIMARY_SITE_URL } from '@/lib/seo-settings';

export const dynamic = 'force-dynamic';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const host = headers().get('x-forwarded-host') || headers().get('host');
  const settings = await getSeoSettings();
  if (!settings.indexingEnabled || !isPrimaryHost(host)) return [];

  const now = new Date();
  const routes = [
    '/',
    '/hosting/cloud',
    '/hosting/shared',
    '/hosting/dedicated',
    '/vps',
    ...countries.map((country) => `/vps/${country.code}`),
    '/domains'
  ];

  return routes.map((route) => ({
    url: `${PRIMARY_SITE_URL}${route}`,
    lastModified: now,
    changeFrequency: route === '/' ? 'daily' : 'weekly',
    priority: route === '/' ? 1 : route.startsWith('/hosting') || route === '/vps' || route === '/domains' ? 0.85 : 0.7
  }));
}
