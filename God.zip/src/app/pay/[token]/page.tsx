import { notFound } from 'next/navigation';
import { cookies } from 'next/headers';
import { Copy, CreditCard, ShieldCheck, Wallet } from 'lucide-react';
import { query } from '@/lib/db';
import { hashToken } from '@/lib/payment';
import { SESSION_COOKIE } from '@/lib/auth';
import { verifySession } from '@/lib/crypto';
import { formatPrice } from '@/lib/products';
import { PaymentMethodTabs } from '@/components/PaymentMethodTabs';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { getGatewaySettings, calculateGatewayAmounts } from '@/lib/gateway-settings';
import { getCurrentHost } from '@/lib/host';
import { isPaymentAllowedHost } from '@/lib/payment-host';

type PayRow = {
  session_id: string;
  purpose: 'service_order' | 'wallet_topup';
  order_id: string | null;
  topup_id: string | null;
  reference_number: string;
  total_amount: number;
  currency: string;
  domain_name: string | null;
  expires_at: string;
  used_at: string | null;
  title: string;
  category: string;
  cycle: string;
  user_id: string;
};
type SettingRow = { value: { bank: string; cardNumber: string; iban: string; ownerName: string; description: string } };

export const dynamic = 'force-dynamic';

export default async function PayPage({ params }: { params: { token: string } }) {
  const session = verifySession(cookies().get(SESSION_COOKIE)?.value);
  if (!session) notFound();
  await query(`delete from payment_sessions where used_at is not null and used_at < now() - interval '30 seconds'`);
  const result = await query<PayRow>(
    `select ps.id as session_id, ps.purpose, ps.order_id, ps.topup_id, ps.expires_at, ps.used_at, ps.user_id,
      coalesce(o.order_number, 'TOPUP-' || left(wt.id, 8)) as reference_number,
      coalesce(o.total_amount, wt.amount) as total_amount,
      coalesce(o.currency, wt.currency) as currency,
      o.domain_name,
      case when ps.purpose = 'wallet_topup' then 'افزایش موجودی کیف پول' else oi.title end as title,
      case when ps.purpose = 'wallet_topup' then 'wallet' else oi.category end as category,
      case when ps.purpose = 'wallet_topup' then 'wallet_topup' else oi.cycle end as cycle
     from payment_sessions ps
     left join orders o on o.id = ps.order_id
     left join order_items oi on oi.order_id = o.id
     left join wallet_topups wt on wt.id = ps.topup_id
     where ps.token_hash=$1 limit 1`,
    [hashToken(params.token)]
  );
  const payment = result.rows[0];
  if (!payment || payment.user_id !== session.sub) notFound();
  if (payment.used_at && Date.now() - new Date(payment.used_at).getTime() > 30_000) {
    await query('delete from payment_sessions where id=$1', [payment.session_id]);
    notFound();
  }
  const settings = await query<SettingRow>(`select value from app_settings where key='card_to_card' limit 1`);
  const card = settings.rows[0]?.value ?? { bank: 'بانک ملت', cardNumber: '6104-3377-0000-0000', iban: 'IR00 0000 0000 0000 0000 0000 00', ownerName: 'ابرهاست', description: 'پس از واریز، فیش را بارگذاری کنید.' };
  const expired = new Date(payment.expires_at).getTime() < Date.now();
  const isWallet = payment.purpose === 'wallet_topup';
  const gatewaySettings = await getGatewaySettings();
  const gatewayAmounts = calculateGatewayAmounts(Number(payment.total_amount), gatewaySettings);
  const onlineAllowed = isPaymentAllowedHost(getCurrentHost());

  return (
    <main className="min-h-screen bg-slate-50 py-8">
      <div className="shell grid gap-6 lg:grid-cols-[.9fr_1.1fr] lg:items-start">
        <Card className="overflow-hidden">
          <div className="bg-slate-950 p-7 text-white">
            <Badge className="bg-white/10 text-white" variant="outline">{isWallet ? <Wallet size={13} className="ml-1" /> : <CreditCard size={13} className="ml-1" />} {isWallet ? 'Wallet Top-up' : 'Card to Card'}</Badge>
            <h1 className="mt-5 text-3xl font-black">{isWallet ? 'افزایش موجودی' : 'پرداخت کارت‌به‌کارت'}</h1>
            <p className="mt-3 text-sm leading-8 text-slate-300">{isWallet ? 'برای افزایش موجودی می‌توانید کارت‌به‌کارت یا درگاه پرداخت را انتخاب کنید.' : 'این صفحه پرداخت مخصوص سفارش شماست و دارای توکن امن است.'}</p>
          </div>
          <div className="grid gap-3 p-6">
            <div className="flex justify-between rounded-2xl bg-slate-50 p-4"><span className="font-bold text-slate-500">شناسه</span><strong className="dir-ltr">{payment.reference_number}</strong></div>
            <div className="flex justify-between rounded-2xl bg-slate-50 p-4"><span className="font-bold text-slate-500">عنوان</span><strong>{payment.title}</strong></div>
            <div className="flex justify-between rounded-2xl bg-slate-50 p-4"><span className="font-bold text-slate-500">مبلغ</span><strong className="text-lg text-slate-950">{formatPrice(payment.total_amount, payment.currency)}</strong></div>
            <div className="rounded-2xl border border-sky-100 bg-sky-50 p-4 text-sm leading-8 text-sky-800"><ShieldCheck className="mb-2 h-5 w-5" /> {isWallet ? 'در پرداخت آنلاین، موجودی پس از تایید بانکی به‌صورت خودکار اضافه می‌شود؛ در کارت‌به‌کارت پس از تایید مدیر.' : 'بعد از ارسال فیش، سفارش در وضعیت در انتظار تایید قرار می‌گیرد.'}</div>
          </div>
        </Card>

        <Card className="p-6">
          {expired || payment.used_at ? (
            <div className="alert error">{expired ? 'مهلت این صفحه پرداخت منقضی شده است.' : 'برای این پرداخت قبلاً فیش ثبت شده است.'}</div>
          ) : (
            <PaymentMethodTabs
              token={params.token}
              walletOnly={isWallet}
              gatewayProps={{ amount: gatewayAmounts.amount, feeAmount: gatewayAmounts.feeAmount, payableAmount: gatewayAmounts.payableAmount, onlineAllowed, gatewayEnabled: Boolean(gatewaySettings.enabled), zibalEnabled: Boolean(gatewaySettings.zibal.enabled), zarinpalEnabled: Boolean(gatewaySettings.zarinpal.enabled) }}
              cardNode={<>
                <h2 className="text-2xl font-black text-slate-950">اطلاعات واریز</h2>
                <div className="mt-5 grid gap-3 rounded-3xl border border-slate-200 bg-slate-50 p-4">
                  <div className="flex justify-between gap-4"><span className="font-bold text-slate-500">بانک</span><strong>{card.bank}</strong></div>
                  <div className="flex justify-between gap-4"><span className="font-bold text-slate-500">به نام</span><strong>{card.ownerName}</strong></div>
                  <div className="flex justify-between gap-4"><span className="font-bold text-slate-500">شماره کارت</span><strong className="dir-ltr flex items-center gap-2"><Copy size={14} />{card.cardNumber}</strong></div>
                  <div className="flex justify-between gap-4"><span className="font-bold text-slate-500">شبا</span><strong className="dir-ltr text-xs">{card.iban}</strong></div>
                </div>
                <p className="my-5 text-sm leading-8 text-slate-500">{card.description}</p>
              </>}
            />
          )}
        </Card>
      </div>
    </main>
  );
}
