import { Wallet, Clock3 } from 'lucide-react';
import { DashboardShell } from '@/components/DashboardShell';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { getWalletBalance } from '@/lib/wallet';
import { formatPrice } from '@/lib/products';
import { WalletTopupForm } from '@/components/WalletTopupForm';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatTehranDateTime } from '@/lib/date';

type Topup = { id: string; amount: number; currency: string; status: string; payment_status: string; created_at: string };
export const dynamic = 'force-dynamic';
function statusLabel(status: string) { const map: Record<string,string> = { pending_payment:'در انتظار پرداخت', awaiting_admin_approval:'در انتظار تایید', approved:'تایید شده', rejected:'رد شده' }; return map[status] ?? status; }
function variant(status: string) { return status === 'approved' ? 'success' : status === 'rejected' ? 'secondary' : 'warning' as any; }
export default async function WalletPage() {
  const user = await requireUser();
  const wallet = await getWalletBalance(user.id);
  const topups = await query<Topup>('select id, amount, currency, status, payment_status, created_at from wallet_topups where user_id=$1 order by created_at desc limit 12', [user.id]);
  return <DashboardShell user={user}><section className="grid gap-5"><Card className="p-6"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><h1 className="flex items-center gap-2 text-3xl font-black text-slate-950"><Wallet size={30}/> موجودی حساب</h1><p className="mt-2 text-sm text-slate-500">افزایش موجودی با کارت‌به‌کارت و تایید مدیر.</p></div><div className="rounded-2xl bg-slate-950 px-5 py-4 text-white"><span className="text-xs text-slate-300">موجودی</span><strong className="block text-2xl">{formatPrice(wallet.balance, wallet.currency)}</strong></div></div></Card><div className="grid gap-5 lg:grid-cols-[.9fr_1.1fr]"><Card className="p-6"><WalletTopupForm minAmount={user.role === 'admin' ? 1000 : 50000} maxAmount={10000000} isAdmin={user.role === 'admin'} /></Card><Card className="overflow-hidden"><div className="border-b border-slate-100 p-5"><h2 className="text-xl font-black">آخرین افزایش موجودی‌ها</h2></div>{topups.rows.length?<div className="grid divide-y divide-slate-100">{topups.rows.map(t=><div key={t.id} className="flex items-center justify-between gap-3 p-4"><div><strong>{formatPrice(t.amount,t.currency)}</strong><p className="mt-1 flex items-center gap-1 text-xs text-slate-500"><Clock3 size={13}/>{formatTehranDateTime(t.created_at)}</p></div><Badge variant={variant(t.status)}>{statusLabel(t.status)}</Badge></div>)}</div>:<div className="p-5 text-sm text-slate-500">هنوز افزایشی ثبت نشده است.</div>}</Card></div></section></DashboardShell>;
}
