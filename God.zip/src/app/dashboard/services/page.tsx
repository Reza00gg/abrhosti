import { DashboardShell } from '@/components/DashboardShell';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { formatPrice } from '@/lib/products';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

type ServiceRow = { id: string; order_number: string; provision_status: string; total_amount: number; currency: string; created_at: string; title: string; category: string; cycle: string };
export const dynamic = 'force-dynamic';

function provisionLabel(status: string) { const map: Record<string,string> = { queued: 'در صف تحویل', waiting_for_receipt: 'در انتظار فیش', awaiting_admin_approval: 'در انتظار تایید', on_hold: 'متوقف' }; return map[status] ?? status; }

export default async function ServicesPage() {
  const user = await requireUser();
  const services = await query<ServiceRow>(`select o.id, o.order_number, o.provision_status, o.total_amount, o.currency, o.created_at, oi.title, oi.category, oi.cycle from orders o join order_items oi on oi.order_id = o.id where o.user_id = $1 order by o.created_at desc`, [user.id]);
  return (
    <DashboardShell user={user}>
      <section className="grid gap-5">
        <Card className="p-6"><h1 className="text-3xl font-black text-slate-950">سرویس‌های من</h1><p className="mt-2 text-sm leading-8 text-slate-500">سرویس‌های خریداری‌شده و وضعیت تحویل.</p></Card>
        <div className="grid gap-4 md:grid-cols-2">
          {services.rows.length ? services.rows.map((service) => <Card className="p-5" key={`${service.id}-${service.title}`}><Badge>{service.category}</Badge><h3 className="mt-4 text-xl font-black text-slate-950">{service.title}</h3><p className="mt-1 text-sm font-bold text-slate-400 dir-ltr">{service.order_number}</p><div className="mt-5 grid gap-3 rounded-2xl bg-slate-50 p-4 text-sm"><div className="flex justify-between"><span className="text-slate-500">وضعیت</span><strong className="text-slate-950">{provisionLabel(service.provision_status)}</strong></div><div className="flex justify-between"><span className="text-slate-500">دوره</span><strong className="text-slate-950">{service.cycle === 'yearly' ? 'سالانه' : service.cycle === 'quarterly' ? 'سه‌ماهه' : 'ماهانه'}</strong></div><div className="flex justify-between"><span className="text-slate-500">مبلغ</span><strong className="text-slate-950">{formatPrice(service.total_amount, service.currency)}</strong></div></div></Card>) : <Card className="p-5"><div className="alert">فعلاً سرویسی ندارید.</div></Card>}
        </div>
      </section>
    </DashboardShell>
  );
}
