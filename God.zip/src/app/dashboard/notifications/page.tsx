import Link from 'next/link';
import { Bell, CheckCircle2, Clock3, CreditCard, Wallet, AlertCircle, ArrowLeft } from 'lucide-react';
import { DashboardShell } from '@/components/DashboardShell';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MarkNotificationsReadButton } from '@/components/MarkNotificationsReadButton';
import { formatTehranDateTime } from '@/lib/date';
import { NotificationsPagination } from '@/components/NotificationsPagination';

type NotificationRow = { id: string; type: string; title: string; message: string; read_at: string | null; created_at: string; metadata: { payUrl?: string; [key: string]: unknown } };
export const dynamic = 'force-dynamic';
const PAGE_SIZE = 5;

function icon(type: string) {
  if (type === 'wallet') return <Wallet size={18} />;
  if (type === 'payment') return <CreditCard size={18} />;
  if (type === 'success') return <CheckCircle2 size={18} />;
  if (type === 'error') return <AlertCircle size={18} />;
  return <Bell size={18} />;
}
function tone(type: string) {
  if (type === 'success') return 'bg-emerald-50 text-emerald-700';
  if (type === 'error') return 'bg-red-50 text-red-600';
  if (type === 'wallet') return 'bg-sky-50 text-sky-700';
  if (type === 'payment') return 'bg-amber-50 text-amber-700';
  return 'bg-slate-100 text-slate-700';
}

export default async function NotificationsPage({ searchParams }: { searchParams: { page?: string } }) {
  const user = await requireUser();
  const page = Math.max(1, Number(searchParams.page ?? 1) || 1);
  const offset = (page - 1) * PAGE_SIZE;
  const [result, counts] = await Promise.all([
    query<NotificationRow>(
      `select id, type, title, message, read_at, metadata, created_at from notifications where user_id=$1 order by created_at desc limit $2 offset $3`,
      [user.id, PAGE_SIZE, offset]
    ),
    query<{ total: string; unread: string }>(
      `select count(*)::text as total, count(*) filter (where read_at is null)::text as unread from notifications where user_id=$1`,
      [user.id]
    )
  ]);
  const total = Number(counts.rows[0]?.total ?? 0);
  const unread = Number(counts.rows[0]?.unread ?? 0);
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <DashboardShell user={user}>
      <section id="notifications-section" className="scroll-mt-20 grid gap-5">
        <Card className="p-6">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
            <div>
              <Badge variant={unread ? 'warning' : 'secondary'} className="mb-3">{unread.toLocaleString('fa-IR')} خوانده‌نشده</Badge>
              <h1 id="notifications-title" className="scroll-mt-28 flex items-center gap-2 text-3xl font-black text-slate-950"><Bell size={29}/> اعلان‌ها</h1>
              <p className="mt-2 text-sm leading-8 text-slate-500">پیام‌های مربوط به سفارش‌ها، پرداخت‌ها و موجودی حساب شما.</p>
            </div>
            {total ? <MarkNotificationsReadButton /> : null}
          </div>
        </Card>

        <Card className="overflow-hidden">
          {result.rows.length ? (
            <div className="divide-y divide-slate-100">
              {result.rows.map((item) => {
                const payUrl = typeof item.metadata?.payUrl === 'string' ? item.metadata.payUrl : null;
                return (
                  <article key={item.id} className={`grid gap-3 p-5 md:grid-cols-[auto_1fr_auto] md:items-start ${item.read_at ? 'bg-white' : 'bg-slate-50/70'}`}>
                    <span className={`grid h-11 w-11 place-items-center rounded-2xl ${tone(item.type)}`}>{icon(item.type)}</span>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-black text-slate-950">{item.title}</h3>
                        {!item.read_at ? <Badge variant="warning" className="rounded-md px-2 py-1 text-[11px]">جدید</Badge> : null}
                      </div>
                      <p className="mt-2 text-sm leading-8 text-slate-500">{item.message}</p>
                      {payUrl ? (
                        <Button asChild size="sm" variant="secondary" className="mt-3">
                          <Link href={payUrl}>پرداخت <ArrowLeft size={14} /></Link>
                        </Button>
                      ) : null}
                    </div>
                    <span className="flex items-center gap-1 text-xs font-bold text-slate-400"><Clock3 size={13}/>{formatTehranDateTime(item.created_at)}</span>
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center text-sm font-bold text-slate-500">هنوز اعلانی ندارید.</div>
          )}
        </Card>

        {total > PAGE_SIZE ? <NotificationsPagination page={page} totalPages={totalPages} total={total} /> : null}
      </section>
    </DashboardShell>
  );
}
