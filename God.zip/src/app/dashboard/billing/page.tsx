import Link from 'next/link';
import { DashboardShell } from '@/components/DashboardShell';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { formatPrice } from '@/lib/products';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { formatTehranDateTime } from '@/lib/date';

type InvoiceRow = { id: string; order_number: string; payment_status: string; total_amount: number; currency: string; created_at: string };
export const dynamic = 'force-dynamic';

export default async function BillingPage() {
  const user = await requireUser();
  const invoices = await query<InvoiceRow>('select id, order_number, payment_status, total_amount, currency, created_at from orders where user_id = $1 order by created_at desc', [user.id]);
  return (
    <DashboardShell user={user}>
      <section className="grid gap-5">
        <Card className="p-6"><h1 className="text-3xl font-black text-slate-950">مالی و فاکتورها</h1><p className="mt-2 text-sm leading-8 text-slate-500">پرداخت‌ها فعلاً شبیه‌سازی‌شده‌اند و آماده اتصال به درگاه هستند.</p></Card>
        <Card className="overflow-hidden">
          {invoices.rows.length ? <div className="overflow-x-auto"><table className="table min-w-[680px]"><thead><tr><th>شماره فاکتور</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th></tr></thead><tbody>{invoices.rows.map((invoice) => <tr key={invoice.id}><td className="dir-ltr">{invoice.order_number}</td><td>{formatPrice(invoice.total_amount, invoice.currency)}</td><td><span className="status">پرداخت موفق آزمایشی</span></td><td>{formatTehranDateTime(invoice.created_at)}</td></tr>)}</tbody></table></div> : <div className="p-5"><div className="alert">هنوز فاکتوری ثبت نشده است.</div><Button asChild className="mt-4"><Link href="/vps">خرید سرویس</Link></Button></div>}
        </Card>
      </section>
    </DashboardShell>
  );
}
