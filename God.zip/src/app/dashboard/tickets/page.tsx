import Link from 'next/link';
import { notFound } from 'next/navigation';
import { MessageCircle, Clock3, ArrowLeft } from 'lucide-react';
import { DashboardShell } from '@/components/DashboardShell';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TicketCreateForm } from '@/components/tickets/TicketCreateForm';
import { formatTehranDateTime } from '@/lib/date';
import { requireTicketsHost } from '@/lib/host';
import { ticketPriorityLabel, ticketPriorityVariant, ticketStatusLabel, ticketStatusVariant } from '@/lib/ticket-labels';

type Ticket = { id: string; subject: string; priority: string; status: string; created_at: string; updated_at: string; messages: string };
export const dynamic = 'force-dynamic';

export default async function TicketsPage() {
  if (!requireTicketsHost()) notFound();
  const user = await requireUser();
  const tickets = await query<Ticket>(`select t.id,t.subject,t.priority,t.status,t.created_at,t.updated_at,count(tm.id)::text as messages from tickets t left join ticket_messages tm on tm.ticket_id=t.id where t.user_id=$1 group by t.id order by t.updated_at desc`, [user.id]);
  return <DashboardShell user={user}><section className="grid gap-5"><Card className="p-6"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><h1 className="flex items-center gap-2 text-3xl font-black"><MessageCircle size={30}/> تیکت‌ها</h1><p className="mt-2 text-sm text-slate-500">پیام‌های شما با پشتیبانی سایت.</p></div><TicketCreateForm/></div></Card>{tickets.rows.length?<div className="grid gap-3">{tickets.rows.map(t=><Card key={t.id} className="p-5"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><div className="flex flex-wrap gap-2"><Badge variant={ticketStatusVariant(t.status) as any}>{ticketStatusLabel(t.status)}</Badge><Badge variant={ticketPriorityVariant(t.priority) as any}>{ticketPriorityLabel(t.priority)}</Badge></div><h3 className="mt-3 text-lg font-black">{t.subject}</h3><p className="mt-2 flex items-center gap-2 text-xs font-bold text-slate-400"><Clock3 size={13}/>{formatTehranDateTime(t.updated_at)} • {Number(t.messages).toLocaleString('fa-IR')} پیام</p></div><Button asChild variant="secondary"><Link href={`/dashboard/tickets/${t.id}`}>مشاهده <ArrowLeft size={15}/></Link></Button></div></Card>)}</div>:<Card className="p-8 text-center text-sm font-bold text-slate-500">هنوز تیکتی ثبت نکرده‌اید.</Card>}</section></DashboardShell>
}
