import Link from 'next/link';
import { ArrowLeft, CheckCircle2, Clock3, CreditCard, Server, Wallet } from 'lucide-react';
import { DashboardShell } from '@/components/DashboardShell';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { formatPrice } from '@/lib/products';
import { getWalletBalance } from '@/lib/wallet';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatTehranDateTime } from '@/lib/date';

type OrderRow = { id: string; order_number: string; status: string; payment_status: string; provision_status: string; total_amount: number; currency: string; domain_name: string | null; created_at: string; items: Array<{ title: string; category: string; cycle: string; unitAmount: number }> };
export const dynamic = 'force-dynamic';
function cycleLabel(cycle: string) { return cycle === 'yearly' ? 'سالانه' : cycle === 'quarterly' ? 'سه‌ماهه' : 'ماهانه'; }
function paymentLabel(status: string) { const map: Record<string,string> = { paid_mock: 'موفق آزمایشی', awaiting_card_to_card: 'در انتظار واریز', receipt_submitted: 'رسید ارسال شده', approved_card_to_card: 'تایید شده', rejected: 'رد شده' }; return map[status] ?? status; }
function provisionLabel(status: string) { const map: Record<string,string> = { queued: 'در صف تحویل', waiting_for_receipt: 'در انتظار فیش', awaiting_admin_approval: 'در انتظار تایید', on_hold: 'متوقف' }; return map[status] ?? status; }

export default async function DashboardPage() {
  const user = await requireUser();
  const orders = await query<OrderRow>(`select o.*, coalesce(json_agg(json_build_object('title', oi.title,'category', oi.category,'cycle', oi.cycle,'unitAmount', oi.unit_amount)) filter (where oi.id is not null), '[]') as items from orders o left join order_items oi on oi.order_id = o.id where o.user_id = $1 group by o.id order by o.created_at desc`, [user.id]);
  const wallet = await getWalletBalance(user.id);
  const totalPaid = orders.rows.reduce((sum, order) => sum + Number(order.total_amount), 0);
  const activeServices = orders.rows.filter((order) => ['paid_mock', 'active'].includes(order.status)).length;

  return (
    <DashboardShell user={user}>
      <section className="grid gap-5">
        <Card className="overflow-hidden">
          <div className="grid gap-5 p-6 md:grid-cols-[1fr_auto] md:items-center">
            <div><Badge variant="success" className="mb-3">حساب فعال</Badge><h1 className="text-3xl font-black tracking-tight text-slate-950">داشبورد ابرهاست</h1><p className="mt-2 text-sm leading-8 text-slate-500">نمای کلی سفارش‌ها، پرداخت‌ها و سرویس‌های شما.</p></div>
            <Button asChild><Link href="/hosting/cloud">خرید سرویس جدید <ArrowLeft size={17} /></Link></Button>
          </div>
        </Card>
        <div className="grid gap-4 md:grid-cols-4">
          <Card className="p-5"><Server className="mb-4 h-7 w-7 text-sky-600" /><b className="block text-3xl font-black text-slate-950">{orders.rowCount}</b><span className="text-sm font-bold text-slate-500">کل سفارش‌ها</span></Card>
          <Card className="p-5"><CheckCircle2 className="mb-4 h-7 w-7 text-emerald-600" /><b className="block text-3xl font-black text-slate-950">{activeServices}</b><span className="text-sm font-bold text-slate-500">سرویس پرداخت‌شده</span></Card>
          <Card className="p-5"><CreditCard className="mb-4 h-7 w-7 text-sky-600" /><b className="block text-2xl font-black text-slate-950">{formatPrice(totalPaid)}</b><span className="text-sm font-bold text-slate-500">مجموع سفارش‌ها</span></Card><Card className="p-5"><Wallet className="mb-4 h-7 w-7 text-sky-600" /><b className="block text-2xl font-black text-slate-950">{formatPrice(wallet.balance, wallet.currency)}</b><span className="text-sm font-bold text-slate-500">موجودی</span></Card>
        </div>
        <Card className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-100 p-5"><div><h2 className="text-xl font-black text-slate-950">آخرین سفارش‌ها</h2><p className="mt-1 text-sm text-slate-500">سفارش‌ها مستقیم از دیتابیس خوانده می‌شوند.</p></div><span className="inline-flex items-center gap-2 rounded-full border border-emerald-100 bg-white px-2.5 py-1 text-xs font-extrabold text-slate-700"><span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" /></span>Live</span></div>
          {orders.rows.length ? <div className="overflow-x-auto"><table className="table min-w-[820px]"><thead><tr><th>شماره</th><th>محصول</th><th>دوره</th><th>دامنه</th><th>پرداخت</th><th>تحویل</th><th>مبلغ</th><th>تاریخ</th></tr></thead><tbody>{orders.rows.map((order) => <tr key={order.id}><td className="dir-ltr">{order.order_number}</td><td>{order.items.map((item) => item.title).join('، ')}</td><td>{order.items.map((item) => cycleLabel(item.cycle)).join('، ')}</td><td className="dir-ltr">{order.domain_name ?? '—'}</td><td><span className="status">{paymentLabel(order.payment_status)}</span></td><td><span className="status pending"><Clock3 size={13} /> {provisionLabel(order.provision_status)}</span></td><td>{formatPrice(order.total_amount, order.currency)}</td><td>{formatTehranDateTime(order.created_at)}</td></tr>)}</tbody></table></div> : <div className="p-5"><div className="alert">هنوز سفارشی ندارید. از بخش محصولات، یک سرویس انتخاب کنید.</div></div>}
        </Card>
      </section>
    </DashboardShell>
  );
}
