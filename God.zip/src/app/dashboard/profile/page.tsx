import { UserRound } from 'lucide-react';
import { DashboardShell } from '@/components/DashboardShell';
import { requireUser } from '@/lib/auth';
import { Card } from '@/components/ui/card';
import { PasswordChangeForm } from '@/components/PasswordChangeForm';
import { ProfileEditForm } from '@/components/ProfileEditForm';
import { Badge } from '@/components/ui/badge';

export const dynamic = 'force-dynamic';

function display(value?: string | null) {
  return value?.trim() ? value : 'ثبت نشده';
}

export default async function ProfilePage() {
  const user = await requireUser();

  const profileRows = [
    ['نام', user.name],
    ['ایمیل', user.email, 'ltr'],
    ['نقش', user.role === 'admin' ? 'مدیر' : 'کاربر'],
    ['کشور', display(user.country)],
    ['استان', display(user.province)],
    ['شهر', display(user.city)],
    ['کد پستی', display(user.postal_code), 'ltr'],
    ['آدرس', display(user.address)]
  ] as const;

  return (
    <DashboardShell user={user}>
      <section className="grid gap-5">
        <Card className="p-6">
          <h1 className="text-3xl font-black text-slate-950">پروفایل و امنیت</h1>
          <p className="mt-2 text-sm leading-8 text-slate-500">اطلاعات حساب، آدرس و وضعیت امنیتی ورود.</p>
        </Card>

        <div className="grid gap-4 md:grid-cols-2">
          <Card className="p-6 md:col-span-2">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <UserRound className="mb-4 h-8 w-8 text-sky-600" />
                <Badge variant="secondary">Account</Badge>
                <h3 className="mt-4 text-xl font-black text-slate-950">اطلاعات کاربری</h3>
                <p className="mt-2 text-sm leading-7 text-slate-500">نام، موقعیت و آدرس حساب شما.</p>
              </div>
              <ProfileEditForm user={user} />
            </div>

            <div className="mt-5 grid gap-3 text-sm">
              {profileRows.map(([label, value, direction]) => (
                <div key={label} className="flex items-start justify-between gap-4 border-b border-slate-100 pb-3 last:border-b-0 last:pb-0">
                  <span className="shrink-0 text-slate-500">{label}</span>
                  <strong className={`${direction === 'ltr' ? 'dir-ltr text-left' : 'text-right'} break-words text-slate-950`}>
                    {value}
                  </strong>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 md:col-span-2">
            <h3 className="mb-4 text-xl font-black text-slate-950">تغییر رمز عبور</h3>
            <PasswordChangeForm />
          </Card>
        </div>
      </section>
    </DashboardShell>
  );
}
