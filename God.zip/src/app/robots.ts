import type { MetadataRoute } from 'next';
import { headers } from 'next/headers';
import { getSeoSettings, isPrimaryHost, PRIMARY_SITE_URL } from '@/lib/seo-settings';

export const dynamic = 'force-dynamic';

export default async function robots(): Promise<MetadataRoute.Robots> {
  const host = headers().get('x-forwarded-host') || headers().get('host');
  const settings = await getSeoSettings();

  if (!settings.indexingEnabled || !isPrimaryHost(host)) {
    return {
      rules: [{ userAgent: '*', disallow: '/' }]
    };
  }

  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/adminChash7nakg', '/dashboard', '/auth', '/pay', '/api', '/wallet/payment']
      }
    ],
    sitemap: `${PRIMARY_SITE_URL}/sitemap.xml`,
    host: PRIMARY_SITE_URL
  };
}
