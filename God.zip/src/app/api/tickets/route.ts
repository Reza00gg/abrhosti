import crypto from 'crypto';
import { getPool } from '@/lib/db';
import { requireUser } from '@/lib/auth';
import { jsonError, jsonOk } from '@/lib/http';
import { createNotification } from '@/lib/notifications';
import { isTicketsHostFromRequest } from '@/lib/host';
import { getAccountAccessError } from '@/lib/account-guards';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const priorities = new Set(['low', 'medium', 'high']);

export async function POST(request: Request) {
  if (!isTicketsHostFromRequest(request)) return jsonError('سیستم تیکت در این دامنه فعال نیست.', 404, 'NOT_FOUND');
  const user = await requireUser();
  const accessError = await getAccountAccessError(user);
  if (accessError) return jsonError(accessError.message, 403, accessError.code);
  const body = await request.json();
  const subject = String(body.subject ?? '').trim().slice(0, 160);
  const priority = priorities.has(String(body.priority)) ? String(body.priority) : 'medium';
  const message = String(body.message ?? '').trim().slice(0, 4000);
  if (subject.length < 3) return jsonError('موضوع تیکت را وارد کنید.');
  if (message.length < 5) return jsonError('متن تیکت را کامل وارد کنید.');

  const ticketId = crypto.randomUUID();
  const messageId = crypto.randomUUID();
  const client = await getPool().connect();
  try {
    await client.query('begin');
    await client.query(
      `insert into tickets (id,user_id,subject,priority,status) values ($1,$2,$3,$4,'open_review')`,
      [ticketId, user.id, subject, priority]
    );
    await client.query(
      `insert into ticket_messages (id,ticket_id,sender_id,sender_role,message) values ($1,$2,$3,'user',$4)`,
      [messageId, ticketId, user.id, message]
    );
    await client.query('commit');
    await createNotification({ userId: user.id, type: 'info', title: 'تیکت شما ثبت شد', message: `تیکت «${subject}» برای پشتیبانی ارسال شد.`, metadata: { ticketId } });
    return jsonOk({ ticketId }, { status: 201 });
  } catch (error) {
    await client.query('rollback');
    console.error(error);
    return jsonError('ثبت تیکت انجام نشد.', 500);
  } finally {
    client.release();
  }
}
