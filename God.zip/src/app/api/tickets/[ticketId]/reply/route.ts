import crypto from 'crypto';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { isTicketsHostFromRequest } from '@/lib/host';
import { getAccountAccessError } from '@/lib/account-guards';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ticket = { id: string; user_id: string; status: string; subject: string };

export async function POST(request: Request, { params }: { params: { ticketId: string } }) {
  if (!isTicketsHostFromRequest(request)) return jsonError('سیستم تیکت در این دامنه فعال نیست.', 404, 'NOT_FOUND');
  const user = await requireUser();
  const accessError = await getAccountAccessError(user);
  if (accessError) return jsonError(accessError.message, 403, accessError.code);
  const body = await request.json();
  const message = String(body.message ?? '').trim().slice(0, 4000);
  if (message.length < 2) return jsonError('متن پیام را وارد کنید.');
  const result = await query<Ticket>('select id,user_id,status,subject from tickets where id=$1 and user_id=$2 limit 1', [params.ticketId, user.id]);
  const ticket = result.rows[0];
  if (!ticket) return jsonError('تیکت پیدا نشد.', 404);
  if (ticket.status === 'closed') return jsonError('این تیکت بسته شده است.');
  await query(`insert into ticket_messages (id,ticket_id,sender_id,sender_role,message) values ($1,$2,$3,'user',$4)`, [crypto.randomUUID(), ticket.id, user.id, message]);
  await query(`update tickets set status='open_review', updated_at=now() where id=$1`, [ticket.id]);
  return jsonOk({ sent: true });
}
