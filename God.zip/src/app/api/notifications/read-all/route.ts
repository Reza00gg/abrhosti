import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonOk } from '@/lib/http';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST() {
  const user = await requireUser();
  await query('update notifications set read_at=now() where user_id=$1 and read_at is null', [user.id]);
  return jsonOk({ read: true });
}
