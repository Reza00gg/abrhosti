import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { hashPassword, signSession } from '@/lib/crypto';
import { isValidEmail, jsonError, jsonOk, normalizeEmail } from '@/lib/http';
import { SESSION_COOKIE } from '@/lib/auth';
import { getEmailSettings } from '@/lib/email-settings';
import { sendWelcomeEmailOnce } from '@/lib/welcome-email';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = String(body.name ?? '').trim();
    const email = normalizeEmail(String(body.email ?? ''));
    const password = String(body.password ?? '');

    if (name.length < 3) return jsonError('نام باید حداقل ۳ کاراکتر باشد.');
    if (!isValidEmail(email)) return jsonError('ایمیل معتبر نیست.');
    if (password.length < 8) return jsonError('رمز عبور باید حداقل ۸ کاراکتر باشد.');

    const exists = await query('select id from users where email = $1 limit 1', [email]);
    if (exists.rowCount) return jsonError('قبلاً حسابی با این ایمیل ساخته شده است.', 409, 'EMAIL_EXISTS');

    const emailSettings = await getEmailSettings();
    const id = crypto.randomUUID();
    const passwordHash = hashPassword(password);
    await query(
      `insert into users (id, name, email, password_hash, role, email_verified_at)
       values ($1, $2, $3, $4, 'user', $5)`,
      [id, name, email, passwordHash, emailSettings.enabled ? null : new Date()]
    );

    const h = headers();
    await query(
      `insert into audit_events (id, user_id, event, ip, user_agent, metadata)
       values ($1, $2, 'auth.register', $3, $4, '{}'::jsonb)`,
      [crypto.randomUUID(), id, h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null]
    );

    const token = signSession({ sub: id, email, name });
    cookies().set(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      path: '/',
      maxAge: 60 * 60 * 24 * 7
    });

    await sendWelcomeEmailOnce({ userId: id, email, name, origin: new URL(request.url).origin });
    return jsonOk({ user: { id, name, email, role: 'user' } }, { status: 201 });
  } catch (error) {
    console.error(error);
    return jsonError('ثبت‌نام انجام نشد. اتصال دیتابیس و تنظیمات را بررسی کنید.', 500, 'REGISTER_FAILED');
  }
}
