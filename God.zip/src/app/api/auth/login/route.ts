import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { query } from '@/lib/db';
import { signSession, verifyPassword } from '@/lib/crypto';
import { SESSION_COOKIE } from '@/lib/auth';
import { isValidEmail, jsonError, jsonOk, normalizeEmail } from '@/lib/http';

export const runtime = 'nodejs';

type DbUser = {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  password_hash: string;
  banned_at: string | null;
  banned_reason: string | null;
  deleted_at: string | null;
};

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const email = normalizeEmail(String(body.email ?? ''));
    const password = String(body.password ?? '');

    if (!isValidEmail(email)) return jsonError('ایمیل معتبر نیست.');
    if (!password) return jsonError('رمز عبور را وارد کنید.');

    const result = await query<DbUser>('select id, name, email, role, password_hash, banned_at, banned_reason, deleted_at from users where email = $1 limit 1', [email]);
    const user = result.rows[0];
    if (!user || !verifyPassword(password, user.password_hash)) {
      return jsonError('ایمیل یا رمز عبور اشتباه است.', 401, 'INVALID_CREDENTIALS');
    }

    if (user.deleted_at) {
      return jsonError('این حساب حذف شده است.', 403, 'USER_DELETED');
    }
    if (user.banned_at) {
      return jsonError(user.banned_reason || 'حساب شما مسدود شده است.', 403, 'USER_BANNED');
    }

    const token = signSession({ sub: user.id, email: user.email, name: user.name });
    cookies().set(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      path: '/',
      maxAge: 60 * 60 * 24 * 7
    });

    const h = headers();
    await query(
      `insert into audit_events (id, user_id, event, ip, user_agent, metadata)
       values ($1, $2, 'auth.login', $3, $4, '{}'::jsonb)`,
      [crypto.randomUUID(), user.id, h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null]
    );

    return jsonOk({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    console.error(error);
    return jsonError('ورود انجام نشد. اتصال دیتابیس و تنظیمات را بررسی کنید.', 500, 'LOGIN_FAILED');
  }
}
