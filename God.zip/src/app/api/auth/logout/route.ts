import { cookies } from 'next/headers';
import { SESSION_COOKIE } from '@/lib/auth';
import { jsonOk } from '@/lib/http';

export const runtime = 'nodejs';

export async function POST() {
  cookies().set(SESSION_COOKIE, '', {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 0
  });
  return jsonOk({ loggedOut: true });
}
