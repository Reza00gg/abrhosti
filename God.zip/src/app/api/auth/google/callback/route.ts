import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { SESSION_COOKIE } from '@/lib/auth';
import { signSession } from '@/lib/crypto';
import { exchangeCodeForTokens, getGoogleConfig, GOOGLE_PENDING_COOKIE, GOOGLE_STATE_COOKIE, verifyGoogleIdToken, verifyGoogleState } from '@/lib/google-oauth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type UserRow = { id: string; name: string; email: string; role: 'user' | 'admin'; banned_at: string | null; deleted_at: string | null };

type OAuthRow = { user_id: string };

function errorRedirect(request: Request, mode: string, code: string) {
  return NextResponse.redirect(new URL(`/auth/${mode === 'register' ? 'register' : 'login'}?google_error=${code}`, request.url));
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const error = url.searchParams.get('error');
  const code = url.searchParams.get('code');
  const returnedState = url.searchParams.get('state');
  const state = verifyGoogleState(cookies().get(GOOGLE_STATE_COOKIE)?.value, returnedState);
  cookies().set(GOOGLE_STATE_COOKIE, '', { path: '/', maxAge: 0 });

  if (!state) return errorRedirect(request, 'login', 'state');
  if (error) return errorRedirect(request, state.mode, 'cancelled');
  if (!code) return errorRedirect(request, state.mode, 'missing_code');

  try {
    const config = getGoogleConfig(url.origin);
    const tokens = await exchangeCodeForTokens(code, config);
    const profile = await verifyGoogleIdToken(tokens.id_token);
    const emailVerified = profile.email_verified === true || profile.email_verified === 'true';
    if (!profile.email || !emailVerified) return errorRedirect(request, state.mode, 'email_not_verified');
    const email = profile.email.toLowerCase();
    const googleSub = profile.sub;
    const displayName = profile.name || email.split('@')[0];

    const oauth = await query<OAuthRow>(`select user_id from user_oauth_accounts where provider='google' and provider_user_id=$1 limit 1`, [googleSub]);
    let user: UserRow | undefined;
    if (oauth.rows[0]) {
      const existing = await query<UserRow>('select id, name, email, role, banned_at, deleted_at from users where id=$1 limit 1', [oauth.rows[0].user_id]);
      user = existing.rows[0];
    }
    if (!user) {
      const byEmail = await query<UserRow>('select id, name, email, role, banned_at, deleted_at from users where email=$1 limit 1', [email]);
      user = byEmail.rows[0];
      if (user) {
        await query('update users set email_verified_at=coalesce(email_verified_at, now()), updated_at=now() where id=$1', [user.id]);
        await query(
          `insert into user_oauth_accounts (id, user_id, provider, provider_user_id, email, avatar_url)
           values ($1,$2,'google',$3,$4,$5)
           on conflict (provider, provider_user_id) do update set user_id=excluded.user_id, email=excluded.email, avatar_url=excluded.avatar_url, updated_at=now()`,
          [crypto.randomUUID(), user.id, googleSub, email, profile.picture ?? null]
        );
      }
    }

    if (user) {
      if (user.deleted_at) return errorRedirect(request, state.mode, 'deleted');
      if (user.banned_at) return errorRedirect(request, state.mode, 'banned');
      const token = signSession({ sub: user.id, email: user.email, name: user.name });
      cookies().set(SESSION_COOKIE, token, {
        httpOnly: true,
        sameSite: 'lax',
        secure: process.env.NODE_ENV === 'production',
        path: '/',
        maxAge: 60 * 60 * 24 * 7
      });
      const h = headers();
      await query(
        `insert into audit_events (id, user_id, event, ip, user_agent, metadata) values ($1,$2,'auth.google.login',$3,$4,$5)`,
        [crypto.randomUUID(), user.id, h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null, JSON.stringify({ email })]
      );
      return NextResponse.redirect(new URL(state.next || '/dashboard', request.url));
    }

    const pending = signSession({ sub: googleSub, email, name: displayName }, 60 * 15);
    cookies().set(GOOGLE_PENDING_COOKIE, pending, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      path: '/',
      maxAge: 60 * 15
    });
    return NextResponse.redirect(new URL(`/auth/google/complete?next=${encodeURIComponent(state.next || '/dashboard')}`, request.url));
  } catch (error) {
    console.error(error);
    return errorRedirect(request, state.mode, 'failed');
  }
}
