import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { query } from '@/lib/db';
import { GOOGLE_PENDING_COOKIE } from '@/lib/google-oauth';
import { SESSION_COOKIE } from '@/lib/auth';
import { hashPassword, signSession, verifySession } from '@/lib/crypto';
import { jsonError, jsonOk, normalizeEmail } from '@/lib/http';
import { sendWelcomeEmailOnce } from '@/lib/welcome-email';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type UserRow = { id: string; name: string; email: string; role: 'user' | 'admin'; banned_at: string | null; deleted_at: string | null };

export async function POST(request: Request) {
  const pending = verifySession(cookies().get(GOOGLE_PENDING_COOKIE)?.value);
  if (!pending) return jsonError('جلسه تکمیل حساب گوگل معتبر نیست. دوباره تلاش کنید.', 401, 'GOOGLE_PENDING_EXPIRED');

  const body = await request.json();
  const name = String(body.name ?? '').trim();
  const password = String(body.password ?? '');
  const confirmPassword = String(body.confirmPassword ?? '');
  const next = String(body.next ?? '/dashboard');
  const email = normalizeEmail(pending.email);

  if (name.length < 3) return jsonError('نام باید حداقل ۳ کاراکتر باشد.');
  if (password.length < 8) return jsonError('رمز عبور باید حداقل ۸ کاراکتر باشد.');
  if (password !== confirmPassword) return jsonError('تکرار رمز عبور مطابقت ندارد.');

  const existing = await query<UserRow>('select id, name, email, role, banned_at, deleted_at from users where email=$1 limit 1', [email]);
  let user = existing.rows[0];
  if (user?.deleted_at) return jsonError('این حساب حذف شده است.', 403, 'USER_DELETED');
  if (user?.banned_at) return jsonError('این حساب مسدود شده است.', 403, 'USER_BANNED');

  const isNewUser = !user;
  if (!user) {
    const id = crypto.randomUUID();
    await query(
      `insert into users (id, name, email, password_hash, role, email_verified_at) values ($1,$2,$3,$4,'user',now())`,
      [id, name, email, hashPassword(password)]
    );
    user = { id, name, email, role: 'user', banned_at: null, deleted_at: null };
  } else {
    await query('update users set name=$1, password_hash=$2, email_verified_at=coalesce(email_verified_at, now()), updated_at=now() where id=$3', [name, hashPassword(password), user.id]);
    user.name = name;
  }

  await query(
    `insert into user_oauth_accounts (id, user_id, provider, provider_user_id, email, avatar_url)
     values ($1,$2,'google',$3,$4,null)
     on conflict (provider, provider_user_id) do update set user_id=excluded.user_id, email=excluded.email, updated_at=now()`,
    [crypto.randomUUID(), user.id, pending.sub, email]
  );

  if (isNewUser) await sendWelcomeEmailOnce({ userId: user.id, email: user.email, name: user.name, origin: new URL(request.url).origin });

  const token = signSession({ sub: user.id, email: user.email, name: user.name });
  cookies().set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24 * 7
  });
  cookies().set(GOOGLE_PENDING_COOKIE, '', { path: '/', maxAge: 0 });
  const h = headers();
  await query(
    `insert into audit_events (id, user_id, event, ip, user_agent, metadata) values ($1,$2,'auth.google.complete',$3,$4,$5)`,
    [crypto.randomUUID(), user.id, h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null, JSON.stringify({ email })]
  );
  return jsonOk({ user: { id: user.id, name: user.name, email: user.email, role: user.role }, next: next.startsWith('/') ? next : '/dashboard' });
}
