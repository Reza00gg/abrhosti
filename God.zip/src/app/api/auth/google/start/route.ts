import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { createGoogleState, getGoogleConfig, GOOGLE_STATE_COOKIE, type GoogleMode } from '@/lib/google-oauth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const mode = (url.searchParams.get('mode') === 'register' ? 'register' : 'login') as GoogleMode;
    const next = url.searchParams.get('next') || '/dashboard';
    const origin = url.origin;
    const config = getGoogleConfig(origin);
    const state = createGoogleState(mode, next);
    cookies().set(GOOGLE_STATE_COOKIE, state, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      path: '/',
      maxAge: 60 * 10
    });
    const google = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    google.searchParams.set('client_id', config.clientId);
    google.searchParams.set('redirect_uri', config.redirectUri);
    google.searchParams.set('response_type', 'code');
    google.searchParams.set('scope', 'openid email profile');
    google.searchParams.set('state', state);
    google.searchParams.set('prompt', 'select_account');
    return NextResponse.redirect(google);
  } catch (error) {
    console.error(error);
    return NextResponse.redirect(new URL('/auth/login?google_error=config', request.url));
  }
}
