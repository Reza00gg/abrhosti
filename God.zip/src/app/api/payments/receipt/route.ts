import crypto from 'crypto';
import { cookies } from 'next/headers';
import { query, getPool } from '@/lib/db';
import { hashToken } from '@/lib/payment';
import { SESSION_COOKIE } from '@/lib/auth';
import { verifySession } from '@/lib/crypto';
import { jsonError, jsonOk } from '@/lib/http';
import { createNotification } from '@/lib/notifications';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const allowed = new Set(['image/png', 'image/jpeg', 'image/webp', 'application/pdf']);

type SessionRow = { order_id: string | null; topup_id: string | null; user_id: string; amount: number; expires_at: string; used_at: string | null; purpose: 'service_order' | 'wallet_topup' };

export async function POST(request: Request) {
  try {
    const authSession = verifySession(cookies().get(SESSION_COOKIE)?.value);
    if (!authSession) return jsonError('صفحه پرداخت پیدا نشد.', 404, 'PAYMENT_NOT_FOUND');
    const body = await request.json();
    const token = String(body.token ?? '');
    const payerName = String(body.payerName ?? '').trim();
    const trackingNumber = String(body.trackingNumber ?? '').trim().slice(0, 80);
    const fileName = String(body.fileName ?? '').trim().slice(0, 180);
    const mime = String(body.mime ?? '').trim();
    const data = String(body.data ?? '');
    const size = Number(body.size ?? 0);

    if (!token) return jsonError('توکن پرداخت معتبر نیست.');
    if (payerName.length < 3) return jsonError('نام واریزکننده را وارد کنید.');
    if (!fileName || !allowed.has(mime)) return jsonError('فرمت فیش باید png، jpg، webp یا pdf باشد.');
    if (!data || size <= 0 || size > 2_000_000) return jsonError('حجم فایل باید کمتر از ۲ مگابایت باشد.');

    const session = await query<SessionRow>(
      `select ps.order_id, ps.topup_id, ps.user_id, ps.expires_at, ps.used_at, ps.purpose,
              coalesce(o.total_amount, wt.amount) as amount
       from payment_sessions ps
       left join orders o on o.id = ps.order_id
       left join wallet_topups wt on wt.id = ps.topup_id
       where ps.token_hash = $1 limit 1`,
      [hashToken(token)]
    );
    const row = session.rows[0];
    if (!row || row.user_id !== authSession.sub) return jsonError('صفحه پرداخت پیدا نشد.', 404, 'PAYMENT_NOT_FOUND');
    if (row.used_at) return jsonError('برای این پرداخت قبلاً فیش ثبت شده است.');
    if (new Date(row.expires_at).getTime() < Date.now()) return jsonError('مهلت پرداخت منقضی شده است.');

    const client = await getPool().connect();
    try {
      await client.query('begin');
      const receiptId = crypto.randomUUID();
      await client.query(
        `insert into payment_receipts (id, order_id, topup_id, user_id, amount, payer_name, tracking_number, receipt_file_name, receipt_mime, receipt_size, receipt_data, status, purpose)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'pending_review',$12)`,
        [receiptId, row.order_id, row.topup_id, row.user_id, row.amount, payerName, trackingNumber || null, fileName, mime, size, data, row.purpose]
      );
      await client.query(`update payment_sessions set used_at = now() where token_hash = $1`, [hashToken(token)]);
      if (row.purpose === 'wallet_topup') {
        await client.query(`update wallet_topups set status='awaiting_admin_approval', payment_status='receipt_submitted', updated_at=now() where id=$1`, [row.topup_id]);
      } else {
        await client.query(
          `update orders set status='awaiting_admin_approval', payment_status='receipt_submitted', provision_status='awaiting_admin_approval', updated_at=now() where id=$1`,
          [row.order_id]
        );
      }
      await client.query(
        `insert into audit_events (id, user_id, event, metadata) values ($1,$2,'payment.receipt.submit',$3)`,
        [crypto.randomUUID(), row.user_id, JSON.stringify({ orderId: row.order_id, topupId: row.topup_id, receiptId, purpose: row.purpose })]
      );
      await createNotification({
        userId: row.user_id,
        type: 'payment',
        title: 'فیش پرداخت ارسال شد',
        message: row.purpose === 'wallet_topup' ? 'فیش افزایش موجودی برای بررسی مدیر ارسال شد.' : 'فیش پرداخت سفارش برای بررسی مدیر ارسال شد.',
        metadata: { orderId: row.order_id, topupId: row.topup_id, receiptId, purpose: row.purpose }
      });
      await client.query('commit');
      return jsonOk({ receiptId, message: 'رسید شما برای بررسی پشتیبانی ارسال شد.' }, { status: 201 });
    } catch (e) { await client.query('rollback'); throw e; } finally { client.release(); }
  } catch (error) {
    console.error(error);
    return jsonError('ثبت فیش پرداخت انجام نشد.', 500, 'RECEIPT_FAILED');
  }
}
