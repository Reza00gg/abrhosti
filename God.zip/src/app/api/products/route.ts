import { getCatalogProducts } from '@/lib/catalog';
import { jsonOk } from '@/lib/http';

export async function GET() {
  const products = await getCatalogProducts();
  return jsonOk({ products });
}
