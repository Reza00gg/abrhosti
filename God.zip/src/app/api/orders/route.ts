import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { getPool, query } from '@/lib/db';
import { SESSION_COOKIE } from '@/lib/auth';
import { verifySession, makeOrderNumber } from '@/lib/crypto';
import { getCatalogProductById } from '@/lib/catalog';
import { jsonError, jsonOk } from '@/lib/http';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function cycleMultiplier(cycle: string) {
  if (cycle === 'yearly') return 10;
  if (cycle === 'quarterly') return 3;
  return 1;
}

export async function GET() {
  try {
    const session = verifySession(cookies().get(SESSION_COOKIE)?.value);
    if (!session) return jsonError('برای مشاهده سفارش‌ها ابتدا وارد شوید.', 401, 'UNAUTHORIZED');

    const result = await query(
      `select o.*, coalesce(json_agg(json_build_object(
        'id', oi.id,
        'productId', oi.product_id,
        'title', oi.title,
        'category', oi.category,
        'quantity', oi.quantity,
        'unitAmount', oi.unit_amount,
        'cycle', oi.cycle
      )) filter (where oi.id is not null), '[]') as items
       from orders o
       left join order_items oi on oi.order_id = o.id
       where o.user_id = $1
       group by o.id
       order by o.created_at desc`,
      [session.sub]
    );

    return jsonOk({ orders: result.rows });
  } catch (error) {
    console.error(error);
    return jsonError('امکان دریافت سفارش‌ها وجود ندارد.', 500, 'ORDERS_FETCH_FAILED');
  }
}

export async function POST(request: Request) {
  try {
    const session = verifySession(cookies().get(SESSION_COOKIE)?.value);
    if (!session) return jsonError('برای ثبت سفارش ابتدا وارد شوید.', 401, 'UNAUTHORIZED');

    const body = await request.json();
    const productId = String(body.productId ?? '');
    const cycle = ['monthly', 'quarterly', 'yearly'].includes(body.cycle) ? String(body.cycle) : 'monthly';
    const domainName = body.domainName ? String(body.domainName).trim().toLowerCase() : null;
    const notes = body.notes ? String(body.notes).trim().slice(0, 500) : null;

    const product = await getCatalogProductById(productId);
    if (!product) return jsonError('محصول انتخاب‌شده پیدا نشد.', 404, 'PRODUCT_NOT_FOUND');

    if (product.category === 'domain' && !domainName) {
      return jsonError('برای ثبت دامنه، نام دامنه را وارد کنید.');
    }

    const orderId = crypto.randomUUID();
    const itemId = crypto.randomUUID();
    const total = product.priceMonthly * cycleMultiplier(cycle);
    const orderNumber = makeOrderNumber();

    const client = await getPool().connect();
    try {
      await client.query('begin');
      await client.query(
        `insert into orders (id, order_number, user_id, status, payment_status, provision_status, total_amount, currency, domain_name, notes)
         values ($1,$2,$3,'paid_mock','paid_mock','queued',$4,$5,$6,$7)`,
        [orderId, orderNumber, session.sub, total, product.currency.replace('/سال', '').replace('/ماه', ''), domainName, notes]
      );

      await client.query(
        `insert into order_items (id, order_id, product_id, title, category, quantity, unit_amount, cycle, product_snapshot)
         values ($1,$2,$3,$4,$5,1,$6,$7,$8)`,
        [itemId, orderId, product.id, product.title, product.category, product.priceMonthly, cycle, JSON.stringify(product)]
      );

      const h = headers();
      await client.query(
        `insert into audit_events (id, user_id, event, ip, user_agent, metadata)
         values ($1, $2, 'order.create', $3, $4, $5)`,
        [crypto.randomUUID(), session.sub, h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null, JSON.stringify({ orderId, productId, cycle })]
      );
      await client.query('commit');
    } catch (error) {
      await client.query('rollback');
      throw error;
    } finally {
      client.release();
    }

    return jsonOk({ order: { id: orderId, orderNumber, total, status: 'paid_mock', provisionStatus: 'queued' } }, { status: 201 });
  } catch (error) {
    console.error(error);
    return jsonError('ثبت سفارش انجام نشد. اتصال دیتابیس را بررسی کنید.', 500, 'ORDER_FAILED');
  }
}
