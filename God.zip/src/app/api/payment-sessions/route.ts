import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { getPool, query } from '@/lib/db';
import { SESSION_COOKIE } from '@/lib/auth';
import { verifySession, makeOrderNumber } from '@/lib/crypto';
import { getCatalogProductById } from '@/lib/catalog';
import { jsonError, jsonOk } from '@/lib/http';
import { makePaymentToken, hashToken } from '@/lib/payment';
import { createNotification } from '@/lib/notifications';
import { getAccountAccessError } from '@/lib/account-guards';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function cycleMultiplier(cycle: string) { return cycle === 'yearly' ? 10 : cycle === 'quarterly' ? 3 : 1; }

export async function POST(request: Request) {
  const session = verifySession(cookies().get(SESSION_COOKIE)?.value);
  if (!session) return jsonError('برای ثبت سفارش ابتدا وارد شوید.', 401, 'UNAUTHORIZED');

  const userResult = await query<{ id: string; name: string; email: string; role: 'user' | 'admin'; created_at: string; email_verified_at: string | null; phone_verified_at: string | null }>('select id,name,email,role,created_at,email_verified_at,phone_verified_at from users where id=$1 limit 1', [session.sub]);
  const accessError = userResult.rows[0] ? await getAccountAccessError(userResult.rows[0]) : { message: 'کاربر پیدا نشد.', code: 'USER_NOT_FOUND' };
  if (accessError) return jsonError(accessError.message, 403, accessError.code);

  const body = await request.json();
  const productId = String(body.productId ?? '');
  const cycle = ['monthly', 'quarterly', 'yearly'].includes(body.cycle) ? String(body.cycle) : 'monthly';
  const domainName = body.domainName ? String(body.domainName).trim().toLowerCase() : null;
  const notes = body.notes ? String(body.notes).trim().slice(0, 500) : null;
  const product = await getCatalogProductById(productId);
  if (!product) return jsonError('محصول انتخاب‌شده پیدا نشد.', 404, 'PRODUCT_NOT_FOUND');
  if (product.category === 'domain' && !domainName) return jsonError('برای ثبت دامنه، نام دامنه را وارد کنید.');

  const token = makePaymentToken();
  const orderId = crypto.randomUUID();
  const itemId = crypto.randomUUID();
  const sessionId = crypto.randomUUID();
  const total = product.priceMonthly * cycleMultiplier(cycle);
  const orderNumber = makeOrderNumber();
  const client = await getPool().connect();

  try {
    await client.query('begin');
    await client.query(
      `insert into orders (id, order_number, user_id, status, payment_status, provision_status, total_amount, currency, domain_name, notes, payment_method, payment_token)
       values ($1,$2,$3,'pending_payment','awaiting_card_to_card','waiting_for_receipt',$4,$5,$6,$7,'card_to_card',$8)`,
      [orderId, orderNumber, session.sub, total, product.currency.replace('/سال', '').replace('/ماه', ''), domainName, notes, token.slice(0, 10)]
    );
    await client.query(
      `insert into order_items (id, order_id, product_id, title, category, quantity, unit_amount, cycle, product_snapshot)
       values ($1,$2,$3,$4,$5,1,$6,$7,$8)`,
      [itemId, orderId, product.id, product.title, product.category, product.priceMonthly, cycle, JSON.stringify(product)]
    );
    await client.query(
      `insert into payment_sessions (id, token_hash, order_id, user_id, expires_at) values ($1,$2,$3,$4,now() + interval '2 hours')`,
      [sessionId, hashToken(token), orderId, session.sub]
    );
    const h = headers();
    await client.query(
      `insert into audit_events (id, user_id, event, ip, user_agent, metadata) values ($1,$2,'payment.session.create',$3,$4,$5)`,
      [crypto.randomUUID(), session.sub, h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null, JSON.stringify({ orderId, productId })]
    );
    await createNotification({ userId: session.sub, type: 'order', title: 'سفارش جدید ثبت شد', message: `صفحه پرداخت سفارش ${orderNumber} برای ${product.title} ساخته شد.`, metadata: { orderId, orderNumber, productId, payUrl: `/pay/${token}` } });
    await client.query('commit');
    return jsonOk({ orderId, orderNumber, payUrl: `/pay/${token}` }, { status: 201 });
  } catch (error) {
    await client.query('rollback');
    console.error(error);
    return jsonError('ایجاد صفحه پرداخت انجام نشد.', 500, 'PAYMENT_SESSION_FAILED');
  } finally { client.release(); }
}
