import { checkDomainAvailability } from '@/lib/domain-rdap';
import { jsonError, jsonOk } from '@/lib/http';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const result = await checkDomainAvailability(String(body.domain ?? ''));
    if (!result.domain || !result.tld) return jsonError(result.message);
    return jsonOk(result);
  } catch (error) {
    console.error(error);
    return jsonError('بررسی دامنه انجام نشد. چند لحظه بعد دوباره تلاش کنید.', 500, 'DOMAIN_CHECK_FAILED');
  }
}
