import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { getPool, query } from '@/lib/db';
import { SESSION_COOKIE } from '@/lib/auth';
import { makeOrderNumber, verifySession } from '@/lib/crypto';
import { checkDomainAvailability, getDomainPrice, normalizeDomain } from '@/lib/domain-rdap';
import { makePaymentToken, hashToken } from '@/lib/payment';
import { jsonError, jsonOk } from '@/lib/http';
import { createNotification } from '@/lib/notifications';
import { getAccountAccessError } from '@/lib/account-guards';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const session = verifySession(cookies().get(SESSION_COOKIE)?.value);
  if (!session) return jsonError('برای ثبت دامنه ابتدا وارد شوید.', 401, 'UNAUTHORIZED');

  const userResult = await query<{ id: string; name: string; email: string; role: 'user' | 'admin'; created_at: string; email_verified_at: string | null; phone_verified_at: string | null }>('select id,name,email,role,created_at,email_verified_at,phone_verified_at from users where id=$1 limit 1', [session.sub]);
  const accessError = userResult.rows[0] ? await getAccountAccessError(userResult.rows[0]) : { message: 'کاربر پیدا نشد.', code: 'USER_NOT_FOUND' };
  if (accessError) return jsonError(accessError.message, 403, accessError.code);

  const body = await request.json();
  const domain = normalizeDomain(String(body.domain ?? ''));
  const years = Math.max(1, Math.min(5, Number(body.years ?? 1)));
  const registrantName = String(body.registrantName ?? '').trim().slice(0, 120);
  const notes = body.notes ? String(body.notes).trim().slice(0, 500) : null;

  if (!registrantName || registrantName.length < 3) return jsonError('نام مالک دامنه را وارد کنید.');

  const availability = await checkDomainAvailability(domain);
  if (!availability.supported) return jsonError(availability.message, 400, 'TLD_NOT_SUPPORTED');
  if (!availability.available) return jsonError('این دامنه آزاد نیست و امکان ثبت سفارش ندارد.', 409, 'DOMAIN_NOT_AVAILABLE');

  const unit = getDomainPrice(availability.tld);
  const total = unit * years;
  const token = makePaymentToken();
  const orderId = crypto.randomUUID();
  const itemId = crypto.randomUUID();
  const sessionId = crypto.randomUUID();
  const orderNumber = makeOrderNumber();
  const title = `ثبت دامنه ${domain}`;
  const snapshot = {
    id: `domain-${availability.tld}-${domain}`,
    category: 'domain',
    title,
    subtitle: `${years} سال ثبت دامنه .${availability.tld}`,
    priceMonthly: unit,
    currency: 'تومان/سال',
    badge: `.${availability.tld}`,
    cpu: 'RDAP Check',
    ram: 'DNS مدیریت‌شده',
    storage: 'کنترل پنل دامنه',
    bandwidth: `${years} سال`,
    features: ['بررسی واقعی RDAP', 'ثبت پس از تایید پرداخت', 'مدیریت DNS', 'اعلان تمدید'],
    route: '/domains',
    domain,
    years,
    registrantName
  };

  const client = await getPool().connect();
  try {
    await client.query('begin');
    await client.query(
      `insert into orders (id, order_number, user_id, status, payment_status, provision_status, total_amount, currency, domain_name, notes, payment_method, payment_token)
       values ($1,$2,$3,'pending_payment','awaiting_card_to_card','waiting_for_receipt',$4,'تومان',$5,$6,'card_to_card',$7)`,
      [orderId, orderNumber, session.sub, total, domain, notes, token.slice(0, 10)]
    );
    await client.query(
      `insert into order_items (id, order_id, product_id, title, category, quantity, unit_amount, cycle, product_snapshot)
       values ($1,$2,$3,$4,'domain',1,$5,$6,$7)`,
      [itemId, orderId, snapshot.id, title, unit, `${years}year`, JSON.stringify(snapshot)]
    );
    await client.query(
      `insert into payment_sessions (id, token_hash, order_id, user_id, expires_at) values ($1,$2,$3,$4,now() + interval '2 hours')`,
      [sessionId, hashToken(token), orderId, session.sub]
    );
    const h = headers();
    await client.query(
      `insert into audit_events (id, user_id, event, ip, user_agent, metadata) values ($1,$2,'domain.order.create',$3,$4,$5)`,
      [crypto.randomUUID(), session.sub, h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null, JSON.stringify({ orderId, domain, years })]
    );
    await createNotification({ userId: session.sub, type: 'order', title: 'سفارش دامنه ثبت شد', message: `صفحه پرداخت برای ثبت دامنه ${domain} ساخته شد.`, metadata: { orderId, domain, years, payUrl: `/pay/${token}` } });
    await client.query('commit');
    return jsonOk({ orderId, orderNumber, payUrl: `/pay/${token}` }, { status: 201 });
  } catch (error) {
    await client.query('rollback');
    console.error(error);
    return jsonError('ثبت سفارش دامنه انجام نشد.', 500, 'DOMAIN_ORDER_FAILED');
  } finally {
    client.release();
  }
}
