import crypto from 'crypto';
import { cookies } from 'next/headers';
import { getPool, query } from '@/lib/db';
import { SESSION_COOKIE } from '@/lib/auth';
import { verifySession } from '@/lib/crypto';
import { hashToken } from '@/lib/payment';
import { jsonError, jsonOk } from '@/lib/http';
import { getGatewaySettings, getZibalMerchant, getZarinpalMerchant, calculateGatewayAmounts } from '@/lib/gateway-settings';
import { isPaymentAllowedRequest, PAYMENT_BASE_URL } from '@/lib/payment-host';
import { zibalRequestPayment, zibalStartUrl } from '@/lib/gateways/zibal';
import { zarinpalRequestPayment, zarinpalStartUrl } from '@/lib/gateways/zarinpal';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type PaySession = { id: string; topup_id: string; user_id: string; amount: number; status: string; payment_status: string; used_at: string | null; expires_at: string; email: string };

export async function POST(request: Request) {
  if (!isPaymentAllowedRequest(request)) return jsonError('پرداخت آنلاین فقط از دامنه اصلی فعال است.', 403, 'PAYMENT_DOMAIN_NOT_ALLOWED');
  const session = verifySession(cookies().get(SESSION_COOKIE)?.value);
  if (!session) return jsonError('برای پرداخت ابتدا وارد شوید.', 401, 'UNAUTHORIZED');
  const body = await request.json();
  const token = String(body.token ?? '');
  const provider = String(body.provider ?? 'zarinpal');
  if (!['zibal', 'zarinpal'].includes(provider)) return jsonError('این درگاه فعال نیست.', 400, 'PROVIDER_DISABLED');
  const settings = await getGatewaySettings();
  if (!settings.enabled) return jsonError('پرداخت آنلاین در حال حاضر غیرفعال است.', 400, 'GATEWAY_DISABLED');
  if (provider === 'zibal' && !settings.zibal.enabled) return jsonError('درگاه زیبال فعال نیست.', 400, 'ZIBAL_DISABLED');
  if (provider === 'zarinpal' && !settings.zarinpal.enabled) return jsonError('درگاه زرین‌پال فعال نیست.', 400, 'ZARINPAL_DISABLED');

  const paySession = await query<PaySession>(`select ps.id, ps.topup_id, ps.user_id, wt.amount, wt.status, wt.payment_status, ps.used_at, ps.expires_at, u.email from payment_sessions ps join wallet_topups wt on wt.id=ps.topup_id join users u on u.id=ps.user_id where ps.token_hash=$1 and ps.purpose='wallet_topup' limit 1`, [hashToken(token)]);
  const row = paySession.rows[0];
  if (!row || row.user_id !== session.sub) return jsonError('صفحه پرداخت پیدا نشد.', 404, 'PAYMENT_NOT_FOUND');
  if (row.used_at) return jsonError('این پرداخت قبلاً استفاده شده است.');
  if (new Date(row.expires_at).getTime() < Date.now()) return jsonError('مهلت پرداخت منقضی شده است.');
  if (['approved'].includes(row.status) || ['approved_card_to_card', 'approved_gateway_zibal', 'approved_gateway_zarinpal'].includes(row.payment_status)) return jsonError('این افزایش موجودی قبلاً تایید شده است.');

  const amounts = calculateGatewayAmounts(Number(row.amount), settings);
  const paymentId = crypto.randomUUID();
  const callbackUrl = `${PAYMENT_BASE_URL}/api/gateway/callback/${provider}`;
  const orderId = `wallet-${row.topup_id.slice(0, 8)}-${Date.now()}`;
  const client = await getPool().connect();
  try {
    await client.query('begin');
    await client.query(`insert into gateway_payments (id,user_id,topup_id,payment_session_id,provider,amount,fee_amount,payable_amount,currency,status,callback_url,request_payload) values ($1,$2,$3,$4,$5,$6,$7,$8,'تومان','created',$9,$10)`, [paymentId, row.user_id, row.topup_id, row.id, provider, amounts.amount, amounts.feeAmount, amounts.payableAmount, callbackUrl, JSON.stringify({ orderId })]);
    await client.query('commit');
  } catch (e) { await client.query('rollback'); client.release(); throw e; }
  client.release();

  if (provider === 'zibal') {
    const merchant = await getZibalMerchant();
    if (!merchant) return jsonError('مرچنت زیبال تنظیم نشده است.');
    const zibal = await zibalRequestPayment({ merchant, amountRial: amounts.payableAmount * 10, callbackUrl, description: 'افزایش موجودی ابرهاست', orderId: paymentId });
    if (!zibal.ok || !zibal.data.trackId) {
      await query(`update gateway_payments set status='failed', failure_message=$1, request_payload=request_payload || $2::jsonb, updated_at=now() where id=$3`, [zibal.data.message || 'خطا در ساخت پرداخت زیبال', JSON.stringify({ zibal: zibal.data }), paymentId]);
      return jsonError(`زیبال: ${zibal.data.message || 'خطا در ساخت پرداخت'}`, 502, 'ZIBAL_REQUEST_FAILED');
    }
    const gatewayUrl = zibalStartUrl(zibal.data.trackId);
    await query(`update gateway_payments set status='requested', track_id=$1, gateway_url=$2, request_payload=request_payload || $3::jsonb, updated_at=now() where id=$4`, [String(zibal.data.trackId), gatewayUrl, JSON.stringify({ zibal: zibal.data }), paymentId]);
    await query(`update wallet_topups set status='sent_to_gateway', payment_status='gateway_pending', updated_at=now() where id=$1`, [row.topup_id]);
    return jsonOk({ paymentId, gatewayUrl });
  }

  const merchantId = await getZarinpalMerchant();
  if (!merchantId) return jsonError('مرچنت زرین‌پال تنظیم نشده است.');
  const zp = await zarinpalRequestPayment({ merchantId, amountToman: amounts.payableAmount, callbackUrl, description: 'افزایش موجودی ابرهاست', orderId: paymentId, email: row.email, sandbox: settings.zarinpal.sandbox });
  if (!zp.ok || !zp.data.data?.authority) {
    await query(`update gateway_payments set status='failed', failure_message=$1, request_payload=request_payload || $2::jsonb, updated_at=now() where id=$3`, [zp.message, JSON.stringify({ zarinpal: zp.data }), paymentId]);
    return jsonError(`زرین‌پال: ${zp.message}`, 502, 'ZARINPAL_REQUEST_FAILED');
  }
  const authority = zp.data.data.authority;
  const gatewayUrl = zarinpalStartUrl(authority, settings.zarinpal.sandbox);
  await query(`update gateway_payments set status='requested', authority=$1, gateway_url=$2, request_payload=request_payload || $3::jsonb, updated_at=now() where id=$4`, [authority, gatewayUrl, JSON.stringify({ zarinpal: zp.data }), paymentId]);
  await query(`update wallet_topups set status='sent_to_gateway', payment_status='gateway_pending', updated_at=now() where id=$1`, [row.topup_id]);
  return jsonOk({ paymentId, gatewayUrl });
}
