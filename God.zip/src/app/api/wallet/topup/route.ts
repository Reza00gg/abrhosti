import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { getPool, query } from '@/lib/db';
import { SESSION_COOKIE } from '@/lib/auth';
import { verifySession } from '@/lib/crypto';
import { makePaymentToken, hashToken } from '@/lib/payment';
import { jsonError, jsonOk } from '@/lib/http';
import { createNotification } from '@/lib/notifications';
import { getAccountAccessError } from '@/lib/account-guards';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const session = verifySession(cookies().get(SESSION_COOKIE)?.value);
  if (!session) return jsonError('برای افزایش موجودی ابتدا وارد شوید.', 401, 'UNAUTHORIZED');

  const userResult = await query<{ id: string; name: string; email: string; role: 'user' | 'admin'; created_at: string; email_verified_at: string | null; phone_verified_at: string | null }>('select id,name,email,role,created_at,email_verified_at,phone_verified_at from users where id=$1 limit 1', [session.sub]);
  const accessError = userResult.rows[0] ? await getAccountAccessError(userResult.rows[0]) : { message: 'کاربر پیدا نشد.', code: 'USER_NOT_FOUND' };
  if (accessError) return jsonError(accessError.message, 403, accessError.code);
  const isAdmin = userResult.rows[0]?.role === 'admin';
  const minAmount = isAdmin ? 1000 : 50000;
  const maxAmount = 10000000;
  const body = await request.json();
  const amount = Math.round(Number(body.amount ?? 0));
  if (!Number.isFinite(amount) || amount < minAmount) return jsonError(`حداقل مبلغ افزایش موجودی ${new Intl.NumberFormat('fa-IR').format(minAmount)} تومان است.`);
  if (amount > maxAmount) return jsonError(`حداکثر مبلغ افزایش موجودی ${new Intl.NumberFormat('fa-IR').format(maxAmount)} تومان است.`);

  const topupId = crypto.randomUUID();
  const sessionId = crypto.randomUUID();
  const token = makePaymentToken();
  const client = await getPool().connect();

  try {
    await client.query('begin');
    await client.query(
      `insert into wallet_topups (id, user_id, amount, currency, status, payment_status)
       values ($1,$2,$3,'تومان','pending_payment','awaiting_card_to_card')`,
      [topupId, session.sub, amount]
    );
    await client.query(
      `insert into payment_sessions (id, token_hash, order_id, topup_id, user_id, expires_at, purpose)
       values ($1,$2,null,$3,$4,now() + interval '2 hours','wallet_topup')`,
      [sessionId, hashToken(token), topupId, session.sub]
    );
    const h = headers();
    await client.query(
      `insert into audit_events (id, user_id, event, ip, user_agent, metadata) values ($1,$2,'wallet.topup.create',$3,$4,$5)`,
      [crypto.randomUUID(), session.sub, h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null, JSON.stringify({ topupId, amount })]
    );
    await createNotification({ userId: session.sub, type: 'wallet', title: 'درخواست افزایش موجودی ساخته شد', message: `پرداخت افزایش موجودی به مبلغ ${new Intl.NumberFormat('fa-IR').format(amount)} تومان ایجاد شد.`, metadata: { topupId, amount, payUrl: `/pay/${token}` } });
    await client.query('commit');
    return jsonOk({ topupId, payUrl: `/pay/${token}` }, { status: 201 });
  } catch (error) {
    await client.query('rollback');
    console.error(error);
    return jsonError('ایجاد پرداخت افزایش موجودی انجام نشد.', 500, 'TOPUP_FAILED');
  } finally {
    client.release();
  }
}
