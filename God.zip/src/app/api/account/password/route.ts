import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { hashPassword, verifyPassword } from '@/lib/crypto';
import { jsonError, jsonOk } from '@/lib/http';
export const runtime = 'nodejs';
type Row = { password_hash: string };
export async function POST(request: Request) {
  const user = await requireUser();
  const body = await request.json();
  const current = String(body.currentPassword ?? '');
  const next = String(body.newPassword ?? '');
  if (next.length < 8) return jsonError('رمز جدید باید حداقل ۸ کاراکتر باشد.');
  const r = await query<Row>('select password_hash from users where id=$1 limit 1', [user.id]);
  if (!r.rows[0] || !verifyPassword(current, r.rows[0].password_hash)) return jsonError('رمز فعلی اشتباه است.', 401);
  await query('update users set password_hash=$1, updated_at=now() where id=$2', [hashPassword(next), user.id]);
  return jsonOk({ changed: true });
}
