import { headers } from 'next/headers';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { IRAN_COUNTRY, isIranCity, isIranProvince } from '@/lib/iran-locations';

export const runtime = 'nodejs';

function cleanOptional(value: unknown, max = 200) {
  const text = String(value ?? '').trim().replace(/\s+/g, ' ');
  return text ? text.slice(0, max) : null;
}

function normalizePostalCode(value: unknown) {
  const text = String(value ?? '')
    .trim()
    .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    .replace(/[\s-]/g, '');
  return text || null;
}

export async function POST(request: Request) {
  const user = await requireUser();
  const body = await request.json();

  const name = String(body.name ?? '').trim().replace(/\s+/g, ' ');
  if (name.length < 2) return jsonError('نام باید حداقل ۲ کاراکتر باشد.');
  if (name.length > 80) return jsonError('نام نمی‌تواند بیشتر از ۸۰ کاراکتر باشد.');

  const country = cleanOptional(body.country, 40);
  const province = cleanOptional(body.province, 80);
  const city = cleanOptional(body.city, 80);
  const address = cleanOptional(body.address, 500);
  const postalCode = normalizePostalCode(body.postalCode);

  if (country && country !== IRAN_COUNTRY) return jsonError('در حال حاضر فقط کشور ایران قابل انتخاب است.');
  if (!country && (province || city)) return jsonError('برای انتخاب استان یا شهر، ابتدا کشور ایران را انتخاب کنید.');
  if (province && !isIranProvince(province)) return jsonError('استان انتخاب‌شده معتبر نیست.');
  if (city && !province) return jsonError('برای انتخاب شهر، ابتدا استان را انتخاب کنید.');
  if (city && province && !isIranCity(province, city)) return jsonError('شهر انتخاب‌شده برای این استان معتبر نیست.');
  if (postalCode && !/^\d{10}$/.test(postalCode)) return jsonError('کد پستی باید ۱۰ رقم باشد.');

  await query(
    `update users
     set name=$1, country=$2, province=$3, city=$4, address=$5, postal_code=$6, updated_at=now()
     where id=$7`,
    [name, country, province, city, address, postalCode, user.id]
  );

  const h = headers();
  await query(
    `insert into audit_events (id, user_id, event, ip, user_agent, metadata)
     values ($1,$2,'account.profile.update',$3,$4,$5)`,
    [crypto.randomUUID(), user.id, h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null, JSON.stringify({ fields: ['name', 'country', 'province', 'city', 'address', 'postal_code'] })]
  );

  return jsonOk({ updated: true });
}
