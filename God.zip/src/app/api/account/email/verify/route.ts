import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { hashEmailCode } from '@/lib/email-verification';
import { getEmailSettings } from '@/lib/email-settings';
import { jsonError, jsonOk } from '@/lib/http';
import { createNotification } from '@/lib/notifications';

type Verification = { id: string; email: string; code_hash: string; attempts: number; expires_at: string; used_at: string | null; verified_at: string | null };
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const settings = await getEmailSettings();
    if (!settings.enabled) return jsonError('تایید ایمیل غیرفعال است.', 400, 'EMAIL_DISABLED');
    if (user.email_verified_at) return jsonOk({ verified: true, already: true });
    const body = await request.json();
    const code = String(body.code ?? '').replace(/\D/g, '');
    if (!/^\d{6}$/.test(code)) return jsonError('کد تایید معتبر نیست.');
    const result = await query<Verification>(`select id,email,code_hash,attempts,expires_at,used_at,verified_at from email_verifications where user_id=$1 and email=$2 order by created_at desc limit 1`, [user.id, user.email.toLowerCase()]);
    const row = result.rows[0];
    if (!row || row.verified_at || row.used_at) return jsonError('کد تایید پیدا نشد. دوباره کد بگیرید.', 404, 'CODE_NOT_FOUND');
    if (new Date(row.expires_at).getTime() < Date.now()) return jsonError('کد تایید منقضی شده است. دوباره کد بگیرید.', 400, 'CODE_EXPIRED');
    if (row.attempts >= 5) return jsonError('تعداد تلاش‌ها بیش از حد مجاز است. دوباره کد بگیرید.', 429, 'ATTEMPTS_LIMIT');
    if (hashEmailCode(code, row.email, user.id) !== row.code_hash) {
      await query('update email_verifications set attempts=attempts+1 where id=$1', [row.id]);
      return jsonError('کد وارد شده صحیح نیست.', 400, 'INVALID_CODE');
    }
    await query('update email_verifications set verified_at=now(), used_at=now() where id=$1', [row.id]);
    await query('update users set email_verified_at=now(), updated_at=now() where id=$1', [user.id]);
    await createNotification({ userId: user.id, type: 'success', title: 'ایمیل شما تایید شد', message: 'حساب شما فعال شد و اکنون می‌توانید از خدمات سایت استفاده کنید.', metadata: { email: user.email } });
    return jsonOk({ verified: true });
  } catch (error) {
    console.error(error);
    return jsonError('تایید ایمیل انجام نشد.', 500, 'EMAIL_VERIFY_FAILED');
  }
}
