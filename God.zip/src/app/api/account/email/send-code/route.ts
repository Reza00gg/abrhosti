import crypto from 'crypto';
import { headers } from 'next/headers';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { generateEmailCode, generateEmailToken, hashEmailCode, hashEmailToken } from '@/lib/email-verification';
import { getEmailSettings, getResendApiKey } from '@/lib/email-settings';
import { sendResendEmail, verificationEmailTemplate } from '@/lib/resend';
import { jsonError, jsonOk } from '@/lib/http';

type CountRow = { count: string };
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const settings = await getEmailSettings();
    if (!settings.enabled) return jsonError('تایید ایمیل غیرفعال است.', 400, 'EMAIL_DISABLED');
    if (user.email_verified_at) return jsonOk({ alreadyVerified: true });
    const last = await query<{ created_at: string }>('select created_at from email_verifications where user_id=$1 order by created_at desc limit 1', [user.id]);
    if (last.rows[0] && Date.now() - new Date(last.rows[0].created_at).getTime() < 60_000) return jsonError('برای ارسال مجدد کد، کمی صبر کنید.', 429, 'TOO_SOON');
    const recent = await query<CountRow>(`select count(*)::text from email_verifications where user_id=$1 and created_at > now() - interval '15 minutes'`, [user.id]);
    if (Number(recent.rows[0]?.count ?? 0) >= 3) return jsonError('تعداد ارسال کد بیش از حد مجاز است. کمی بعد تلاش کنید.', 429, 'RATE_LIMIT');
    const daily = await query<CountRow>(`select count(*)::text from email_verifications where user_id=$1 and created_at > now() - interval '24 hours'`, [user.id]);
    if (Number(daily.rows[0]?.count ?? 0) >= 10) return jsonError('سقف ارسال ایمیل امروز پر شده است.', 429, 'DAILY_LIMIT');
    const apiKey = await getResendApiKey();
    if (!apiKey) return jsonError('تنظیمات ایمیل کامل نیست.', 500, 'EMAIL_CONFIG');
    const code = generateEmailCode();
    const token = generateEmailToken();
    const origin = new URL(request.url).origin;
    const verifyUrl = `${origin}/auth/email/verify?token=${encodeURIComponent(token)}`;
    const { html, text } = verificationEmailTemplate({ name: user.name, code, verifyUrl, minutes: settings.expiresMinutes });
    const sent = await sendResendEmail({ apiKey, from: `${settings.fromName} <${settings.fromEmail}>`, to: user.email, subject: 'کد تایید ایمیل ابرهاست', html, text });
    if (!sent.ok) return jsonError(`ایمیل ارسال نشد: ${sent.message}`, 502, 'EMAIL_SEND_FAILED');
    const h = headers();
    await query(
      `insert into email_verifications (id,user_id,email,code_hash,token_hash,expires_at,ip,user_agent)
       values ($1,$2,$3,$4,$5,now() + ($6 || ' minutes')::interval,$7,$8)`,
      [crypto.randomUUID(), user.id, user.email.toLowerCase(), hashEmailCode(code, user.email.toLowerCase(), user.id), hashEmailToken(token), String(settings.expiresMinutes), h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null]
    );
    return jsonOk({ sent: true, expiresIn: settings.expiresMinutes * 60, resendAfter: 60 });
  } catch (error) {
    console.error(error);
    return jsonError('ارسال کد ایمیل انجام نشد.', 500, 'EMAIL_SEND_FAILED');
  }
}
