import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { hashOtpCode, normalizeIranPhone } from '@/lib/phone';
import { getSmsIrApiKey, getSmsSettings } from '@/lib/sms-settings';
import { sendSmsIrVerify } from '@/lib/smsir';
import { createNotification } from '@/lib/notifications';
import { isSmsHostFromRequest } from '@/lib/host';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Verification = { id: string; phone: string; code_hash: string; attempts: number; expires_at: string; verified_at: string | null };

export async function POST(request: Request) {
  try {
    if (!isSmsHostFromRequest(request)) return jsonError('تایید پیامکی در این دامنه فعال نیست.', 404, 'NOT_FOUND');
    const user = await requireUser();
    const settings = await getSmsSettings();
    if (!settings.enabled) return jsonError('تایید پیامکی غیرفعال است.', 400, 'SMS_DISABLED');
    const body = await request.json();
    const phone = normalizeIranPhone(String(body.phone ?? ''));
    const code = String(body.code ?? '').replace(/\D/g, '');
    if (!phone || !/^\d{6}$/.test(code)) return jsonError('کد یا شماره معتبر نیست.');
    const duplicate = await query('select id from users where phone=$1 and phone_verified_at is not null and id<>$2 limit 1', [phone, user.id]);
    if (duplicate.rowCount) return jsonError('این شماره قبلاً برای حساب دیگری تایید شده است.', 409, 'PHONE_USED');
    const result = await query<Verification>(`select id, phone, code_hash, attempts, expires_at, verified_at from phone_verifications where user_id=$1 and phone=$2 order by created_at desc limit 1`, [user.id, phone]);
    const row = result.rows[0];
    if (!row || row.verified_at) return jsonError('کد تایید پیدا نشد. دوباره کد بگیرید.', 404, 'CODE_NOT_FOUND');
    if (new Date(row.expires_at).getTime() < Date.now()) return jsonError('کد تایید منقضی شده است. دوباره کد بگیرید.', 400, 'CODE_EXPIRED');
    if (row.attempts >= 5) return jsonError('تعداد تلاش‌ها بیش از حد مجاز است. دوباره کد بگیرید.', 429, 'ATTEMPTS_LIMIT');
    const expected = hashOtpCode(code, phone, user.id);
    if (expected !== row.code_hash) {
      await query('update phone_verifications set attempts=attempts+1 where id=$1', [row.id]);
      return jsonError('کد وارد شده صحیح نیست.', 400, 'INVALID_CODE');
    }
    await query('update phone_verifications set verified_at=now() where id=$1', [row.id]);
    await query('update users set phone=$1, phone_verified_at=now(), updated_at=now() where id=$2', [phone, user.id]);
    await createNotification({ userId: user.id, type: 'success', title: 'شماره همراه تایید شد', message: 'حساب شما فعال شد و اکنون می‌توانید از خدمات سایت استفاده کنید.', metadata: { phone } });
    if (settings.welcomeTemplateId) {
      try {
        const apiKey = await getSmsIrApiKey();
        await sendSmsIrVerify({ apiKey, mobile: phone.replace(/^0/, ''), templateId: Number(settings.welcomeTemplateId), parameters: [{ name: settings.welcomeNameParam || 'Name', value: user.name.slice(0, 25) }] });
      } catch (error) {
        console.error('welcome sms failed', error);
      }
    }
    return jsonOk({ verified: true });
  } catch (error) {
    console.error(error);
    return jsonError('تایید شماره انجام نشد.', 500, 'PHONE_VERIFY_FAILED');
  }
}
