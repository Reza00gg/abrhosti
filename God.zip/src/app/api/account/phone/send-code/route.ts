import crypto from 'crypto';
import { headers } from 'next/headers';
import { requireUser } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { generateOtpCode, hashOtpCode, normalizeIranPhone } from '@/lib/phone';
import { getSmsIrApiKey, getSmsSettings } from '@/lib/sms-settings';
import { sendSmsIrVerify } from '@/lib/smsir';
import { isSmsHostFromRequest } from '@/lib/host';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type CountRow = { count: string };

export async function POST(request: Request) {
  try {
    if (!isSmsHostFromRequest(request)) return jsonError('تایید پیامکی در این دامنه فعال نیست.', 404, 'NOT_FOUND');
    const user = await requireUser();
    const settings = await getSmsSettings();
    if (!settings.enabled) return jsonError('تایید پیامکی غیرفعال است.', 400, 'SMS_DISABLED');
    const body = await request.json();
    const phone = normalizeIranPhone(String(body.phone ?? ''));
    if (!phone) return jsonError('شماره موبایل معتبر نیست. مثال: 09123456789');
    const duplicate = await query('select id from users where phone=$1 and phone_verified_at is not null and id<>$2 limit 1', [phone, user.id]);
    if (duplicate.rowCount) return jsonError('این شماره قبلاً برای حساب دیگری تایید شده است.', 409, 'PHONE_USED');
    const last = await query<{ created_at: string }>('select created_at from phone_verifications where user_id=$1 order by created_at desc limit 1', [user.id]);
    if (last.rows[0] && Date.now() - new Date(last.rows[0].created_at).getTime() < 60_000) return jsonError('برای ارسال مجدد کد، کمی صبر کنید.', 429, 'TOO_SOON');
    const recent = await query<CountRow>(`select count(*)::text from phone_verifications where user_id=$1 and created_at > now() - interval '15 minutes'`, [user.id]);
    if (Number(recent.rows[0]?.count ?? 0) >= 3) return jsonError('تعداد ارسال کد بیش از حد مجاز است. کمی بعد تلاش کنید.', 429, 'RATE_LIMIT');
    const daily = await query<CountRow>(`select count(*)::text from phone_verifications where user_id=$1 and created_at > now() - interval '24 hours'`, [user.id]);
    if (Number(daily.rows[0]?.count ?? 0) >= 10) return jsonError('سقف ارسال پیامک امروز پر شده است.', 429, 'DAILY_LIMIT');
    const apiKey = await getSmsIrApiKey();
    if (!apiKey || !settings.verifyTemplateId) return jsonError('تنظیمات پیامک کامل نیست.', 500, 'SMS_CONFIG');
    const code = generateOtpCode();
    const h = headers();
    const sms = await sendSmsIrVerify({ apiKey, mobile: phone.replace(/^0/, ''), templateId: Number(settings.verifyTemplateId), parameters: [{ name: settings.verifyCodeParam || 'Code', value: code }] });
    if (!sms.ok) return jsonError(`پیامک ارسال نشد: ${sms.message}`, 502, 'SMS_SEND_FAILED');
    await query(
      `insert into phone_verifications (id,user_id,phone,code_hash,sms_message_id,expires_at,ip,user_agent)
       values ($1,$2,$3,$4,$5,now() + interval '5 minutes',$6,$7)`,
      [crypto.randomUUID(), user.id, phone, hashOtpCode(code, phone, user.id), String(sms.data?.data?.messageId ?? ''), h.get('x-forwarded-for') ?? null, h.get('user-agent') ?? null]
    );
    return jsonOk({ sent: true, expiresIn: 300, resendAfter: 60 });
  } catch (error) {
    console.error(error);
    return jsonError('ارسال کد تایید انجام نشد.', 500, 'PHONE_SEND_FAILED');
  }
}
