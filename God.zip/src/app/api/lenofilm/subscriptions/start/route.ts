import crypto from 'crypto';
import { getPool } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { getGatewaySettings, getZarinpalMerchant } from '@/lib/gateway-settings';
import { encryptSecret } from '@/lib/secure-settings';
import { isPaymentAllowedRequest, PAYMENT_BASE_URL } from '@/lib/payment-host';
import { zarinpalRequestPayment, zarinpalStartUrl } from '@/lib/gateways/zarinpal';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const TABLE_SQL = `
create table if not exists lenofilm_subscription_payments (
  id text primary key,
  lenofilm_order_id integer not null unique,
  amount_toman integer not null,
  title text not null,
  description text not null,
  user_email text,
  user_mobile text,
  notify_url text not null,
  return_success_url text not null,
  return_failed_url text not null,
  status text not null default 'created',
  authority text unique,
  ref_id text,
  gateway_url text,
  request_payload jsonb not null default '{}'::jsonb,
  verify_payload jsonb not null default '{}'::jsonb,
  notify_payload jsonb not null default '{}'::jsonb,
  failure_message text,
  merchant_encrypted text,
  sandbox boolean not null default false,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_lenofilm_subscription_payments_status on lenofilm_subscription_payments(status);
alter table lenofilm_subscription_payments add column if not exists merchant_encrypted text;
alter table lenofilm_subscription_payments add column if not exists sandbox boolean not null default false;
create index if not exists idx_lenofilm_subscription_payments_authority on lenofilm_subscription_payments(authority);
`;

type ExistingPayment = { id: string; lenofilm_order_id: number; status: string; gateway_url: string | null; authority: string | null };

function secret() {
  return process.env.LENO_ABRAHOST_PAYMENT_SECRET || '';
}

function sign(raw: string) {
  return crypto.createHmac('sha256', secret()).update(raw).digest('hex');
}

function safeEqual(a: string, b: string) {
  const left = Buffer.from(a || '', 'hex');
  const right = Buffer.from(b || '', 'hex');
  return left.length === right.length && left.length > 0 && crypto.timingSafeEqual(left, right);
}

async function ensureTable(client: any) {
  await client.query(TABLE_SQL);
}

export async function POST(request: Request) {
  if (!isPaymentAllowedRequest(request)) return jsonError('درخواست پرداخت فقط روی دامنه اصلی ابرهاست فعال است.', 403, 'PAYMENT_DOMAIN_NOT_ALLOWED');
  if (!secret()) return jsonError('کلید اتصال لنوفیلم و ابرهاست تنظیم نشده است.', 500, 'PAYMENT_SECRET_MISSING');

  const raw = await request.text();
  const signature = request.headers.get('x-leno-signature') || '';
  if (!safeEqual(signature, sign(raw))) return jsonError('امضای درخواست پرداخت معتبر نیست.', 401, 'BAD_SIGNATURE');

  let body: any;
  try { body = JSON.parse(raw); } catch { return jsonError('بدنه درخواست معتبر نیست.'); }

  const orderId = Number(body.orderId);
  const amountToman = Number(body.amountToman);
  const title = String(body.title || '').trim().slice(0, 160);
  const description = String(body.description || title || 'خرید اشتراک لنوفیلم').trim().slice(0, 255);
  const notifyUrl = String(body.notifyUrl || '').trim();
  const returnSuccessUrl = String(body.returnSuccessUrl || '').trim();
  const returnFailedUrl = String(body.returnFailedUrl || '').trim();
  const userEmail = body.userEmail ? String(body.userEmail).trim().slice(0, 160) : null;
  const userMobile = /^09\d{9}$/.test(String(body.userMobile || '')) ? String(body.userMobile) : null;

  if (!orderId || !Number.isFinite(orderId)) return jsonError('شناسه سفارش لنوفیلم معتبر نیست.');
  if (!amountToman || amountToman < 1000) return jsonError('مبلغ پرداخت معتبر نیست.');
  if (!title) return jsonError('عنوان پرداخت معتبر نیست.');
  if (!notifyUrl.startsWith('https://')) return jsonError('آدرس تایید لنوفیلم معتبر نیست.');
  if (!returnSuccessUrl.startsWith('https://') || !returnFailedUrl.startsWith('https://')) return jsonError('آدرس برگشت لنوفیلم معتبر نیست.');

  const settings = await getGatewaySettings();
  if (!settings.enabled || !settings.zarinpal.enabled) return jsonError('درگاه زرین‌پال ابرهاست فعال نیست.', 400, 'ZARINPAL_DISABLED');
  const merchantId = await getZarinpalMerchant();
  const sandbox = settings.zarinpal.sandbox;
  if (!merchantId) return jsonError('مرچنت زرین‌پال ابرهاست تنظیم نشده است.', 400, 'ZARINPAL_MERCHANT_MISSING');

  const client = await getPool().connect();
  const paymentId = crypto.randomUUID();
  try {
    await client.query('begin');
    await ensureTable(client);
    const existing = await client.query('select id,lenofilm_order_id,status,gateway_url,authority from lenofilm_subscription_payments where lenofilm_order_id=$1 limit 1', [orderId]);
    const old = existing.rows[0] as ExistingPayment | undefined;
    if (old?.gateway_url && ['created', 'requested'].includes(old.status)) {
      await client.query('commit');
      return jsonOk({ paymentId: old.id, authority: old.authority, gatewayUrl: old.gateway_url });
    }
    await client.query(
      `insert into lenofilm_subscription_payments (id,lenofilm_order_id,amount_toman,title,description,user_email,user_mobile,notify_url,return_success_url,return_failed_url,merchant_encrypted,sandbox,request_payload)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
       on conflict (lenofilm_order_id) do update set
         id=excluded.id, amount_toman=excluded.amount_toman, title=excluded.title, description=excluded.description,
         user_email=excluded.user_email, user_mobile=excluded.user_mobile, notify_url=excluded.notify_url,
         return_success_url=excluded.return_success_url, return_failed_url=excluded.return_failed_url,
         merchant_encrypted=excluded.merchant_encrypted, sandbox=excluded.sandbox,
         status='created', authority=null, ref_id=null, gateway_url=null, failure_message=null,
         request_payload=excluded.request_payload, verify_payload='{}'::jsonb, notify_payload='{}'::jsonb, updated_at=now()`,
      [paymentId, orderId, amountToman, title, description, userEmail, userMobile, notifyUrl, returnSuccessUrl, returnFailedUrl, encryptSecret(merchantId), sandbox, JSON.stringify({ source: 'lenofilm', orderId, amountToman, sandbox })]
    );
    await client.query('commit');
  } catch (e) {
    await client.query('rollback');
    console.error(e);
    return jsonError('ثبت پرداخت واسط ابرهاست انجام نشد.', 500, 'BRIDGE_PAYMENT_CREATE_FAILED');
  } finally { client.release(); }

  const callbackUrl = `${PAYMENT_BASE_URL}/api/lenofilm/subscriptions/callback/zarinpal`;
  const zp = await zarinpalRequestPayment({
    merchantId,
    amountToman,
    callbackUrl,
    description,
    orderId: `lenofilm-${orderId}`,
    email: userEmail || undefined,
    mobile: userMobile || undefined,
    sandbox,
  });

  if (!zp.ok || !zp.data.data?.authority) {
    await getPool().query(
      `update lenofilm_subscription_payments set status='failed', failure_message=$1, request_payload=request_payload || $2::jsonb, updated_at=now() where id=$3`,
      [zp.message, JSON.stringify({ zarinpal: zp.data }), paymentId]
    );
    return jsonError(`زرین‌پال: ${zp.message}`, 502, 'ZARINPAL_REQUEST_FAILED');
  }

  const authority = zp.data.data.authority;
  const gatewayUrl = String(zp.data.data?.link || zarinpalStartUrl(authority, sandbox));
  await getPool().query(
    `update lenofilm_subscription_payments set status='requested', authority=$1, gateway_url=$2, request_payload=request_payload || $3::jsonb, updated_at=now() where id=$4`,
    [authority, gatewayUrl, JSON.stringify({ zarinpal: zp.data }), paymentId]
  );

  return jsonOk({ paymentId, authority, gatewayUrl });
}
