import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { getPool, query } from '@/lib/db';
import { getGatewaySettings, getZarinpalMerchant } from '@/lib/gateway-settings';
import { decryptSecret } from '@/lib/secure-settings';
import { isPaymentAllowedRequest } from '@/lib/payment-host';
import { zarinpalVerifyPayment } from '@/lib/gateways/zarinpal';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Payment = {
  id: string;
  lenofilm_order_id: number;
  amount_toman: number;
  status: string;
  authority: string | null;
  ref_id: string | null;
  merchant_encrypted: string | null;
  sandbox: boolean;
  notify_url: string;
  return_success_url: string;
  return_failed_url: string;
};

function secret() { return process.env.LENO_ABRAHOST_PAYMENT_SECRET || ''; }
function hmac(raw: string) { return crypto.createHmac('sha256', secret()).update(raw).digest('hex'); }
function redirectTo(url: string) { return NextResponse.redirect(url || 'https://leno-film.vercel.app/account/subscription?payment=failed'); }

async function notifyLenofilm(payment: Payment, status: 'paid' | 'failed', extra: Record<string, unknown>) {
  if (!secret()) throw new Error('payment secret missing');
  const payload = {
    orderId: payment.lenofilm_order_id,
    status,
    provider: 'zarinpal',
    amountToman: Number(payment.amount_toman),
    authority: payment.authority || '',
    refId: String(extra.refId || payment.ref_id || ''),
    message: String(extra.message || ''),
    verifiedBy: 'lnupro.sbs',
    verifiedAt: new Date().toISOString(),
  };
  const raw = JSON.stringify(payload);
  const response = await fetch(payment.notify_url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-abrahost-signature': hmac(raw) },
    body: raw,
  });
  const text = await response.text();
  await query(`update lenofilm_subscription_payments set notify_payload=notify_payload || $1::jsonb, updated_at=now() where id=$2`, [JSON.stringify({ status: response.status, body: text.slice(0, 2000), payload }), payment.id]);
  if (!response.ok) throw new Error(`lenofilm notify failed: ${response.status} ${text.slice(0, 200)}`);
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  if (!isPaymentAllowedRequest(request)) return redirectTo('https://leno-film.vercel.app/account/subscription?payment=failed');
  const authority = url.searchParams.get('Authority') || '';
  const status = url.searchParams.get('Status') || '';
  if (!authority) return redirectTo('https://leno-film.vercel.app/account/subscription?payment=failed');

  const result = await query<Payment>('select id,lenofilm_order_id,amount_toman,status,authority,ref_id,merchant_encrypted,sandbox,notify_url,return_success_url,return_failed_url from lenofilm_subscription_payments where authority=$1 limit 1', [authority]);
  const payment = result.rows[0];
  if (!payment) return redirectTo('https://leno-film.vercel.app/account/subscription?payment=failed');
  if (payment.status === 'verified') return redirectTo(payment.return_success_url);

  if (status !== 'OK') {
    const message = `پرداخت ناموفق یا لغو شده. Status=${status}`;
    await query(`update lenofilm_subscription_payments set status='cancelled', failure_message=$1, verify_payload=$2, updated_at=now() where id=$3 and status <> 'verified'`, [message, JSON.stringify({ callback: Object.fromEntries(url.searchParams.entries()) }), payment.id]);
    try { await notifyLenofilm(payment, 'failed', { message }); } catch (e) { console.error(e); }
    return redirectTo(payment.return_failed_url);
  }

  const settings = await getGatewaySettings();
  const settingsMerchant = settings.enabled && settings.zarinpal.enabled ? await getZarinpalMerchant() : '';
  const merchantId = decryptSecret(payment.merchant_encrypted) || settingsMerchant;
  const sandbox = typeof payment.sandbox === 'boolean' ? payment.sandbox : settings.zarinpal.sandbox;
  const verify = await zarinpalVerifyPayment({ merchantId, amountToman: Number(payment.amount_toman), authority, sandbox });
  if (!verify.ok || !verify.data.data || ![100, 101].includes(Number(verify.data.data.code))) {
    await query(`update lenofilm_subscription_payments set status='failed', failure_message=$1, verify_payload=$2, updated_at=now() where id=$3 and status <> 'verified'`, [verify.message, JSON.stringify({ callback: Object.fromEntries(url.searchParams.entries()), verify: verify.data }), payment.id]);
    try { await notifyLenofilm(payment, 'failed', { message: verify.message }); } catch (e) { console.error(e); }
    return redirectTo(payment.return_failed_url);
  }

  const refId = String(verify.data.data.ref_id ?? '');
  const client = await getPool().connect();
  try {
    await client.query('begin');
    await client.query(`update lenofilm_subscription_payments set status='verified', ref_id=$1, verified_at=now(), verify_payload=$2, updated_at=now() where id=$3`, [refId, JSON.stringify({ callback: Object.fromEntries(url.searchParams.entries()), verify: verify.data }), payment.id]);
    await client.query('commit');
  } catch (e) { await client.query('rollback'); console.error(e); return redirectTo(payment.return_failed_url); }
  finally { client.release(); }

  try {
    await notifyLenofilm({ ...payment, ref_id: refId }, 'paid', { refId });
    return redirectTo(payment.return_success_url);
  } catch (e) {
    console.error(e);
    await query(`update lenofilm_subscription_payments set status='verified_sync_failed', failure_message=$1, updated_at=now() where id=$2`, [String(e), payment.id]);
    return redirectTo(payment.return_success_url);
  }
}
