import { requireAdmin } from '@/lib/auth';
import { getPool } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { products } from '@/lib/products';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  const admin = await requireAdmin();
  const body = await request.json().catch(() => ({}));
  if (String(body.confirm ?? '') !== 'RESET') return jsonError('برای ریست باید عبارت RESET را وارد کنید.');
  const client = await getPool().connect();
  try {
    await client.query('begin');
    await client.query('delete from payment_receipts');
    await client.query('delete from payment_sessions');
    await client.query('delete from order_items');
    await client.query('delete from orders');
    await client.query('delete from audit_events');
    await client.query('delete from user_oauth_accounts where user_id <> $1', [admin.id]);
    await client.query('delete from users where id <> $1', [admin.id]);
    await client.query('delete from products');
    for (const product of products) {
      await client.query(
        `insert into products (id, category, country, title, subtitle, price_monthly, currency, badge, specs, features, route, active)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,true)`,
        [product.id, product.category, product.country ?? null, product.title, product.subtitle, product.priceMonthly, product.currency, product.badge, JSON.stringify({ cpu: product.cpu, ram: product.ram, storage: product.storage, bandwidth: product.bandwidth }), JSON.stringify(product.features), product.route]
      );
    }
    await client.query('commit');
    return jsonOk({ reset: true });
  } catch (e) {
    await client.query('rollback');
    console.error(e);
    return jsonError('ریست اطلاعات انجام نشد.', 500);
  } finally {
    client.release();
  }
}
