import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { defaultGatewaySettings } from '@/lib/gateway-settings';
import { jsonError, jsonOk } from '@/lib/http';
import { encryptSecret } from '@/lib/secure-settings';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const admin = await requireAdmin();
  const currentResult = await query<{ value: any }>(`select value from app_settings where key='payment_gateways' limit 1`);
  const current = { ...defaultGatewaySettings, ...(currentResult.rows[0]?.value ?? {}) };
  const body = await request.json();
  const gatewayEnabled = Boolean(body.gatewayEnabled);
  const zibalMerchant = String(body.zibalMerchant ?? '').trim();
  const zibalEnabled = Boolean(body.zibalEnabled);
  const zibalSandbox = Boolean(body.zibalSandbox);
  const zarinpalMerchant = String(body.zarinpalMerchant ?? '').trim();
  const zarinpalEnabled = Boolean(body.zarinpalEnabled);
  const zarinpalSandbox = Boolean(body.zarinpalSandbox);
  const feeFixed = Math.max(0, Math.round(Number(body.feeFixed ?? 0)));
  const feePercent = Math.max(0, Number(body.feePercent ?? 0));
  if (zibalEnabled && !zibalSandbox && !zibalMerchant && !current.zibal?.merchantEncrypted) {
    return jsonError('برای فعال‌سازی زیبال، کد مرچنت را وارد کنید.');
  }
  if (zarinpalEnabled && !zarinpalMerchant && !current.zarinpal?.merchantEncrypted) {
    return jsonError('برای فعال‌سازی زرین‌پال، مرچنت را وارد کنید.');
  }
  const value = {
    enabled: gatewayEnabled,
    zibal: {
      enabled: zibalEnabled,
      sandbox: zibalSandbox,
      merchantEncrypted: zibalMerchant ? encryptSecret(zibalMerchant) : current.zibal?.merchantEncrypted || ''
    },
    zarinpal: {
      enabled: zarinpalEnabled,
      sandbox: zarinpalSandbox,
      merchantEncrypted: zarinpalMerchant ? encryptSecret(zarinpalMerchant) : current.zarinpal?.merchantEncrypted || ''
    },
    fee: { fixed: feeFixed, percent: feePercent }
  };
  await query(
    `insert into app_settings (key,value,updated_by,updated_at) values ('payment_gateways',$1,$2,now())
     on conflict (key) do update set value=excluded.value, updated_by=excluded.updated_by, updated_at=now()`,
    [JSON.stringify(value), admin.id]
  );
  return jsonOk({ saved: true });
}
