import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonOk, jsonError } from '@/lib/http';
export const runtime = 'nodejs';
export async function POST(request: Request) {
  const admin = await requireAdmin();
  const body = await request.json();
  const value = { bank: String(body.bank ?? '').trim(), cardNumber: String(body.cardNumber ?? '').trim(), iban: String(body.iban ?? '').trim(), ownerName: String(body.ownerName ?? '').trim(), description: String(body.description ?? '').trim() };
  if (!value.bank || !value.cardNumber || !value.ownerName) return jsonError('بانک، شماره کارت و نام صاحب کارت الزامی است.');
  await query(`insert into app_settings (key,value,updated_by,updated_at) values ('card_to_card',$1,$2,now()) on conflict (key) do update set value=excluded.value, updated_by=excluded.updated_by, updated_at=now()`, [JSON.stringify(value), admin.id]);
  return jsonOk({ saved: true });
}
