import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { defaultSmsSettings } from '@/lib/sms-settings';
import { encryptSecret } from '@/lib/secure-settings';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const admin = await requireAdmin();
  const currentResult = await query<{ value: any }>(`select value from app_settings where key='sms_settings' limit 1`);
  const current = { ...defaultSmsSettings, ...(currentResult.rows[0]?.value ?? {}) };
  const body = await request.json();
  const enabled = Boolean(body.enabled);
  const apiKey = String(body.apiKey ?? '').trim();
  const verifyTemplateId = Number(body.verifyTemplateId ?? 0);
  const verifyCodeParam = String(body.verifyCodeParam ?? 'Code').trim() || 'Code';
  const welcomeTemplateId = Number(body.welcomeTemplateId ?? 0) || undefined;
  const welcomeNameParam = String(body.welcomeNameParam ?? 'Name').trim() || 'Name';
  if (enabled && !apiKey && !current.apiKeyEncrypted) return jsonError('کلید API پیامک را وارد کنید.');
  if (enabled && !verifyTemplateId && !current.verifyTemplateId) return jsonError('شناسه قالب کد تایید را وارد کنید.');
  const value = {
    enabled,
    provider: 'smsir',
    apiKeyEncrypted: apiKey ? encryptSecret(apiKey) : current.apiKeyEncrypted || '',
    verifyTemplateId: verifyTemplateId || current.verifyTemplateId,
    verifyCodeParam,
    welcomeTemplateId,
    welcomeNameParam
  };
  await query(
    `insert into app_settings (key,value,updated_by,updated_at) values ('sms_settings',$1,$2,now())
     on conflict (key) do update set value=excluded.value, updated_by=excluded.updated_by, updated_at=now()`,
    [JSON.stringify(value), admin.id]
  );
  return jsonOk({ saved: true });
}
