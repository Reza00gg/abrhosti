import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { defaultEmailSettings } from '@/lib/email-settings';
import { jsonError, jsonOk } from '@/lib/http';
import { encryptSecret } from '@/lib/secure-settings';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const admin = await requireAdmin();
  const currentResult = await query<{ value: any }>(`select value from app_settings where key='email_settings' limit 1`);
  const current = { ...defaultEmailSettings, ...(currentResult.rows[0]?.value ?? {}) };
  const body = await request.json();
  const enabled = Boolean(body.enabled);
  const apiKey = String(body.apiKey ?? '').trim();
  const fromEmail = String(body.fromEmail ?? current.fromEmail).trim().toLowerCase();
  const fromName = String(body.fromName ?? current.fromName).trim() || 'ابرهاست';
  const expiresMinutes = Math.max(5, Math.min(30, Number(body.expiresMinutes ?? current.expiresMinutes ?? 10)));
  if (enabled && !apiKey && !current.apiKeyEncrypted) return jsonError('API Key سرویس Resend را وارد کنید.');
  if (enabled && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fromEmail)) return jsonError('ایمیل فرستنده معتبر نیست.');
  const value = {
    enabled,
    provider: 'resend',
    apiKeyEncrypted: apiKey ? encryptSecret(apiKey) : current.apiKeyEncrypted || '',
    fromEmail,
    fromName,
    expiresMinutes
  };
  await query(
    `insert into app_settings (key,value,updated_by,updated_at) values ('email_settings',$1,$2,now())
     on conflict (key) do update set value=excluded.value, updated_by=excluded.updated_by, updated_at=now()`,
    [JSON.stringify(value), admin.id]
  );
  return jsonOk({ saved: true });
}
