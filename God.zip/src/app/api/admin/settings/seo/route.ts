import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { defaultSeoSettings } from '@/lib/seo-settings';
import { jsonError, jsonOk } from '@/lib/http';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const admin = await requireAdmin();
  const body = await request.json();
  const indexingEnabled = Boolean(body.indexingEnabled);
  const siteName = String(body.siteName ?? defaultSeoSettings.siteName).trim().slice(0, 80) || defaultSeoSettings.siteName;
  const defaultTitle = String(body.defaultTitle ?? defaultSeoSettings.defaultTitle).trim().slice(0, 120) || defaultSeoSettings.defaultTitle;
  const defaultDescription = String(body.defaultDescription ?? defaultSeoSettings.defaultDescription).trim().slice(0, 240) || defaultSeoSettings.defaultDescription;

  if (defaultTitle.length < 10) return jsonError('عنوان سئو خیلی کوتاه است.');
  if (defaultDescription.length < 30) return jsonError('توضیحات سئو خیلی کوتاه است.');

  const value = { indexingEnabled, siteName, defaultTitle, defaultDescription };
  await query(
    `insert into app_settings (key,value,updated_by,updated_at) values ('seo_settings',$1,$2,now())
     on conflict (key) do update set value=excluded.value, updated_by=excluded.updated_by, updated_at=now()`,
    [JSON.stringify(value), admin.id]
  );
  return jsonOk({ saved: true });
}
