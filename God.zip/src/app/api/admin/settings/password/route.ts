import crypto from 'crypto';
import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { hashPassword, verifyPassword } from '@/lib/crypto';
import { jsonError, jsonOk } from '@/lib/http';
export const runtime = 'nodejs';
type Row={password_hash:string};
export async function POST(request: Request){const admin=await requireAdmin(); const body=await request.json(); const current=String(body.currentPassword??''); const next=String(body.newPassword??''); if(next.length<10) return jsonError('رمز جدید باید حداقل ۱۰ کاراکتر باشد.'); const r=await query<Row>('select password_hash from users where id=$1 limit 1',[admin.id]); if(!r.rows[0]||!verifyPassword(current,r.rows[0].password_hash)) return jsonError('رمز فعلی اشتباه است.',401); await query('update users set password_hash=$1, updated_at=now() where id=$2',[hashPassword(next),admin.id]); await query(`insert into audit_events (id,user_id,event,metadata) values ($1,$2,'admin.password.change','{}'::jsonb)`,[crypto.randomUUID(),admin.id]); return jsonOk({changed:true});}
