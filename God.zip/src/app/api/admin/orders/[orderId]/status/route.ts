import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonOk, jsonError } from '@/lib/http';
export async function POST(request: Request, { params }: { params: { orderId: string } }) { await requireAdmin(); const b=await request.json(); const status=String(b.status??''); const provision=String(b.provisionStatus??''); if(!status || !provision) return jsonError('وضعیت‌ها الزامی است.'); await query('update orders set status=$1, provision_status=$2, admin_note=$3, updated_at=now() where id=$4',[status,provision,String(b.note??'').slice(0,300)||null,params.orderId]); return jsonOk({updated:true}); }
