import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonOk, jsonError } from '@/lib/http';
export async function DELETE(request: Request, { params }: { params: { userId: string } }) {
  const admin = await requireAdmin();
  if (admin.id === params.userId) return jsonError('حذف حساب خودتان مجاز نیست.');
  const url = new URL(request.url);
  if (url.searchParams.get('hard') === '1') {
    await query('delete from users where id=$1 and role <> $2', [params.userId, 'admin']);
    return jsonOk({ deleted: true, hard: true });
  }
  await query(`update users set deleted_at=now(), deleted_reason='حذف شده توسط مدیر', updated_at=now() where id=$1 and role <> $2`, [params.userId, 'admin']);
  return jsonOk({ deleted: true, soft: true });
}
