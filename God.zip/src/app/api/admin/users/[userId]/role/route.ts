import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonOk, jsonError } from '@/lib/http';
export async function POST(request: Request, { params }: { params: { userId: string } }) { await requireAdmin(); const body=await request.json(); const role=String(body.role); if(!['user','admin'].includes(role)) return jsonError('نقش معتبر نیست.'); await query('update users set role=$1, updated_at=now() where id=$2',[role,params.userId]); return jsonOk({role}); }
