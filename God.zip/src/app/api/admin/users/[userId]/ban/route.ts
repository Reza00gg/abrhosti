import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonOk } from '@/lib/http';
export async function POST(request: Request, { params }: { params: { userId: string } }) { await requireAdmin(); const body=await request.json().catch(()=>({})); await query('update users set banned_at=now(), banned_reason=$1, updated_at=now() where id=$2 and role <> $3',[String(body.reason??'').slice(0,300)||'مسدود شده توسط مدیر',params.userId,'admin']); return jsonOk({banned:true}); }
