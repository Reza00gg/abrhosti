import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonOk } from '@/lib/http';
export async function POST(_: Request, { params }: { params: { userId: string } }) {
  await requireAdmin();
  await query('update users set deleted_at=null, deleted_reason=null, updated_at=now() where id=$1', [params.userId]);
  return jsonOk({ restored: true });
}
