import crypto from 'crypto';
import { requireAdmin } from '@/lib/auth';
import { getPool, query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { createNotification } from '@/lib/notifications';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type UserRow = { id: string; name: string; email: string; deleted_at: string | null };

export async function POST(request: Request, { params }: { params: { userId: string } }) {
  const admin = await requireAdmin();
  const body = await request.json().catch(() => ({}));
  const operation = String(body.operation ?? 'credit');
  const amount = Math.round(Number(body.amount ?? 0));
  const note = String(body.note ?? '').trim().slice(0, 300);

  if (!['credit', 'debit'].includes(operation)) return jsonError('نوع عملیات معتبر نیست.');
  if (!Number.isFinite(amount) || amount <= 0) return jsonError('مبلغ معتبر نیست.');
  if (amount > 500000000) return jsonError('مبلغ بیش از حد مجاز است.');

  const userResult = await query<UserRow>('select id, name, email, deleted_at from users where id=$1 limit 1', [params.userId]);
  const user = userResult.rows[0];
  if (!user) return jsonError('کاربر پیدا نشد.', 404);
  if (user.deleted_at) return jsonError('کاربر حذف شده است و امکان تغییر موجودی ندارد.', 400);

  const signedAmount = operation === 'credit' ? amount : -amount;
  const client = await getPool().connect();
  try {
    await client.query('begin');
    const wallet = await client.query<{ balance: number; currency: string }>(
      `insert into user_wallets (user_id, balance, currency) values ($1, 0, 'تومان')
       on conflict (user_id) do update set user_id=excluded.user_id
       returning balance, currency`,
      [params.userId]
    );
    const current = Number(wallet.rows[0]?.balance ?? 0);
    const currency = wallet.rows[0]?.currency ?? 'تومان';
    const next = current + signedAmount;
    await client.query('update user_wallets set balance=$1, updated_at=now() where user_id=$2', [next, params.userId]);
    const txId = crypto.randomUUID();
    await client.query(
      `insert into wallet_transactions (id,user_id,type,amount,currency,balance_after,reference_type,reference_id,description)
       values ($1,$2,$3,$4,$5,$6,'admin_adjustment',$7,$8)`,
      [txId, params.userId, operation === 'credit' ? 'admin_credit' : 'admin_debit', signedAmount, currency, next, admin.id, note || (operation === 'credit' ? 'افزایش موجودی توسط مدیریت' : 'کاهش موجودی توسط مدیریت')]
    );
    await client.query(
      `insert into audit_events (id,user_id,event,metadata) values ($1,$2,'admin.wallet.adjust',$3)`,
      [crypto.randomUUID(), admin.id, JSON.stringify({ targetUserId: params.userId, operation, amount, balanceBefore: current, balanceAfter: next, txId })]
    );
    await client.query('commit');

    if (operation === 'credit') {
      await createNotification({
        userId: params.userId,
        type: 'wallet',
        title: 'موجودی شما توسط مدیریت افزایش یافت',
        message: `مبلغ ${new Intl.NumberFormat('fa-IR').format(amount)} تومان از طرف مدیریت به حساب شما اضافه شد.`,
        metadata: { txId, amount, balanceAfter: next }
      });
    }

    return jsonOk({ balance: next, currency, transactionId: txId });
  } catch (error) {
    await client.query('rollback');
    console.error(error);
    return jsonError('تغییر موجودی انجام نشد.', 500);
  } finally {
    client.release();
  }
}
