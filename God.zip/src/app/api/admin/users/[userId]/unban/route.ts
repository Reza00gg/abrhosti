import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonOk } from '@/lib/http';
export async function POST(_: Request, { params }: { params: { userId: string } }) { await requireAdmin(); await query('update users set banned_at=null, banned_reason=null, updated_at=now() where id=$1',[params.userId]); return jsonOk({unbanned:true}); }
