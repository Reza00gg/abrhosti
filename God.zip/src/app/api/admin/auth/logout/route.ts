import { cookies } from 'next/headers';
import { ADMIN_SESSION_COOKIE } from '@/lib/auth';
import { jsonOk } from '@/lib/http';
export async function POST() { cookies().set(ADMIN_SESSION_COOKIE, '', { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 0 }); return jsonOk({ loggedOut: true }); }
