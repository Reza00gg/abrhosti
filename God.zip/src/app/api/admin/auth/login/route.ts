import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { query } from '@/lib/db';
import { ADMIN_SESSION_COOKIE } from '@/lib/auth';
import { signSession, verifyPassword } from '@/lib/crypto';
import { isValidEmail, jsonError, jsonOk, normalizeEmail } from '@/lib/http';

export const runtime = 'nodejs';

type DbUser = { id: string; name: string; email: string; role: 'user' | 'admin'; password_hash: string };

export async function POST(request: Request) {
  const h = headers();
  const ip = h.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown';
  const ua = h.get('user-agent') ?? null;
  try {
    const body = await request.json();
    const email = normalizeEmail(String(body.email ?? ''));
    const password = String(body.password ?? '');
    if (!isValidEmail(email) || !password) return jsonError('اطلاعات ورود معتبر نیست.');

    const failed = await query<{ count: string }>(`select count(*)::text from audit_events where event='admin.login.failed' and metadata->>'email'=$1 and coalesce(ip,'')=$2 and created_at > now() - interval '15 minutes'`, [email, ip]);
    if (Number(failed.rows[0]?.count ?? 0) >= 5) return jsonError('به دلیل تلاش‌های ناموفق، ورود موقتاً قفل شده است.', 429, 'ADMIN_LOCKED');

    const result = await query<DbUser>(`select id,name,email,role,password_hash from users where email=$1 and role='admin' limit 1`, [email]);
    const user = result.rows[0];
    if (!user || !verifyPassword(password, user.password_hash)) {
      await query(`insert into audit_events (id,event,ip,user_agent,metadata) values ($1,'admin.login.failed',$2,$3,$4)`, [crypto.randomUUID(), ip, ua, JSON.stringify({ email })]);
      return jsonError('ایمیل یا رمز عبور ادمین اشتباه است.', 401, 'INVALID_ADMIN');
    }

    const token = signSession({ sub: user.id, email: user.email, name: user.name }, 60 * 60 * 8);
    cookies().set(ADMIN_SESSION_COOKIE, token, { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 60 * 60 * 8 });
    await query(`insert into audit_events (id,user_id,event,ip,user_agent,metadata) values ($1,$2,'admin.login.success',$3,$4,'{}'::jsonb)`, [crypto.randomUUID(), user.id, ip, ua]);
    return jsonOk({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { console.error(e); return jsonError('ورود ادمین انجام نشد.', 500, 'ADMIN_LOGIN_FAILED'); }
}
