import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { createNotification } from '@/lib/notifications';
import { isTicketsHostFromRequest } from '@/lib/host';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ticket = { id: string; user_id: string; status: string; subject: string };

export async function POST(request: Request, { params }: { params: { ticketId: string } }) {
  if (!isTicketsHostFromRequest(request)) return jsonError('سیستم تیکت در این دامنه فعال نیست.', 404, 'NOT_FOUND');
  const admin = await requireAdmin();
  const result = await query<Ticket>('select id,user_id,status,subject from tickets where id=$1 limit 1', [params.ticketId]);
  const ticket = result.rows[0];
  if (!ticket) return jsonError('تیکت پیدا نشد.', 404);
  await query(`update tickets set status='closed', closed_by=$1, closed_at=now(), updated_at=now() where id=$2`, [admin.id, ticket.id]);
  await createNotification({ userId: ticket.user_id, type: 'warning', title: 'تیکت بسته شد', message: `تیکت «${ticket.subject}» توسط پشتیبانی بسته شد.`, metadata: { ticketId: ticket.id } });
  return jsonOk({ closed: true });
}
