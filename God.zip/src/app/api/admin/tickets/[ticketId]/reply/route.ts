import crypto from 'crypto';
import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { createNotification } from '@/lib/notifications';
import { isTicketsHostFromRequest } from '@/lib/host';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ticket = { id: string; user_id: string; status: string; subject: string };

export async function POST(request: Request, { params }: { params: { ticketId: string } }) {
  if (!isTicketsHostFromRequest(request)) return jsonError('سیستم تیکت در این دامنه فعال نیست.', 404, 'NOT_FOUND');
  const admin = await requireAdmin();
  const body = await request.json();
  const message = String(body.message ?? '').trim().slice(0, 4000);
  if (message.length < 2) return jsonError('متن پاسخ را وارد کنید.');
  const result = await query<Ticket>('select id,user_id,status,subject from tickets where id=$1 limit 1', [params.ticketId]);
  const ticket = result.rows[0];
  if (!ticket) return jsonError('تیکت پیدا نشد.', 404);
  if (ticket.status === 'closed') return jsonError('این تیکت بسته شده است.');
  await query(`insert into ticket_messages (id,ticket_id,sender_id,sender_role,message) values ($1,$2,$3,'admin',$4)`, [crypto.randomUUID(), ticket.id, admin.id, message]);
  await query(`update tickets set status='answered', updated_at=now() where id=$1`, [ticket.id]);
  await createNotification({ userId: ticket.user_id, type: 'info', title: 'تیکت شما پاسخ داده شد', message: `پشتیبانی به تیکت «${ticket.subject}» پاسخ داد.`, metadata: { ticketId: ticket.id } });
  return jsonOk({ sent: true });
}
