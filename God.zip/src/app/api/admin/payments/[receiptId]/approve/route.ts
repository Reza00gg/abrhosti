import crypto from 'crypto';
import { requireAdmin } from '@/lib/auth';
import { getPool, query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
export const runtime = 'nodejs';
type Receipt = { order_id: string | null; topup_id: string | null; user_id: string; amount: number; currency: string; status: string; purpose: 'service_order' | 'wallet_topup' };
export async function POST(_: Request, { params }: { params: { receiptId: string } }) {
  const admin = await requireAdmin();
  const receipt = await query<Receipt>(`select pr.order_id, pr.topup_id, pr.user_id, pr.amount, coalesce(o.currency, wt.currency, 'تومان') as currency, pr.status, pr.purpose from payment_receipts pr left join orders o on o.id=pr.order_id left join wallet_topups wt on wt.id=pr.topup_id where pr.id=$1 limit 1`, [params.receiptId]);
  const row = receipt.rows[0]; if (!row) return jsonError('رسید پیدا نشد.', 404);
  if (row.status === 'approved') return jsonOk({ approved: true, already: true });
  const client = await getPool().connect();
  try {
    await client.query('begin');
    await client.query(`update payment_receipts set status='approved', reviewed_by=$1, reviewed_at=now() where id=$2`, [admin.id, params.receiptId]);
    if (row.purpose === 'wallet_topup') {
      const wallet = await client.query<{ balance: number }>(
        `insert into user_wallets (user_id, balance, currency) values ($1, 0, $2)
         on conflict (user_id) do update set user_id=excluded.user_id returning balance`,
        [row.user_id, row.currency]
      );
      const nextBalance = Number(wallet.rows[0].balance) + Number(row.amount);
      await client.query(`update user_wallets set balance=$1, updated_at=now() where user_id=$2`, [nextBalance, row.user_id]);
      await client.query(`insert into wallet_transactions (id,user_id,type,amount,currency,balance_after,reference_type,reference_id,description) values ($1,$2,'credit',$3,$4,$5,'topup',$6,'افزایش موجودی با کارت‌به‌کارت')`, [crypto.randomUUID(), row.user_id, row.amount, row.currency, nextBalance, row.topup_id]);
      await client.query(`update wallet_topups set status='approved', payment_status='approved_card_to_card', approved_by=$1, approved_at=now(), updated_at=now() where id=$2`, [admin.id, row.topup_id]);
      await client.query(`insert into notifications (id,user_id,type,title,message,metadata) values ($1,$2,'success','موجودی شما افزایش یافت',$3,$4)`, [crypto.randomUUID(), row.user_id, `مبلغ ${new Intl.NumberFormat('fa-IR').format(Number(row.amount))} تومان به موجودی حساب شما اضافه شد.`, JSON.stringify({ topupId: row.topup_id, receiptId: params.receiptId })]);
    } else {
      await client.query(`update orders set status='approved', payment_status='approved_card_to_card', provision_status='queued', approved_by=$1, approved_at=now(), updated_at=now() where id=$2`, [admin.id, row.order_id]);
      await client.query(`insert into notifications (id,user_id,type,title,message,metadata) values ($1,$2,'success','پرداخت سفارش تایید شد','پرداخت شما تایید شد و سفارش در صف تحویل قرار گرفت.',$3)`, [crypto.randomUUID(), row.user_id, JSON.stringify({ orderId: row.order_id, receiptId: params.receiptId })]);
    }
    await client.query(`insert into audit_events (id,user_id,event,metadata) values ($1,$2,'admin.payment.approve',$3)`, [crypto.randomUUID(), admin.id, JSON.stringify({ receiptId: params.receiptId, orderId: row.order_id, topupId: row.topup_id, purpose: row.purpose })]);
    await client.query('commit');
    return jsonOk({ approved: true });
  } catch (e) { await client.query('rollback'); console.error(e); return jsonError('تایید پرداخت انجام نشد.', 500); } finally { client.release(); }
}
