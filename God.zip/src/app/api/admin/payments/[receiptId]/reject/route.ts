import crypto from 'crypto';
import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { jsonError, jsonOk } from '@/lib/http';
import { createNotification } from '@/lib/notifications';
export const runtime = 'nodejs';
type Receipt = { order_id: string | null; topup_id: string | null; user_id: string; purpose: 'service_order' | 'wallet_topup' };
export async function POST(request: Request, { params }: { params: { receiptId: string } }) {
  const admin = await requireAdmin();
  const body = await request.json().catch(() => ({}));
  const note = String(body.note ?? '').slice(0, 300);
  const receipt = await query<Receipt>('select order_id, topup_id, user_id, purpose from payment_receipts where id=$1 limit 1', [params.receiptId]);
  const row = receipt.rows[0]; if (!row) return jsonError('رسید پیدا نشد.', 404);
  await query(`update payment_receipts set status='rejected', admin_note=$1, reviewed_by=$2, reviewed_at=now() where id=$3`, [note || null, admin.id, params.receiptId]);
  if (row.purpose === 'wallet_topup') {
    await query(`update wallet_topups set status='rejected', payment_status='rejected', admin_note=$1, updated_at=now() where id=$2`, [note || null, row.topup_id]);
  } else {
    await query(`update orders set status='payment_rejected', payment_status='rejected', provision_status='on_hold', admin_note=$1, updated_at=now() where id=$2`, [note || null, row.order_id]);
  }
  await createNotification({ userId: row.user_id, type: 'error', title: row.purpose === 'wallet_topup' ? 'افزایش موجودی رد شد' : 'پرداخت سفارش رد شد', message: note || 'رسید پرداخت توسط مدیر رد شد.', metadata: { orderId: row.order_id, topupId: row.topup_id, receiptId: params.receiptId } });
  await query(`insert into audit_events (id,user_id,event,metadata) values ($1,$2,'admin.payment.reject',$3)`, [crypto.randomUUID(), admin.id, JSON.stringify({ receiptId: params.receiptId, orderId: row.order_id, topupId: row.topup_id, purpose: row.purpose })]);
  return jsonOk({ rejected: true });
}
