import { requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';

type Row = { receipt_file_name: string; receipt_mime: string; receipt_data: string };
export const runtime = 'nodejs';
export async function GET(_: Request, { params }: { params: { receiptId: string } }) {
  await requireAdmin();
  const r = await query<Row>('select receipt_file_name, receipt_mime, receipt_data from payment_receipts where id=$1 limit 1', [params.receiptId]);
  const row = r.rows[0];
  if (!row) return new Response('Not found', { status: 404 });
  const bytes = Buffer.from(row.receipt_data, 'base64');
  return new Response(bytes, { headers: { 'Content-Type': row.receipt_mime, 'Content-Disposition': `inline; filename="${encodeURIComponent(row.receipt_file_name)}"`, 'Cache-Control': 'private, max-age=60' } });
}
