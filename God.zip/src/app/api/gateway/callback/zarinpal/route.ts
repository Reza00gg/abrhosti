import { NextResponse } from 'next/server';
import { getPool, query } from '@/lib/db';
import { getGatewaySettings, getZarinpalMerchant } from '@/lib/gateway-settings';
import { isPaymentAllowedRequest, PAYMENT_BASE_URL } from '@/lib/payment-host';
import { zarinpalVerifyPayment } from '@/lib/gateways/zarinpal';
import { creditWalletForVerifiedGateway } from '@/lib/gateway-credit';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type GatewayPayment = { id: string; user_id: string; topup_id: string; payment_session_id: string | null; amount: number; fee_amount: number; payable_amount: number; currency: string; status: string; authority: string | null };
function resultUrl(id: string, status: 'success' | 'failed') { return `${PAYMENT_BASE_URL}/wallet/payment/result?paymentId=${encodeURIComponent(id)}&status=${status}`; }

export async function GET(request: Request) {
  const url = new URL(request.url);
  if (!isPaymentAllowedRequest(request)) return NextResponse.redirect(`${PAYMENT_BASE_URL}/wallet/payment/result?status=failed`);
  const authority = url.searchParams.get('Authority');
  const status = url.searchParams.get('Status');
  if (!authority) return NextResponse.redirect(`${PAYMENT_BASE_URL}/wallet/payment/result?status=failed`);
  const result = await query<GatewayPayment>(`select id,user_id,topup_id,payment_session_id,amount,fee_amount,payable_amount,currency,status,authority from gateway_payments where provider='zarinpal' and authority=$1 limit 1`, [authority]);
  const payment = result.rows[0];
  if (!payment) return NextResponse.redirect(`${PAYMENT_BASE_URL}/wallet/payment/result?status=failed`);
  if (payment.status === 'verified') return NextResponse.redirect(resultUrl(payment.id, 'success'));
  if (status !== 'OK') {
    await query(`update gateway_payments set status='cancelled', failure_message=$1, verify_payload=$2, updated_at=now() where id=$3 and status <> 'verified'`, [`پرداخت ناموفق یا لغو شده. Status=${status ?? ''}`, JSON.stringify({ callback: Object.fromEntries(url.searchParams.entries()) }), payment.id]);
    await query(`update wallet_topups set status='cancelled', payment_status='cancelled', updated_at=now() where id=$1`, [payment.topup_id]);
    return NextResponse.redirect(resultUrl(payment.id, 'failed'));
  }
  const settings = await getGatewaySettings();
  const merchantId = await getZarinpalMerchant();
  const verify = await zarinpalVerifyPayment({ merchantId, amountToman: Number(payment.payable_amount), authority, sandbox: settings.zarinpal.sandbox });
  if (!verify.ok || !verify.data.data || ![100, 101].includes(Number(verify.data.data.code))) {
    await query(`update gateway_payments set status='failed', failure_message=$1, verify_payload=$2, updated_at=now() where id=$3 and status <> 'verified'`, [verify.message, JSON.stringify({ callback: Object.fromEntries(url.searchParams.entries()), verify: verify.data }), payment.id]);
    await query(`update wallet_topups set status='failed', payment_status='gateway_failed', updated_at=now() where id=$1`, [payment.topup_id]);
    return NextResponse.redirect(resultUrl(payment.id, 'failed'));
  }
  const client = await getPool().connect();
  try {
    await client.query('begin');
    await creditWalletForVerifiedGateway(client, payment, 'zarinpal', String(verify.data.data.ref_id ?? ''), { callback: Object.fromEntries(url.searchParams.entries()), verify: verify.data });
    await client.query('commit');
    return NextResponse.redirect(resultUrl(payment.id, 'success'));
  } catch (e) {
    await client.query('rollback');
    console.error(e);
    return NextResponse.redirect(resultUrl(payment.id, 'failed'));
  } finally { client.release(); }
}
