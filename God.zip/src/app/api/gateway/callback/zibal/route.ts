import { NextResponse } from 'next/server';
import { getPool, query } from '@/lib/db';
import { getZibalMerchant } from '@/lib/gateway-settings';
import { isPaymentAllowedRequest, PAYMENT_BASE_URL } from '@/lib/payment-host';
import { zibalVerifyPayment } from '@/lib/gateways/zibal';
import { creditWalletForVerifiedGateway } from '@/lib/gateway-credit';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type GatewayPayment = { id: string; user_id: string; topup_id: string; payment_session_id: string | null; amount: number; fee_amount: number; payable_amount: number; currency: string; status: string; track_id: string | null };

function resultUrl(id: string, status: 'success' | 'failed') { return `${PAYMENT_BASE_URL}/wallet/payment/result?paymentId=${encodeURIComponent(id)}&status=${status}`; }

export async function GET(request: Request) {
  const url = new URL(request.url);
  if (!isPaymentAllowedRequest(request)) return NextResponse.redirect(`${PAYMENT_BASE_URL}/wallet/payment/result?status=failed`);
  const trackId = url.searchParams.get('trackId');
  const success = url.searchParams.get('success');
  const status = url.searchParams.get('status');
  if (!trackId) return NextResponse.redirect(`${PAYMENT_BASE_URL}/wallet/payment/result?status=failed`);
  const paymentResult = await query<GatewayPayment>(`select id,user_id,topup_id,payment_session_id,amount,fee_amount,payable_amount,currency,status,track_id from gateway_payments where provider='zibal' and track_id=$1 limit 1`, [trackId]);
  const payment = paymentResult.rows[0];
  if (!payment) return NextResponse.redirect(`${PAYMENT_BASE_URL}/wallet/payment/result?status=failed`);
  if (payment.status === 'verified') return NextResponse.redirect(resultUrl(payment.id, 'success'));
  if (success !== '1') {
    await query(`update gateway_payments set status='cancelled', failure_message=$1, verify_payload=$2, updated_at=now() where id=$3 and status <> 'verified'`, [`پرداخت ناموفق یا لغو شده. status=${status ?? ''}`, JSON.stringify({ callback: Object.fromEntries(url.searchParams.entries()) }), payment.id]);
    await query(`update wallet_topups set status='cancelled', payment_status='cancelled', updated_at=now() where id=$1`, [payment.topup_id]);
    return NextResponse.redirect(resultUrl(payment.id, 'failed'));
  }
  const merchant = await getZibalMerchant();
  const verify = await zibalVerifyPayment({ merchant, trackId: Number(trackId) });
  if (!verify.ok || !verify.data || ![100, 201].includes(verify.data.result)) {
    await query(`update gateway_payments set status='failed', failure_message=$1, verify_payload=$2, updated_at=now() where id=$3 and status <> 'verified'`, [verify.data?.message || 'verify failed', JSON.stringify({ callback: Object.fromEntries(url.searchParams.entries()), verify: verify.data }), payment.id]);
    await query(`update wallet_topups set status='failed', payment_status='gateway_failed', updated_at=now() where id=$1`, [payment.topup_id]);
    return NextResponse.redirect(resultUrl(payment.id, 'failed'));
  }
  const verifiedAmountToman = Math.round(Number(verify.data.amount ?? 0) / 10);
  if (verifiedAmountToman !== Number(payment.payable_amount)) {
    await query(`update gateway_payments set status='failed', failure_message='amount mismatch', verify_payload=$1, updated_at=now() where id=$2 and status <> 'verified'`, [JSON.stringify({ callback: Object.fromEntries(url.searchParams.entries()), verify: verify.data, expectedToman: payment.payable_amount, gotToman: verifiedAmountToman }), payment.id]);
    return NextResponse.redirect(resultUrl(payment.id, 'failed'));
  }
  const client = await getPool().connect();
  try {
    await client.query('begin');
    await creditWalletForVerifiedGateway(client, payment, 'zibal', String(verify.data.refNumber ?? ''), { callback: Object.fromEntries(url.searchParams.entries()), verify: verify.data });
    await client.query('commit');
    return NextResponse.redirect(resultUrl(payment.id, 'success'));
  } catch (e) {
    await client.query('rollback');
    console.error(e);
    return NextResponse.redirect(resultUrl(payment.id, 'failed'));
  } finally { client.release(); }
}
