import { ProductLanding } from '@/components/ProductLanding';
import { getCatalogByCategory } from '@/lib/catalog';

export default async function SharedHostingPage() {
  return <ProductLanding visual="shared" eyebrow="Shared Hosting" title="هاست اشتراکی سریع و اقتصادی" description="برای سایت شرکتی، وردپرس و شروع فروشگاه آنلاین." products={await getCatalogByCategory('shared')} />;
}
