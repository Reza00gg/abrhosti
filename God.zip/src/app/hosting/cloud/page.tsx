import { ProductLanding } from '@/components/ProductLanding';
import { getCatalogByCategory } from '@/lib/catalog';

export default async function CloudHostingPage() {
  return <ProductLanding visual="cloud" eyebrow="Cloud Hosting" title="هاست ابری پایدار و مقیاس‌پذیر" description="برای فروشگاه، اپلیکیشن و سایت‌های پرترافیک." products={await getCatalogByCategory('cloud')} />;
}
