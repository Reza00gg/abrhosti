import { ProductLanding } from '@/components/ProductLanding';
import { getCatalogByCategory } from '@/lib/catalog';

export default async function DedicatedHostingPage() {
  return <ProductLanding visual="dedicated" eyebrow="Dedicated Servers" title="سرور اختصاصی برای پروژه‌های سنگین" description="منابع کامل، شبکه پایدار و کنترل بیشتر." products={await getCatalogByCategory('dedicated')} />;
}
