import { Globe2 } from 'lucide-react';
import { DomainChecker } from '@/components/DomainChecker';
import { popularTlds, tldPrices } from '@/lib/domain-rdap';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatPrice } from '@/lib/products';

export default async function DomainsPage() {
  const featured = ['com', 'net', 'org', 'io', 'app', 'dev', 'cloud', 'shop', 'store', 'online', 'co', 'ai'];
  return (
    <>
      <section className="border-b border-slate-200 bg-white py-12">
        <div className="shell"><DomainChecker /></div>
      </section>
      <section className="py-12">
        <div className="shell">
          <div className="mb-6">
            <Badge variant="secondary"><Globe2 size={13} className="ml-1" /> TLDs</Badge>
            <h2 className="mt-4 text-3xl font-black text-slate-950">پسوندهای پرکاربرد</h2>
            <p className="mt-2 text-sm leading-7 text-slate-500">برای ثبت، ابتدا نام کامل دامنه را در جستجوی بالا بررسی کنید.</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((tld) => (
              <Card key={tld} className="p-4">
                <strong className="text-xl font-black text-slate-950 dir-ltr">.{tld}</strong>
                <p className="mt-2 text-sm font-bold text-slate-500">از {formatPrice(tldPrices[tld] ?? 990000)} / سال</p>
              </Card>
            ))}
          </div>
          <div className="mt-6 rounded-3xl border border-slate-200 bg-white p-5 text-sm leading-8 text-slate-500">
            ابرهاست از بیش از {popularTlds.length.toLocaleString('fa-IR')} پسوند بین‌المللی پشتیبانی می‌کند. برای پسوندهای کمتر شناخته‌شده هم وضعیت از رجیستری RDAP بررسی می‌شود.
          </div>
        </div>
      </section>
    </>
  );
}
