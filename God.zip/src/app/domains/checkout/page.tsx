import Link from 'next/link';
import { notFound } from 'next/navigation';
import { CheckCircle2, Globe2 } from 'lucide-react';
import { checkDomainAvailability, getDomainPrice, normalizeDomain } from '@/lib/domain-rdap';
import { DomainOrderForm } from '@/components/DomainOrderForm';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatPrice } from '@/lib/products';

export const dynamic = 'force-dynamic';

export default async function DomainCheckoutPage({ searchParams }: { searchParams: { domain?: string } }) {
  const domain = normalizeDomain(String(searchParams.domain ?? ''));
  if (!domain) notFound();
  const check = await checkDomainAvailability(domain);
  if (!check.supported || !check.available) {
    return (
      <div className="shell py-10">
        <Card className="mx-auto max-w-xl p-6">
          <Badge variant="warning">Domain Check</Badge>
          <h1 className="mt-4 text-2xl font-black text-slate-950">امکان ثبت دامنه وجود ندارد</h1>
          <p className="mt-3 text-sm leading-8 text-slate-500">{check.message}</p>
          <Button asChild className="mt-5"><Link href="/domains">بازگشت به جستجوی دامنه</Link></Button>
        </Card>
      </div>
    );
  }
  const price = getDomainPrice(check.tld);

  return (
    <div className="shell grid gap-6 py-10 lg:grid-cols-[.85fr_1.15fr] lg:items-start">
      <Card className="overflow-hidden">
        <div className="bg-slate-950 p-7 text-white">
          <Badge className="bg-white/10 text-white" variant="outline"><Globe2 size={13} className="ml-1" /> دامنه آزاد است</Badge>
          <h1 className="mt-5 text-3xl font-black tracking-tight dir-ltr">{domain}</h1>
          <p className="mt-3 text-sm leading-8 text-slate-300">این دامنه با RDAP رجیستری بررسی شد و در حال حاضر آزاد است.</p>
        </div>
        <div className="grid gap-3 p-6 text-sm">
          <div className="flex justify-between rounded-2xl bg-slate-50 p-4"><span className="font-bold text-slate-500">پسوند</span><strong className="dir-ltr">.{check.tld}</strong></div>
          <div className="flex justify-between rounded-2xl bg-slate-50 p-4"><span className="font-bold text-slate-500">قیمت سالانه</span><strong>{formatPrice(price)}</strong></div>
          <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4 text-emerald-700"><CheckCircle2 className="mb-2 h-5 w-5" /> پس از تایید پرداخت، ثبت دامنه توسط پشتیبانی انجام می‌شود.</div>
        </div>
      </Card>
      <Card className="p-6"><DomainOrderForm domain={domain} unitPrice={price} /></Card>
    </div>
  );
}
