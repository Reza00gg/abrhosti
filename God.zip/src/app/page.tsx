import Link from 'next/link';
import { ArrowLeft, BarChart3, Check, Cloud, Cpu, DatabaseZap, Globe2, Headphones, Layers3, LockKeyhole, Network, Server, ShieldCheck, Sparkles, Zap } from 'lucide-react';
import { ProductCard } from '@/components/ProductCard';
import { SectionHead } from '@/components/SectionHead';
import { CountryGrid } from '@/components/CountryGrid';
import { DomainChecker } from '@/components/DomainChecker';
import { getCatalogByCategory } from '@/lib/catalog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';



const capabilities = [
  { icon: ShieldCheck, title: 'امنیت حساب', desc: 'Session امن، هش رمز، ثبت رویدادها و آماده اتصال 2FA' },
  { icon: Zap, title: 'تحویل سریع', desc: 'ثبت سفارش و قرارگیری سرویس در صف provisioning' },
  { icon: BarChart3, title: 'پنل مدیریتی', desc: 'مشاهده سفارش‌ها، سرویس‌ها، مالی و وضعیت تحویل' },
  { icon: Headphones, title: 'تجربه پشتیبانی', desc: 'ساختار آماده برای تیکت، مانیتورینگ و اعلان‌ها' }
];

export default async function HomePage() {
  const productTabs = [
    { value: 'cloud', label: 'هاست ابری', products: await getCatalogByCategory('cloud') },
    { value: 'shared', label: 'اشتراکی', products: await getCatalogByCategory('shared') },
    { value: 'vps', label: 'VPS', products: (await getCatalogByCategory('vps')).slice(0, 3) },
    { value: 'domain', label: 'دامنه', products: await getCatalogByCategory('domain') }
  ];
  return (
    <>
      <section className="relative overflow-hidden border-b border-slate-200 bg-white">
        <div className="absolute inset-0 bg-grid opacity-70" />
        <div className="shell relative grid min-h-[650px] gap-10 py-12 lg:grid-cols-[1.05fr_.95fr] lg:items-center lg:py-16">
          <div>
            <Badge variant="secondary" className="mb-5 border-sky-100 bg-sky-50 text-sky-700"><Sparkles size={14} className="ml-1" /> سرویس ابری و هاستینگ</Badge>
            <h1 className="text-balance text-4xl font-black leading-[1.15] tracking-tight text-slate-950 md:text-6xl">
              هاست، VPS و دامنه را سریع انتخاب کنید
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-9 text-slate-500 md:text-lg">
              سرویس موردنظرتان را انتخاب کنید، سفارش دهید و وضعیت پرداخت و تحویل را از داشبورد پیگیری کنید.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg"><Link href="/hosting/cloud">مشاهده پلن‌ها <ArrowLeft size={18} /></Link></Button>
              <Button asChild size="lg" variant="secondary"><Link href="/domains">جستجوی دامنه</Link></Button>
            </div>
            <div className="mt-9 grid gap-3 sm:grid-cols-3">
              <div className="rounded-3xl border border-slate-200 bg-white/80 p-4 shadow-sm"><strong className="block text-2xl font-black text-slate-950">پلن‌ها</strong><span className="text-xs font-bold text-slate-500">پلن آماده فروش</span></div>
              <div className="rounded-3xl border border-slate-200 bg-white/80 p-4 shadow-sm"><strong className="block text-2xl font-black text-slate-950">۶</strong><span className="text-xs font-bold text-slate-500">لوکیشن سرور مجازی</span></div>
              <div className="rounded-3xl border border-slate-200 bg-white/80 p-4 shadow-sm"><strong className="block text-2xl font-black text-slate-950">پرداخت</strong><span className="text-xs font-bold text-slate-500">کارت‌به‌کارت</span></div>
            </div>
          </div>

          <div className="relative">
            <Card className="overflow-hidden rounded-[2rem] border-slate-200 bg-white/95 shadow-[0_34px_100px_rgba(15,23,42,.12)]">
              <div className="border-b border-slate-100 p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-black text-slate-950">کنسول خرید ابرهاست</div>
                    <div className="mt-1 text-xs font-bold text-slate-400">انتخاب سرویس، لوکیشن و ثبت سفارش</div>
                  </div>
                  <Badge variant="success">Live</Badge>
                </div>
              </div>
              <div className="grid gap-4 p-5">
                {[
                  { icon: Cloud, title: 'هاست ابری Scale', meta: '۴ vCPU / ۸GB RAM', status: 'پیشنهادی', href: '/checkout/cloud-scale' },
                  { icon: Server, title: 'VPS آلمان ۴ گیگ', meta: 'Frankfurt / IPv4 اختصاصی', status: 'تحویل سریع', href: '/checkout/vps-de-4' },
                  { icon: Globe2, title: 'دامنه .com', meta: 'DNS مدیریت‌شده', status: 'ثبت سالانه', href: '/checkout/domain-com' }
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href} className="group flex items-center justify-between gap-4 rounded-3xl border border-slate-200 bg-slate-50/70 p-4 transition hover:border-sky-200 hover:bg-sky-50">
                      <span className="flex items-center gap-3">
                        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white text-sky-700 shadow-sm"><Icon size={23} /></span>
                        <span>
                          <strong className="block text-sm font-black text-slate-950">{item.title}</strong>
                          <span className="mt-1 block text-xs font-bold text-slate-500">{item.meta}</span>
                        </span>
                      </span>
                      <Badge variant="secondary">{item.status}</Badge>
                    </Link>
                  );
                })}
              </div>
              <div className="grid grid-cols-3 border-t border-slate-100 bg-slate-50">
                <div className="p-4 text-center"><Cpu className="mx-auto mb-2 h-5 w-5 text-sky-600" /><span className="text-xs font-black text-slate-500">Compute</span></div>
                <div className="border-x border-slate-100 p-4 text-center"><DatabaseZap className="mx-auto mb-2 h-5 w-5 text-sky-600" /><span className="text-xs font-black text-slate-500">Storage</span></div>
                <div className="p-4 text-center"><Network className="mx-auto mb-2 h-5 w-5 text-sky-600" /><span className="text-xs font-black text-slate-500">Network</span></div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-14">
        <div className="shell">
          <div className="grid gap-4 md:grid-cols-4">
            {capabilities.map((item) => {
              const Icon = item.icon;
              return (
                <Card key={item.title} className="p-5 transition hover:-translate-y-1 hover:border-sky-200 hover:shadow-[0_24px_70px_rgba(14,165,233,.10)]">
                  <div className="grid h-12 w-12 place-items-center rounded-2xl bg-sky-50 text-sky-700"><Icon size={23} /></div>
                  <h3 className="mt-5 text-lg font-black text-slate-950">{item.title}</h3>
                  <p className="mt-2 text-sm leading-8 text-slate-500">{item.desc}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="shell">
          <SectionHead eyebrow="Product Catalog" title="سرویس را از داخل یک کاتالوگ تعاملی انتخاب کنید" description="پلن‌ها را بر اساس نوع سرویس ببینید و سریع وارد سفارش شوید." />
          <Tabs defaultValue="cloud" className="w-full">
            <div className="flex justify-end">
              <TabsList className="h-auto flex-wrap rounded-3xl p-1.5">
                {productTabs.map((tab) => <TabsTrigger key={tab.value} value={tab.value} className="rounded-2xl px-5 py-3">{tab.label}</TabsTrigger>)}
              </TabsList>
            </div>
            {productTabs.map((tab) => (
              <TabsContent key={tab.value} value={tab.value}>
                <div dir="rtl" className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                  {tab.products.map((product, index) => <ProductCard key={product.id} product={product} featured={index === 0 && tab.value === 'cloud'} />)}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      <section className="py-12">
        <div className="shell">
          <Card className="overflow-hidden">
            <div className="grid lg:grid-cols-[.9fr_1.1fr]">
              <div className="bg-slate-950 p-8 text-white lg:p-10">
                <Badge className="bg-white/10 text-white" variant="outline"><Layers3 size={13} className="ml-1" /> راهنمای انتخاب</Badge>
                <h2 className="mt-5 text-3xl font-black tracking-tight">کدام سرویس برای شما مناسب‌تر است؟</h2>
                <p className="mt-4 text-sm leading-8 text-slate-300">اگر مطمئن نیستید، از این راهنما شروع کنید.</p>
              </div>
              <div className="divide-y divide-slate-100">
                {[
                  ['سایت وردپرسی یا شرکتی', 'هاست اشتراکی', 'اقتصادی، ساده، سریع برای شروع'],
                  ['فروشگاه و SaaS رو به رشد', 'هاست ابری', 'منابع پایدار، بکاپ و Failover'],
                  ['اپلیکیشن اختصاصی و Docker', 'VPS', 'دسترسی root و انتخاب لوکیشن'],
                  ['بار پردازشی سنگین', 'سرور اختصاصی', 'سخت‌افزار کامل و منابع اختصاصی']
                ].map(([need, suggestion, desc]) => (
                  <div key={need} className="grid gap-3 p-5 sm:grid-cols-[1fr_.8fr_1.2fr] sm:items-center">
                    <span className="text-sm font-black text-slate-950">{need}</span>
                    <Badge variant="default" className="w-fit">{suggestion}</Badge>
                    <span className="text-sm leading-7 text-slate-500">{desc}</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </section>

      <section className="py-12">
        <div className="shell">
          <SectionHead eyebrow="Global VPS" title="لوکیشن‌های VPS را مثل یک نقشه سرویس انتخاب کنید" description="هر کشور مسیر جدا دارد و پلن همان لوکیشن مستقیماً وارد checkout می‌شود." />
          <CountryGrid />
        </div>
      </section>

      <section className="py-12">
        <div className="shell"><DomainChecker /></div>
      </section>

      <section className="py-12">
        <div className="shell grid gap-6 lg:grid-cols-[.9fr_1.1fr]">
          <div>
            <Badge variant="secondary"><LockKeyhole size={13} className="ml-1" /> FAQ</Badge>
            <h2 className="mt-4 text-3xl font-black tracking-tight text-slate-950">سوالات پرتکرار قبل از خرید</h2>
            <p className="mt-3 text-sm leading-8 text-slate-500">پاسخ‌های کوتاه قبل از خرید.</p>
          </div>
          <Card className="px-5">
            <Accordion type="single" collapsible>
              <AccordionItem value="auth"><AccordionTrigger>ثبت‌نام و ورود واقعاً کار می‌کند؟</AccordionTrigger><AccordionContent>بله. حساب کاربری در PostgreSQL ذخیره می‌شود و نشست کاربر با کوکی HttpOnly مدیریت می‌شود.</AccordionContent></AccordionItem>
              <AccordionItem value="order"><AccordionTrigger>سفارش‌ها واقعی ثبت می‌شوند؟</AccordionTrigger><AccordionContent>بله. سفارش و آیتم سفارش در دیتابیس ذخیره می‌شوند. پرداخت فعلاً شبیه‌سازی شده و آماده اتصال به درگاه است.</AccordionContent></AccordionItem>
              <AccordionItem value="domain"><AccordionTrigger>دامنه به رجیسترار واقعی وصل است؟</AccordionTrigger><AccordionContent>در نسخه فعلی منطق بررسی داخلی است؛ ساختار API برای اتصال به رجیسترار واقعی آماده شده است.</AccordionContent></AccordionItem>
            </Accordion>
          </Card>
        </div>
      </section>
    </>
  );
}
