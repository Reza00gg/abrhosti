import crypto from 'crypto';

function secret() {
  const value = process.env.AUTH_SECRET;
  if (!value || value.length < 24) throw new Error('AUTH_SECRET تنظیم نشده است.');
  return value;
}

export function generateEmailCode() {
  return crypto.randomInt(100000, 999999).toString();
}

export function generateEmailToken() {
  return crypto.randomBytes(32).toString('base64url');
}

export function hashEmailCode(code: string, email: string, userId: string) {
  return crypto.createHmac('sha256', secret()).update(`email-code:${userId}:${email}:${code}`).digest('hex');
}

export function hashEmailToken(token: string) {
  return crypto.createHmac('sha256', secret()).update(`email-token:${token}`).digest('hex');
}
