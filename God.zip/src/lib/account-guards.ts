import type { User } from '@/lib/auth';
import { getEmailSettings } from '@/lib/email-settings';
import { getSmsSettings } from '@/lib/sms-settings';

export async function getAccountAccessError(user: User) {
  if (user.role === 'admin') return null;
  const emailSettings = await getEmailSettings();
  if (emailSettings.enabled && !user.email_verified_at) return { message: 'ابتدا ایمیل حساب خود را تایید کنید.', code: 'EMAIL_NOT_VERIFIED' };
  const smsSettings = await getSmsSettings();
  if (smsSettings.enabled && !user.phone_verified_at) return { message: 'ابتدا شماره همراه خود را تایید کنید.', code: 'PHONE_NOT_VERIFIED' };
  return null;
}
