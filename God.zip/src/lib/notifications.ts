import crypto from 'crypto';
import { query } from '@/lib/db';

export type NotificationType = 'info' | 'success' | 'warning' | 'error' | 'payment' | 'order' | 'wallet';

export async function createNotification({
  userId,
  type = 'info',
  title,
  message,
  metadata = {}
}: {
  userId: string;
  type?: NotificationType | string;
  title: string;
  message: string;
  metadata?: Record<string, unknown>;
}) {
  await query(
    `insert into notifications (id, user_id, type, title, message, metadata)
     values ($1,$2,$3,$4,$5,$6)`,
    [crypto.randomUUID(), userId, type, title, message, JSON.stringify(metadata)]
  );
}

export async function getUnreadNotificationCount(userId: string) {
  const result = await query<{ count: string }>('select count(*)::text from notifications where user_id=$1 and read_at is null', [userId]);
  return Number(result.rows[0]?.count ?? 0);
}
