import crypto from 'crypto';

const ITERATIONS = 210_000;
const KEY_LENGTH = 64;
const DIGEST = 'sha512';

function getSecret() {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 24) {
    throw new Error('AUTH_SECRET باید یک مقدار طولانی و امن باشد.');
  }
  return secret;
}

function base64Url(input: Buffer | string) {
  return Buffer.from(input).toString('base64url');
}

export function hashPassword(password: string) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, ITERATIONS, KEY_LENGTH, DIGEST).toString('hex');
  return `pbkdf2$${ITERATIONS}$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string) {
  const [scheme, iter, salt, originalHash] = stored.split('$');
  if (scheme !== 'pbkdf2' || !iter || !salt || !originalHash) return false;

  const hash = crypto.pbkdf2Sync(password, salt, Number(iter), KEY_LENGTH, DIGEST).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(originalHash, 'hex'));
}

export type SessionPayload = {
  sub: string;
  email: string;
  name: string;
  iat: number;
  exp: number;
};

export function signSession(payload: Omit<SessionPayload, 'iat' | 'exp'>, maxAgeSeconds = 60 * 60 * 24 * 7) {
  const now = Math.floor(Date.now() / 1000);
  const body: SessionPayload = {
    ...payload,
    iat: now,
    exp: now + maxAgeSeconds
  };

  const encoded = base64Url(JSON.stringify(body));
  const signature = crypto.createHmac('sha256', getSecret()).update(encoded).digest('base64url');
  return `${encoded}.${signature}`;
}

export function verifySession(token?: string | null): SessionPayload | null {
  if (!token || !token.includes('.')) return null;
  const [encoded, signature] = token.split('.');
  const expected = crypto.createHmac('sha256', getSecret()).update(encoded).digest('base64url');

  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;

  const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SessionPayload;
  if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
  return payload;
}

export function makeOrderNumber() {
  const date = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Tehran', year: 'numeric', month: '2-digit', day: '2-digit' })
    .format(new Date())
    .replaceAll('-', '');
  return `ABR-${date}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}
