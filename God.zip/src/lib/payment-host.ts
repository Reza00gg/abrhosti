export const PAYMENT_ALLOWED_HOST = 'lnupro.sbs';
export const PAYMENT_BASE_URL = 'https://lnupro.sbs';

export function normalizeHost(host?: string | null) {
  return (host || '').split(':')[0].toLowerCase();
}

export function isPaymentAllowedHost(host?: string | null) {
  const value = normalizeHost(host);
  return value === PAYMENT_ALLOWED_HOST || value === 'localhost' || value === '127.0.0.1';
}

export function isPaymentAllowedRequest(request: Request) {
  return isPaymentAllowedHost(request.headers.get('x-forwarded-host') || request.headers.get('host') || new URL(request.url).host);
}
