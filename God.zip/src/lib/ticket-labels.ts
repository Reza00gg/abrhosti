export function ticketStatusLabel(status: string) {
  const map: Record<string, string> = { open_review: 'در حال بررسی', answered: 'پاسخ داده شده', closed: 'بسته شده' };
  return map[status] ?? status;
}
export function ticketPriorityLabel(priority: string) {
  const map: Record<string, string> = { low: 'ساده', medium: 'متوسط', high: 'زیاد' };
  return map[priority] ?? priority;
}
export function ticketStatusVariant(status: string) {
  if (status === 'answered') return 'success';
  if (status === 'closed') return 'secondary';
  return 'warning';
}
export function ticketPriorityVariant(priority: string) {
  if (priority === 'high') return 'warning';
  if (priority === 'low') return 'secondary';
  return 'default';
}
