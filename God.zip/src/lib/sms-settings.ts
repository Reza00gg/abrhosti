import { query } from '@/lib/db';
import { decryptSecret } from '@/lib/secure-settings';

export type SmsSettings = {
  enabled: boolean;
  provider: 'smsir';
  apiKeyEncrypted?: string;
  verifyTemplateId?: number;
  verifyCodeParam?: string;
  welcomeTemplateId?: number;
  welcomeNameParam?: string;
};

export const defaultSmsSettings: SmsSettings = {
  enabled: false,
  provider: 'smsir',
  apiKeyEncrypted: '',
  verifyTemplateId: undefined,
  verifyCodeParam: 'Code',
  welcomeTemplateId: undefined,
  welcomeNameParam: 'Name'
};

export async function getSmsSettings(): Promise<SmsSettings> {
  const result = await query<{ value: Partial<SmsSettings> }>(`select value from app_settings where key='sms_settings' limit 1`);
  return { ...defaultSmsSettings, ...(result.rows[0]?.value ?? {}) };
}

export async function getSmsIrApiKey() {
  const settings = await getSmsSettings();
  return decryptSecret(settings.apiKeyEncrypted);
}
