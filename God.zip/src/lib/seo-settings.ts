import { query } from '@/lib/db';

export const PRIMARY_SITE_URL = 'https://lnupro.sbs';
export const PRIMARY_HOST = 'lnupro.sbs';

export type SeoSettings = {
  indexingEnabled: boolean;
  siteName: string;
  defaultTitle: string;
  defaultDescription: string;
};

export const defaultSeoSettings: SeoSettings = {
  indexingEnabled: false,
  siteName: 'ابرهاست',
  defaultTitle: 'ابرهاست | خرید هاست، سرور مجازی و دامنه',
  defaultDescription: 'خرید هاست ابری، هاست اشتراکی، سرور مجازی، سرور اختصاصی و ثبت دامنه با پنل کاربری حرفه‌ای.'
};

export async function getSeoSettings(): Promise<SeoSettings> {
  try {
    const result = await query<{ value: Partial<SeoSettings> }>(`select value from app_settings where key='seo_settings' limit 1`);
    return { ...defaultSeoSettings, ...(result.rows[0]?.value ?? {}) };
  } catch {
    return defaultSeoSettings;
  }
}

export function normalizeHost(host?: string | null) {
  return (host || '').split(':')[0].toLowerCase();
}

export function isPrimaryHost(host?: string | null) {
  return normalizeHost(host) === PRIMARY_HOST;
}

export function isPrivatePath(pathname: string) {
  return pathname.startsWith('/adminChash7nakg') ||
    pathname.startsWith('/dashboard') ||
    pathname.startsWith('/auth') ||
    pathname.startsWith('/pay') ||
    pathname.startsWith('/api') ||
    pathname.startsWith('/wallet/payment');
}

export function canonicalUrl(pathname = '/') {
  const clean = pathname.startsWith('/') ? pathname : `/${pathname}`;
  return `${PRIMARY_SITE_URL}${clean}`;
}
