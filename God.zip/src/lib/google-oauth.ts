import crypto from 'crypto';

export const GOOGLE_STATE_COOKIE = 'abrhost_google_state';
export const GOOGLE_PENDING_COOKIE = 'abrhost_google_pending';

export type GoogleMode = 'login' | 'register';
export type GoogleProfile = {
  sub: string;
  email: string;
  email_verified: boolean | string;
  name?: string;
  picture?: string;
};

type StatePayload = {
  mode: GoogleMode;
  next: string;
  nonce: string;
  exp: number;
};

function secret() {
  const value = process.env.AUTH_SECRET;
  if (!value || value.length < 24) throw new Error('AUTH_SECRET تنظیم نشده است.');
  return value;
}

function sign(value: string) {
  return crypto.createHmac('sha256', secret()).update(value).digest('base64url');
}

export function getGoogleConfig(origin: string) {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  // Multi-domain support: use the current request origin so Google OAuth works
  // on both the Vercel preview/domain and any custom domain attached to the project.
  // Every possible redirect URI must be added in Google Cloud Console.
  const redirectUri = `${origin}/api/auth/google/callback`;
  if (!clientId || !clientSecret) throw new Error('GOOGLE_CLIENT_ID یا GOOGLE_CLIENT_SECRET تنظیم نشده است.');
  return { clientId, clientSecret, redirectUri };
}

export function createGoogleState(mode: GoogleMode, next = '/dashboard') {
  const payload: StatePayload = {
    mode,
    next: next.startsWith('/') ? next : '/dashboard',
    nonce: crypto.randomBytes(16).toString('base64url'),
    exp: Math.floor(Date.now() / 1000) + 60 * 10
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return `${encoded}.${sign(encoded)}`;
}

export function verifyGoogleState(cookieValue: string | undefined, returnedState: string | null) {
  if (!cookieValue || !returnedState || cookieValue !== returnedState || !cookieValue.includes('.')) return null;
  const [encoded, signature] = cookieValue.split('.');
  const expected = sign(encoded);
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;
  const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as StatePayload;
  if (payload.exp < Math.floor(Date.now() / 1000)) return null;
  return payload;
}

export async function exchangeCodeForTokens(code: string, config: { clientId: string; clientSecret: string; redirectUri: string }) {
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: config.clientId,
      client_secret: config.clientSecret,
      redirect_uri: config.redirectUri,
      grant_type: 'authorization_code'
    })
  });
  if (!response.ok) throw new Error(`Google token exchange failed: ${response.status}`);
  return response.json() as Promise<{ id_token: string; access_token?: string; expires_in?: number }>;
}

export async function verifyGoogleIdToken(idToken: string) {
  const response = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Google id_token verify failed: ${response.status}`);
  const profile = await response.json() as GoogleProfile & { aud?: string };
  if (profile.aud && process.env.GOOGLE_CLIENT_ID && profile.aud !== process.env.GOOGLE_CLIENT_ID) {
    throw new Error('Google token audience mismatch');
  }
  return profile;
}
