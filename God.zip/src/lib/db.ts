import { Pool, type QueryResult, type QueryResultRow } from 'pg';

declare global {
  // eslint-disable-next-line no-var
  var __abrhostPool: Pool | undefined;
}

function createPool() {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL تنظیم نشده است. فایل .env.local را بر اساس .env.example بسازید.');
  }

  return new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    ssl: process.env.DATABASE_URL.includes('sslmode=require') ? { rejectUnauthorized: false } : undefined
  });
}

export function getPool() {
  if (!global.__abrhostPool) {
    global.__abrhostPool = createPool();
  }
  return global.__abrhostPool;
}

export async function query<T extends QueryResultRow = QueryResultRow>(text: string, params?: unknown[]): Promise<QueryResult<T>> {
  return getPool().query<T>(text, params);
}

export function isDatabaseConfigured() {
  return Boolean(process.env.DATABASE_URL);
}
