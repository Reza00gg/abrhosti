const SMSIR_VERIFY_URL = 'https://api.sms.ir/v1/send/verify';

export async function sendSmsIrVerify({ apiKey, mobile, templateId, parameters }: { apiKey: string; mobile: string; templateId: number; parameters: Array<{ name: string; value: string }> }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);
  try {
    const response = await fetch(SMSIR_VERIFY_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'x-api-key': apiKey
      },
      body: JSON.stringify({ mobile, templateId, parameters }),
      signal: controller.signal,
      cache: 'no-store'
    });
    const data = await response.json().catch(() => ({}));
    const ok = response.ok && Number(data.status) === 1;
    return { ok, data, message: data.message || (response.ok ? 'خطا در ارسال پیامک' : `خطای ارتباط با پیامک (${response.status})`) };
  } catch (error) {
    const message = error instanceof Error && error.name === 'AbortError' ? 'زمان پاسخ‌دهی سرویس پیامک تمام شد.' : 'ارتباط با سرویس پیامک برقرار نشد.';
    return { ok: false, data: {}, message };
  } finally {
    clearTimeout(timer);
  }
}
