import { query } from '@/lib/db';

export async function getWalletBalance(userId: string) {
  const result = await query<{ balance: number; currency: string }>(
    `insert into user_wallets (user_id, balance, currency) values ($1, 0, 'تومان')
     on conflict (user_id) do update set user_id = excluded.user_id
     returning balance, currency`,
    [userId]
  );
  return { balance: Number(result.rows[0]?.balance ?? 0), currency: result.rows[0]?.currency ?? 'تومان' };
}
