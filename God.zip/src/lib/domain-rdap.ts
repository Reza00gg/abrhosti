export type DomainCheckResult = {
  domain: string;
  tld: string;
  available: boolean;
  supported: boolean;
  method: 'rdap';
  message: string;
  suggestions: string[];
  rdapUrl?: string;
};

type Bootstrap = { services: [string[], string[]][] };

declare global {
  // eslint-disable-next-line no-var
  var __rdapBootstrap: { fetchedAt: number; map: Map<string, string> } | undefined;
}

const BOOTSTRAP_URL = 'https://data.iana.org/rdap/dns.json';
const CACHE_MS = 1000 * 60 * 60 * 12;

export const popularTlds = [
  'com','net','org','info','biz','co','io','ai','app','dev','cloud','site','online','store','shop','tech','me','xyz','pro','top','club','vip','live','life','world','space','website','digital','agency','solutions','systems','network','software','email','media','studio','company','center','services','support','tools','plus','team','group','global','today','news','blog','wiki','link','click','host','hosting','domains','design','art','games','video','tv','fm','am','cc','ws','name','mobi','asia','eu','de','fr','uk','us','ca','nl','es','it','ch','se','no','fi','dk','be','at','pl','cz','jp','kr','in','ae','tr','io','is','to','gg','la','one','page','fun','run','zone','expert','academy','education','institute','school','training','care','health','clinic','legal','law','finance','capital','cash','fund','market','exchange','ventures','business','marketing','social','community','events','travel','tours','hotel','restaurant','cafe','bar','pizza','fashion','style','beauty','fit','fitness','photography','photo','photos','gallery','graphics','press','pub','works','repair','builders','construction','energy','solar','green','bio','farm','tax','accountants','consulting','management','partners','enterprises','international','limited','ltd','llc','inc','rocks','cool','ninja','guru','city','town','place','land','earth','guide','tips','reviews','directory','download','stream','chat','codes','computer','technology','engineering','science','data','security','systems','cards','credit','claims','insure','estate','properties','rent','rentals','house','homes','apartments','realty','broker','football','soccer','tennis','bike','boats','cars','auto','motorcycles','baby','kids','pet','dog','horse','garden','gift','gifts','supply','supplies','equipment','discount','sale','shopping','blackfriday','christmas','capital','gold','money','navy','army','airforce','degree','recipes','wine','beer','vodka','coffee','yoga','church','charity','foundation','ngo','careers','jobs','work','mba','ceo','bio','eco','organic','farmers','fish','healthcare','doctor','dentist','hospital','surgery','vision','radio','audio','movie','theater','show','band','dance','music','actor','cards','casino','poker','bet','watch','jewelry','shoes','clothing','boutique','makeup','skin','hair','flowers','florist','kitchen','cleaning','plumbing','lighting','furniture'
];

export const tldPrices: Record<string, number> = {
  com: 890000, net: 980000, org: 920000, info: 720000, biz: 760000,
  co: 1550000, io: 4200000, ai: 7200000, app: 1250000, dev: 1280000,
  cloud: 1150000, site: 490000, online: 540000, store: 690000, shop: 760000,
  tech: 820000, me: 1100000, xyz: 390000, pro: 990000, vip: 640000,
  tv: 2100000, cc: 1350000, de: 790000, fr: 840000, uk: 790000,
  us: 760000, ca: 1180000, nl: 760000, es: 820000, it: 860000
};

export function getDomainPrice(tld: string) {
  return tldPrices[tld.toLowerCase()] ?? 990000;
}

export function normalizeDomain(input: string) {
  return input
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/^www\./, '')
    .split('/')[0]
    .replace(/[^a-z0-9.-]/g, '');
}

export function getTld(domain: string) {
  const parts = domain.split('.').filter(Boolean);
  if (parts.length < 2) return '';
  return parts[parts.length - 1];
}

export function isValidDomain(domain: string) {
  if (domain.length < 4 || domain.length > 253) return false;
  if (!/^[a-z0-9.-]+$/.test(domain)) return false;
  const labels = domain.split('.');
  if (labels.length < 2) return false;
  return labels.every((label) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label));
}

async function loadBootstrap() {
  const now = Date.now();
  if (global.__rdapBootstrap && now - global.__rdapBootstrap.fetchedAt < CACHE_MS) return global.__rdapBootstrap.map;
  const res = await fetch(BOOTSTRAP_URL, { next: { revalidate: 43200 } });
  if (!res.ok) throw new Error('RDAP bootstrap failed');
  const data = (await res.json()) as Bootstrap;
  const map = new Map<string, string>();
  for (const [tlds, urls] of data.services) {
    const url = urls[0];
    if (!url) continue;
    for (const tld of tlds) map.set(tld.toLowerCase(), url);
  }
  global.__rdapBootstrap = { fetchedAt: now, map };
  return map;
}

function joinUrl(base: string, domain: string) {
  return `${base.endsWith('/') ? base : `${base}/`}domain/${encodeURIComponent(domain)}`;
}

export async function checkDomainAvailability(input: string): Promise<DomainCheckResult> {
  const domain = normalizeDomain(input);
  if (!isValidDomain(domain)) {
    return { domain, tld: '', available: false, supported: false, method: 'rdap', suggestions: [], message: 'نام دامنه معتبر نیست.' };
  }

  const tld = getTld(domain);
  const map = await loadBootstrap();
  const base = map.get(tld);
  if (!base) {
    return { domain, tld, available: false, supported: false, method: 'rdap', suggestions: suggestDomains(domain), message: `پسوند .${tld} فعلاً از RDAP عمومی پشتیبانی نمی‌کند.` };
  }

  const rdapUrl = joinUrl(base, domain);
  const response = await fetch(rdapUrl, {
    headers: { accept: 'application/rdap+json, application/json' },
    cache: 'no-store'
  });

  if (response.status === 404) {
    return { domain, tld, available: true, supported: true, method: 'rdap', rdapUrl, suggestions: [], message: 'دامنه آزاد است و می‌توانید ثبت سفارش کنید.' };
  }
  if (response.ok) {
    return { domain, tld, available: false, supported: true, method: 'rdap', rdapUrl, suggestions: suggestDomains(domain), message: 'این دامنه قبلاً ثبت شده است.' };
  }
  if ([400, 422].includes(response.status)) {
    return { domain, tld, available: false, supported: true, method: 'rdap', rdapUrl, suggestions: [], message: 'رجیستری این دامنه را معتبر تشخیص نداد.' };
  }

  return { domain, tld, available: false, supported: true, method: 'rdap', rdapUrl, suggestions: suggestDomains(domain), message: 'در حال حاضر امکان دریافت پاسخ قطعی از رجیستری وجود ندارد.' };
}

export function suggestDomains(domain: string) {
  const name = domain.split('.')[0] || 'brand';
  return ['com', 'net', 'org', 'co', 'io', 'app', 'dev', 'cloud']
    .map((tld) => `${name}.${tld}`)
    .filter((item) => item !== domain)
    .slice(0, 6);
}

export function supportedTldCount() {
  return popularTlds.length;
}
