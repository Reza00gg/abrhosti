import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { query, isDatabaseConfigured } from '@/lib/db';
import { verifySession } from '@/lib/crypto';

export const SESSION_COOKIE = 'abrhost_session';
export const ADMIN_SESSION_COOKIE = 'abrhost_admin_session';

export type User = {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  created_at: string;
  banned_at?: string | null;
  deleted_at?: string | null;
  phone?: string | null;
  phone_verified_at?: string | null;
  email_verified_at?: string | null;
  country?: string | null;
  province?: string | null;
  city?: string | null;
  address?: string | null;
  postal_code?: string | null;
};

export async function getCurrentUser(): Promise<User | null> {
  try {
    if (!isDatabaseConfigured()) return null;
    const token = cookies().get(SESSION_COOKIE)?.value;
    const session = verifySession(token);
    if (!session) return null;

    const result = await query<User>(
      'select id, name, email, role, created_at, banned_at, deleted_at, phone, phone_verified_at, email_verified_at, country, province, city, address, postal_code from users where id = $1 limit 1',
      [session.sub]
    );
    const user = result.rows[0] ?? null;
    if (user?.banned_at || user?.deleted_at) return null;
    return user;
  } catch {
    return null;
  }
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) redirect('/auth/login?next=/dashboard');
  return user;
}


export async function getCurrentAdmin(): Promise<User | null> {
  try {
    if (!isDatabaseConfigured()) return null;
    const token = cookies().get(ADMIN_SESSION_COOKIE)?.value;
    const session = verifySession(token);
    if (!session) return null;
    const result = await query<User>(
      "select id, name, email, role, created_at from users where id = $1 and role = 'admin' limit 1",
      [session.sub]
    );
    const user = result.rows[0] ?? null;
    if (user?.banned_at || user?.deleted_at) return null;
    return user;
  } catch {
    return null;
  }
}

export async function requireAdmin() {
  const admin = await getCurrentAdmin();
  if (!admin) redirect('/adminChash7nakg');
  return admin;
}
