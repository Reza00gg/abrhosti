const ZIBAL_BASE = 'https://gateway.zibal.ir';

export type ZibalRequestResponse = { result: number; message: string; trackId?: number };
export type ZibalVerifyResponse = { result: number; message: string; status?: number; amount?: number; refNumber?: number; paidAt?: string; cardNumber?: string; orderId?: string; description?: string };

export async function zibalRequestPayment(input: { merchant: string; amountRial: number; callbackUrl: string; description: string; orderId: string }) {
  const response = await fetch(`${ZIBAL_BASE}/v1/request`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ merchant: input.merchant, amount: input.amountRial, callbackUrl: input.callbackUrl, description: input.description, orderId: input.orderId, feeMode: 0 })
  });
  const data = await response.json() as ZibalRequestResponse;
  return { ok: response.ok && data.result === 100 && Boolean(data.trackId), data };
}

export async function zibalVerifyPayment(input: { merchant: string; trackId: number }) {
  const response = await fetch(`${ZIBAL_BASE}/v1/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ merchant: input.merchant, trackId: input.trackId })
  });
  const data = await response.json() as ZibalVerifyResponse;
  return { ok: response.ok && (data.result === 100 || data.result === 201), data };
}

export function zibalStartUrl(trackId: number | string) {
  return `${ZIBAL_BASE}/start/${trackId}`;
}
