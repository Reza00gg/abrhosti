const RESEND_EMAILS_URL = 'https://api.resend.com/emails';

export async function sendResendEmail({ apiKey, from, to, subject, html, text }: { apiKey: string; from: string; to: string; subject: string; html: string; text: string }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);
  try {
    const response = await fetch(RESEND_EMAILS_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ from, to, subject, html, text }),
      signal: controller.signal,
      cache: 'no-store'
    });
    const data = await response.json().catch(() => ({}));
    return { ok: response.ok, data, message: data?.message || data?.error || (response.ok ? 'sent' : `خطای ارسال ایمیل (${response.status})`) };
  } catch (error) {
    const message = error instanceof Error && error.name === 'AbortError' ? 'زمان پاسخ‌دهی سرویس ایمیل تمام شد.' : 'ارتباط با سرویس ایمیل برقرار نشد.';
    return { ok: false, data: {}, message };
  } finally {
    clearTimeout(timer);
  }
}

export function verificationEmailTemplate({ name, code, verifyUrl, minutes }: { name: string; code: string; verifyUrl: string; minutes: number }) {
  const safeName = name || 'کاربر عزیز';
  const text = `کد تایید ابرهاست: ${code}\nاین کد تا ${minutes} دقیقه معتبر است.\nیا از لینک زیر برای تایید استفاده کنید:\n${verifyUrl}`;
  const html = `
  <div dir="rtl" style="margin:0;padding:0;background:#f6f7fb;font-family:Tahoma,Arial,sans-serif;color:#0f172a">
    <div style="max-width:560px;margin:0 auto;padding:28px 16px">
      <div style="background:#ffffff;border:1px solid #e5e7eb;border-radius:24px;overflow:hidden;box-shadow:0 18px 60px rgba(15,23,42,.08)">
        <div style="background:#0f172a;padding:28px;color:white;text-align:right">
          <div style="font-size:22px;font-weight:900">ابرهاست</div>
          <div style="margin-top:8px;color:#cbd5e1;font-size:14px">تایید ایمیل حساب کاربری</div>
        </div>
        <div style="padding:28px;text-align:right">
          <h1 style="font-size:24px;margin:0 0 12px;font-weight:900;color:#0f172a">${safeName}، کد تایید شما آماده است</h1>
          <p style="font-size:15px;line-height:2;color:#64748b;margin:0 0 18px">برای فعال‌سازی حساب، کد زیر را در سایت وارد کنید یا روی دکمه تایید حساب بزنید.</p>
          <div dir="ltr" style="letter-spacing:10px;text-align:center;font-size:34px;font-weight:900;background:#f8fafc;border:1px solid #e2e8f0;border-radius:18px;padding:18px;margin:22px 0;color:#0f172a">${code}</div>
          <a href="${verifyUrl}" style="display:block;text-align:center;background:#0f172a;color:#fff;text-decoration:none;border-radius:16px;padding:14px 18px;font-size:16px;font-weight:900;margin:18px 0">تایید حساب</a>
          <p style="font-size:13px;line-height:2;color:#94a3b8;margin:18px 0 0">این لینک و کد فقط یک‌بار قابل استفاده هستند و تا ${minutes} دقیقه اعتبار دارند.</p>
        </div>
      </div>
    </div>
  </div>`;
  return { html, text };
}
