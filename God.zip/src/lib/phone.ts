import crypto from 'crypto';

export function normalizeIranPhone(input: string) {
  const digits = input.replace(/\D/g, '');
  if (/^09\d{9}$/.test(digits)) return digits;
  if (/^9\d{9}$/.test(digits)) return `0${digits}`;
  return '';
}

export function isValidIranPhone(input: string) {
  return Boolean(normalizeIranPhone(input));
}

function secret() {
  const value = process.env.AUTH_SECRET;
  if (!value || value.length < 24) throw new Error('AUTH_SECRET تنظیم نشده است.');
  return value;
}

export function generateOtpCode() {
  return crypto.randomInt(100000, 999999).toString();
}

export function hashOtpCode(code: string, phone: string, userId: string) {
  return crypto.createHmac('sha256', secret()).update(`${userId}:${phone}:${code}`).digest('hex');
}
