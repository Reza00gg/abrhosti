import { query } from '@/lib/db';
import { getEmailSettings, getResendApiKey } from '@/lib/email-settings';
import { sendResendEmail } from '@/lib/resend';

function welcomeTemplate({ name, dashboardUrl }: { name: string; dashboardUrl: string }) {
  const safeName = name || 'کاربر عزیز';
  const text = `${safeName} عزیز، به ابرهاست خوش آمدید.\nحساب شما با موفقیت ساخته شد.\nورود به داشبورد: ${dashboardUrl}`;
  const html = `
  <div dir="rtl" style="margin:0;padding:0;background:#f6f7fb;font-family:Tahoma,Arial,sans-serif;color:#0f172a">
    <div style="max-width:560px;margin:0 auto;padding:28px 16px">
      <div style="background:#ffffff;border:1px solid #e5e7eb;border-radius:24px;overflow:hidden;box-shadow:0 18px 60px rgba(15,23,42,.08)">
        <div style="background:#0f172a;padding:30px;color:white;text-align:right">
          <div style="font-size:24px;font-weight:900">ابرهاست</div>
          <div style="margin-top:8px;color:#cbd5e1;font-size:14px">هاست، سرور مجازی و دامنه</div>
        </div>
        <div style="padding:30px;text-align:right">
          <h1 style="font-size:25px;margin:0 0 12px;font-weight:900;color:#0f172a">${safeName} عزیز، خوش آمدید</h1>
          <p style="font-size:15px;line-height:2;color:#64748b;margin:0 0 20px">حساب شما در ابرهاست با موفقیت ساخته شد. از این پس می‌توانید سرویس‌ها، پرداخت‌ها، تیکت‌ها و موجودی حساب خود را از داشبورد مدیریت کنید.</p>
          <a href="${dashboardUrl}" style="display:block;text-align:center;background:#0f172a;color:#fff;text-decoration:none;border-radius:16px;padding:14px 18px;font-size:16px;font-weight:900;margin:22px 0">ورود به داشبورد</a>
          <p style="font-size:13px;line-height:2;color:#94a3b8;margin:18px 0 0">اگر این حساب توسط شما ساخته نشده، این ایمیل را نادیده بگیرید.</p>
        </div>
      </div>
    </div>
  </div>`;
  return { html, text };
}

export async function sendWelcomeEmailOnce({ userId, email, name, origin }: { userId: string; email: string; name: string; origin: string }) {
  try {
    const exists = await query('select id from audit_events where user_id=$1 and event=$2 limit 1', [userId, 'email.welcome.sent']);
    if (exists.rowCount) return { sent: false, skipped: true };
    const settings = await getEmailSettings();
    const apiKey = await getResendApiKey();
    if (!apiKey || !settings.fromEmail) return { sent: false, skipped: true };
    const dashboardUrl = `${origin}/dashboard`;
    const { html, text } = welcomeTemplate({ name, dashboardUrl });
    const result = await sendResendEmail({
      apiKey,
      from: `${settings.fromName || 'ابرهاست'} <${settings.fromEmail}>`,
      to: email,
      subject: 'به ابرهاست خوش آمدید',
      html,
      text
    });
    if (result.ok) {
      await query(`insert into audit_events (id,user_id,event,metadata) values (gen_random_uuid(),$1,'email.welcome.sent',$2)`, [userId, JSON.stringify({ email })]);
    }
    return { sent: result.ok, skipped: false };
  } catch (error) {
    console.error('welcome email failed', error);
    return { sent: false, skipped: false };
  }
}
