import crypto from 'crypto';

function key() {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 24) throw new Error('AUTH_SECRET تنظیم نشده است.');
  return crypto.createHash('sha256').update(secret).digest();
}

export function encryptSecret(value: string) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString('base64url')}:${tag.toString('base64url')}:${encrypted.toString('base64url')}`;
}

export function decryptSecret(value?: string | null) {
  if (!value) return '';
  if (!value.startsWith('v1:')) return value;
  const [, ivRaw, tagRaw, encryptedRaw] = value.split(':');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key(), Buffer.from(ivRaw, 'base64url'));
  decipher.setAuthTag(Buffer.from(tagRaw, 'base64url'));
  return Buffer.concat([decipher.update(Buffer.from(encryptedRaw, 'base64url')), decipher.final()]).toString('utf8');
}

export function maskSecret(value?: string | null) {
  if (!value) return '';
  const plain = value.startsWith('v1:') ? decryptSecret(value) : value;
  if (plain.length <= 6) return '••••••';
  return `${plain.slice(0, 3)}••••${plain.slice(-3)}`;
}
