import { query, isDatabaseConfigured } from '@/lib/db';
import { products as fallbackProducts, type Product, type ProductCategory } from '@/lib/products';

type DbProduct = {
  id: string;
  category: ProductCategory;
  country: string | null;
  title: string;
  subtitle: string;
  price_monthly: number;
  currency: string;
  badge: string;
  specs: { cpu?: string; ram?: string; storage?: string; bandwidth?: string };
  features: string[];
  route: string;
  active: boolean;
};

function fromDb(row: DbProduct): Product {
  return {
    id: row.id,
    category: row.category,
    country: row.country ?? undefined,
    title: row.title,
    subtitle: row.subtitle,
    priceMonthly: Number(row.price_monthly),
    currency: row.currency,
    badge: row.badge,
    cpu: row.specs?.cpu ?? '—',
    ram: row.specs?.ram ?? '—',
    storage: row.specs?.storage ?? '—',
    bandwidth: row.specs?.bandwidth ?? '—',
    features: Array.isArray(row.features) ? row.features : [],
    route: row.route
  };
}

/**
 * Single source of truth for products:
 * - local/dev without DATABASE_URL: fallback JSON
 * - production/DB configured: only PostgreSQL products
 * This prevents showing products on the public site that don't exist in admin.
 */
export async function getCatalogProducts(options: { includeInactive?: boolean } = {}) {
  if (!isDatabaseConfigured()) return fallbackProducts;

  try {
    const result = await query<DbProduct>(
      `select id, category, country, title, subtitle, price_monthly, currency, badge, specs, features, route, active
       from products ${options.includeInactive ? '' : 'where active = true'} order by category, price_monthly asc`
    );
    return result.rows.map(fromDb);
  } catch (error) {
    console.error('Catalog DB read failed:', error);
    return [];
  }
}

export async function getCatalogByCategory(category: ProductCategory) {
  const all = await getCatalogProducts();
  return all.filter((p) => p.category === category);
}

export async function getCatalogProductById(id: string, options: { includeInactive?: boolean } = {}) {
  const all = await getCatalogProducts({ includeInactive: options.includeInactive });
  return all.find((p) => p.id === id);
}

export async function getCatalogVpsByCountry(country: string) {
  const all = await getCatalogProducts();
  return all.filter((p) => p.category === 'vps' && p.country === country);
}
