import crypto from 'crypto';
import type { PoolClient } from 'pg';

type Payment = {
  id: string;
  user_id: string;
  topup_id: string;
  payment_session_id: string | null;
  amount: number;
  fee_amount: number;
  payable_amount: number;
  currency: string;
  status: string;
};

export async function creditWalletForVerifiedGateway(client: PoolClient, payment: Payment, provider: string, referenceId: string, verifyPayload: unknown) {
  const locked = await client.query<Payment>(`select * from gateway_payments where id=$1 for update`, [payment.id]);
  const current = locked.rows[0];
  if (!current || current.status === 'verified') return false;
  const wallet = await client.query<{ balance: number }>(`insert into user_wallets (user_id,balance,currency) values ($1,0,$2) on conflict (user_id) do update set user_id=excluded.user_id returning balance`, [payment.user_id, payment.currency]);
  const nextBalance = Number(wallet.rows[0].balance) + Number(payment.amount);
  await client.query(`update user_wallets set balance=$1, updated_at=now() where user_id=$2`, [nextBalance, payment.user_id]);
  await client.query(`insert into wallet_transactions (id,user_id,type,amount,currency,balance_after,reference_type,reference_id,description) values ($1,$2,'gateway_credit',$3,$4,$5,'gateway_payment',$6,$7)`, [crypto.randomUUID(), payment.user_id, payment.amount, payment.currency, nextBalance, payment.id, `افزایش موجودی با درگاه ${provider === 'zarinpal' ? 'زرین‌پال' : 'زیبال'}`]);
  await client.query(`update wallet_topups set status='approved', payment_status=$1, approved_at=now(), updated_at=now() where id=$2`, [`approved_gateway_${provider}`, payment.topup_id]);
  await client.query(`update payment_sessions set used_at=now() where id=$1`, [payment.payment_session_id]);
  await client.query(`update gateway_payments set status='verified', reference_id=$1, verified_at=now(), verify_payload=$2, updated_at=now() where id=$3`, [referenceId, JSON.stringify(verifyPayload), payment.id]);
  await client.query(`insert into notifications (id,user_id,type,title,message,metadata) values ($1,$2,'success','پرداخت آنلاین تایید شد',$3,$4)`, [crypto.randomUUID(), payment.user_id, `مبلغ ${new Intl.NumberFormat('fa-IR').format(Number(payment.amount))} تومان از طریق ${provider === 'zarinpal' ? 'زرین‌پال' : 'زیبال'} به موجودی شما اضافه شد.`, JSON.stringify({ gatewayPaymentId: payment.id, topupId: payment.topup_id })]);
  return true;
}
