import { query } from '@/lib/db';
import { decryptSecret } from '@/lib/secure-settings';

export type EmailSettings = {
  enabled: boolean;
  provider: 'resend';
  apiKeyEncrypted?: string;
  fromEmail: string;
  fromName: string;
  expiresMinutes: number;
};

export const defaultEmailSettings: EmailSettings = {
  enabled: false,
  provider: 'resend',
  apiKeyEncrypted: '',
  fromEmail: 'no-reply@lnupro.sbs',
  fromName: 'ابرهاست',
  expiresMinutes: 10
};

export async function getEmailSettings(): Promise<EmailSettings> {
  const result = await query<{ value: Partial<EmailSettings> }>(`select value from app_settings where key='email_settings' limit 1`);
  return { ...defaultEmailSettings, ...(result.rows[0]?.value ?? {}) };
}

export async function getResendApiKey() {
  const settings = await getEmailSettings();
  return decryptSecret(settings.apiKeyEncrypted);
}
