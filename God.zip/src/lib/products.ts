import rawProducts from '../../data/products.json';

export type ProductCategory = 'shared' | 'cloud' | 'dedicated' | 'vps' | 'domain';

export type Product = {
  id: string;
  category: ProductCategory;
  country?: string;
  title: string;
  subtitle: string;
  priceMonthly: number;
  currency: string;
  badge: string;
  cpu: string;
  ram: string;
  storage: string;
  bandwidth: string;
  features: string[];
  route: string;
};

export const products = rawProducts as Product[];

export const countries = [
  { code: 'us', name: 'آمریکا', city: 'New York / Dallas', flag: '🇺🇸', latency: '۹۵ms اروپا', color: '#4f7cff' },
  { code: 'de', name: 'آلمان', city: 'Frankfurt', flag: '🇩🇪', latency: '۲۵ms اروپا', color: '#ffbf47' },
  { code: 'fr', name: 'فرانسه', city: 'Paris', flag: '🇫🇷', latency: '۳۱ms اروپا', color: '#7c5cff' },
  { code: 'uk', name: 'انگلیس', city: 'London', flag: '🇬🇧', latency: '۳۸ms اروپا', color: '#ff5c7c' },
  { code: 'nl', name: 'هلند', city: 'Amsterdam', flag: '🇳🇱', latency: '۲۹ms اروپا', color: '#ff8c42' },
  { code: 'ca', name: 'کانادا', city: 'Toronto', flag: '🇨🇦', latency: '۸۸ms آمریکا', color: '#e84855' }
] as const;

export function formatPrice(value: number, currency = 'تومان') {
  return `${new Intl.NumberFormat('fa-IR').format(value)} ${currency}`;
}

export function getProductsByCategory(category: ProductCategory) {
  return products.filter((product) => product.category === category);
}

export function getProductById(id: string) {
  return products.find((product) => product.id === id);
}

export function getVpsByCountry(country: string) {
  return products.filter((product) => product.category === 'vps' && product.country === country);
}

export function getCategoryLabel(category: ProductCategory) {
  const labels: Record<ProductCategory, string> = {
    shared: 'هاست اشتراکی',
    cloud: 'هاست ابری',
    dedicated: 'هاست اختصاصی',
    vps: 'سرور مجازی',
    domain: 'دامنه'
  };
  return labels[category];
}
