export const TEHRAN_TIME_ZONE = 'Asia/Tehran';

export function formatTehranDateTime(value: string | Date | null | undefined) {
  if (!value) return '—';
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('fa-IR', {
    timeZone: TEHRAN_TIME_ZONE,
    dateStyle: 'medium',
    timeStyle: 'short'
  }).format(date);
}

export function formatTehranDate(value: string | Date | null | undefined) {
  if (!value) return '—';
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('fa-IR', {
    timeZone: TEHRAN_TIME_ZONE,
    dateStyle: 'medium'
  }).format(date);
}
