import { headers } from 'next/headers';

export const TICKETS_ALLOWED_HOSTS = ['abrhost-webapp.vercel.app', 'lnupro.sbs'];

export function isTicketsHost(host?: string | null) {
  const value = (host || '').split(':')[0].toLowerCase();
  return TICKETS_ALLOWED_HOSTS.includes(value) || value === 'localhost' || value === '127.0.0.1';
}

export function getCurrentHost() {
  return headers().get('x-forwarded-host') || headers().get('host') || '';
}

export function requireTicketsHost() {
  return isTicketsHost(getCurrentHost());
}

export function isTicketsHostFromRequest(request: Request) {
  const headerHost = request.headers.get('x-forwarded-host') || request.headers.get('host');
  if (headerHost) return isTicketsHost(headerHost);
  return isTicketsHost(new URL(request.url).host);
}

export const SMS_ALLOWED_HOSTS = ['lnupro.sbs'];
export function isSmsHost(host?: string | null) {
  const value = (host || '').split(':')[0].toLowerCase();
  return SMS_ALLOWED_HOSTS.includes(value) || value === 'localhost' || value === '127.0.0.1';
}
export function requireSmsHost() {
  return isSmsHost(getCurrentHost());
}
export function isSmsHostFromRequest(request: Request) {
  const headerHost = request.headers.get('x-forwarded-host') || request.headers.get('host');
  if (headerHost) return isSmsHost(headerHost);
  return isSmsHost(new URL(request.url).host);
}
