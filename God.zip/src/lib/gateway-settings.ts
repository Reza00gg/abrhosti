import { query } from '@/lib/db';
import { decryptSecret } from '@/lib/secure-settings';

export type GatewaySettings = {
  enabled: boolean;
  zibal: { enabled: boolean; merchantEncrypted?: string; sandbox: boolean };
  zarinpal: { enabled: boolean; merchantEncrypted?: string; sandbox: boolean };
  fee: { fixed: number; percent: number };
};

export const defaultGatewaySettings: GatewaySettings = {
  enabled: true,
  zibal: { enabled: false, merchantEncrypted: '', sandbox: true },
  zarinpal: { enabled: false, merchantEncrypted: '', sandbox: true },
  fee: { fixed: 0, percent: 0 }
};

function mergeSettings(value: Partial<GatewaySettings> | undefined): GatewaySettings {
  return {
    enabled: value?.enabled ?? defaultGatewaySettings.enabled,
    zibal: { ...defaultGatewaySettings.zibal, ...(value?.zibal ?? {}) },
    zarinpal: { ...defaultGatewaySettings.zarinpal, ...(value?.zarinpal ?? {}) },
    fee: { ...defaultGatewaySettings.fee, ...(value?.fee ?? {}) }
  };
}

export async function getGatewaySettings(): Promise<GatewaySettings> {
  const result = await query<{ value: Partial<GatewaySettings> }>(`select value from app_settings where key='payment_gateways' limit 1`);
  return mergeSettings(result.rows[0]?.value);
}

export async function getZibalMerchant() {
  const settings = await getGatewaySettings();
  const encrypted = settings.zibal.merchantEncrypted;
  if (settings.zibal.sandbox && !encrypted) return 'zibal';
  return decryptSecret(encrypted);
}

export async function getZarinpalMerchant() {
  const settings = await getGatewaySettings();
  return decryptSecret(settings.zarinpal.merchantEncrypted);
}

export function calculateGatewayAmounts(amount: number, settings: GatewaySettings) {
  const fixed = Math.max(0, Number(settings.fee?.fixed ?? 0));
  const percent = Math.max(0, Number(settings.fee?.percent ?? 0));
  const fee = Math.round(fixed + (amount * percent) / 100);
  return { amount, feeAmount: fee, payableAmount: amount + fee };
}
