import { pgTable, serial, text, integer, real, timestamp, boolean, uniqueIndex } from 'drizzle-orm/pg-core'

export const movies = pgTable('movies', {
  id: serial('id').primaryKey(),
  titleFa: text('title_fa').notNull(),
  titleEn: text('title_en').notNull(),
  duration: integer('duration').notNull(),
  year: integer('year').notNull(),
  rating: real('rating').notNull(),
  posterUrl: text('poster_url').notNull(),
  coverUrl: text('cover_url').notNull(),
  description: text('description').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  passwordHash: text('password_hash').notNull(),
  banned: boolean('banned').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  emailIdx: uniqueIndex('users_email_idx').on(table.email),
}))

export type Movie = typeof movies.$inferSelect
export type NewMovie = typeof movies.$inferInsert
export type User = typeof users.$inferSelect
export type NewUser = typeof users.$inferInsert
