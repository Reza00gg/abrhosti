import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  const id = Number(body?.id)
  if (!id || isNaN(id)) {
    return { exists: false, banned: false }
  }
  const db = useDb()
  const [user] = await db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    banned: users.banned,
  }).from(users).where(eq(users.id, id)).limit(1)
  if (!user) return { exists: false, banned: false }
  return { exists: true, banned: user.banned, name: user.name, email: user.email }
})
