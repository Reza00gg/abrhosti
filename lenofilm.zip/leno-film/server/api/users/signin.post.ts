import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { verifyPassword } from '~~/server/utils/password'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  if (!body.email?.trim() || !body.password) {
    throw createError({ statusCode: 400, statusMessage: 'ایمیل و رمز عبور الزامی هستند' })
  }
  const db = useDb()
  const email = body.email.trim().toLowerCase()
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1)
  if (!user || !verifyPassword(body.password, user.passwordHash)) {
    throw createError({ statusCode: 401, statusMessage: 'ایمیل یا رمز عبور اشتباه است' })
  }
  if (user.banned) {
    throw createError({ statusCode: 403, statusMessage: 'حساب شما از طرف مدیریت مسدود شده است' })
  }
  return { id: user.id, name: user.name, email: user.email }
})
