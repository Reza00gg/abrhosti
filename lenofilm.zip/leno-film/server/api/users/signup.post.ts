import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { hashPassword } from '~~/server/utils/password'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  if (!body.name?.trim() || !body.email?.trim() || !body.password) {
    throw createError({ statusCode: 400, statusMessage: 'نام، ایمیل و رمز عبور الزامی هستند' })
  }
  if (body.password.length < 6) {
    throw createError({ statusCode: 400, statusMessage: 'رمز عبور باید حداقل ۶ کاراکتر باشد' })
  }
  const db = useDb()
  const email = body.email.trim().toLowerCase()
  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1)
  if (existing.length > 0) {
    throw createError({ statusCode: 409, statusMessage: 'این ایمیل قبلاً ثبت شده است' })
  }
  const [user] = await db.insert(users).values({
    name: body.name.trim(),
    email,
    passwordHash: hashPassword(body.password),
  }).returning()
  return { id: user.id, name: user.name, email: user.email }
})
