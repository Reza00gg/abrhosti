import { useDb } from '~~/server/db'
import { movies } from '~~/server/db/schema'

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  if (!body.titleFa || !body.titleEn || !body.duration || !body.year || body.rating == null) {
    throw createError({ statusCode: 400, statusMessage: 'اطلاعات فیلم ناقص است' })
  }
  const db = useDb()
  const [movie] = await db.insert(movies).values({
    titleFa: String(body.titleFa),
    titleEn: String(body.titleEn),
    duration: Number(body.duration),
    year: Number(body.year),
    rating: Number(body.rating),
    posterUrl: String(body.posterUrl || ''),
    coverUrl: String(body.coverUrl || ''),
    description: String(body.description || ''),
  }).returning()
  return movie
})
