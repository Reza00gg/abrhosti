import { useDb } from '~~/server/db'
import { movies } from '~~/server/db/schema'
import { ilike, or } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const q = getQuery(event)
  const search = (q.q as string | undefined)?.trim()
  const db = useDb()

  if (search) {
    return await db.select().from(movies)
      .where(or(ilike(movies.titleFa, `%${search}%`), ilike(movies.titleEn, `%${search}%`)))
      .limit(50)
  }
  return await db.select().from(movies).limit(100)
})
