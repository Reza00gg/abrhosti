import { useDb } from '~~/server/db'
import { movies } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const db = useDb()
  const [deleted] = await db.delete(movies).where(eq(movies.id, id)).returning()
  if (!deleted) throw createError({ statusCode: 404, statusMessage: 'فیلم پیدا نشد' })
  return { success: true, id }
})
