import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { eq } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, 'id'))
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: 'ID نامعتبر' })
  const db = useDb()
  const [deleted] = await db.delete(users).where(eq(users.id, id)).returning()
  if (!deleted) throw createError({ statusCode: 404, statusMessage: 'کاربر پیدا نشد' })
  return { success: true, id }
})
