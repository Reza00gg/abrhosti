import { useDb } from '~~/server/db'
import { users } from '~~/server/db/schema'
import { ilike, or, desc } from 'drizzle-orm'

export default defineEventHandler(async (event) => {
  const q = getQuery(event)
  const search = (q.q as string | undefined)?.trim()
  const db = useDb()

  const baseQuery = db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    banned: users.banned,
    createdAt: users.createdAt,
  }).from(users)

  if (search) {
    return await baseQuery
      .where(or(ilike(users.name, `%${search}%`), ilike(users.email, `%${search}%`)))
      .orderBy(desc(users.createdAt))
      .limit(100)
  }

  return await baseQuery.orderBy(desc(users.createdAt)).limit(100)
})
