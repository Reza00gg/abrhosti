export default defineNuxtRouteMiddleware(async (to) => {
  if (!to.path.startsWith('/account')) return

  const auth = useUserAuthStore()

  // /account → اگه لاگین نیست، بره به صفحه‌ی ورود
  if (to.path === '/account' && !auth.isAuthenticated) {
    return navigateTo('/account/signin')
  }

  // /account/signin یا /account/signup → اگه لاگین هست، بره به /account
  if ((to.path === '/account/signin' || to.path === '/account/signup') && auth.isAuthenticated) {
    return navigateTo('/account')
  }

  // اگه لاگین هست و می‌خواد بره /account، چک کن بن شده یا نه
  if (to.path === '/account' && auth.isAuthenticated && auth.user?.id) {
    try {
      const status = await $fetch<{ exists: boolean; banned: boolean }>('/api/users/check', {
        method: 'POST',
        body: { id: auth.user.id }
      })
      if (!status.exists) {
        auth.logout()
        return navigateTo('/account/signin')
      }
      if (status.banned) {
        auth.logout()
        return navigateTo('/account/signin')
      }
    } catch {
      // ignore
    }
  }
})
