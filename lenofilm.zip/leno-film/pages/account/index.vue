<template>
  <div class="min-h-[60vh] flex items-center justify-center px-6 py-10">
    <div class="w-full max-w-sm text-center">
      <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-ink-900 border border-[color:var(--hairline)] mb-5">
        <Icon icon="lucide:user-round" class="text-[28px] text-ink-300" />
      </div>
      <h1 class="text-[22px] font-semibold tracking-tight text-ink-50">{{ auth.user?.name }}</h1>
      <p class="mt-1.5 text-[13px] text-ink-500">{{ auth.user?.email }}</p>
      <div class="mt-8 space-y-2 text-right">
        <div class="p-4 rounded-xl bg-ink-900/40 border border-[color:var(--hairline)]">
          <p class="text-[12px] uppercase tracking-widest text-ink-600">زمان ورود</p>
          <p class="mt-1 text-[14px] text-ink-300">{{ loginTime }}</p>
        </div>
        <div class="p-4 rounded-xl bg-ink-900/40 border border-[color:var(--hairline)]">
          <p class="text-[12px] uppercase tracking-widest text-ink-600">اشتراک</p>
          <p class="mt-1 text-[14px] text-ink-300">رایگان</p>
        </div>
      </div>
      <button v-wave style="color: rgba(255, 255, 255, 0.4)" @click="handleLogout" class="mt-8 w-full h-12 rounded-xl bg-ink-900/40 border border-[color:var(--hairline)] text-[14px] text-ink-300 hover:text-ink-50 hover:border-[color:var(--input-border-focus)] transition-colors">
        خروج از حساب
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ title: 'حساب' })
const auth = useUserAuthStore()
const router = useRouter()
const loginTime = computed(() => {
  if (!auth.user?.loggedInAt) return '—'
  return new Date(auth.user.loggedInAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
})
function handleLogout() {
  auth.logout()
  router.push('/account/signin')
}
</script>
