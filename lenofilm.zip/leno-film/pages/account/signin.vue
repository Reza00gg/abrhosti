<template>
  <div class="min-h-[60vh] flex items-center justify-center px-6 py-10">
    <div class="w-full max-w-sm">
      <div class="text-center mb-10">
        <h1 class="text-[24px] font-semibold tracking-tight text-ink-50">ورود به حساب</h1>
        <p class="mt-2 text-[13px] text-ink-500">به حساب خود وارد شوید</p>
      </div>
      <form @submit.prevent="handleSubmit" novalidate class="space-y-1">
        <FloatingInput id="signin-email" v-model="email" label="شماره موبایل یا ایمیل" type="text" autocomplete="username" required />
        <FloatingInput id="signin-password" v-model="password" label="رمز عبور" type="password" autocomplete="current-password" required />
        <button v-wave="{ color: 'rgba(0,0,0,0.18)' }" type="submit" :disabled="loading"
          class="mt-6 w-full h-12 rounded-xl bg-ink-50 text-ink-950 text-[15px] font-semibold hover:bg-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2">
          <svg v-if="loading" class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" opacity="0.25" />
            <path d="M12 2a10 10 0 0110 10" stroke="currentColor" stroke-width="3" stroke-linecap="round" />
          </svg>
          <span>{{ loading ? 'در حال ورود...' : 'ورود به حساب' }}</span>
        </button>
      </form>
      <div class="mt-6 text-center text-[13px]">
        <span class="text-ink-500">حسابی کاربری نداری؟ </span>
        <NuxtLink v-wave to="/account/signup" class="text-ink-300 font-medium hover:text-ink-50 transition-colors">ایجاد حساب کاربری</NuxtLink>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ title: 'ورود' })
const auth = useUserAuthStore()
const toast = useToastStore()
const router = useRouter()
const email = ref('')
const password = ref('')
const loading = ref(false)

async function handleSubmit() {
  if (loading.value) return
  if (!email.value.trim() || !password.value) {
    toast.error('ایمیل و رمز عبور را وارد کنید')
    return
  }
  loading.value = true
  // تاخیر برای احراز هویت واقعی
  await new Promise(r => setTimeout(r, 1500))
  try {
    const result = await auth.login(email.value.trim(), password.value)
    if (result.success) {
      toast.success('خوش آمدید!')
      await router.push('/account')
    } else {
      toast.error(result.error || 'خطا در ورود')
    }
  } catch {
    toast.error('خطای غیرمنتظره')
  } finally {
    loading.value = false
  }
}
</script>
