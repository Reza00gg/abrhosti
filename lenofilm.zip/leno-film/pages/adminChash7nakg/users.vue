<template>
  <div class="min-h-screen">
    <AdminHeader />
    <main class="pt-[60px] min-h-screen pb-10">
      <div class="px-4 sm:px-6 py-6 max-w-6xl mx-auto">

        <!-- عنوان -->
        <div class="flex items-center justify-between mb-5">
          <div>
            <h1 class="text-[18px] font-semibold tracking-tight text-[#fafafa]">کاربران</h1>
            <p class="mt-1 text-[11px] text-[#71717a]">مدیریت کاربران سایت</p>
          </div>
          <div class="text-[11px] text-[#71717a]">{{ users.length }} کاربر</div>
        </div>

        <!-- جستجو -->
        <div class="mb-5">
          <div class="relative">
            <Icon icon="lucide:search" class="absolute right-3 top-1/2 -translate-y-1/2 text-[14px] text-[#71717a] pointer-events-none" />
            <input v-model="search" type="text" placeholder="جستجو..." class="w-full h-10 ps-9 pe-3 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
          </div>
        </div>

        <!-- لیست -->
        <div v-if="loading" class="text-center py-12">
          <Icon icon="lucide:loader-2" class="text-[32px] text-[#52525b] mx-auto animate-spin" />
        </div>

        <div v-else-if="filteredUsers.length === 0" class="text-center py-16">
          <Icon icon="lucide:users" class="text-[36px] text-[#52525b] mx-auto" />
          <p class="mt-3 text-[14px] text-[#71717a]">{{ search ? 'نتیجه‌ای یافت نشد' : 'هنوز کاربری ثبت‌نام نکرده' }}</p>
        </div>

        <ul v-else class="space-y-2">
          <li v-for="u in pagedUsers" :key="u.id" class="p-3.5 rounded-xl bg-[#18181b] border border-[#1f1f1f] flex items-center gap-3.5">
            <!-- آواتار -->
            <div class="w-10 h-10 rounded-full bg-[#0a0a0a] border border-[#1f1f1f] flex items-center justify-center shrink-0">
              <Icon icon="lucide:user" class="text-[18px] text-[#52525b]" />
            </div>

            <!-- اطلاعات -->
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2">
                <h3 class="text-[13px] font-semibold text-[#fafafa] truncate">{{ u.name }}</h3>
                <span v-if="u.banned" class="text-[10px] px-1.5 py-0.5 rounded bg-[#ef4444]/15 text-[#ef4444] border border-[#ef4444]/20">مسدود</span>
              </div>
              <p class="text-[11px] text-[#71717a] truncate" dir="ltr">{{ u.email }}</p>
              <p class="mt-0.5 text-[10px] text-[#52525b]">عضو از {{ formatDate(u.createdAt) }}</p>
            </div>

            <!-- اکشن‌ها -->
            <div class="flex items-center gap-1 shrink-0">
              <button v-wave @click="toggleBan(u)" :title="u.banned ? 'رفع مسدودیت' : 'مسدود کردن'"
                class="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] transition-colors"
                :class="u.banned ? 'text-[#22c55e] hover:text-[#22c55e]' : 'text-[#a1a1aa] hover:text-[#f59e0b]'">
                <Icon :icon="u.banned ? 'lucide:check-circle' : 'lucide:ban'" class="text-[16px]" />
              </button>
              <button v-wave @click="confirmDelete(u)" title="حذف"
                class="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] text-[#a1a1aa] hover:text-[#ef4444] transition-colors">
                <Icon icon="lucide:trash-2" class="text-[16px]" />
              </button>
            </div>
          </li>
        </ul>

        <!-- Pagination -->
        <div v-if="totalPages > 1" class="mt-6 flex items-center justify-center gap-2">
          <button v-wave @click="prevPage" :disabled="page === 1"
            class="flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[12px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
            <Icon icon="lucide:chevron-right" class="text-[16px]" />
            قبلی
          </button>
          <span class="text-[12px] text-[#71717a] px-3">صفحه {{ page }} از {{ totalPages }}</span>
          <button v-wave @click="nextPage" :disabled="page === totalPages"
            class="flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[12px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
            بعدی
            <Icon icon="lucide:chevron-left" class="text-[16px]" />
          </button>
        </div>
      </div>
    </main>
    <AdminDrawer />
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'admin', middleware: 'admin-auth' })

interface AdminUser {
  id: number
  name: string
  email: string
  banned: boolean
  createdAt: string
}

const toast = useToastStore()
const PAGE_SIZE = 15

const users = ref<AdminUser[]>([])
const search = ref('')
const loading = ref(false)
const page = ref(1)

const filteredUsers = computed(() => {
  if (!search.value.trim()) return users.value
  const q = search.value.trim().toLowerCase()
  return users.value.filter(u => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q))
})

const totalPages = computed(() => Math.max(1, Math.ceil(filteredUsers.value.length / PAGE_SIZE)))
const pagedUsers = computed(() => {
  const start = (page.value - 1) * PAGE_SIZE
  return filteredUsers.value.slice(start, start + PAGE_SIZE)
})

watch(search, () => { page.value = 1 })

async function fetchUsers() {
  loading.value = true
  try {
    users.value = await $fetch<AdminUser[]>('/api/admin/users')
  } catch {
    users.value = []
  } finally {
    loading.value = false
  }
}

async function toggleBan(u: AdminUser) {
  try {
    const res = await $fetch<{ success: boolean; banned: boolean }>(`/api/admin/users/${u.id}/ban`, {
      method: 'PUT',
      body: { banned: !u.banned }
    })
    const idx = users.value.findIndex(x => x.id === u.id)
    if (idx > -1) users.value[idx].banned = res.banned
    toast.success(res.banned ? 'کاربر مسدود شد' : 'کاربر رفع مسدودیت شد')
  } catch {
    toast.error('خطا در تغییر وضعیت کاربر')
  }
}

async function confirmDelete(u: AdminUser) {
  if (!confirm(`آیا از حذف «${u.name}» مطمئن هستید؟ این عملیات غیرقابل بازگشت است.`)) return
  try {
    await $fetch(`/api/admin/users/${u.id}`, { method: 'DELETE' })
    toast.success('کاربر حذف شد')
    users.value = users.value.filter(x => x.id !== u.id)
    if (page.value > totalPages.value) page.value = totalPages.value
  } catch {
    toast.error('خطا در حذف کاربر')
  }
}

function prevPage() { if (page.value > 1) page.value-- }
function nextPage() { if (page.value < totalPages.value) page.value++ }

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('fa-IR')
}

onMounted(() => { fetchUsers() })
</script>
