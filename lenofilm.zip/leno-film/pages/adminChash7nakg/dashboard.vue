<template>
  <div class="min-h-screen">
    <AdminHeader />
    <main class="pt-[60px] min-h-screen">
      <div class="px-5 sm:px-8 py-8 max-w-6xl mx-auto">
        <div class="mb-8">
          <h1 class="text-[24px] font-semibold tracking-tight text-[#fafafa]">داشبورد</h1>
          <p class="mt-2 text-[13px] text-[#71717a]">به پنل مدیریت خوش آمدید</p>
        </div>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <div v-for="stat in stats" :key="stat.label" class="p-5 rounded-2xl bg-[#18181b] border border-[#1f1f1f]">
            <div class="flex items-center gap-2 text-[#71717a]">
              <Icon :icon="stat.icon" class="text-[16px]" />
              <span class="text-[11px] uppercase tracking-widest">{{ stat.label }}</span>
            </div>
            <p class="mt-3 text-[28px] font-semibold text-[#fafafa] tracking-tight">{{ stat.value }}</p>
            <p class="mt-1 text-[11px] text-[#52525b]">{{ stat.hint }}</p>
          </div>
        </div>
        <div class="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">
          <div class="p-6 rounded-2xl bg-[#18181b] border border-[#1f1f1f]">
            <div class="flex items-center gap-2">
              <Icon icon="lucide:user-round" class="text-[18px] text-[#a1a1aa]" />
              <h3 class="text-[14px] font-semibold text-[#fafafa]">اطلاعات حساب</h3>
            </div>
            <div class="mt-4 space-y-2 text-[13px]">
              <div class="flex justify-between"><span class="text-[#71717a]">ایمیل</span><span class="text-[#fafafa]">{{ auth.user?.email }}</span></div>
              <div class="flex justify-between"><span class="text-[#71717a]">زمان ورود</span><span class="text-[#fafafa]">{{ loginTime }}</span></div>
            </div>
          </div>
          <div class="p-6 rounded-2xl bg-[#18181b] border border-[#1f1f1f]">
            <div class="flex items-center gap-2">
              <Icon icon="lucide:rocket" class="text-[18px] text-[#a1a1aa]" />
              <h3 class="text-[14px] font-semibold text-[#fafafa]">مرحله‌ی توسعه</h3>
            </div>
            <p class="mt-3 text-[13px] text-[#a1a1aa] leading-6">پنل مدیریت در حال ساخت است. بخش‌های سریال، کاربران و نظرات به‌زودی فعال خواهند شد.</p>
          </div>
        </div>
      </div>
    </main>
    <AdminDrawer />
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'admin', middleware: 'admin-auth' })
const auth = useAuthStore()

interface Stats { movies: number; series: number; users: number; comments: number }
const statsData = ref<Stats>({ movies: 0, series: 0, users: 0, comments: 0 })

async function fetchStats() {
  try { statsData.value = await $fetch<Stats>('/api/stats') }
  catch { statsData.value = { movies: 0, series: 0, users: 0, comments: 0 } }
}

const stats = computed(() => [
  { label: 'فیلم‌ها',  value: toFa(statsData.value.movies),    icon: 'lucide:clapperboard',    hint: statsData.value.movies > 0 ? 'در سایت نمایش داده می‌شوند' : 'هنوز فیلمی اضافه نشده' },
  { label: 'سریال‌ها', value: toFa(statsData.value.series),   icon: 'lucide:monitor-play',    hint: 'به‌زودی فعال می‌شود' },
  { label: 'کاربران',  value: toFa(statsData.value.users),    icon: 'lucide:users',           hint: 'فقط شما (ادمین)' },
  { label: 'نظرات',    value: toFa(statsData.value.comments), icon: 'lucide:message-circle',  hint: 'به‌زودی فعال می‌شود' },
])

function toFa(n: number): string {
  const map: Record<string, string> = { '0': '۰', '1': '۱', '2': '۲', '3': '۳', '4': '۴', '5': '۵', '6': '۶', '7': '۷', '8': '۸', '9': '۹' }
  return String(n).split('').map(c => map[c] ?? c).join('')
}

const loginTime = computed(() => {
  if (!auth.user?.loggedInAt) return '—'
  return new Date(auth.user.loggedInAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
})

onMounted(() => { fetchStats() })
</script>
