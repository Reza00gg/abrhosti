<template>
  <div class="min-h-screen">
    <AdminHeader />
    <main class="pt-[60px] min-h-screen pb-10">
      <div class="px-4 sm:px-6 py-6 max-w-6xl mx-auto">
        <div class="flex items-center justify-between mb-5">
          <div>
            <h1 class="text-[18px] font-semibold tracking-tight text-[#fafafa]">فیلم ها</h1>
            <p class="mt-1 text-[11px] text-[#71717a]">مدیریت فیلم‌های سایت</p>
          </div>
          <button v-wave="{ color: 'rgba(0,0,0,0.12)' }" @click="openAddForm" class="flex items-center gap-2 h-10 px-4 rounded-xl bg-[#fafafa] text-[#0a0a0a] text-[13px] font-medium hover:bg-[#e4e4e7] transition-colors">
            <Icon icon="lucide:plus" class="text-[18px]" />
            <span>افزودن فیلم</span>
          </button>
        </div>
        <div class="mb-5">
          <div class="relative">
            <Icon icon="lucide:search" class="absolute right-3 top-1/2 -translate-y-1/2 text-[14px] text-[#71717a] pointer-events-none" />
            <input v-model="search" type="text" placeholder="جستجو..." class="w-full h-10 ps-9 pe-3 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
          </div>
        </div>
        <div v-if="loading" class="text-center py-12">
          <Icon icon="lucide:loader-2" class="text-[32px] text-[#52525b] mx-auto animate-spin" />
        </div>
        <div v-else-if="filteredMovies.length === 0" class="text-center py-16">
          <Icon icon="lucide:film" class="text-[36px] text-[#52525b] mx-auto" />
          <p class="mt-3 text-[14px] text-[#71717a]">{{ search ? 'نتیجه‌ای یافت نشد' : 'هنوز فیلمی اضافه نشده' }}</p>
        </div>
        <ul v-else class="space-y-2">
          <li v-for="movie in pagedMovies" :key="movie.id" class="p-3.5 rounded-xl bg-[#18181b] border border-[#1f1f1f] flex items-center gap-3.5">
            <div class="w-10 h-14 rounded-md overflow-hidden bg-[#0a0a0a] shrink-0 flex items-center justify-center">
              <img v-if="movie.posterUrl" :src="movie.posterUrl" :alt="movie.titleFa" draggable="false" class="w-full h-full object-cover select-none pointer-events-none" @error="(e: any) => e.target.style.display = 'none'" />
              <Icon v-else icon="lucide:film" class="text-[18px] text-[#52525b]" />
            </div>
            <div class="flex-1 min-w-0">
              <h3 class="text-[13px] font-semibold text-[#fafafa] truncate">{{ movie.titleFa }}</h3>
              <p class="text-[11px] text-[#71717a] truncate" dir="ltr">{{ movie.titleEn }}</p>
              <div class="mt-1 flex items-center gap-2.5 text-[10px] text-[#52525b]">
                <span class="flex items-center gap-1"><Icon icon="lucide:star" class="text-[11px] text-yellow-400" /><span class="text-[#fafafa] font-medium">{{ movie.rating.toFixed(1) }}</span></span>
                <span>{{ movie.year }}</span>
                <span>{{ movie.duration }} دقیقه</span>
              </div>
            </div>
            <div class="flex items-center gap-1 shrink-0">
              <button v-wave @click="openEditForm(movie)" class="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] text-[#a1a1aa] hover:text-[#fafafa] transition-colors" title="ویرایش"><Icon icon="lucide:pencil" class="text-[15px]" /></button>
              <button v-wave @click="confirmDelete(movie)" class="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#0a0a0a] text-[#a1a1aa] hover:text-[#ef4444] transition-colors" title="حذف"><Icon icon="lucide:trash-2" class="text-[15px]" /></button>
            </div>
          </li>
        </ul>

        <div v-if="totalPages > 1" class="mt-6 flex items-center justify-center gap-2">
          <button v-wave @click="prevPage" :disabled="page === 1" class="flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[12px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
            <Icon icon="lucide:chevron-right" class="text-[16px]" />
            قبلی
          </button>
          <span class="text-[12px] text-[#71717a] px-3">صفحه {{ page }} از {{ totalPages }}</span>
          <button v-wave @click="nextPage" :disabled="page === totalPages" class="flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[12px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors disabled:opacity-30 disabled:cursor-not-allowed">
            بعدی
            <Icon icon="lucide:chevron-left" class="text-[16px]" />
          </button>
        </div>
      </div>
    </main>
    <AdminDrawer />
    <MovieForm v-model="formOpen" :movie="editingMovie" @saved="onMovieSaved" />
  </div>
</template>

<script setup lang="ts">
import type { Movie } from '~~/server/db/schema'
definePageMeta({ layout: 'admin', middleware: 'admin-auth' })
const toast = useToastStore()

const PAGE_SIZE = 15

const movies = ref<Movie[]>([])
const search = ref('')
const loading = ref(false)
const page = ref(1)
const formOpen = ref(false)
const editingMovie = ref<Movie | null>(null)

const filteredMovies = computed(() => {
  if (!search.value.trim()) return movies.value
  const q = search.value.trim().toLowerCase()
  return movies.value.filter(m => m.titleFa.toLowerCase().includes(q) || m.titleEn.toLowerCase().includes(q))
})

const totalPages = computed(() => Math.max(1, Math.ceil(filteredMovies.value.length / PAGE_SIZE)))
const pagedMovies = computed(() => {
  const start = (page.value - 1) * PAGE_SIZE
  return filteredMovies.value.slice(start, start + PAGE_SIZE)
})

watch(search, () => { page.value = 1 })

async function fetchMovies() {
  loading.value = true
  try { movies.value = await $fetch<Movie[]>('/api/movies') }
  catch { movies.value = [] }
  finally { loading.value = false }
}

function openAddForm() { editingMovie.value = null; formOpen.value = true }
function openEditForm(movie: Movie) { editingMovie.value = movie; formOpen.value = true }

async function onMovieSaved(savedMovie: Movie) {
  const idx = movies.value.findIndex(m => m.id === savedMovie.id)
  if (idx > -1) movies.value[idx] = savedMovie
  else movies.value.unshift(savedMovie)
  page.value = 1
}

async function confirmDelete(movie: Movie) {
  if (!confirm(`آیا از حذف «${movie.titleFa}» مطمئن هستید؟`)) return
  try {
    await $fetch(`/api/movies/${movie.id}`, { method: 'DELETE' })
    toast.success('فیلم حذف شد')
    movies.value = movies.value.filter(m => m.id !== movie.id)
    if (page.value > totalPages.value) page.value = totalPages.value
  } catch { toast.error('خطا در حذف فیلم') }
}

function prevPage() { if (page.value > 1) page.value-- }
function nextPage() { if (page.value < totalPages.value) page.value++ }

onMounted(() => { fetchMovies() })
</script>
