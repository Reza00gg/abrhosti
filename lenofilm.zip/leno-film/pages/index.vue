<template>
  <div class="px-4 sm:px-6 pt-6 sm:pt-8 pb-8">
    <div class="mb-5">
      <h1 class="text-[18px] font-semibold tracking-tight text-ink-50">فیلم‌ها</h1>
      <p class="mt-1 text-[11px] text-ink-500">{{ loading ? 'در حال بارگذاری...' : `${movies.length} فیلم` }}</p>
    </div>
    <div v-if="loading" class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2 sm:gap-3">
      <div v-for="i in 12" :key="i" class="rounded-xl overflow-hidden bg-ink-900/40 border border-[color:var(--hairline)]">
        <div class="aspect-[3/4] bg-ink-900 animate-pulse"></div>
        <div class="p-2 space-y-1.5"><div class="h-2.5 bg-ink-900 rounded animate-pulse"></div><div class="h-2 bg-ink-900 rounded w-2/3 animate-pulse"></div></div>
      </div>
    </div>
    <div v-else-if="movies.length === 0" class="text-center py-16">
      <Icon icon="lucide:clapperboard" class="text-[40px] text-ink-600 mx-auto" />
      <p class="mt-4 text-base text-ink-300 font-medium">بزودی فیلم/سریال اضافه میشود</p>
    </div>
    <div v-else class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2 sm:gap-3">
      <MovieCard v-for="movie in movies" :key="movie.id" :movie="movie" />
    </div>
  </div>
</template>

<script setup lang="ts">
import type { Movie } from '~~/server/db/schema'
definePageMeta({ title: 'خانه' })
const movies = ref<Movie[]>([])
const loading = ref(true)
async function fetchMovies() {
  try { movies.value = await $fetch<Movie[]>('/api/movies') }
  catch { movies.value = [] }
  finally { loading.value = false }
}
onMounted(() => { fetchMovies() })
</script>
