import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, a as users } from '../../../_/index.mjs';
import { h as hashPassword } from '../../../_/password.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'crypto';

const signup_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  if (!((_a = body.name) == null ? void 0 : _a.trim()) || !((_b = body.email) == null ? void 0 : _b.trim()) || !body.password) {
    throw createError({ statusCode: 400, statusMessage: "\u0646\u0627\u0645\u060C \u0627\u06CC\u0645\u06CC\u0644 \u0648 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0647\u0633\u062A\u0646\u062F" });
  }
  if (body.password.length < 6) {
    throw createError({ statusCode: 400, statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06F6 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F" });
  }
  const db = useDb();
  const email = body.email.trim().toLowerCase();
  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing.length > 0) {
    throw createError({ statusCode: 409, statusMessage: "\u0627\u06CC\u0646 \u0627\u06CC\u0645\u06CC\u0644 \u0642\u0628\u0644\u0627\u064B \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A" });
  }
  const [user] = await db.insert(users).values({
    name: body.name.trim(),
    email,
    passwordHash: hashPassword(body.password)
  }).returning();
  return { id: user.id, name: user.name, email: user.email };
});

export { signup_post as default };
//# sourceMappingURL=signup.post.mjs.map
