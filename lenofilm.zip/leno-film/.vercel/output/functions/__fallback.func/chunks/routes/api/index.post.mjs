import { d as defineEventHandler, r as readBody, c as createError } from '../../nitro/nitro.mjs';
import { u as useDb, m as movies } from '../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!body.titleFa || !body.titleEn || !body.duration || !body.year || body.rating == null) {
    throw createError({ statusCode: 400, statusMessage: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0641\u06CC\u0644\u0645 \u0646\u0627\u0642\u0635 \u0627\u0633\u062A" });
  }
  const db = useDb();
  const [movie] = await db.insert(movies).values({
    titleFa: String(body.titleFa),
    titleEn: String(body.titleEn),
    duration: Number(body.duration),
    year: Number(body.year),
    rating: Number(body.rating),
    posterUrl: String(body.posterUrl || ""),
    coverUrl: String(body.coverUrl || ""),
    description: String(body.description || "")
  }).returning();
  return movie;
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
