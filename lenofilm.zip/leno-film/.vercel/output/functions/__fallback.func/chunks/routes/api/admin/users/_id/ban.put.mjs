import { d as defineEventHandler, g as getRouterParam, c as createError, r as readBody } from '../../../../../nitro/nitro.mjs';
import { u as useDb, a as users } from '../../../../../_/index.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const ban_put = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: "ID \u0646\u0627\u0645\u0639\u062A\u0628\u0631" });
  const body = await readBody(event);
  const banned = !!body.banned;
  const db = useDb();
  const [updated] = await db.update(users).set({ banned }).where(eq(users.id, id)).returning();
  if (!updated) throw createError({ statusCode: 404, statusMessage: "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F" });
  return { success: true, banned: updated.banned };
});

export { ban_put as default };
//# sourceMappingURL=ban.put.mjs.map
