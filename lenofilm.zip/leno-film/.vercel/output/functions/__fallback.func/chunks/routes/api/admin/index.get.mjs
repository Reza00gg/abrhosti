import { d as defineEventHandler, a as getQuery } from '../../../nitro/nitro.mjs';
import { u as useDb, a as users } from '../../../_/index.mjs';
import { or, ilike, desc } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const q = getQuery(event);
  const search = (_a = q.q) == null ? void 0 : _a.trim();
  const db = useDb();
  const baseQuery = db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    banned: users.banned,
    createdAt: users.createdAt
  }).from(users);
  if (search) {
    return await baseQuery.where(or(ilike(users.name, `%${search}%`), ilike(users.email, `%${search}%`))).orderBy(desc(users.createdAt)).limit(100);
  }
  return await baseQuery.orderBy(desc(users.createdAt)).limit(100);
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
