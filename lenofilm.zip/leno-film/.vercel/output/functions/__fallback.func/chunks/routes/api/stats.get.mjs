import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import { u as useDb, m as movies } from '../../_/index.mjs';
import { count } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const stats_get = defineEventHandler(async () => {
  var _a;
  const db = useDb();
  const [moviesCount] = await db.select({ count: count() }).from(movies);
  return {
    movies: (_a = moviesCount == null ? void 0 : moviesCount.count) != null ? _a : 0,
    series: 0,
    users: 1,
    comments: 0
  };
});

export { stats_get as default };
//# sourceMappingURL=stats.get.mjs.map
