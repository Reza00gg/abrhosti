import { d as defineEventHandler, a as getQuery } from '../../nitro/nitro.mjs';
import { u as useDb, m as movies } from '../../_/index.mjs';
import { or, ilike } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const q = getQuery(event);
  const search = (_a = q.q) == null ? void 0 : _a.trim();
  const db = useDb();
  if (search) {
    return await db.select().from(movies).where(or(ilike(movies.titleFa, `%${search}%`), ilike(movies.titleEn, `%${search}%`))).limit(50);
  }
  return await db.select().from(movies).limit(100);
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
