import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { u as useDb, a as users } from '../../../_/index.mjs';
import { v as verifyPassword } from '../../../_/password.mjs';
import { eq } from 'drizzle-orm';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'crypto';

const signin_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  if (!((_a = body.email) == null ? void 0 : _a.trim()) || !body.password) {
    throw createError({ statusCode: 400, statusMessage: "\u0627\u06CC\u0645\u06CC\u0644 \u0648 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0647\u0633\u062A\u0646\u062F" });
  }
  const db = useDb();
  const email = body.email.trim().toLowerCase();
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user || !verifyPassword(body.password, user.passwordHash)) {
    throw createError({ statusCode: 401, statusMessage: "\u0627\u06CC\u0645\u06CC\u0644 \u06CC\u0627 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A" });
  }
  if (user.banned) {
    throw createError({ statusCode: 403, statusMessage: "\u062D\u0633\u0627\u0628 \u0634\u0645\u0627 \u0627\u0632 \u0637\u0631\u0641 \u0645\u062F\u06CC\u0631\u06CC\u062A \u0645\u0633\u062F\u0648\u062F \u0634\u062F\u0647 \u0627\u0633\u062A" });
  }
  return { id: user.id, name: user.name, email: user.email };
});

export { signin_post as default };
//# sourceMappingURL=signin.post.mjs.map
