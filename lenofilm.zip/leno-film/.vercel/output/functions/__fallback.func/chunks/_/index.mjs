import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { pgTable, timestamp, boolean, text, serial, uniqueIndex, real, integer } from 'drizzle-orm/pg-core';

const movies = pgTable("movies", {
  id: serial("id").primaryKey(),
  titleFa: text("title_fa").notNull(),
  titleEn: text("title_en").notNull(),
  duration: integer("duration").notNull(),
  year: integer("year").notNull(),
  rating: real("rating").notNull(),
  posterUrl: text("poster_url").notNull(),
  coverUrl: text("cover_url").notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  passwordHash: text("password_hash").notNull(),
  banned: boolean("banned").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull()
}, (table) => ({
  emailIdx: uniqueIndex("users_email_idx").on(table.email)
}));

const schema = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  movies: movies,
  users: users
}, Symbol.toStringTag, { value: 'Module' }));

let _db = null;
function useDb() {
  if (_db) return _db;
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is not set");
  const client = postgres(url, { ssl: "require", max: 1 });
  _db = drizzle(client, { schema });
  return _db;
}

export { users as a, movies as m, useDb as u };
//# sourceMappingURL=index.mjs.map
