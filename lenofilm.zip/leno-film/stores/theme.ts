import { defineStore } from 'pinia'

export type ThemeName = 'ink' | 'light' | 'blue'

export const useThemeStore = defineStore('theme', () => {
  const themes: ThemeName[] = ['ink', 'light', 'blue']

  // ذخیره در کوکی مرورگر - 1 سال
  const cookie = useCookie<ThemeName>('leno-theme', {
    default: () => 'ink',
    maxAge: 60 * 60 * 24 * 365,
    sameSite: 'lax',
    watch: true,
  })

  const current = computed<ThemeName>(() => cookie.value || 'ink')

  // چرخش بین تم‌ها
  function next() {
    const idx = themes.indexOf(cookie.value)
    cookie.value = themes[(idx + 1) % themes.length]
  }

  function setTheme(theme: ThemeName) {
    cookie.value = theme
  }

  return {
    themes,
    current,
    next,
    setTheme,
  }
})
