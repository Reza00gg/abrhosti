import { defineStore } from 'pinia'

interface Toast {
  id: number
  message: string
  type: 'success' | 'error' | 'info'
}

export const useToastStore = defineStore('toast', () => {
  const toasts = ref<Toast[]>([])
  let nextId = 1

  function show(message: string, type: 'success' | 'error' | 'info' = 'info', duration = 3000) {
    const id = nextId++

    // حداکثر ۳ toast همزمان - اگه بیشتر شد، قدیمی‌ترین رو حذف کن
    while (toasts.value.length >= 3) {
      toasts.value.shift()
    }

    toasts.value.push({ id, message, type })

    if (duration > 0) {
      setTimeout(() => {
        remove(id)
      }, duration)
    }
  }

  function remove(id: number) {
    const idx = toasts.value.findIndex(t => t.id === id)
    if (idx > -1) toasts.value.splice(idx, 1)
  }

  function success(message: string, duration = 3000) {
    show(message, 'success', duration)
  }

  function error(message: string, duration = 3000) {
    show(message, 'error', duration)
  }

  function info(message: string, duration = 3000) {
    show(message, 'info', duration)
  }

  return { toasts, show, remove, success, error, info }
})
