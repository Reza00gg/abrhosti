import { defineStore } from 'pinia'

interface User {
  id: number
  name: string
  email: string
  loggedInAt: number
}

export const useUserAuthStore = defineStore('user-auth', () => {
  const cookie = useCookie<User | null>('user-auth', {
    default: () => null,
    maxAge: 60 * 60 * 24 * 7,
    sameSite: 'lax',
  })

  const user = computed(() => cookie.value)
  const isAuthenticated = computed(() => !!cookie.value)

  async function login(email: string, password: string): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await $fetch<{ id: number; name: string; email: string }>('/api/users/signin', {
        method: 'POST',
        body: { email, password },
      })
      cookie.value = { ...res, loggedInAt: Date.now() }
      return { success: true }
    } catch (err: any) {
      return { success: false, error: err?.statusMessage || 'خطا در ورود' }
    }
  }

  async function signup(name: string, email: string, password: string): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await $fetch<{ id: number; name: string; email: string }>('/api/users/signup', {
        method: 'POST',
        body: { name, email, password },
      })
      cookie.value = { ...res, loggedInAt: Date.now() }
      return { success: true }
    } catch (err: any) {
      return { success: false, error: err?.statusMessage || 'خطا در ثبت‌نام' }
    }
  }

  function logout() {
    cookie.value = null
  }

  return { user, isAuthenticated, login, signup, logout }
})
