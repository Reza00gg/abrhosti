export default defineNuxtConfig({
  compatibilityDate: '2025-01-01',
  devtools: { enabled: false },

  modules: [
    '@nuxtjs/tailwindcss',
    '@pinia/nuxt',
    '@vueuse/nuxt',
  ],

  css: ['~/assets/css/main.css'],

  plugins: [
    '~/plugins/iconify',
    '~/plugins/v-wave.client',
    '~/plugins/theme.client',
  ],

  components: [
    { path: '~/components', pathPrefix: false }
  ],

  app: {
    head: {
      title: 'لنوفیلم',
      htmlAttrs: { lang: 'fa', dir: 'rtl' },
      meta: [
        { charset: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1' },
        { name: 'description', content: 'لنوفیلم - تماشای فیلم و سریال' },
        { name: 'theme-color', content: '#0a0a0a' },
      ],
      link: [
        { rel: 'icon', type: 'image/svg+xml', href: '/favicon.svg' },
        { rel: 'preconnect', href: 'https://cdn.jsdelivr.net' },
        { rel: 'stylesheet', href: 'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css' },
      ],
      meta: [
        // جلوگیری از cache شدن HTML اصلی
        { 'http-equiv': 'Cache-Control', content: 'no-cache, no-store, must-revalidate' },
        { 'http-equiv': 'Pragma', content: 'no-cache' },
        { 'http-equiv': 'Expires', content: '0' },
      ],
    },
  },

  ssr: false,
  nitro: { preset: 'vercel' },

  // Vercel route headers - فایل اصلی HTML cache نشه، chunk ها cache بشن
  routeRules: {
    '/**': {
      headers: {
        'Cache-Control': 'public, max-age=0, must-revalidate',
      },
    },
    '/_nuxt/**': {
      headers: {
        'Cache-Control': 'public, max-age=31536000, immutable',
      },
    },
  },

  experimental: { payloadExtraction: false },
  typescript: { strict: false, typeCheck: false }
})
