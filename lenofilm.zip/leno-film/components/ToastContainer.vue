<template>
  <Teleport to="body">
    <div class="fixed bottom-6 inset-x-0 z-[60] flex flex-col items-center gap-2 px-4 pointer-events-none">
      <TransitionGroup name="toast">
        <div
          v-for="t in toasts.toasts"
          :key="t.id"
          class="pointer-events-auto max-w-sm w-full px-5 py-3.5 rounded-2xl shadow-2xl backdrop-blur-md flex items-center gap-3"
          :class="{
            'bg-[#0a0a0a]/95 border border-[#1f1f1f]': true,
          }"
        >
          <!-- Icon -->
          <Icon
            :icon="t.type === 'success' ? 'lucide:check-circle' : t.type === 'error' ? 'lucide:alert-circle' : 'lucide:info'"
            class="text-[20px] shrink-0"
            :class="{
              'text-[#22c55e]': t.type === 'success',
              'text-[#ef4444]': t.type === 'error',
              'text-[#a1a1aa]': t.type === 'info',
            }"
          />
          <!-- Message -->
          <p class="text-[13px] text-[#fafafa]">{{ t.message }}</p>
        </div>
      </TransitionGroup>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
const toasts = useToastStore()
</script>

<style scoped>
.toast-enter-active,
.toast-leave-active {
  transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
}
.toast-enter-from {
  opacity: 0;
  transform: translateY(24px);
}
.toast-leave-to {
  opacity: 0;
  transform: translateY(24px);
}
</style>
