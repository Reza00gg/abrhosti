<template>
  <div class="relative pt-3">
    <input
      :id="id"
      :type="type"
      :value="modelValue"
      @input="onInput"
      @focus="focused = true"
      @blur="focused = false"
      :required="required"
      :autocomplete="autocomplete"
      :dir="dir"
      class="peer w-full h-12 bg-transparent border-b-2 border-[color:var(--hairline)] text-ink-50 text-[15px] pt-3 pb-1 px-1 outline-none focus:border-[color:var(--input-border-focus)] transition-colors duration-300 ease-out rounded-none"
      placeholder=" "
    />
    <label
      :for="id"
      class="absolute right-1 pointer-events-none transition-all duration-300 ease-out font-medium"
      :class="floating
        ? 'top-0 text-[11px] text-ink-400'
        : 'top-1/2 -translate-y-1/2 text-[15px] text-ink-500'"
    >
      {{ label }}
    </label>
  </div>
</template>

<script setup lang="ts">
const props = defineProps<{
  modelValue?: string
  label: string
  type?: string
  required?: boolean
  autocomplete?: string
  id: string
  dir?: 'ltr' | 'rtl' | 'auto'
}>()

const emit = defineEmits<{
  'update:modelValue': [v: string]
}>()

const focused = ref(false)
const floating = computed(() => focused.value || !!props.modelValue)

function onInput(e: Event) {
  emit('update:modelValue', (e.target as HTMLInputElement).value)
}
</script>
