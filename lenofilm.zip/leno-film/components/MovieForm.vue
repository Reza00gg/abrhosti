<template>
  <Teleport to="body">
    <Transition name="backdrop">
      <div v-if="modelValue" @click="close" class="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"></div>
    </Transition>
    <Transition name="modal">
      <div v-if="modelValue" class="fixed inset-x-0 bottom-0 sm:inset-0 z-50 flex items-end sm:items-center justify-center pointer-events-none">
        <div @click.stop class="pointer-events-auto w-full sm:max-w-lg max-h-[92vh] bg-[#0a0a0a] border-t sm:border border-[#1f1f1f] sm:rounded-2xl rounded-t-2xl flex flex-col overflow-hidden">
          <header class="px-5 py-4 border-b border-[#1f1f1f] flex items-center justify-between shrink-0">
            <h2 class="text-[15px] font-semibold text-[#fafafa]">{{ isEdit ? 'ویرایش فیلم' : 'افزودن فیلم' }}</h2>
            <button v-wave @click="close" class="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-[#18181b] text-[#a1a1aa] hover:text-[#fafafa] transition-colors"><Icon icon="lucide:x" class="text-[20px]" /></button>
          </header>
          <form @submit.prevent="submit" class="flex-1 overflow-y-auto p-5 space-y-3">
            <div>
              <label class="block text-[12px] text-[#a1a1aa] mb-1.5">نام فارسی</label>
              <input v-model="form.titleFa" type="text" required placeholder="مثال: مظنونین همیشگی" class="w-full h-10 px-3.5 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
            </div>
            <div>
              <label class="block text-[12px] text-[#a1a1aa] mb-1.5">نام انگلیسی</label>
              <input v-model="form.titleEn" type="text" required placeholder="The Usual Suspects" dir="ltr" class="w-full h-10 px-3.5 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-[12px] text-[#a1a1aa] mb-1.5">زمان (دقیقه)</label>
                <input v-model.number="form.duration" type="number" required min="1" placeholder="120" class="w-full h-10 px-3.5 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
              </div>
              <div>
                <label class="block text-[12px] text-[#a1a1aa] mb-1.5">سال ساخت</label>
                <input v-model.number="form.year" type="number" required min="1900" :max="new Date().getFullYear()" placeholder="2024" class="w-full h-10 px-3.5 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
              </div>
            </div>
            <div>
              <label class="block text-[12px] text-[#a1a1aa] mb-1.5">امتیاز IMDb</label>
              <input v-model.number="form.rating" type="number" required step="0.1" min="0" max="10" placeholder="8.5" class="w-full h-10 px-3.5 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
            </div>

            <div>
              <label class="block text-[12px] text-[#a1a1aa] mb-1.5">پوستر فیلم</label>
              <div class="flex gap-2">
                <div class="flex-1">
                  <label class="flex items-center justify-center gap-2 h-10 px-3.5 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] border-dashed cursor-pointer hover:border-[#3f3f46] transition-colors">
                    <Icon icon="lucide:image-plus" class="text-[16px] text-[#71717a]" />
                    <span class="text-[12px] text-[#a1a1aa]">انتخاب از دستگاه</span>
                    <input type="file" accept="image/*" @change="(e: any) => onFileChange(e, 'poster')" class="hidden" />
                  </label>
                </div>
                <div v-if="form.posterUrl" class="w-10 h-10 rounded-lg overflow-hidden bg-[#0a0a0a] shrink-0 border border-[#1f1f1f]">
                  <img :src="form.posterUrl" class="w-full h-full object-cover" alt="پوستر" />
                </div>
              </div>
            </div>

            <div>
              <label class="block text-[12px] text-[#a1a1aa] mb-1.5">کاور فیلم (اختیاری)</label>
              <div class="flex gap-2">
                <div class="flex-1">
                  <label class="flex items-center justify-center gap-2 h-10 px-3.5 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] border-dashed cursor-pointer hover:border-[#3f3f46] transition-colors">
                    <Icon icon="lucide:image-plus" class="text-[16px] text-[#71717a]" />
                    <span class="text-[12px] text-[#a1a1aa]">انتخاب از دستگاه</span>
                    <input type="file" accept="image/*" @change="(e: any) => onFileChange(e, 'cover')" class="hidden" />
                  </label>
                </div>
                <div v-if="form.coverUrl" class="w-10 h-10 rounded-lg overflow-hidden bg-[#0a0a0a] shrink-0 border border-[#1f1f1f]">
                  <img :src="form.coverUrl" class="w-full h-full object-cover" alt="کاور" />
                </div>
              </div>
            </div>

            <details class="text-[12px] text-[#71717a]">
              <summary class="cursor-pointer hover:text-[#a1a1aa]">یا از آدرس اینترنتی استفاده کن</summary>
              <div class="mt-2 space-y-2">
                <input v-model="form.posterUrl" type="url" placeholder="آدرس پوستر (اینترنتی)" dir="ltr" class="w-full h-9 px-3 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[12px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
                <input v-model="form.coverUrl" type="url" placeholder="آدرس کاور (اینترنتی)" dir="ltr" class="w-full h-9 px-3 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[12px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out" />
              </div>
            </details>

            <div>
              <label class="block text-[12px] text-[#a1a1aa] mb-1.5">توضیحات</label>
              <textarea v-model="form.description" rows="3" placeholder="خلاصه داستان..." class="w-full px-3.5 py-2.5 rounded-lg bg-[#0a0a0a] border border-[#1f1f1f] text-[13px] text-[#fafafa] placeholder:text-[#52525b] focus:border-[#3f3f46] outline-none transition-[border-color] duration-300 ease-out resize-none"></textarea>
            </div>
          </form>
          <footer class="px-5 py-3 border-t border-[#1f1f1f] flex items-center gap-3 shrink-0">
            <button v-wave @click="close" type="button" class="flex-1 h-10 rounded-lg bg-[#18181b] border border-[#1f1f1f] text-[13px] text-[#a1a1aa] hover:text-[#fafafa] hover:border-[#3f3f46] transition-colors">لغو</button>
            <button v-wave="{ color: 'rgba(0,0,0,0.12)' }" @click="submit" type="button" :disabled="loading" class="flex-1 h-10 rounded-lg bg-[#fafafa] text-[#0a0a0a] text-[13px] font-medium flex items-center justify-center gap-2 transition-opacity duration-200 disabled:opacity-40 hover:bg-[#e4e4e7]">
              <svg v-if="loading" class="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" opacity="0.25" /><path d="M12 2a10 10 0 0110 10" stroke="currentColor" stroke-width="3" stroke-linecap="round" /></svg>
              <span>{{ isEdit ? 'ذخیره' : 'افزودن' }}</span>
            </button>
          </footer>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import type { Movie } from '~~/server/db/schema'
const props = defineProps<{ modelValue: boolean; movie?: Movie | null }>()
const emit = defineEmits<{ 'update:modelValue': [v: boolean]; saved: [movie: Movie] }>()
const toast = useToastStore()
const isEdit = computed(() => !!props.movie)
const loading = ref(false)
const form = reactive({ titleFa: '', titleEn: '', duration: 0, year: new Date().getFullYear(), rating: 0, posterUrl: '', coverUrl: '', description: '' })

watch(() => props.modelValue, (open) => {
  if (open) {
    if (props.movie) Object.assign(form, { titleFa: props.movie.titleFa, titleEn: props.movie.titleEn, duration: props.movie.duration, year: props.movie.year, rating: props.movie.rating, posterUrl: props.movie.posterUrl, coverUrl: props.movie.coverUrl, description: props.movie.description })
    else Object.assign(form, { titleFa: '', titleEn: '', duration: 0, year: new Date().getFullYear(), rating: 0, posterUrl: '', coverUrl: '', description: '' })
  }
})

function close() { emit('update:modelValue', false) }

function onFileChange(e: Event, field: 'poster' | 'cover') {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  if (file.size > 5 * 1024 * 1024) {
    toast.error('حجم عکس نباید بیشتر از ۵ مگابایت باشد')
    input.value = ''
    return
  }
  const reader = new FileReader()
  reader.onload = () => {
    if (field === 'poster') form.posterUrl = reader.result as string
    else form.coverUrl = reader.result as string
  }
  reader.readAsDataURL(file)
}

async function submit() {
  if (loading.value) return
  loading.value = true
  try {
    let saved: Movie
    if (isEdit.value && props.movie) {
      saved = await $fetch(`/api/movies/${props.movie.id}`, { method: 'PUT', body: form })
      toast.success('فیلم با موفقیت ویرایش شد')
    } else {
      saved = await $fetch('/api/movies', { method: 'POST', body: form })
      toast.success('فیلم با موفقیت اضافه شد')
    }
    emit('saved', saved)
    close()
  } catch (err: any) {
    toast.error(err?.statusMessage || 'خطا در ذخیره‌سازی')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.backdrop-enter-active, .backdrop-leave-active { transition: opacity 0.3s ease; }
.backdrop-enter-from, .backdrop-leave-to { opacity: 0; }
.modal-enter-active, .modal-leave-active { transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
.modal-enter-from, .modal-leave-to { opacity: 0; transform: translateY(40px); }
@media (min-width: 640px) { .modal-enter-from, .modal-leave-to { transform: translateY(20px) scale(0.96); } }
</style>
