<template>
  <Teleport to="body">
    <Transition name="backdrop">
      <div v-if="ui.adminDrawerOpen" @click="ui.closeAdminDrawer()" class="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"></div>
    </Transition>
    <Transition name="panel">
      <aside v-if="ui.adminDrawerOpen" class="fixed top-0 right-0 bottom-0 z-50 w-[78%] max-w-[320px] bg-[#0a0a0a] border-l border-[#1f1f1f] flex flex-col">
        <header class="px-4 h-[60px] flex items-center justify-between border-b border-[#1f1f1f] shrink-0">
          <span class="text-[15px] font-semibold text-[#fafafa]">پنل مدیریت</span>
          <button v-wave style="color: rgba(255, 255, 255, 0.45)" @click="ui.closeAdminDrawer()" class="btn-press w-9 h-9 flex items-center justify-center rounded-lg hover:bg-[#18181b] text-[#a1a1aa] hover:text-[#fafafa] transition-colors"><Icon icon="lucide:x" class="text-[20px]" /></button>
        </header>
        <nav class="flex-1 p-3 overflow-y-auto">
          <ul class="space-y-1">
            <li v-for="item in items" :key="item.label">
              <NuxtLink v-if="item.to && item.enabled" :to="item.to" v-wave style="color: rgba(255, 255, 255, 0.45)" @click="ui.closeAdminDrawer()" class="btn-press group flex items-center gap-3 px-4 py-3 rounded-xl transition-colors" :class="isActive(item) ? 'bg-[#18181b] text-[#fafafa]' : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-[#fafafa]'">
                <Icon :icon="item.icon" class="text-[20px]" />
                <span class="text-[14px] font-medium">{{ item.label }}</span>
                <span v-if="isActive(item)" class="mr-auto w-1.5 h-1.5 rounded-full bg-[#fafafa]"></span>
              </NuxtLink>
              <button v-else v-wave style="color: rgba(255, 255, 255, 0.45)" type="button" class="btn-press group w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#52525b] cursor-default transition-colors">
                <Icon :icon="item.icon" class="text-[20px]" />
                <span class="text-[14px] font-medium">{{ item.label }}</span>
                <span class="mr-auto text-2xs uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity duration-300">بزودی</span>
              </button>
            </li>
          </ul>
        </nav>
        <footer class="px-4 py-3 border-t border-[#1f1f1f] shrink-0">
          <p class="text-2xs text-[#52525b] text-center tracking-wider">v1.0.0 · Admin Panel</p>
        </footer>
      </aside>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
const ui = useUIStore()
const route = useRoute()
const items = [
  { label: 'داشبورد',  icon: 'lucide:layout-dashboard', to: '/adminChash7nakg/dashboard', enabled: true  },
  { label: 'فیلم ها',  icon: 'lucide:clapperboard',    to: '/adminChash7nakg/movies',    enabled: true  },
  { label: 'سریال ها', icon: 'lucide:monitor-play',    to: null,                          enabled: false },
  { label: 'کاربران',  icon: 'lucide:users',     to: '/adminChash7nakg/users', enabled: true  },
  { label: 'نظرات',    icon: 'lucide:message-circle',   to: null,                          enabled: false },
  { label: 'مدیریت',   icon: 'lucide:shield',           to: null,                          enabled: false },
  { label: 'تنظیمات',  icon: 'lucide:settings',         to: null,                          enabled: false },
]
function isActive(item: any) { return route.path === item.to }
</script>

<style scoped>
.backdrop-enter-active, .backdrop-leave-active { transition: opacity 0.3s ease; }
.backdrop-enter-from, .backdrop-leave-to { opacity: 0; }
.panel-enter-active, .panel-leave-active { transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1); }
.panel-enter-from, .panel-leave-to { transform: translateX(100%); }
</style>
