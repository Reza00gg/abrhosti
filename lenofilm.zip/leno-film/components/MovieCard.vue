<template>
  <div v-wave style="color: rgba(255, 255, 255, 0.4)" class="group relative rounded-xl overflow-hidden bg-ink-900/40 border border-[color:var(--hairline)] hover:border-[color:var(--input-border-focus)] transition-colors duration-300 ease-out cursor-pointer select-none">
    <div class="aspect-[3/4] relative overflow-hidden bg-ink-950">
      <!-- Placeholder: تا زمانی که عکس کامل لود نشده -->
      <div v-if="!loaded && !error" class="absolute inset-0 flex items-center justify-center bg-ink-950">
        <Icon icon="lucide:film" class="text-[40px] text-ink-800" />
      </div>

      <!-- Placeholder خطا: اگه عکس لود نشه -->
      <div v-if="error" class="absolute inset-0 flex items-center justify-center bg-ink-950">
        <Icon icon="lucide:image-off" class="text-[32px] text-ink-700" />
      </div>

      <!-- عکس واقعی - با fade-in وقتی لود شد + زوم نرم روی هاور -->
      <img
        v-if="movie.posterUrl"
        :src="movie.posterUrl"
        :alt="movie.titleEn"
        draggable="false"
        loading="lazy"
        decoding="async"
        @load="onLoad"
        @error="onError"
        @dragstart.prevent
        class="absolute inset-0 w-full h-full object-cover transition-all duration-500 ease-out pointer-events-none select-none"
        :class="loaded ? 'opacity-100 group-hover:scale-105' : 'opacity-0 scale-[1.03]'"
        :style="{ imageRendering: 'high-quality' }"
      />

      <!-- رتبه IMDb - فقط وقتی عکس لود شده -->
      <div v-if="loaded" class="absolute top-1.5 right-1.5 flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur-sm text-[10px] font-medium text-white pointer-events-none">
        <Icon icon="lucide:star" class="text-[11px] text-yellow-400" />
        <span>{{ movie.rating.toFixed(1) }}</span>
      </div>
    </div>
    <div class="p-2 pointer-events-none select-none">
      <h3 class="text-[12px] font-semibold text-ink-50 truncate" dir="ltr">{{ movie.titleEn }}</h3>
      <div class="mt-0.5 flex items-center gap-1.5 text-[10px] text-ink-500">
        <span>{{ movie.year }}</span>
        <span class="w-0.5 h-0.5 rounded-full bg-ink-600"></span>
        <span>{{ movie.duration }} دقیقه</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { Movie } from '~~/server/db/schema'
const props = defineProps<{ movie: Movie }>()

const loaded = ref(false)
const error = ref(false)

function onLoad() { loaded.value = true; error.value = false }
function onError() { error.value = true; loaded.value = false }

watch(() => props.movie.posterUrl, () => {
  loaded.value = false
  error.value = false
})
</script>
