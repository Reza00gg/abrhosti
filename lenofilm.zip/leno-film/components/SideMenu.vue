<template>
  <Teleport to="body">
    <!-- Backdrop (روی هدر و منوی پایین) -->
    <Transition name="backdrop">
      <div
        v-if="ui.sideMenuOpen"
        @click="ui.closeSideMenu()"
        class="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm"
      ></div>
    </Transition>

    <!-- Panel: از سمت راست می‌آد -->
    <Transition name="panel">
      <aside
        v-if="ui.sideMenuOpen"
        class="fixed top-0 right-0 bottom-0 z-50 w-[78%] max-w-[320px] bg-ink-950 border-l border-[color:var(--hairline)] flex flex-col shadow-2xl"
        :style="{
          paddingTop: 'var(--safe-top)',
          paddingBottom: 'var(--safe-bottom)'
        }"
      >
        <!-- Top: لوگو + دکمه بستن -->
        <header class="border-b border-[color:var(--hairline)] px-4 h-[60px] flex items-center justify-between shrink-0">
          <span class="text-[17px] font-semibold tracking-tight text-ink-50">
            لنوفیلم
          </span>
          <button
            v-wave
            style="color: var(--ripple)"
            @click="ui.closeSideMenu()"
            class="btn-press group w-10 h-10 flex items-center justify-center rounded-lg hover:bg-ink-900/60 transition-colors"
            aria-label="بستن منو"
          >
            <span class="text-ink-500 group-hover:text-ink-50 transition-colors">
              <Icon icon="lucide:x" class="text-[22px]" />
            </span>
          </button>
        </header>

        <!-- Menu items -->
        <nav class="flex-1 px-3 py-6 overflow-y-auto">
          <ul class="space-y-1">
            <li v-for="item in items" :key="item.label">
              <!-- آیتم‌های فعال (مثل حساب) → NuxtLink -->
              <NuxtLink
                v-if="item.to"
                :to="item.to"
                v-wave
                style="color: var(--ripple)"
                @click="ui.closeSideMenu()"
                class="btn-press group w-full flex items-center gap-4 px-4 py-3.5 rounded-xl transition-colors"
              >
                <span class="text-ink-500 group-hover:text-ink-50 transition-colors">
                  <Icon :icon="item.icon" class="text-[22px]" />
                </span>
                <span class="text-[15px] font-medium text-ink-200 group-hover:text-ink-50 transition-colors">
                  {{ item.label }}
                </span>
              </NuxtLink>

              <!-- آیتم‌های غیرفعال (فیلم، سریال، دیسکاور) → دکمه بدون عملکرد -->
              <button
                v-else
                v-wave
                style="color: var(--ripple)"
                type="button"
                class="btn-press group w-full flex items-center gap-4 px-4 py-3.5 rounded-xl transition-colors"
              >
                <span class="text-ink-500 group-hover:text-ink-50 transition-colors">
                  <Icon :icon="item.icon" class="text-[22px]" />
                </span>
                <span class="text-[15px] font-medium text-ink-200 group-hover:text-ink-50 transition-colors">
                  {{ item.label }}
                </span>
                <span class="mr-auto text-2xs text-ink-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300 tracking-widest uppercase">
                  بزودی
                </span>
              </button>
            </li>
          </ul>

          <!-- جداکننده -->
          <div class="my-4 h-px bg-[color:var(--hairline)] mx-4"></div>

          <!-- اطلاعات اضافی -->
          <div class="px-4 py-2">
            <p class="text-2xs text-ink-600 tracking-wider uppercase">
              دسترسی سریع
            </p>
            <p class="mt-2 text-sm text-ink-500 leading-6">
              بخش‌های فیلم و سریال به‌زودی فعال خواهند شد.
            </p>
          </div>
        </nav>

        <!-- Footer -->
        <footer class="border-t border-[color:var(--hairline)] px-4 py-4 shrink-0">
          <p class="text-2xs text-ink-600 text-center tracking-wider">
            v1.0.0 · ساخته شده با ❤️
          </p>
        </footer>
      </aside>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
const ui = useUIStore()

const items = [
  { label: 'فیلم ها',   icon: 'lucide:film',       to: null,        disabled: true  },
  { label: 'سریال ها',  icon: 'lucide:tv',         to: null,        disabled: true  },
  { label: 'دیسکاور',   icon: 'lucide:compass',    to: null,        disabled: true  },
  { label: 'حساب',      icon: 'lucide:user-round', to: '/account',  disabled: false },
]

// ESC برای بستن
function onKeyDown(e: KeyboardEvent) {
  if (e.key === 'Escape' && ui.sideMenuOpen) {
    ui.closeSideMenu()
  }
}

onMounted(() => {
  window.addEventListener('keydown', onKeyDown)
})

onUnmounted(() => {
  window.removeEventListener('keydown', onKeyDown)
})

// قفل کردن اسکرول بدن وقتی منو باز است
watch(() => ui.sideMenuOpen, (open) => {
  if (import.meta.client) {
    document.body.style.overflow = open ? 'hidden' : ''
  }
})
</script>

<style scoped>
/* Backdrop fade */
.backdrop-enter-active,
.backdrop-leave-active {
  transition: opacity 0.3s ease;
}
.backdrop-enter-from,
.backdrop-leave-to {
  opacity: 0;
}

/* Panel slide from right (در RTL، سمت راست = ابتدا = محل همبرگر) */
.panel-enter-active,
.panel-leave-active {
  transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}
.panel-enter-from,
.panel-leave-to {
  transform: translateX(100%);
}
</style>
