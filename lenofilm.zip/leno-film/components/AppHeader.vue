<template>
  <header
    class="fixed top-0 inset-x-0 z-40 bg-ink-950/90 backdrop-blur-md hairline-b"
    :style="{
      paddingTop: 'var(--safe-top)',
      height: 'calc(var(--header-h) + var(--safe-top))'
    }"
  >
    <div class="h-full max-w-screen-2xl mx-auto px-3 sm:px-5 flex items-center justify-between">

      <!-- Right: Hamburger -->
      <button
        v-wave
        style="color: var(--ripple)"
        @click="ui.toggleSideMenu()"
        class="btn-press group w-11 h-11 flex items-center justify-center rounded-lg hover:bg-ink-900/60 transition-colors"
        aria-label="منو"
        :aria-expanded="ui.sideMenuOpen"
      >
        <span class="text-ink-500 group-hover:text-ink-50 transition-colors duration-200">
          <Icon icon="lucide:menu" class="text-[24px]" />
        </span>
      </button>

      <!-- Center: Site Name -->
      <NuxtLink
        to="/"
        class="absolute left-1/2 -translate-x-1/2 no-select"
      >
        <span class="text-[17px] font-semibold tracking-tight text-ink-50">
          لنوفیلم
        </span>
      </NuxtLink>

      <!-- Left: Theme toggle (palette) -->
      <button
        v-wave
        style="color: var(--ripple)"
        @click="cycleTheme"
        class="btn-press group w-11 h-11 flex items-center justify-center rounded-lg hover:bg-ink-900/60 transition-colors"
        :aria-label="`تغییر تم - فعلی: ${themeLabel}`"
        :title="`تم فعلی: ${themeLabel}`"
      >
        <span class="text-ink-500 group-hover:text-ink-50 transition-colors duration-200">
          <Icon :icon="themeIcon" class="text-[24px]" />
        </span>
      </button>

    </div>
  </header>
</template>

<script setup lang="ts">
const ui = useUIStore()
const themeStore = useThemeStore()

// آیکون بر اساس تم فعلی
const themeIcon = computed(() => {
  switch (themeStore.current) {
    case 'ink':    return 'lucide:palette'
    case 'light':  return 'lucide:sun'
    case 'blue':   return 'lucide:droplet'
    default:       return 'lucide:palette'
  }
})

// برچسب فارسی تم فعلی
const themeLabel = computed(() => {
  switch (themeStore.current) {
    case 'ink':    return 'مشکی'
    case 'light':  return 'سفید'
    case 'blue':   return 'آبی'
    default:       return 'مشکی'
  }
})

function cycleTheme() {
  themeStore.next()
}
</script>
