<template>
  <!-- Bottom Navigation: موبایل + دسکتاپ -->
  <nav
    class="fixed bottom-0 inset-x-0 z-40 bg-ink-950/95 backdrop-blur-md hairline-t"
    :style="{
      paddingBottom: 'var(--safe-bottom)',
      height: 'calc(var(--nav-h) + var(--safe-bottom))'
    }"
  >
    <div class="h-full max-w-screen-xl mx-auto px-1 sm:px-3">
      <ul class="h-full flex items-stretch">

        <li
          v-for="item in items"
          :key="item.to"
          class="flex-1 h-full"
        >
          <NuxtLink
            :to="item.to"
            v-slot="{ isActive, navigate, href }"
            custom
          >
            <a
              :href="href"
              @click="navigate"
              v-wave
              style="color: var(--ripple)"
              class="btn-press group relative h-full w-full flex flex-col items-center justify-center gap-1 rounded-md text-2xs font-medium transition-colors duration-200"
              :aria-label="item.label"
              :aria-current="isActive ? 'page' : undefined"
            >
              <!-- Icon: رنگ متن داخلی -->
              <Icon
                :icon="item.icon"
                class="text-[22px] transition-colors duration-200"
                :class="isActive ? 'text-ink-50' : 'text-ink-500 group-hover:text-ink-200'"
              />
              <!-- Label: رنگ متن داخلی -->
              <span
                class="leading-none transition-colors duration-200"
                :class="isActive ? 'text-ink-50' : 'text-ink-500 group-hover:text-ink-200'"
              >
                {{ item.label }}
              </span>
            </a>
          </NuxtLink>
        </li>
      </ul>
    </div>
  </nav>
</template>

<script setup lang="ts">
const items = [
  { to: '/',         label: 'خانه',    icon: 'lucide:home' },
  { to: '/search',   label: 'جستجو',   icon: 'lucide:search' },
  { to: '/discover', label: 'دیسکاور', icon: 'lucide:compass' },
  { to: '/account',  label: 'حساب',    icon: 'lucide:user-round' },
]
</script>
