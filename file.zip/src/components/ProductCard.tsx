import Link from 'next/link';
import { ArrowLeft, Check, Cpu, Database, HardDrive, MemoryStick, Network } from 'lucide-react';
import { type Product, formatPrice } from '@/lib/products';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

const icons = [Cpu, MemoryStick, HardDrive, Network];

export function ProductCard({ product, featured = false }: { product: Product; featured?: boolean }) {
  const specs = [
    ['پردازنده', product.cpu],
    ['رم', product.ram],
    ['فضا', product.storage],
    ['ترافیک', product.bandwidth]
  ];

  return (
    <Card className={`relative flex h-full flex-col overflow-hidden ${featured ? 'border-slate-300' : ''}`}>
      <CardHeader className="pb-4">
        <div className="flex flex-wrap gap-2"><Badge variant={product.category === 'vps' ? 'warning' : 'default'} className="w-fit">{product.badge}</Badge>{featured ? <Badge variant="success">پیشنهادی</Badge> : null}</div>
        <h3 className="mt-4 text-xl font-black tracking-tight text-slate-950">{product.title}</h3>
        <p className="min-h-[56px] text-sm leading-7 text-slate-500">{product.subtitle}</p>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col">
        <div className="rounded-2xl bg-slate-50 p-4">
          <div className="text-xs font-bold text-slate-400">شروع قیمت</div>
          <div className="mt-1 flex flex-wrap items-end gap-1">
            <strong className="text-2xl font-black tracking-tight text-slate-950">{formatPrice(product.priceMonthly, product.currency)}</strong>
            {product.category !== 'domain' ? <span className="pb-1 text-xs font-bold text-slate-400">/ ماهانه</span> : null}
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2">
          {specs.map(([label, value], index) => {
            const Icon = icons[index];
            return (
              <div key={label} className="rounded-2xl border border-slate-100 bg-white p-3">
                <div className="mb-2 flex items-center gap-2 text-xs font-black text-slate-400"><Icon size={14} /> {label}</div>
                <div className="text-xs font-extrabold leading-6 text-slate-700">{value}</div>
              </div>
            );
          })}
        </div>

        <ul className="mt-4 grid gap-2 text-sm font-bold text-slate-600">
          {product.features.slice(0, 4).map((feature) => (
            <li key={feature} className="flex items-start gap-2 leading-7"><Check className="mt-1 h-4 w-4 shrink-0 text-emerald-500" />{feature}</li>
          ))}
        </ul>

        <div className="mt-auto flex gap-2 pt-5">
          <Button asChild className="flex-1">
            <Link href={product.category === 'domain' ? '/domains' : `/checkout/${product.id}`}>{product.category === 'domain' ? 'جستجوی دامنه' : 'سفارش'} <ArrowLeft size={16} /></Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href={product.route}>جزئیات</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
