import { KeyRound, ShieldCheck, UserRound } from 'lucide-react';
import { DashboardShell } from '@/components/DashboardShell';
import { requireUser } from '@/lib/auth';
import { Card } from '@/components/ui/card';
import { PasswordChangeForm } from '@/components/PasswordChangeForm';
import { Badge } from '@/components/ui/badge';

export const dynamic = 'force-dynamic';

export default async function ProfilePage() {
  const user = await requireUser();
  return (
    <DashboardShell user={user}>
      <section className="grid gap-5">
        <Card className="p-6"><h1 className="text-3xl font-black text-slate-950">پروفایل و امنیت</h1><p className="mt-2 text-sm leading-8 text-slate-500">اطلاعات حساب و وضعیت امنیتی ورود.</p></Card>
        <div className="grid gap-4 md:grid-cols-2">
          <Card className="p-6"><UserRound className="mb-4 h-8 w-8 text-sky-600" /><Badge variant="secondary">Account</Badge><h3 className="mt-4 text-xl font-black text-slate-950">اطلاعات کاربری</h3><div className="mt-5 grid gap-3 text-sm"><div className="flex justify-between border-b border-slate-100 pb-3"><span className="text-slate-500">نام</span><strong>{user.name}</strong></div><div className="flex justify-between border-b border-slate-100 pb-3"><span className="text-slate-500">ایمیل</span><strong className="dir-ltr">{user.email}</strong></div><div className="flex justify-between"><span className="text-slate-500">نقش</span><strong>{user.role === 'admin' ? 'مدیر' : 'کاربر'}</strong></div></div></Card>
          <Card className="p-6"><ShieldCheck className="mb-4 h-8 w-8 text-emerald-600" /><Badge variant="success">Security</Badge><h3 className="mt-4 text-xl font-black text-slate-950">امنیت احراز هویت</h3><ul className="mt-5 grid gap-3 text-sm leading-8 text-slate-600"><li className="flex gap-2"><KeyRound className="mt-1 h-4 w-4 text-sky-600" />رمز عبور با PBKDF2 و Salt اختصاصی هش می‌شود.</li><li className="flex gap-2"><KeyRound className="mt-1 h-4 w-4 text-sky-600" />Session با HttpOnly Cookie نگهداری می‌شود.</li><li className="flex gap-2"><KeyRound className="mt-1 h-4 w-4 text-sky-600" />رویدادهای مهم در audit_events ثبت می‌شوند.</li></ul></Card>
        <Card className="p-6"><h3 className="mb-4 text-xl font-black text-slate-950">تغییر رمز عبور</h3><PasswordChangeForm /></Card></div>
      </section>
    </DashboardShell>
  );
}
