const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'lnufilm.db');
let db = null;

async function initialize() {
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  // جدول دنبالهٔ مشترک
  db.run(`
    CREATE TABLE IF NOT EXISTS title_ids (
      id INTEGER PRIMARY KEY AUTOINCREMENT
    )
  `);

  // ---------- مهاجرت ایمن جدول فیلم‌ها (بدون autoincrement) ----------
  db.run(`
    CREATE TABLE IF NOT EXISTS movies_new (
      title_id INTEGER PRIMARY KEY,
      title_type_title_farsi TEXT DEFAULT 'فیلم',
      title_farsi TEXT NOT NULL,
      title_english TEXT DEFAULT '',
      has_dubbed INTEGER DEFAULT 0,
      has_subtitle INTEGER DEFAULT 0,
      year INTEGER NOT NULL,
      runtime INTEGER DEFAULT 0,
      imdb_rating REAL NOT NULL,
      picture_url TEXT DEFAULT '/placeholder.jpg'
    )
  `);
  try {
    const oldMoviesAutoinc = db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='movies' AND sql LIKE '%AUTOINCREMENT%'");
    if (oldMoviesAutoinc.length > 0 && oldMoviesAutoinc[0].values.length > 0) {
      db.run("INSERT OR IGNORE INTO movies_new SELECT * FROM movies");
      db.run("DROP TABLE movies");
      db.run("ALTER TABLE movies_new RENAME TO movies");
    } else {
      // اگر جدول movies_new بلااستفاده است حذفش کن
      db.run("DROP TABLE IF EXISTS movies_new");
    }
  } catch(e) {
    // در صورت خطا، جدول جدید را حذف کن
    try { db.run("DROP TABLE IF EXISTS movies_new"); } catch(e2) {}
  }

  // ---------- مهاجرت ایمن جدول سریال‌ها (بدون autoincrement) ----------
  // حذف جدول موقت قبلی (اگر وجود داشته باشد)
  db.run("DROP TABLE IF EXISTS series_new");
  db.run(`
    CREATE TABLE series_new (
      id INTEGER PRIMARY KEY,
      title_farsi TEXT NOT NULL,
      title_english TEXT DEFAULT '',
      year INTEGER NOT NULL,
      imdb_rating REAL NOT NULL,
      picture_url TEXT DEFAULT '/placeholder.jpg',
      seasons TEXT DEFAULT '[]'
    )
  `);
  try {
    const oldSeriesAutoinc = db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='series' AND sql LIKE '%AUTOINCREMENT%'");
    if (oldSeriesAutoinc.length > 0 && oldSeriesAutoinc[0].values.length > 0) {
      db.run("INSERT OR IGNORE INTO series_new SELECT * FROM series");
      db.run("DROP TABLE series");
      db.run("ALTER TABLE series_new RENAME TO series");
    } else {
      // سریال‌ها یا بدون autoincrement است یا جدول وجود ندارد
      // اگر جدول سریال‌ها وجود ندارد، نام series_new را به series تغییر بده
      const seriesExists = db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='series'");
      if (seriesExists.length === 0 || seriesExists[0].values.length === 0) {
        db.run("ALTER TABLE series_new RENAME TO series");
      } else {
        // جدول سریال‌ها از قبل بدون autoincrement وجود دارد، پس series_new را حذف کن
        db.run("DROP TABLE IF EXISTS series_new");
      }
    }
  } catch(e) {
    try { db.run("DROP TABLE IF EXISTS series_new"); } catch(e2) {}
  }

  // ---------- جدول کاربران (بدون تغییر) ----------
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      display_name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      status TEXT DEFAULT 'active',
      last_login TEXT
    )
  `);

  // ---------- جدول تنظیمات ----------
  db.run(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
  `);

  // مقدار پیش‌فرض تنظیمات
  const stmt = db.prepare("INSERT OR IGNORE INTO settings (key, value) VALUES ('site_enabled', 'true')");
  stmt.run();
  stmt.free();

  // مهاجرت ستون‌های کاربران (اگر لازم باشد)
  try { db.run(`ALTER TABLE users ADD COLUMN status TEXT DEFAULT 'active'`); } catch(e) {}
  try { db.run(`ALTER TABLE users ADD COLUMN last_login TEXT`); } catch(e) {}

  // ---------- تنظیم اولیهٔ دنباله ----------
  const maxMovieId = db.exec("SELECT COALESCE(MAX(title_id),0) FROM movies")[0].values[0][0];
  const maxSeriesId = db.exec("SELECT COALESCE(MAX(id),0) FROM series")[0].values[0][0];
  const maxExisting = Math.max(maxMovieId, maxSeriesId);
  const currentSeq = db.exec("SELECT COALESCE(MAX(id),0) FROM title_ids")[0].values[0][0];
  for (let i = currentSeq; i < maxExisting; i++) {
    db.run("INSERT INTO title_ids DEFAULT VALUES");
  }

  saveDb();
  console.log('Database Is Run !');
}

function saveDb() {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// ---------- دنبالهٔ یکتا ----------
function getNextTitleId() {
  db.run("INSERT INTO title_ids DEFAULT VALUES");
  const result = db.exec("SELECT last_insert_rowid() as id");
  return result[0].values[0][0];
}

// ================== فیلم‌ها ==================
function getAllMovies() {
  const stmt = db.prepare('SELECT * FROM movies ORDER BY title_id DESC');
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

function getMovieById(id) {
  const stmt = db.prepare('SELECT * FROM movies WHERE title_id = ?');
  stmt.bind([id]);
  if (stmt.step()) {
    const movie = stmt.getAsObject();
    stmt.free();
    return movie;
  }
  stmt.free();
  return null;
}

function insertMovie({ title_farsi, year, imdb_rating, title_english, runtime, picture_url }) {
  const newId = getNextTitleId();
  const stmt = db.prepare(`
    INSERT INTO movies (title_id, title_farsi, year, imdb_rating, picture_url, title_english, runtime)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run([newId, title_farsi, year, imdb_rating, picture_url, title_english || '', runtime || 0]);
  stmt.free();
  saveDb();
  return getMovieById(newId);
}

function updateMovie(id, { title_farsi, year, imdb_rating, title_english, runtime, picture_url }) {
  const stmt = db.prepare(`
    UPDATE movies
    SET title_farsi = ?, year = ?, imdb_rating = ?, picture_url = ?,
        title_english = ?, runtime = ?
    WHERE title_id = ?
  `);
  stmt.run([title_farsi, year, imdb_rating, picture_url, title_english || '', runtime || 0, id]);
  stmt.free();
  saveDb();
  return getMovieById(id);
}

function deleteMovie(id) {
  const stmt = db.prepare('DELETE FROM movies WHERE title_id = ?');
  stmt.run([id]);
  stmt.free();
  saveDb();
}

// ================== کاربران ==================
function createUser({ display_name, email, password }) {
  const stmt = db.prepare('INSERT INTO users (display_name, email, password) VALUES (?, ?, ?)');
  stmt.run([display_name, email, password]);
  stmt.free();
  saveDb();
  return getUserByEmail(email);
}

function getUserByEmail(email) {
  const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
  stmt.bind([email]);
  if (stmt.step()) {
    const user = stmt.getAsObject();
    stmt.free();
    return user;
  }
  stmt.free();
  return null;
}

function getUserById(id) {
  const stmt = db.prepare('SELECT id, display_name, email, created_at, status, last_login FROM users WHERE id = ?');
  stmt.bind([id]);
  if (stmt.step()) {
    const user = stmt.getAsObject();
    stmt.free();
    return user;
  }
  stmt.free();
  return null;
}

function getAllUsers() {
  const stmt = db.prepare('SELECT id, display_name, email, created_at, status, last_login FROM users ORDER BY id DESC');
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

function updateUserStatus(id, status) {
  const stmt = db.prepare('UPDATE users SET status = ? WHERE id = ?');
  stmt.run([status, id]);
  stmt.free();
  saveDb();
  return getUserById(id);
}

function deleteUser(id) {
  const stmt = db.prepare('DELETE FROM users WHERE id = ?');
  stmt.run([id]);
  stmt.free();
  saveDb();
}

function updateLastLogin(id, datetime) {
  const stmt = db.prepare('UPDATE users SET last_login = ? WHERE id = ?');
  stmt.run([datetime, id]);
  stmt.free();
  saveDb();
}

// ================== تنظیمات ==================
function getSetting(key) {
  const stmt = db.prepare('SELECT value FROM settings WHERE key = ?');
  stmt.bind([key]);
  if (stmt.step()) {
    const row = stmt.getAsObject();
    stmt.free();
    return row.value;
  }
  stmt.free();
  return null;
}

function setSetting(key, value) {
  const stmt = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
  stmt.run([key, value]);
  stmt.free();
  saveDb();
}

// ================== سریال‌ها ==================
function getAllSeries() {
  const stmt = db.prepare('SELECT * FROM series ORDER BY id DESC');
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

function getSeriesById(id) {
  const stmt = db.prepare('SELECT * FROM series WHERE id = ?');
  stmt.bind([id]);
  if (stmt.step()) {
    const series = stmt.getAsObject();
    stmt.free();
    return series;
  }
  stmt.free();
  return null;
}

function insertSeries({ title_farsi, year, imdb_rating, picture_url, seasons }) {
  const newId = getNextTitleId();       // شناسهٔ یکتا
  const stmt = db.prepare(`
    INSERT INTO series (id, title_farsi, year, imdb_rating, picture_url, seasons)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  stmt.run([newId, title_farsi, year, imdb_rating, picture_url, JSON.stringify(seasons || [])]);
  stmt.free();
  saveDb();
  return getSeriesById(newId);
}

function updateSeries(id, { title_farsi, year, imdb_rating, picture_url, seasons }) {
  const stmt = db.prepare(`
    UPDATE series
    SET title_farsi = ?, year = ?, imdb_rating = ?, picture_url = ?, seasons = ?
    WHERE id = ?
  `);
  stmt.run([title_farsi, year, imdb_rating, picture_url, JSON.stringify(seasons || []), id]);
  stmt.free();
  saveDb();
  return getSeriesById(id);
}

function deleteSeries(id) {
  const stmt = db.prepare('DELETE FROM series WHERE id = ?');
  stmt.run([id]);
  stmt.free();
  saveDb();
}

// ---------- راه‌اندازی ----------
const ready = initialize();

module.exports = {
  ready,
  getAllMovies, getMovieById, insertMovie, updateMovie, deleteMovie,
  createUser, getUserByEmail, getUserById, getAllUsers, updateUserStatus, deleteUser, updateLastLogin,
  getAllSeries, getSeriesById, insertSeries, updateSeries, deleteSeries,
  getSetting, setSetting
};