const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./database');

const JWT_SECRET = 'lnufilm-secret-key-change-in-production!!';

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// ========== متن‌ها ==========
let siteText = 'lnufilm';
let headerText = 'لنوفیلم';

app.get('/api/text', (req, res) => {
  res.json({ text: siteText, headerText });
});
app.post('/api/text', (req, res) => {
  const { text, headerText: newHeader } = req.body;
  if (text && text.trim()) siteText = text.trim();
  if (newHeader && newHeader.trim()) headerText = newHeader.trim();
  res.json({ success: true, text: siteText, headerText });
});

// ========== فیلم‌ها ==========
app.get('/api/list/movies', (req, res) => {
  try {
    const movies = db.getAllMovies();
    res.json({ data: movies });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در دریافت لیست فیلم‌ها' });
  }
});

app.get('/api/movies/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const movie = db.getMovieById(id);
    if (!movie) {
      return res.status(404).json({ error: 'فیلم پیدا نشد.' });
    }
    res.json(movie);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در دریافت فیلم' });
  }
});

app.post('/api/movies', upload.single('poster'), (req, res) => {
  try {
    const { title_farsi, year, imdb_rating, title_english, runtime } = req.body;
    if (!title_farsi || !year || !imdb_rating) {
      return res.status(400).json({ error: 'فیلدهای نام، سال و امتیاز الزامی هستند.' });
    }

    const picture_url = req.file ? '/uploads/' + req.file.filename : '/placeholder.jpg';

    const movie = db.insertMovie({
      title_farsi: title_farsi.trim(),
      year: parseInt(year, 10),
      imdb_rating: parseFloat(imdb_rating),
      title_english: title_english?.trim() || '',
      runtime: parseInt(runtime) || 0,
      picture_url
    });

    res.status(201).json({ success: true, movie });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در افزودن فیلم' });
  }
});

app.put('/api/movies/:id', upload.single('poster'), (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existing = db.getMovieById(id);
    if (!existing) {
      return res.status(404).json({ error: 'فیلم پیدا نشد.' });
    }

    const { title_farsi, year, imdb_rating, title_english, runtime } = req.body;
    if (!title_farsi || !year || !imdb_rating) {
      return res.status(400).json({ error: 'فیلدهای نام، سال و امتیاز الزامی هستند.' });
    }

    const picture_url = req.file ? '/uploads/' + req.file.filename : existing.picture_url;

    const updated = db.updateMovie(id, {
      title_farsi: title_farsi.trim(),
      year: parseInt(year, 10),
      imdb_rating: parseFloat(imdb_rating),
      title_english: title_english?.trim() || existing.title_english,
      runtime: parseInt(runtime) || existing.runtime,
      picture_url
    });

    res.json({ success: true, movie: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در ویرایش فیلم' });
  }
});

app.delete('/api/movies/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existing = db.getMovieById(id);
    if (!existing) {
      return res.status(404).json({ error: 'فیلم پیدا نشد.' });
    }
    db.deleteMovie(id);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در حذف فیلم' });
  }
});

app.get('/api/search/movies', (req, res) => {
  try {
    const { q } = req.query;
    if (!q || !q.trim()) {
      return res.json({ data: [] });
    }
    const keyword = q.trim().toLowerCase();
    const movies = db.getAllMovies().filter(m =>
      m.title_farsi.toLowerCase().includes(keyword) ||
      m.title_english.toLowerCase().includes(keyword)
    );
    res.json({ data: movies });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در جستجو' });
  }
});

// ========== سریال‌ها ==========
app.get('/api/list/series', (req, res) => {
  try {
    const series = db.getAllSeries();
    res.json({ data: series.map(s => ({ ...s, title_type_title_farsi: 'سریال' })) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در دریافت لیست سریال‌ها' });
  }
});

app.get('/api/series/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const series = db.getSeriesById(id);
    if (!series) return res.status(404).json({ error: 'سریال پیدا نشد.' });
    res.json({ ...series, title_type_title_farsi: 'سریال' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در دریافت سریال' });
  }
});

app.post('/api/series', upload.single('poster'), (req, res) => {
  try {
    const { title_farsi, year, imdb_rating, seasons } = req.body;
    if (!title_farsi || !year || !imdb_rating) {
      return res.status(400).json({ error: 'فیلدهای نام، سال و امتیاز الزامی هستند.' });
    }
    const picture_url = req.file ? '/uploads/' + req.file.filename : '/placeholder.jpg';
    let seasonsArray = [];
    if (seasons) {
      try { seasonsArray = JSON.parse(seasons); } catch(e) {}
    }
    const series = db.insertSeries({
      title_farsi: title_farsi.trim(),
      year: parseInt(year, 10),
      imdb_rating: parseFloat(imdb_rating),
      picture_url,
      seasons: seasonsArray
    });
    res.status(201).json({ success: true, series });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در افزودن سریال' });
  }
});

app.put('/api/series/:id', upload.single('poster'), (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existing = db.getSeriesById(id);
    if (!existing) return res.status(404).json({ error: 'سریال پیدا نشد.' });

    const { title_farsi, year, imdb_rating, seasons } = req.body;
    if (!title_farsi || !year || !imdb_rating) {
      return res.status(400).json({ error: 'فیلدهای نام، سال و امتیاز الزامی هستند.' });
    }
    const picture_url = req.file ? '/uploads/' + req.file.filename : existing.picture_url;
    let seasonsArray = existing.seasons ? JSON.parse(existing.seasons) : [];
    if (seasons) {
      try { seasonsArray = JSON.parse(seasons); } catch(e) {}
    }

    const updated = db.updateSeries(id, {
      title_farsi: title_farsi.trim(),
      year: parseInt(year, 10),
      imdb_rating: parseFloat(imdb_rating),
      picture_url,
      seasons: seasonsArray
    });
    res.json({ success: true, series: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در ویرایش سریال' });
  }
});

app.delete('/api/series/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!db.getSeriesById(id)) return res.status(404).json({ error: 'سریال پیدا نشد.' });
    db.deleteSeries(id);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در حذف سریال' });
  }
});

// جستجوی یکپارچه (فیلم + سریال)
app.get('/api/search/all', (req, res) => {
  try {
    const { q } = req.query;
    if (!q || !q.trim()) return res.json({ data: [] });
    const keyword = q.trim().toLowerCase();
    const movies = db.getAllMovies().filter(m =>
      m.title_farsi.toLowerCase().includes(keyword) || m.title_english.toLowerCase().includes(keyword)
    ).map(m => ({ ...m, id: m.title_id, title_type_title_farsi: 'فیلم' }));
    const series = db.getAllSeries().filter(s =>
      s.title_farsi.toLowerCase().includes(keyword) || s.title_english.toLowerCase().includes(keyword)
    ).map(s => ({ ...s, id: s.id, title_type_title_farsi: 'سریال' }));
    res.json({ data: [...movies, ...series] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در جستجو' });
  }
});

// ========== احراز هویت ==========
app.post('/api/auth/register', async (req, res) => {
  try {
    const { display_name, email, password } = req.body;
    if (!display_name || !email || !password) {
      return res.status(400).json({ error: 'لطفاً تمام فیلدها را پر کنید.' });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^09\d{9}$/;
    if (!emailRegex.test(email) && !phoneRegex.test(email)) {
      return res.status(400).json({ error: 'ایمیل یا شماره موبایل نامعتبر است.' });
    }

    const existing = db.getUserByEmail(email);
    if (existing) {
      return res.status(409).json({ error: 'این ایمیل/شماره قبلاً ثبت شده است.' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const user = db.createUser({ display_name, email, password: hashedPassword });
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' });

    res.status(201).json({ success: true, token, user: { id: user.id, display_name: user.display_name, email: user.email } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطای سرور' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'لطفاً ایمیل/شماره و رمز عبور را وارد کنید.' });
    }

    const user = db.getUserByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'ایمیل/شماره یا رمز عبور اشتباه است.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'ایمیل/شماره یا رمز عبور اشتباه است.' });
    }

    if (user.status === 'banned') {
      return res.status(403).json({ error: 'حساب شما مسدود شده است.' });
    }

    db.updateLastLogin(user.id, new Date().toISOString());

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' });
    const { password: _, ...userWithoutPassword } = user;
    res.json({ success: true, token, user: userWithoutPassword });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطای سرور' });
  }
});

app.get('/api/auth/me', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: 'توکن وجود ندارد.' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = db.getUserById(decoded.id);
    if (!user) {
      return res.status(401).json({ error: 'کاربر یافت نشد.' });
    }
    if (user.status === 'banned') {
      return res.status(403).json({ error: 'حساب کاربری شما مسدود شده است.' });
    }
    res.json({ success: true, user });
  } catch (err) {
    return res.status(401).json({ error: 'توکن نامعتبر است.' });
  }
});

// ========== مدیریت کاربران ==========
app.get('/api/admin/users', (req, res) => {
  try {
    const users = db.getAllUsers();
    res.json({ data: users });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در دریافت لیست کاربران' });
  }
});

app.put('/api/admin/users/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { status } = req.body;
    if (!status || !['active', 'banned'].includes(status)) {
      return res.status(400).json({ error: 'وضعیت نامعتبر است.' });
    }
    const existing = db.getUserById(id);
    if (!existing) {
      return res.status(404).json({ error: 'کاربر پیدا نشد.' });
    }
    const updated = db.updateUserStatus(id, status);
    res.json({ success: true, user: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در تغییر وضعیت کاربر' });
  }
});

app.delete('/api/admin/users/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existing = db.getUserById(id);
    if (!existing) {
      return res.status(404).json({ error: 'کاربر پیدا نشد.' });
    }
    db.deleteUser(id);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در حذف کاربر' });
  }
});

// ========== تنظیمات سایت ==========
app.get('/api/site/status', (req, res) => {
  try {
    const enabled = db.getSetting('site_enabled') === 'true';
    res.json({ enabled });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در دریافت وضعیت سایت' });
  }
});

app.post('/api/site/status', (req, res) => {
  try {
    const { enabled } = req.body;
    db.setSetting('site_enabled', enabled ? 'true' : 'false');
    res.json({ success: true, enabled });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در ذخیره تنظیمات' });
  }
});

// ========== دریافت عنوان یکپارچه (فیلم یا سریال) ==========
app.get('/api/title/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    // ابتدا فیلم را جستجو کن
    const movie = db.getMovieById(id);
    if (movie) {
      return res.json({ ...movie, title_type: 'movie' });
    }
    // سپس سریال را جستجو کن
    const series = db.getSeriesById(id);
    if (series) {
      // seasons را parse کن تا در خروجی آرایه باشد (اختیاری)
      let seasons = [];
      try { seasons = JSON.parse(series.seasons || '[]'); } catch(e) {}
      return res.json({ ...series, seasons, title_type: 'series' });
    }
    // هیچکدام پیدا نشد
    return res.status(404).json({ error: 'عنوان مورد نظر یافت نشد.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'خطا در دریافت اطلاعات' });
  }
});

// ---------- راه‌اندازی ----------
db.ready.then(() => {
  const PORT = 3000;
  app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
});