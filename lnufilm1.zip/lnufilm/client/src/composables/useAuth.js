import { ref, onMounted, onUnmounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import api from '@/services/api'

const user = ref(null)
const loading = ref(true)
let authCheckInterval = null

export function useAuth() {
  const router = useRouter()
  const isAuthenticated = computed(() => user.value !== null)

  // چک کردن اعتبار و وضعیت کاربر
  const fetchUser = async () => {
    const token = localStorage.getItem('token')
    if (!token) {
      user.value = null
      loading.value = false
      return
    }
    try {
      const res = await api.getMe()
      user.value = res.data.user
    } catch (err) {
      // هر خطایی (401, 403, یا شبکه) باعث خروج شود
      localStorage.removeItem('token')
      user.value = null
      if (router.currentRoute?.value?.name === 'AccountHome') {
        router.replace({ name: 'Home' })
      }
    } finally {
      loading.value = false
    }
  }

  const login = async (email, password) => {
    const res = await api.login({ email, password })
    localStorage.setItem('token', res.data.token)
    user.value = res.data.user
    startAuthCheck()  // شروع چک دورهای
    return res.data
  }

  const register = async (display_name, email, password) => {
    const res = await api.register({ display_name, email, password })
    localStorage.setItem('token', res.data.token)
    user.value = res.data.user
    startAuthCheck()
    return res.data
  }

  const logout = async () => {
    localStorage.removeItem('token')
    user.value = null
    stopAuthCheck()
    await router.push({ name: 'Home' })
  }

  // real‑time check: هر ۱۲ ثانیه وضعیت کاربر را چک کن
  function startAuthCheck() {
    if (authCheckInterval) return
    authCheckInterval = setInterval(async () => {
      if (!localStorage.getItem('token')) {
        stopAuthCheck()
        return
      }
      try {
        const res = await api.getMe()
        if (res.data.user.status === 'banned') {
          // کاربر بن شده است – فوراً خارج کن
          localStorage.removeItem('token')
          user.value = null
          stopAuthCheck()
          if (router.currentRoute?.value?.name === 'AccountHome') {
            router.replace({ name: 'Home' })
          }
        }
      } catch (err) {
        // اگر خطایی دریافت شد (توکن نامعتبر یا کاربر حذف شده)
        localStorage.removeItem('token')
        user.value = null
        stopAuthCheck()
        if (router.currentRoute?.value?.name === 'AccountHome') {
          router.replace({ name: 'Home' })
        }
      }
    }, 12000) // هر ۱۲ ثانیه
  }

  function stopAuthCheck() {
    if (authCheckInterval) {
      clearInterval(authCheckInterval)
      authCheckInterval = null
    }
  }

  // در اولین لود، کاربر را چک کن و در صورت وجود توکن، چک دورهای را شروع کن
  onMounted(() => {
    fetchUser().then(() => {
      if (user.value) startAuthCheck()
    })
  })

  onUnmounted(() => {
    stopAuthCheck()
  })

  return {
    user,
    loading,
    isAuthenticated,
    login,
    register,
    logout,
    fetchUser
  }
}