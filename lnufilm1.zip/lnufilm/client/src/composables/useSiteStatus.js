import { ref } from 'vue'
import api from '@/services/api'

const siteEnabled = ref(true)

export function useSiteStatus() {
  const checkStatus = async () => {
    try {
      const res = await api.getSiteStatus()
      siteEnabled.value = res.data.enabled
    } catch (e) {
      console.error(e)
    }
  }

  return { siteEnabled, checkStatus }
}