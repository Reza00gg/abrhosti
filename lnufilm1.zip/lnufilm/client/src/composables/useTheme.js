import { ref, watch } from 'vue'

const themeClasses = [
  'theme-current',
  'theme-purple',
  'theme-blue'
]

const currentIndex = ref(0)

// مقدار از localStorage
const saved = localStorage.getItem('app-theme-index')
if (saved !== null) {
  const idx = parseInt(saved, 10)
  if (idx >= 0 && idx < themeClasses.length) {
    currentIndex.value = idx
  }
}

// اعمال کلاس بر روی html
const applyThemeToHTML = () => {
  document.documentElement.className = themeClasses[currentIndex.value]
}

// ذخیره‌سازی و اعمال اولیه
watch(currentIndex, (newIdx) => {
  localStorage.setItem('app-theme-index', newIdx)
  applyThemeToHTML()
}, { immediate: true }) // فراخوانی اولیه هم با immediate انجام می‌شود

export function useTheme() {
  const currentThemeClass = () => themeClasses[currentIndex.value]

  const cycleTheme = () => {
    currentIndex.value = (currentIndex.value + 1) % themeClasses.length
  }

  return {
    currentIndex,
    currentThemeClass,
    cycleTheme,
    applyThemeToHTML
  }
}