<template>
  <v-container class="py-6">
    <v-row justify="center">
      <v-col cols="12" md="10" lg="10">
        <v-card color="grey-darken-4" rounded="xl" class="pa-6">
          <v-card-title class="text-h5 font-weight-bold mb-2">
            مدیریت کاربران
          </v-card-title>

          <v-text-field
            v-model="searchQuery"
            label="جستجوی کاربر..."
            variant="outlined"
            color="yellow-accent-3"
            clearable
            density="compact"
            class="mb-4 custom-input"
            hide-details
          ></v-text-field>

          <v-table density="compact" hover class="users-table">
            <thead>
              <tr>
                <th>نام نمایشی</th>
                <th>ایمیل / شماره</th>
                <th>وضعیت</th>
                <th>تاریخ عضویت</th>
                <th>آخرین ورود</th>
                <th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="user in filteredUsers" :key="user.id">
                <td class="font-custom-01">{{ user.display_name }}</td>
                <td>{{ user.email }}</td>
                <td>
                  <v-chip
                    :color="user.status === 'active' ? 'success' : 'error'"
                    size="small"
                    class="font-custom-01"
                  >
                    {{ user.status === 'active' ? 'فعال' : 'بن شده' }}
                  </v-chip>
                </td>
                <td>{{ user.created_at ? new Date(user.created_at).toLocaleDateString('fa-IR') : '-' }}</td>
                <td>{{ user.last_login ? new Date(user.last_login).toLocaleDateString('fa-IR') : '-' }}</td>
                <td>
                  <v-btn
                    v-if="user.status === 'active'"
                    size="small"
                    color="warning"
                    variant="tonal"
                    @click="toggleBan(user)"
                  >
                    بن کردن
                  </v-btn>
                  <v-btn
                    v-else
                    size="small"
                    color="success"
                    variant="tonal"
                    @click="toggleBan(user)"
                  >
                    رفع بن
                  </v-btn>
                  <v-btn
                    size="small"
                    color="error"
                    variant="tonal"
                    class="ml-2"
                    @click="deleteUser(user)"
                  >
                    حذف
                  </v-btn>
                </td>
              </tr>
            </tbody>
          </v-table>
          <p v-if="filteredUsers.length === 0" class="text-center text-grey mt-4">
            هیچ کاربری یافت نشد.
          </p>
        </v-card>
      </v-col>
    </v-row>

    <!-- اسنک‌بار -->
    <v-snackbar
      v-model="snackbar.show"
      :timeout="4000"
      :color="snackbar.color"
      location="bottom left"
      rounded="pill"
    >
      {{ snackbar.text }}
    </v-snackbar>
  </v-container>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import api from '@/services/api'

const users = ref([])
const searchQuery = ref('')
const snackbar = ref({ show: false, text: '', color: 'success' })

const filteredUsers = computed(() => {
  if (!searchQuery.value) return users.value
  const q = searchQuery.value.toLowerCase()
  return users.value.filter(u =>
    u.display_name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q)
  )
})

const fetchUsers = async () => {
  try {
    const res = await api.getUsers()
    users.value = res.data.data || []
  } catch (err) {
    console.error('خطا در دریافت کاربران:', err)
    snackbar.value = { show: true, text: 'خطا در دریافت کاربران', color: 'error' }
  }
}

onMounted(fetchUsers)

const toggleBan = async (user) => {
  const newStatus = user.status === 'active' ? 'banned' : 'active'
  try {
    await api.updateUserStatus(user.id, newStatus)
    user.status = newStatus
    snackbar.value = { show: true, text: `کاربر ${newStatus === 'banned' ? 'بن' : 'آنبن'} شد.`, color: 'success' }
  } catch (err) {
    console.error(err)
    snackbar.value = { show: true, text: 'خطا در تغییر وضعیت', color: 'error' }
  }
}

const deleteUser = async (user) => {
  if (!confirm(`آیا از حذف کاربر ${user.display_name} اطمینان دارید؟`)) return
  try {
    await api.deleteUser(user.id)
    users.value = users.value.filter(u => u.id !== user.id)
    snackbar.value = { show: true, text: 'کاربر با موفقیت حذف شد.', color: 'success' }
  } catch (err) {
    console.error(err)
    snackbar.value = { show: true, text: 'خطا در حذف کاربر', color: 'error' }
  }
}
</script>

<style scoped>
.users-table :deep(th) { color: var(--color-text-secondary, #b1b1b1); font-weight: 600; }
.users-table :deep(td) { color: var(--color-text-primary, #fff); }
.custom-input :deep(.v-field__input) { color: #ffffff !important; }
</style>