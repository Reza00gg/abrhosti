<template>
  <v-container class="py-6">
    <v-row justify="center">
      <v-col cols="12" md="8" lg="6">
        <v-card color="grey-darken-4" rounded="xl" class="pa-6">
          <v-card-title class="text-h5 font-weight-bold mb-4">تنظیمات</v-card-title>
          <v-card-text>
            <div class="d-flex align-center justify-space-between">
              <span class="font-custom-01 text-h6">فعال/غیرفعال کردن سایت</span>
              <v-switch
                v-model="siteEnabled"
                color="yellow-accent-3"
                hide-details
                inset
              ></v-switch>
            </div>
          </v-card-text>
          <v-card-actions class="justify-end">
            <v-btn
              color="yellow-accent-3"
              variant="elevated"
              @click="saveSettings"
              :loading="saving"
            >
              ذخیره تنظیمات
            </v-btn>
          </v-card-actions>
          <transition name="notification-slide-fade">
            <v-alert
              v-if="message"
              :type="messageType"
              density="compact"
              class="mt-3 notification-alert font-custom-01"
              closable
              @click:close="message = ''"
            >
              {{ message }}
            </v-alert>
          </transition>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import api from '@/services/api'

const siteEnabled = ref(true)
const saving = ref(false)
const message = ref('')
const messageType = ref('success')

onMounted(async () => {
  try {
    const res = await api.getSiteStatus()
    siteEnabled.value = res.data.enabled
  } catch (err) {
    console.error(err)
  }
})

const saveSettings = async () => {
  saving.value = true
  message.value = ''
  try {
    await api.setSiteStatus(siteEnabled.value)
    message.value = 'تنظیمات ذخیره شد'
    messageType.value = 'success'
  } catch {
    message.value = 'خطا در ذخیره تنظیمات.'
    messageType.value = 'error'
  } finally {
    saving.value = false
  }
}

let timer = null
watch(message, (newVal) => {
  clearTimeout(timer)
  if (newVal) timer = setTimeout(() => { message.value = '' }, 4000)
})
</script>

<style scoped>
.notification-slide-fade-enter-active { transition: all 0.25s ease-out; }
.notification-slide-fade-leave-active { transition: all 0.2s ease-in; }
.notification-slide-fade-enter-from { opacity: 0; transform: translateY(-10px); }
.notification-slide-fade-leave-to { opacity: 0; transform: translateY(-5px); }
.notification-alert { border-radius: 8px; text-align: right; direction: rtl; }
</style>