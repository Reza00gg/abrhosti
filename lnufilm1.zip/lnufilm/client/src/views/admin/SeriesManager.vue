<template>
  <v-container class="py-6">
    <v-row justify="center">
      <v-col cols="12" md="10" lg="10">
        <v-card color="grey-darken-4" rounded="xl" class="pa-6">
          <v-card-title class="d-flex align-center justify-space-between mb-2">
            <span class="text-h5 font-weight-bold">مدیریت سریال‌ها</span>
            <v-btn color="yellow-accent-3" variant="elevated" prepend-icon="mdi-plus" @click="openAddForm">
              افزودن سریال جدید
            </v-btn>
          </v-card-title>

          <v-text-field
            v-model="searchQuery" label="جستجوی سریال..." variant="outlined"
            color="yellow-accent-3" clearable density="compact" class="mb-4 custom-input" hide-details
          ></v-text-field>

          <v-table density="compact" hover class="users-table">
            <thead>
              <tr>
                <th>پوستر</th>
                <th>نام</th>
                <th>سال</th>
                <th>امتیاز</th>
                <th>فصل‌ها</th>
                <th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="series in filteredSeries" :key="series.id">
                <td><img :src="getPosterUrl(series.picture_url)" class="list-poster" /></td>
                <td class="font-custom-01">{{ series.title_farsi }}</td>
                <td>{{ series.year }}</td>
                <td>{{ series.imdb_rating }}</td>
                <td>{{ series.seasons ? JSON.parse(series.seasons).length : 0 }}</td>
                <td>
                  <v-btn icon size="small" variant="text" color="yellow-accent-3" @click="openEditForm(series)">
                    <v-icon>mdi-pencil</v-icon>
                  </v-btn>
                  <v-btn icon size="small" variant="text" color="error" @click="deleteSeries(series.id)">
                    <v-icon>mdi-delete</v-icon>
                  </v-btn>
                </td>
              </tr>
            </tbody>
          </v-table>
        </v-card>
      </v-col>
    </v-row>

    <!-- دیالوگ افزودن/ویرایش -->
    <v-dialog v-model="dialog" max-width="650px">
      <v-card color="grey-darken-3" rounded="xl" class="pa-4">
        <v-card-title class="text-h5 mb-2">{{ isEditing ? 'ویرایش سریال' : 'افزودن سریال جدید' }}</v-card-title>
        <v-card-text>
          <v-row>
            <v-col cols="12"><v-file-input v-model="poster" label="پوستر" accept="image/*" variant="outlined" color="yellow-accent-3" class="custom-input" clearable></v-file-input></v-col>
            <v-col cols="12" sm="6"><v-text-field v-model="title" label="نام سریال" variant="outlined" color="yellow-accent-3" class="custom-input"></v-text-field></v-col>
            <v-col cols="12" sm="6"><v-text-field v-model="year" label="سال انتشار" type="number" variant="outlined" color="yellow-accent-3" class="custom-input"></v-text-field></v-col>
            <v-col cols="12" sm="6"><v-text-field v-model="rating" label="امتیاز IMDB" type="number" step="0.1" min="0" max="10" variant="outlined" color="yellow-accent-3" class="custom-input"></v-text-field></v-col>
          </v-row>

          <!-- بخش فصل‌ها -->
          <div class="mt-4">
            <h3 class="mb-2 font-custom-01">فصل‌ها</h3>
            <div v-for="(season, index) in seasons" :key="index" class="d-flex align-center mb-2 gap-2">
              <v-text-field
                v-model.number="season.number"
                label="شماره فصل"
                type="number"
                density="compact"
                variant="outlined"
                color="yellow-accent-3"
                class="custom-input"
                style="max-width: 100px"
              ></v-text-field>
              <v-text-field
                v-model.number="season.episodes"
                label="تعداد قسمت"
                type="number"
                density="compact"
                variant="outlined"
                color="yellow-accent-3"
                class="custom-input"
                style="max-width: 100px"
              ></v-text-field>
              <v-btn icon size="small" color="error" variant="text" @click="removeSeason(index)">
                <v-icon>mdi-delete</v-icon>
              </v-btn>
            </div>
            <v-btn size="small" variant="tonal" prepend-icon="mdi-plus" @click="addSeason">افزودن فصل</v-btn>
          </div>
        </v-card-text>
        <v-card-actions class="d-flex justify-end">
          <v-btn variant="text" @click="dialog = false">انصراف</v-btn>
          <v-btn color="yellow-accent-3" variant="elevated" @click="submitForm" :loading="submitting">
            {{ isEditing ? 'ذخیره تغییرات' : 'افزودن' }}
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar.show" :timeout="4000" :color="snackbar.color" location="bottom left" rounded="pill">
      {{ snackbar.text }}
    </v-snackbar>
  </v-container>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import api from '@/services/api'

const seriesList = ref([])
const searchQuery = ref('')
const dialog = ref(false)
const isEditing = ref(false)
const editingId = ref(null)
const submitting = ref(false)
const snackbar = ref({ show: false, text: '', color: 'success' })

const poster = ref(null)
const title = ref('')
const year = ref('')
const rating = ref('')
const seasons = ref([])

const filteredSeries = computed(() => {
  if (!searchQuery.value) return seriesList.value
  const q = searchQuery.value.toLowerCase()
  return seriesList.value.filter(s => s.title_farsi.toLowerCase().includes(q))
})

const fetchSeries = async () => {
  try {
    const res = await api.getSeries()
    seriesList.value = res.data.data || []
  } catch (err) {
    snackbar.value = { show: true, text: 'خطا در دریافت سریال‌ها', color: 'error' }
  }
}

onMounted(fetchSeries)

const getPosterUrl = (path) => {
  if (!path) return '/placeholder.jpg'
  return path.startsWith('http') ? path : `http://localhost:3000${path}`
}

const resetForm = () => {
  poster.value = null
  title.value = ''
  year.value = ''
  rating.value = ''
  seasons.value = []
}

const addSeason = () => {
  seasons.value.push({ number: seasons.value.length + 1, episodes: 0 })
}

const removeSeason = (index) => {
  seasons.value.splice(index, 1)
}

const openAddForm = () => {
  isEditing.value = false
  editingId.value = null
  resetForm()
  dialog.value = true
}

const openEditForm = (series) => {
  isEditing.value = true
  editingId.value = series.id
  title.value = series.title_farsi
  year.value = series.year.toString()
  rating.value = series.imdb_rating.toString()
  try {
    seasons.value = JSON.parse(series.seasons || '[]')
  } catch { seasons.value = [] }
  poster.value = null
  dialog.value = true
}

const submitForm = async () => {
  if (!title.value || !year.value || !rating.value) {
    snackbar.value = { show: true, text: 'لطفاً فیلدهای اصلی را پر کنید.', color: 'warning' }
    return
  }
  const formData = new FormData()
  if (poster.value) formData.append('poster', poster.value)
  formData.append('title_farsi', title.value.trim())
  formData.append('year', year.value)
  formData.append('imdb_rating', rating.value)
  formData.append('seasons', JSON.stringify(seasons.value))
  submitting.value = true
  try {
    if (isEditing.value) {
      await api.updateSeries(editingId.value, formData)
      snackbar.value = { show: true, text: 'سریال ویرایش شد.', color: 'success' }
    } else {
      await api.addSeries(formData)
      snackbar.value = { show: true, text: 'سریال اضافه شد.', color: 'success' }
    }
    dialog.value = false
    resetForm()
    await fetchSeries()
  } catch (err) {
    snackbar.value = { show: true, text: 'خطا در ذخیره‌سازی', color: 'error' }
  } finally {
    submitting.value = false
  }
}

const deleteSeries = async (id) => {
  if (!confirm('آیا از حذف سریال مطمئن هستید؟')) return
  try {
    await api.deleteSeries(id)
    seriesList.value = seriesList.value.filter(s => s.id !== id)
    snackbar.value = { show: true, text: 'سریال حذف شد.', color: 'success' }
  } catch (err) {
    snackbar.value = { show: true, text: 'خطا در حذف', color: 'error' }
  }
}
</script>

<style scoped>
/* استایل مانند MoviesManager */
</style>