<template>
  <v-container class="py-10 text-center">
    <h2 class="font-custom-01 text-yellow-accent-3">در حال توسعه</h2>
  </v-container>
</template>