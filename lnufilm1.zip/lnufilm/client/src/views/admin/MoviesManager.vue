<template>
  <v-container class="py-6">
    <v-row justify="center">
      <v-col cols="12" md="10" lg="8">
        <v-card color="grey-darken-4" rounded="xl" class="pa-6">
          <v-card-title class="d-flex align-center justify-space-between mb-2">
            <span class="text-h5 font-weight-bold">مدیریت فیلم‌ها</span>
            <v-btn
              color="yellow-accent-3"
              variant="elevated"
              prepend-icon="mdi-plus"
              @click="openAddForm"
            >
              افزودن فیلم جدید
            </v-btn>
          </v-card-title>

          <!-- جستجو -->
          <v-text-field
            v-model="searchQuery"
            label="جستجوی فیلم..."
            variant="outlined"
            color="yellow-accent-3"
            clearable
            density="compact"
            class="mb-4 custom-input"
            hide-details
          ></v-text-field>

          <!-- جدول فیلم‌ها -->
          <v-table density="compact" hover class="movies-table">
            <thead>
              <tr>
                <th>پوستر</th>
                <th>نام</th>
                <th>سال</th>
                <th>امتیاز</th>
                <th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="movie in filteredMovies" :key="movie.title_id">
                <td>
                  <img
                    :src="getPosterUrl(movie.picture_url)"
                    class="list-poster"
                  />
                </td>
                <td class="font-custom-01">{{ movie.title_farsi }}</td>
                <td>{{ movie.year }}</td>
                <td>{{ movie.imdb_rating }}</td>
                <td>
                  <div class="d-flex">
                    <v-btn
                      icon
                      size="small"
                      variant="text"
                      color="yellow-accent-3"
                      @click="openEditForm(movie)"
                    >
                      <v-icon>mdi-pencil</v-icon>
                    </v-btn>
                    <v-btn
                      icon
                      size="small"
                      variant="text"
                      color="error"
                      @click="deleteMovie(movie.title_id)"
                    >
                      <v-icon>mdi-delete</v-icon>
                    </v-btn>
                  </div>
                </td>
              </tr>
            </tbody>
          </v-table>
          <p v-if="filteredMovies.length === 0 && !searchQuery" class="text-center text-grey mt-4">
            هیچ فیلمی ثبت نشده است.
          </p>
          <p v-else-if="filteredMovies.length === 0" class="text-center text-grey mt-4">
            فیلمی با این نام پیدا نشد.
          </p>
        </v-card>
      </v-col>
    </v-row>

    <!-- دیالوگ افزودن/ویرایش -->
    <v-dialog v-model="dialog" max-width="600px">
      <v-card color="grey-darken-3" rounded="xl" class="pa-4">
        <v-card-title class="text-h5 mb-2">
          {{ isEditing ? 'ویرایش فیلم' : 'افزودن فیلم جدید' }}
        </v-card-title>
        <v-card-text>
          <v-row>
            <v-col cols="12">
              <v-file-input
                v-model="poster"
                label="تصویر پوستر"
                accept="image/*"
                variant="outlined"
                color="yellow-accent-3"
                clearable
                class="custom-input"
              ></v-file-input>
              <small v-if="isEditing" class="text-grey">در صورت عدم انتخاب، تصویر قبلی حفظ می‌شود.</small>
            </v-col>
            <v-col cols="12" sm="6">
              <v-text-field
                v-model="title"
                label="نام فیلم"
                variant="outlined"
                color="yellow-accent-3"
                clearable
                class="custom-input"
              ></v-text-field>
            </v-col>
            <v-col cols="12" sm="6">
              <v-text-field
                v-model="year"
                label="سال انتشار"
                variant="outlined"
                color="yellow-accent-3"
                type="number"
                clearable
                class="custom-input"
              ></v-text-field>
            </v-col>
            <v-col cols="12" sm="6">
              <v-text-field
                v-model="rating"
                label="امتیاز IMDB"
                variant="outlined"
                color="yellow-accent-3"
                type="number"
                step="0.1"
                min="0"
                max="10"
                clearable
                class="custom-input"
              ></v-text-field>
            </v-col>
          </v-row>
        </v-card-text>
        <v-card-actions class="d-flex justify-end gap-2">
          <v-btn
            variant="text"
            @click="dialog = false"
          >
            انصراف
          </v-btn>
          <v-btn
            color="yellow-accent-3"
            variant="elevated"
            @click="submitForm"
            :loading="submitting"
          >
            <v-icon start>mdi-check-bold</v-icon>
            {{ isEditing ? 'ذخیره تغییرات' : 'افزودن' }}
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- اسنک‌بار (نوتیفیکیشن) -->
    <v-snackbar
      v-model="snackbar.visible"
      :timeout="4000"
      :color="snackbar.color"
      location="bottom left"
      rounded="pill"
    >
      {{ snackbar.text }}
      <template #actions>
        <v-btn variant="text" @click="snackbar.visible = false" icon="mdi-close"></v-btn>
      </template>
    </v-snackbar>
  </v-container>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import api from '@/services/api'

// داده‌ها
const movies = ref([])
const dialog = ref(false)
const isEditing = ref(false)
const editingId = ref(null)
const submitting = ref(false)
const searchQuery = ref('')

// فیلدهای فرم
const poster = ref(null)
const title = ref('')
const year = ref('')
const rating = ref('')

// اسنک‌بار
const snackbar = ref({
  visible: false,
  text: '',
  color: 'success'
})

const showSnackbar = (text, color = 'success') => {
  snackbar.value.visible = false
  snackbar.value.text = text
  snackbar.value.color = color
  snackbar.value.visible = true
}

// دریافت فیلم‌ها
const fetchMovies = async () => {
  try {
    const res = await api.getMovies()
    movies.value = res.data.data || []
  } catch (err) {
    console.error(err)
    showSnackbar('خطا در دریافت فیلم‌ها', 'error')
  }
}

// فیلتر فیلم‌ها بر اساس جستجو
const filteredMovies = computed(() => {
  if (!searchQuery.value) return movies.value
  const q = searchQuery.value.toLowerCase()
  return movies.value.filter(m => m.title_farsi.toLowerCase().includes(q))
})

onMounted(fetchMovies)

const getPosterUrl = (path) => {
  if (!path) return '/placeholder.jpg'
  return path.startsWith('http') ? path : `http://localhost:3000${path}`
}

// بازنشانی فرم
const resetForm = () => {
  poster.value = null
  title.value = ''
  year.value = ''
  rating.value = ''
}

// باز کردن افزودن
const openAddForm = () => {
  isEditing.value = false
  editingId.value = null
  resetForm()
  dialog.value = true
}

// باز کردن ویرایش
const openEditForm = (movie) => {
  isEditing.value = true
  editingId.value = movie.title_id
  title.value = movie.title_farsi
  year.value = movie.year.toString()
  rating.value = movie.imdb_rating.toString()
  poster.value = null
  dialog.value = true
}

// ارسال فرم
const submitForm = async () => {
  if (!title.value || !year.value || !rating.value) {
    showSnackbar('لطفاً تمام فیلدها را پر کنید.', 'warning')
    return
  }

  const formData = new FormData()
  if (poster.value) {
    formData.append('poster', poster.value)
  }
  formData.append('title_farsi', title.value.trim())
  formData.append('year', year.value)
  formData.append('imdb_rating', rating.value)

  submitting.value = true
  try {
    if (isEditing.value) {
      await api.updateMovie(editingId.value, formData)
      showSnackbar('فیلم با موفقیت ویرایش شد.', 'success')
    } else {
      await api.addMovie(formData)
      showSnackbar('فیلم با موفقیت اضافه شد.', 'success')
    }
    dialog.value = false
    resetForm()
    await fetchMovies()
  } catch (error) {
    console.error(error)
    showSnackbar('خطا در ذخیره‌سازی فیلم.', 'error')
  } finally {
    submitting.value = false
  }
}

// حذف فیلم
const deleteMovie = async (id) => {
  if (!confirm('آیا از حذف این فیلم مطمئن هستید؟')) return
  try {
    await api.deleteMovie(id)
    showSnackbar('فیلم با موفقیت حذف شد.', 'success')
    await fetchMovies()
  } catch (error) {
    console.error(error)
    showSnackbar('خطا در حذف فیلم.', 'error')
  }
}
</script>

<style scoped>
.list-poster {
  width: 36px;
  height: 48px;
  object-fit: cover;
  border-radius: 4px;
}

.movies-table {
  background-color: transparent;
}

.movies-table :deep(th) {
  font-weight: 600;
  color: var(--color-text-secondary, #b1b1b1) !important;
}

.movies-table :deep(td) {
  color: var(--color-text-primary, #fff);
}

/* افزایش وضوح متن داخل اینپوت‌ها */
:deep(.custom-input .v-field__input),
:deep(.custom-input input),
:deep(.custom-input textarea) {
  color: #ffffff !important;
  caret-color: #eab308 !important;
  font-size: 0.95rem !important;
  font-weight: 500 !important;
}

:deep(.custom-input .v-label) {
  color: rgba(255, 255, 255, 0.7) !important;
}
</style>