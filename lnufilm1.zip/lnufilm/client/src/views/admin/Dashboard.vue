<template>
  <v-container class="py-10">
    <v-row justify="center">
      <v-col cols="12" md="8" lg="6">
        <v-card color="grey-darken-4" rounded="xl" class="pa-6">
          <v-card-title class="text-h5 font-weight-bold mb-4">
            پنل مدیریت سایت
          </v-card-title>
          <v-card-subtitle class="mb-4">
            متن صفحه اصلی و هدر را ویرایش کنید
          </v-card-subtitle>
          <v-card-text>
            <!-- فیلد متن اصلی -->
            <v-text-field
              v-model="mainText"
              label="متن اصلی صفحه"
              variant="outlined"
              color="yellow-accent-3"
              clearable
            ></v-text-field>

            <!-- فیلد متن هدر -->
            <v-text-field
              v-model="headerText"
              label="متن اسم هدر سایت را وارد کنید"
              variant="outlined"
              color="yellow-accent-3"
              clearable
            ></v-text-field>

            <v-btn
              block
              color="yellow-accent-3"
              variant="elevated"
              size="large"
              @click="updateTexts"
              :loading="loading"
            >
              <v-icon start icon="mdi-check-bold"></v-icon>
              ذخیره تغییرات
            </v-btn>

            <!-- Notification wrapper with transition -->
            <transition name="notification-slide-fade">
              <v-alert
                v-if="message"
                :type="alertType"
                density="compact"
                class="mt-4 notification-alert"
                closable
                @click:close="message = ''"
              >
                {{ message }}
              </v-alert>
            </transition>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import api from '@/services/api'

const mainText = ref('')
const headerText = ref('')
const loading = ref(false)
const message = ref('')
const alertType = ref('success')

// دریافت مقادیر قبلی از سرور
onMounted(async () => {
  try {
    const res = await api.getText()
    mainText.value = res.data.text || ''
    headerText.value = res.data.headerText || ''
  } catch {
    mainText.value = ''
    headerText.value = ''
  }
})

// ارسال هر دو متن با هم
const updateTexts = async () => {
  if (!mainText.value.trim() && !headerText.value.trim()) {
    message.value = 'حداقل یکی از فیلدها باید پر شود'
    alertType.value = 'warning'
    return
  }
  loading.value = true
  message.value = ''
  try {
    await api.updateText({
      text: mainText.value.trim(),
      headerText: headerText.value.trim()
    })
    message.value = 'تغییرات با موفقیت ذخیره شد'
    alertType.value = 'success'
  } catch (error) {
    console.error(error)
    message.value = 'خطا در ذخیره‌سازی'
    alertType.value = 'error'
  } finally {
    loading.value = false
  }
}

// پاک‌سازی خودکار پیام
let timer = null
watch(message, (newMsg) => {
  clearTimeout(timer)
  if (newMsg) {
    timer = setTimeout(() => {
      message.value = ''
    }, 4000)
  }
})
</script>

<style scoped>
/* انیمیشن (همان Dashboard) */
.notification-slide-fade-enter-active {
  transition: all 0.25s ease-out;
}
.notification-slide-fade-leave-active {
  transition: all 0.2s ease-in;
}

.notification-slide-fade-enter-from {
  opacity: 0;
  transform: translateY(-10px);
}
.notification-slide-fade-leave-to {
  opacity: 0;
  transform: translateY(-5px);
}

.notification-alert {
  border-radius: 8px;
}
</style>