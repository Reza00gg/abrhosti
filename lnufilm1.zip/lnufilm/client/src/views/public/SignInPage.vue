<template>
  <v-container fluid class="signin-page fill-height d-flex align-center justify-center">
    <v-card color="grey-darken-4" rounded="xl" class="pa-6" max-width="450" width="100%">
      <!-- فرم ورود -->
      <transition name="fade" mode="out-in">
        <div v-if="!showRegister" key="login">
          <h2 class="text-h5 font-weight-bold mb-4 font-custom-01 text-center">ورود به حساب</h2>
          <v-text-field
            v-model="loginEmail"
            label="شماره موبایل یا ایمیل"
            variant="outlined"
            color="yellow-accent-3"
            class="custom-input"
            clearable
          ></v-text-field>
          <v-text-field
            v-model="loginPassword"
            label="رمز عبور"
            variant="outlined"
            type="password"
            color="yellow-accent-3"
            class="custom-input"
            clearable
          ></v-text-field>
          <v-btn
            block
            color="yellow-accent-3"
            variant="elevated"
            size="large"
            @click="handleLogin"
            :loading="submitting"
          >
            ورود به حساب
          </v-btn>
          <p class="mt-4 text-center">
            <span class="toggle-link font-custom-01" @click="showRegister = true">
              حساب کاربری ندارید؟ ایجاد حساب کاربری
            </span>
          </p>
        </div>

        <!-- فرم ثبت‌نام -->
        <div v-else key="register">
          <h2 class="text-h5 font-weight-bold mb-4 font-custom-01 text-center">ایجاد حساب کاربری</h2>
          <v-text-field
            v-model="regName"
            label="نام نمایشی"
            variant="outlined"
            color="yellow-accent-3"
            class="custom-input"
            clearable
          ></v-text-field>
          <v-text-field
            v-model="regEmail"
            label="شماره موبایل یا ایمیل"
            variant="outlined"
            color="yellow-accent-3"
            class="custom-input"
            clearable
          ></v-text-field>
          <v-text-field
            v-model="regPassword"
            label="رمز عبور"
            variant="outlined"
            type="password"
            color="yellow-accent-3"
            class="custom-input"
            clearable
          ></v-text-field>
          <v-text-field
            v-model="regConfirm"
            label="تایید رمز عبور"
            variant="outlined"
            type="password"
            color="yellow-accent-3"
            class="custom-input"
            clearable
          ></v-text-field>
          <v-btn
            block
            color="yellow-accent-3"
            variant="elevated"
            size="large"
            @click="handleRegister"
            :loading="submitting"
          >
            ساخت حساب
          </v-btn>
          <p class="mt-4 text-center">
            <span class="toggle-link font-custom-01" @click="showRegister = false">
              حسابی دارید؟ وارد شوید
            </span>
          </p>
        </div>
      </transition>

      <!-- پیام خطا (نوتیفیکیشن) -->
      <div class="auth-notification-wrapper">
        <transition name="notification-slide-fade">
          <v-alert
            v-if="errorMsg"
            type="error"
            density="compact"
            closable
            class="notification-alert font-custom-01"
            @click:close="errorMsg = ''"
          >
            {{ errorMsg }}
          </v-alert>
        </transition>
      </div>
    </v-card>
  </v-container>
</template>

<script setup>
import { ref, watch } from 'vue'
import { useAuth } from '@/composables/useAuth'
import { useRouter } from 'vue-router'

const router = useRouter()
const { login, register } = useAuth()

const showRegister = ref(false)
const submitting = ref(false)
const errorMsg = ref('')

// فیلدها
const loginEmail = ref('')
const loginPassword = ref('')
const regName = ref('')
const regEmail = ref('')
const regPassword = ref('')
const regConfirm = ref('')

// ورود
const handleLogin = async () => {
  if (!loginEmail.value || !loginPassword.value) {
    errorMsg.value = 'لطفاً فیلد رو پر کنید'
    return
  }
  submitting.value = true
  errorMsg.value = ''
  try {
    await login(loginEmail.value.trim(), loginPassword.value)
    router.push({ name: 'AccountHome' })
  } catch (err) {
    errorMsg.value = err.response?.data?.error || 'خطا در ورود'
  } finally {
    submitting.value = false
  }
}

// ثبت‌نام
const handleRegister = async () => {
  if (!regName.value || !regEmail.value || !regPassword.value || !regConfirm.value) {
    errorMsg.value = 'لطفاً تمام فیلدها را پر کنید.'
    return
  }
  if (regPassword.value !== regConfirm.value) {
    errorMsg.value = 'رمز عبور و تکرار آن مطابقت ندارند.'
    return
  }
  // اعتبار ایمیل/موبایل
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  const phoneRegex = /^09\d{9}$/
  if (!emailRegex.test(regEmail.value) && !phoneRegex.test(regEmail.value)) {
    errorMsg.value = 'ایمیل یا شماره موبایل نامعتبر است.'
    return
  }

  submitting.value = true
  errorMsg.value = ''
  try {
    await register(regName.value.trim(), regEmail.value.trim(), regPassword.value)
    router.push({ name: 'AccountHome' })
  } catch (err) {
    errorMsg.value = err.response?.data?.error || 'خطا در ثبت‌نام'
  } finally {
    submitting.value = false
  }
}

// پاک‌سازی خطا هنگام تعویض فرم
watch(showRegister, () => {
  errorMsg.value = ''
})
</script>

<style scoped>
.signin-page {
  padding: 16px;
}

.custom-input {
  margin-bottom: 8px;
}

.toggle-link {
  color: #eab308;
  cursor: pointer;
  font-size: 0.9rem;
  text-decoration: underline;
}

/* ===== نوتیفیکیشن خطا ===== */
.auth-notification-wrapper {
  position: fixed;
  bottom: 84px;       /* بالاتر از منوی پایین */
  left: 50%;
  transform: translateX(-50%);
  z-index: 9999;
  min-width: 250px;
}

.notification-alert {
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.5);
  font-family: 'CustomFont01', sans-serif !important;
}

.notification-slide-fade-enter-active { transition: all 0.25s ease-out; }
.notification-slide-fade-leave-active { transition: all 0.2s ease-in; }
.notification-slide-fade-enter-from { opacity: 0; transform: translateY(-10px); }
.notification-slide-fade-leave-to { opacity: 0; transform: translateY(-5px); }

/* fade for form transition */
.fade-enter-active, .fade-leave-active { transition: opacity 0.25s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>

<style>
/* global style for input text color */
.custom-input .v-field__input,
.custom-input input,
.custom-input textarea {
  color: #ffffff !important;
  font-family: 'CustomFont01', sans-serif;
}
</style>