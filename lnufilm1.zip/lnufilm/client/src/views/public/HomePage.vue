<template>
  <v-container fluid class="home-container">
    <h1 class="section-title font-custom-01">فیلم و سریال</h1>

    <!-- حالت بارگذاری -->
    <div v-if="loading" class="movie-grid">
      <SkeletonCard v-for="n in 8" :key="n" />
    </div>

    <!-- فیلم‌ها -->
    <div v-else-if="movies.length">
      <h2 class="sub-title font-custom-01">فیلم‌ها</h2>
      <div class="movie-grid">
        <MovieCard
          v-for="movie in movies"
          :key="movie.title_id"
          :movie-id="movie.title_id"
          :title="movie.title_farsi"
          :year="movie.year"
          :rating="movie.imdb_rating"
          :poster="movie.picture_url"
        />
      </div>
    </div>

    <!-- سریال‌ها -->
    <div v-if="!loading && series.length" class="mt-8">
      <h2 class="sub-title font-custom-01">سریال‌ها</h2>
      <div class="movie-grid">
        <MovieCard
          v-for="s in series"
          :key="'s'+s.id"
          :movie-id="s.id"
          :title="s.title_farsi"
          :year="s.year"
          :rating="s.imdb_rating"
          :poster="s.picture_url"
        />
      </div>
    </div>

    <!-- خالی -->
    <p v-if="!loading && !movies.length && !series.length" class="empty-msg">
      فعلاً فیلم یا سریالی برای نمایش وجود ندارد.
    </p>
  </v-container>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '@/services/api'
import MovieCard from '@/components/movie/MovieCard.vue'
import SkeletonCard from '@/components/base/SkeletonCard.vue'

const movies = ref([])
const series = ref([])
const loading = ref(true)

onMounted(async () => {
  try {
    const [moviesRes, seriesRes] = await Promise.all([
      api.getMovies(),
      api.getSeries()
    ])
    movies.value = moviesRes.data.data || []
    series.value = seriesRes.data.data || []
  } catch (err) {
    console.error('خطا در دریافت فیلم‌ها/سریال‌ها:', err)
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.home-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 16px;
}
.section-title {
  font-size: 1.5rem;
  margin-bottom: 16px;
  color: var(--color-accent, #eab308);
  text-align: right; /* راست‌چین */
}
.sub-title {
  font-size: 1.2rem;
  margin: 16px 0 12px;
  color: var(--color-text-secondary, #aaa);
  text-align: right; /* راست‌چین */
}
.movie-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 16px;
  direction: rtl; /* شروع از راست */
}
.empty-msg {
  text-align: center;
  color: var(--color-text-secondary, #aaa);
  margin-top: 40px;
}
</style>