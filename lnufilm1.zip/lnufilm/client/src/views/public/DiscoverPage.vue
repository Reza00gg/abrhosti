<template>
  <v-container fluid class="fill-height d-flex align-center justify-center">
    <div class="text-center">
      <h1 class="text-h3 font-weight-bold text-yellow-accent-3 mb-4 font-custom-01">
        Coming Soon
      </h1>
      <p class="text-grey">صفحه دیسکاور در حال توسعه است</p>
    </div>
  </v-container>
</template>