<template>
  <v-container fluid class="account-home">
    <div class="account-header mb-6">
      <h2 class="font-custom-01 text-yellow-accent-3 text-center">حساب کاربری</h2>
      <p class="text-grey text-center font-custom-01" v-if="user">{{ user.display_name }} خوش آمدید</p>
    </div>

    <v-list rounded="lg" color="transparent" class="account-list">
      <v-list-item
        v-for="item in menuItems"
        :key="item.title"
        class="account-list-item font-custom-01"
        :class="{ 'logout-item': item.action === 'logout' }"
        @click="handleAction(item.action)"
      >
        <v-list-item-title>{{ item.title }}</v-list-item-title>
      </v-list-item>
    </v-list>

    <!-- نوتیفیکیشن (در حال توسعه) -->
    <div class="auth-notification-wrapper">
      <transition name="notification-slide-fade">
        <v-alert
          v-if="notify.show"
          :type="notify.type"
          density="compact"
          closable
          class="notification-alert font-custom-01"
          @click:close="notify.show = false"
        >
          {{ notify.text }}
        </v-alert>
      </transition>
    </div>
  </v-container>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { useAuth } from '@/composables/useAuth'
import { useRouter } from 'vue-router'

const { user, logout } = useAuth()
const router = useRouter()

const notify = ref({ show: false, text: '', type: 'warning' })

const menuItems = computed(() => [
  { title: 'اعلان‌ها', action: 'notifications' },
  { title: 'سوابق خرید', action: 'purchases' },
  { title: 'خرید اشتراک', action: 'subscribe' },
  { title: 'لیست‌ها', action: 'lists' },
  { title: 'لیست تماشا', action: 'watchlist' },
  { title: 'حساب کاربری', action: 'profile' },
  { title: 'نظرات', action: 'comments' },
  { title: 'آخرین بازدیدها', action: 'history' },
  { title: 'پست‌ها', action: 'posts' },
  { title: 'ربات تلگرام', action: 'telegram' },
  { title: 'تنظیمات پخش', action: 'player_settings' },
  { title: 'اتصال به تلویزیون', action: 'tv_connect' },
  { title: 'خروج از حساب', action: 'logout' }
])

const showNotify = (msg, type = 'warning') => {
  notify.value = { show: true, text: msg, type }
}

// پاک‌سازی خودکار
watch(() => notify.value.show, (newVal) => {
  if (newVal) {
    setTimeout(() => { notify.value.show = false }, 4000)
  }
})

const handleAction = async (action) => {
  if (action === 'logout') {
    // تأیید خروج
    if (confirm('آیا مطمئن هستید که می‌خواهید خارج شوید؟')) {
      await logout()
      // بعد از logout به خانه هدایت می‌شود
    }
  } else {
    showNotify('در حال توسعه')
  }
}
</script>

<style scoped>
.account-home {
  max-width: 600px;
  margin: 0 auto;
  padding: 24px 16px;
}

.account-list {
  background-color: rgba(255,255,255,0.03);
  border-radius: 12px;
  overflow: hidden;
}

.account-list-item {
  padding: 12px 16px;
  color: var(--color-text-primary, #fff);
  transition: background 0.2s;
  cursor: pointer;
}

.account-list-item:hover {
  background: rgba(255,255,255,0.05);
}

.logout-item {
  color: #ff5252 !important;
  font-weight: 600;
}

.logout-item:hover {
  background-color: rgba(255,82,82,0.1);
}

/* ===== نوتیفیکیشن ===== */
.auth-notification-wrapper {
  position: fixed;
  bottom: 84px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 9999;
  min-width: 250px;
}

.notification-alert {
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.5);
  font-family: 'CustomFont01', sans-serif !important;
}

.notification-slide-fade-enter-active { transition: all 0.25s ease-out; }
.notification-slide-fade-leave-active { transition: all 0.2s ease-in; }
.notification-slide-fade-enter-from { opacity: 0; transform: translateY(-10px); }
.notification-slide-fade-leave-to { opacity: 0; transform: translateY(-5px); }
</style>