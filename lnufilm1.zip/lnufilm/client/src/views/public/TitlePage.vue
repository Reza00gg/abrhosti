<template>
  <v-container fluid class="fill-height d-flex align-center justify-center">
    <div v-if="loading" class="text-center">
      <v-progress-circular indeterminate color="yellow-accent-3" size="40"></v-progress-circular>
      <p class="mt-3 text-grey font-custom-01">در حال بارگذاری...</p>
    </div>
    <div v-else-if="error" class="text-center">
      <h2 class="text-h4 font-custom-01 mb-3">متأسفیم!</h2>
      <p class="text-grey font-custom-01">{{ error }}</p>
      <v-btn to="/" variant="outlined" color="yellow-accent-3" class="mt-4">
        بازگشت به خانه
      </v-btn>
    </div>
    <div v-else class="text-center">
      <h1 class="text-h3 font-weight-bold text-yellow-accent-3 mb-4 font-custom-01">
        {{ titleData.title_farsi }}
      </h1>
      <p class="text-h6 text-grey font-custom-01">
        {{ titleData.year }} | امتیاز: {{ titleData.imdb_rating }}
      </p>
      <p class="text-grey font-custom-01">
        نوع: {{ titleData.title_type === 'movie' ? 'فیلم' : 'سریال' }}
      </p>
      <p class="text-grey mt-4 font-custom-01">جزئیات بیشتر به‌زودی...</p>
    </div>
  </v-container>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import api from '@/services/api'

const route = useRoute()
const titleData = ref(null)
const loading = ref(true)
const error = ref('')

onMounted(async () => {
  const id = route.params.id
  try {
    // استفاده از endpoint یکپارچه
    const res = await api.getTitle(id)
    titleData.value = res.data
  } catch (err) {
    console.error(err)
    error.value = err.response?.data?.error || 'عنوان مورد نظر یافت نشد.'
  } finally {
    loading.value = false
  }
})
</script>