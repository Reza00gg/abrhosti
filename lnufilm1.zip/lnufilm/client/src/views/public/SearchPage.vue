<template>
  <v-container fluid class="search-page">
    <!-- اینپوت جستجو -->
    <div class="search-input-wrapper">
      <v-text-field
        v-model="query"
        placeholder="جستجو در ۴۰ هزار فیلم و سریال"
        variant="outlined"
        rounded="xl"
        class="search-field"
        hide-details
        clearable
        @update:model-value="onQueryChange"
      >
        <template #prepend-inner>
          <v-icon v-if="!searching" color="grey">mdi-magnify</v-icon>
          <v-progress-circular
            v-else
            indeterminate
            size="20"
            width="2"
            color="yellow-accent-3"
          ></v-progress-circular>
        </template>
      </v-text-field>
    </div>

    <!-- حالت خالی -->
    <div v-if="!query && !searching && !results.length" class="text-center mt-10">
      <p class="text-grey font-custom-01">جستجو در ۴۰ هزار فیلم و سریال</p>
    </div>

    <!-- حالت بارگذاری (اسکلت) -->
    <div v-else-if="searching" class="movie-grid mt-6">
      <SkeletonCard v-for="n in 8" :key="n" />
    </div>

    <!-- نمایش نتایج (فیلم + سریال) -->
    <div v-else-if="results.length" class="movie-grid mt-6">
      <MovieCard
        v-for="item in results"
        :key="item.id"
        :movie-id="item.id"
        :title="item.title_farsi"
        :year="item.year"
        :rating="item.imdb_rating"
        :poster="item.picture_url"
      />
    </div>

    <!-- هیچ نتیجه‌ای یافت نشد -->
    <div v-else-if="query && !searching && results.length === 0" class="no-result mt-6">
      <v-alert
        type="error"
        density="compact"
        class="no-result-alert font-custom-01"
      >
        هیچ موردی یافت نشد
      </v-alert>
    </div>

    <!-- نوتیفیکیشن تعداد نتایج -->
    <div class="search-snackbar-wrapper">
      <transition name="notification-slide-fade">
        <v-alert
          v-if="snackbar.show"
          type="success"
          density="compact"
          closable
          class="notification-alert font-custom-01"
          @click:close="snackbar.show = false"
        >
          {{ snackbar.text }}
        </v-alert>
      </transition>
    </div>
  </v-container>
</template>

<script setup>
import { ref, watch, onBeforeUnmount } from 'vue'
import api from '@/services/api'
import MovieCard from '@/components/movie/MovieCard.vue'
import SkeletonCard from '@/components/base/SkeletonCard.vue'

const query = ref('')
const results = ref([])
const searching = ref(false)
const snackbar = ref({ show: false, text: '' })

let searchTimer = null
let dismissTimer = null

onBeforeUnmount(() => {
  clearTimeout(searchTimer)
  clearTimeout(dismissTimer)
})

// پاک‌سازی خودکار نوتیفیکیشن
watch(() => snackbar.value.show, (newVal) => {
  clearTimeout(dismissTimer)
  if (newVal) {
    dismissTimer = setTimeout(() => {
      snackbar.value.show = false
    }, 4000)
  }
})

const performSearch = async () => {
  const trimmed = (query.value || '').trim()
  if (!trimmed) {
    results.value = []
    searching.value = false
    return
  }

  searching.value = true
  results.value = []

  try {
    const res = await api.searchAll(trimmed)
    results.value = res.data.data || []
    if (results.value.length > 0) {
      snackbar.value.show = false
      snackbar.value.text = `${results.value.length} نتیجه پیدا شد`
      setTimeout(() => {
        snackbar.value.show = true
      }, 100)
    }
  } catch (error) {
    console.error('خطا در جستجو:', error)
    results.value = []
  } finally {
    searching.value = false
  }
}

const onQueryChange = () => {
  clearTimeout(searchTimer)

  const trimmed = (query.value || '').trim()
  if (!trimmed) {
    results.value = []
    searching.value = false
    snackbar.value.show = false
    return
  }

  searching.value = true
  results.value = []
  snackbar.value.show = false

  searchTimer = setTimeout(() => {
    performSearch()
  }, 500)
}

// پاکسازی کامل هنگام خالی شدن دستی
watch(query, (newVal) => {
  if (!(newVal || '').trim()) {
    clearTimeout(searchTimer)
    results.value = []
    searching.value = false
    snackbar.value.show = false
  }
})
</script>

<style scoped>
.search-page {
  max-width: 1000px;
  margin: 0 auto;
  padding: 16px;
}

.search-input-wrapper {
  margin-top: 8px;
}

/* استایل اینپوت جستجو با متغیرهای تم */
.search-field :deep(.v-field--variant-outlined) {
  background-color: var(--color-search-input-bg);
  border-color: var(--color-border-subtle, rgba(255,255,255,0.1));
}

.search-field :deep(.v-field__input) {
  font-family: 'CustomFont01', sans-serif !important;
  font-size: 1rem;
  color: var(--color-text-primary, #fff) !important;
  text-align: right;
}

.search-field :deep(.v-label) {
  color: var(--color-text-secondary, #aaa) !important;
}

.search-field :deep(.v-field__outline) {
  --v-field-border-opacity: 0.8;
  color: var(--color-border-subtle, rgba(255,255,255,0.1));
}

.search-prompt {
  text-align: center;
  color: var(--color-text-secondary, #aaa);
  font-family: 'CustomFont01', sans-serif;
}

/* گرید نتایج (چیدمان از راست) */
.movie-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 16px;
  direction: rtl;
}

/* پیام قرمز بدون نتیجه */
.no-result {
  display: flex;
  justify-content: center;
}
.no-result-alert {
  background-color: #d32f2f !important;
  color: white !important;
  font-weight: bold;
  border-radius: 8px;
  max-width: 400px;
  width: 100%;
  font-family: 'CustomFont01', sans-serif !important;
  text-align: center; /* راست‌چین */
}

/* ===== نوتیفیکیشن ===== */
.search-snackbar-wrapper {
  position: fixed;
  bottom: 84px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 9999;
  min-width: 250px;
}

.notification-alert {
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.5);
  font-family: 'CustomFont01', sans-serif !important;
  direction: rtl;
}

.notification-slide-fade-enter-active {
  transition: all 0.25s ease-out;
}
.notification-slide-fade-leave-active {
  transition: all 0.2s ease-in;
}
.notification-slide-fade-enter-from {
  opacity: 0;
  transform: translateY(-10px);
}
.notification-slide-fade-leave-to {
  opacity: 0;
  transform: translateY(-5px);
}
</style>