<template>
  <v-container fluid class="fill-height d-flex align-center justify-center">
    <div class="text-center">
      <h1 class="text-h3 font-weight-bold text-white mb-2 font-custom-01">
        پیدا نشد
      </h1>
      <p class="text-grey mb-6">صفحه ای که شما به دنبال آن بودید پیدا نشد</p>
      <v-btn
        class="notfound-btn"
        variant="elevated"
        size="large"
        @click="$router.replace('/')"
      >
        صفحه نخست
      </v-btn>
    </div>
  </v-container>
</template>

<script setup>
// بدون اسکریپت خاص
</script>

<style scoped>
.notfound-btn {
  background-color: #f32b2b !important;
  color: white !important;
  border-radius: 8px;
  text-transform: none;
  font-weight: 600;
}
.notfound-btn:hover {
  background-color: #f32b2b !important;
}
</style>