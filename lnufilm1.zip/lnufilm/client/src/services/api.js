import axios from 'axios'

const apiClient = axios.create({
  baseURL: 'http://localhost:3000/api',
  headers: { 'Content-Type': 'application/json' }
})

const authClient = axios.create({
  baseURL: 'http://localhost:3000/api',
  headers: { 'Content-Type': 'application/json' }
})
authClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export default {
  // متدهای قبلی بدون تغییر
  getText() { return apiClient.get('/text') },
  updateText(payload) { return apiClient.post('/text', payload) },
  getMovies() { return apiClient.get('/list/movies') },
  addMovie(formData) {
    return apiClient.post('/movies', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  updateMovie(id, formData) {
    return apiClient.put(`/movies/${id}`, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  deleteMovie(id) { return apiClient.delete(`/movies/${id}`) },
  searchMovies(query) { return apiClient.get('/search/movies', { params: { q: query } }) },
  getMovieById(id) { return apiClient.get(`/movies/${id}`) },

  // سریال‌ها
  getSeries() { return apiClient.get('/list/series') },
  getSeriesById(id) { return apiClient.get(`/series/${id}`) },
  addSeries(formData) {
    return apiClient.post('/series', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  updateSeries(id, formData) {
    return apiClient.put(`/series/${id}`, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  deleteSeries(id) { return apiClient.delete(`/series/${id}`) },

  // جستجوی یکپارچه
  searchAll(query) { return apiClient.get('/search/all', { params: { q: query } }) },

  // دریافت یکپارچه یک عنوان (فیلم یا سریال)
  getTitle(id) { return apiClient.get(`/title/${id}`) },

  // احراز هویت
  register(data) { return apiClient.post('/auth/register', data) },
  login(data) { return apiClient.post('/auth/login', data) },
  getMe() { return authClient.get('/auth/me') },

  // مدیریت کاربران
  getUsers() { return apiClient.get('/admin/users') },
  updateUserStatus(id, status) { return apiClient.put(`/admin/users/${id}`, { status }) },
  deleteUser(id) { return apiClient.delete(`/admin/users/${id}`) },

  // تنظیمات سایت
  getSiteStatus() { return apiClient.get('/site/status') },
  setSiteStatus(enabled) { return apiClient.post('/site/status', { enabled }) }
}