import { createRouter, createWebHistory } from 'vue-router'
import DefaultLayout from '@/layouts/DefaultLayout.vue'
import AdminLayout from '@/layouts/AdminLayout.vue'

const routes = [
  {
    path: '/',
    component: DefaultLayout,
    children: [
      {
        path: '',
        name: 'Home',
        component: () => import('@/views/public/HomePage.vue')
      },
      {
        path: 'search',
        name: 'Search',
        component: () => import('@/views/public/SearchPage.vue')
      },
      {
        path: 'discover',
        name: 'Discover',
        component: () => import('@/views/public/DiscoverPage.vue')
      },
      {
        path: 'account',
        // اگر کاربر لاگین نکرده باشد به صفحهٔ ورود می‌رود، در غیر این‌صورت به پنل کاربری
        redirect: (to) => {
          const token = localStorage.getItem('token')
          return token ? '/account/home' : '/account/signin'
        }
      },
      {
        path: 'account/signin',
        name: 'SignIn',
        component: () => import('@/views/public/SignInPage.vue'),
        beforeEnter: (to, from, next) => {
          const token = localStorage.getItem('token')
          if (token) next({ name: 'AccountHome' })
          else next()
        }
      },
      {
        path: 'account/home',
        name: 'AccountHome',
        component: () => import('@/views/public/AccountHome.vue'),
        meta: { requiresAuth: true }
      },
      {
        path: '/title/:id',
        name: 'MovieTitle',
        component: () => import('@/views/public/TitlePage.vue')
      },
      {
        path: '/:pathMatch(.*)*',
        name: 'NotFound',
        component: () => import('@/views/public/NotFound.vue')
      }
    ]
  },
  {
    path: '/admin',
    component: AdminLayout,
    children: [
      { path: '', name: 'AdminHome', component: () => import('@/views/admin/AdminHome.vue') },
      { path: 'movies', name: 'MoviesManager', component: () => import('@/views/admin/MoviesManager.vue') },
      { path: 'series', name: 'SeriesManager', component: () => import('@/views/admin/SeriesManager.vue') },
      { path: 'users', name: 'UsersManager', component: () => import('@/views/admin/UsersManager.vue') },
      { path: 'management', name: 'Management', component: () => import('@/views/admin/AdminHome.vue') },
      { path: 'settings', name: 'Settings', component: () => import('@/views/admin/SettingsPage.vue') }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth) {
    const token = localStorage.getItem('token')
    if (!token) {
      next({ name: 'SignIn' })
    } else {
      next()
    }
  } else {
    next()
  }
})

export default router