<template>
  <v-app :class="currentThemeClass()">
    <!-- اگر سایت خاموش باشد و کاربر در مسیر ادمین نباشد -->
    <div v-if="!siteEnabled && !isAdminRoute" class="maintenance-overlay">
      <v-container class="fill-height d-flex align-center justify-center">
        <div class="text-center">
          <h1 class="text-h3 font-weight-bold text-yellow-accent-3 mb-4 font-custom-01">
            سایت در دسترس نیست
          </h1>
          <p class="text-grey font-custom-01">لطفاً بعداً مراجعه کنید</p>
        </div>
      </v-container>
    </div>

    <template v-else>
      <!-- هدر ثابت (فقط در غیر از جستجو) -->
      <header v-if="route.name !== 'Search'" class="site-header">
        <div class="header-content">
          <div class="header-left">
            <v-btn
              v-if="route.name === 'Home'"
              icon
              variant="text"
              @click="cycleTheme"
              aria-label="تغییر رنگ"
            >
              <v-icon>mdi-palette</v-icon>
            </v-btn>
          </div>

          <div class="header-right">
            <h1 class="site-title font-custom-01" v-if="siteName">{{ siteName }}</h1>
            <v-btn
              icon
              variant="text"
              @click="showNotify('در حال توسعه')"
              aria-label="منو"
            >
              <v-icon>mdi-menu</v-icon>
            </v-btn>
          </div>
        </div>
      </header>

      <div v-if="route.name !== 'Search'" class="header-spacer"></div>

      <v-main>
        <router-view />
      </v-main>

      <!-- منوی پایین -->
      <nav class="bottom-nav">
        <v-btn
          v-for="item in navItems"
          :key="item.to"
          :to="item.to"
          variant="text"
          class="nav-btn"
          :ripple="{ duration: 600 }"
          exact
          :active="isNavActive(item)"
        >
          <span class="nav-content">
            <v-icon>{{ item.icon }}</v-icon>
            <span class="nav-label font-custom-01">{{ item.label }}</span>
          </span>
        </v-btn>
      </nav>

      <!-- نوتیفیکیشن -->
      <div class="bottom-notification">
        <transition name="notification-slide-fade">
          <v-alert
            v-if="notification"
            type="warning"
            density="compact"
            closable
            class="notification-alert"
            @click:close="notification = null"
          >
            {{ notification }}
          </v-alert>
        </transition>
      </div>
    </template>
  </v-app>
</template>

<script setup>
import { ref, onMounted, watch, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useTheme } from '@/composables/useTheme'
import { useSiteStatus } from '@/composables/useSiteStatus'
import api from '@/services/api'

const route = useRoute()
const { currentThemeClass, cycleTheme, applyThemeToHTML } = useTheme()
const { siteEnabled, checkStatus } = useSiteStatus()

const siteName = ref('')
const notification = ref(null)
const isAdminRoute = computed(() => route.path.startsWith('/admin'))

const navItems = computed(() => [
  { to: '/account', name: 'Account', icon: 'mdi-account', label: 'حساب من' },
  { to: '/discover', name: 'Discover', icon: 'mdi-compass', label: 'دیسکاور' },
  { to: '/search', name: 'Search', icon: 'mdi-magnify', label: 'جستجو' },
  { to: '/', name: 'Home', icon: 'mdi-home', label: 'خانه' }
])

const isNavActive = (item) => {
  if (item.name === 'Account') {
    return route.name === 'AccountHome' || route.name === 'SignIn'
  }
  return route.name === item.name
}

onMounted(async () => {
  applyThemeToHTML()
  await checkStatus()
  try {
    const res = await api.getText()
    siteName.value = res.data.headerText || 'LNU Film'
  } catch {
    siteName.value = 'LNU Film'
  }
})

const showNotify = (msg) => {
  notification.value = msg
}

let timer = null
watch(notification, (newVal) => {
  clearTimeout(timer)
  if (newVal) {
    timer = setTimeout(() => {
      notification.value = null
    }, 4000)
  }
})
</script>

<style scoped>
.maintenance-overlay {
  position: fixed;
  inset: 0;
  background-color: var(--color-bg-surface, #121212);
  z-index: 9999;
}

/* هدر */
.site-header {
  position: fixed;
  top: 0; left: 0; right: 0;
  height: 56px;
  background-color: var(--color-bg-header-opacity, rgba(0,0,0,0.75));
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
  z-index: 1000;
  display: flex; align-items: center;
  padding: 0 12px;
}
.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}
.header-left, .header-right {
  display: flex;
  align-items: center;
}
.header-right {
  gap: 8px;
}
.site-title {
  font-size: 1.25rem;
  color: var(--color-accent, #eab308);
  margin: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.header-spacer { height: 56px; }

/* منوی پایین */
.bottom-nav {
  position: fixed;
  bottom: 0; left: 0; right: 0;
  height: 64px;
  background-color: var(--color-bg-nav, #1e1e1e);
  display: flex; justify-content: space-around; align-items: center;
  z-index: 1000;
  border-top: 1px solid var(--color-border-subtle, rgba(255,255,255,0.08));
  border-radius: 16px 16px 0 0;
  backdrop-filter: blur(10px);
  overflow: hidden;
}
.nav-btn {
  flex: 1;
  height: 100% !important;
  border-radius: 0 !important;
  text-transform: none !important;
  font-weight: 400 !important;
  letter-spacing: 0 !important;
  min-width: 0 !important; padding: 0 !important;
  color: var(--color-text-secondary, rgba(255,255,255,0.6)) !important;
  transition: color 0.2s;
  --v-activated-opacity: 0 !important;
  --v-hover-opacity: 0 !important;
  --v-focus-opacity: 0 !important;
}
.nav-btn:hover, .nav-btn:focus, .nav-btn:active, .nav-btn.v-btn--active {
  background: transparent !important; box-shadow: none !important;
}
.nav-btn.v-btn--active { color: var(--color-accent, #eab308) !important; }
.nav-content {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
}
.nav-btn :deep(.v-icon) { font-size: 24px; margin-bottom: 2px; }
.nav-label { font-size: 0.7rem; line-height: 1; font-family: 'CustomFont01', sans-serif; }

/* نوتیفیکیشن */
.bottom-notification {
  position: fixed; bottom: 84px; left: 50%; transform: translateX(-50%);
  z-index: 9999; min-width: 250px;
}
.notification-alert { border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.5); }
.notification-slide-fade-enter-active { transition: all 0.25s ease-out; }
.notification-slide-fade-leave-active { transition: all 0.2s ease-in; }
.notification-slide-fade-enter-from { opacity: 0; transform: translateY(-10px); }
.notification-slide-fade-leave-to { opacity: 0; transform: translateY(-5px); }

.v-main { padding-bottom: 80px !important; }
</style>