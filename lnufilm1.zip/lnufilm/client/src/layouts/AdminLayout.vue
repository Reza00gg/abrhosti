<template>
  <v-app>
    <header class="admin-header">
      <div class="header-content">
        <h1 class="admin-title font-custom-01">پنل مدیریت</h1>
        <v-btn
          icon
          variant="text"
          @click.stop="drawer = !drawer"
          aria-label="منو"
        >
          <v-icon>mdi-menu</v-icon>
        </v-btn>
      </div>
    </header>

    <v-navigation-drawer
      v-model="drawer"
      temporary
      location="right"
      width="220"
      class="admin-drawer"
    >
      <v-list density="compact" nav>
        <v-list-item
          v-for="item in menuItems"
          :key="item.to"
          :to="item.to"
          :exact="item.to === '/admin'"
          active-class="active-item"
          class="drawer-item"
          @click="drawer = false"
        >
          <v-list-item-title class="font-custom-01">{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<script setup>
import { ref, computed } from 'vue'

const drawer = ref(false)

const menuItems = computed(() => [
  { to: '/admin', title: 'صفحه اصلی' },
  { to: '/admin/movies', title: 'فیلم ها' },
  { to: '/admin/series', title: 'سریال ها' },
  { to: '/admin/users', title: 'کاربران' },
  { to: '/admin/management', title: 'مدیریت' },
  { to: '/admin/settings', title: 'تنظیمات' }
])
</script>

<style scoped>
.admin-header {
  height: 56px;
  background-color: var(--color-bg-header, #242424);
  display: flex;
  align-items: center;
  padding: 0 12px;
  position: sticky;
  top: 0;
  z-index: 100;
}
.header-content {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.admin-title {
  font-size: 1.3rem;
  color: var(--color-accent, #eab308);
  margin: 0;
}
.admin-drawer {
  background-color: var(--color-bg-surface, #1e1e1e);
}
.drawer-item {
  color: var(--color-text-primary, #fff);
  margin: 4px 8px;
  border-radius: 8px;
  direction: rtl;
}
.active-item {
  background-color: rgba(255,255,255,0.1);
}
</style>