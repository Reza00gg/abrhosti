<template>
  <v-btn
    :to="`/title/${movieId}`"
    variant="plain"
    class="movie-card"
    :ripple="{ duration: 600 }"
  >
    <!-- توجه: v-btn خودش یک span.v-btn__content می‌سازد،
         اما ما محتوای داخلی را دقیقاً مانند قبل گذاشته‌ایم -->
    <div class="poster-wrapper">
      <img
        :src="posterUrl"
        :alt="title"
        class="poster-image"
      />
      <div class="rating-badge">
        <v-icon size="14" class="star-icon">mdi-star</v-icon>
        <span>{{ rating }}</span>
      </div>
    </div>
    <p class="movie-year">{{ year }}</p>
    <h3 class="movie-title font-custom-01">{{ title }}</h3>
  </v-btn>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  movieId: { type: Number, required: true },
  title: String,
  year: Number,
  rating: Number,
  poster: String
})

const posterUrl = computed(() => {
  if (!props.poster) return '/placeholder.jpg'
  return props.poster.startsWith('http') ? props.poster : `http://localhost:3000${props.poster}`
})
</script>

<style scoped>
/* ========== بازنشانی کامل v-btn برای تبدیل به کارت ========== */
.movie-card {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  width: 100% !important;
  height: auto !important;
  min-height: 0 !important;
  min-width: 0 !important;
  padding: 0 !important;
  margin: 0 !important;
  border-radius: 0 !important;
  background: transparent !important;
  box-shadow: none !important;
  color: inherit !important;
  text-transform: none !important;
  letter-spacing: normal !important;
  --v-activated-opacity: 0 !important;
  --v-hover-opacity: 0 !important;
  --v-focus-opacity: 0 !important;
  border-radius: 12px !important;
  overflow: hidden;
}

/* حذف هرگونه پس‌زمینه مزاحم در حالت‌های مختلف */
.movie-card:hover,
.movie-card:focus,
.movie-card:active,
.movie-card.v-btn--active {
  background: transparent !important;
  box-shadow: none !important;
}

/* تعمیر span داخلی v-btn (v-btn__content) */
.movie-card :deep(.v-btn__content) {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  height: auto;
  padding: 0;
}

/* ========== استایل‌های خود کارت (دقیقاً مانند قبل) ========== */
.poster-wrapper {
  position: relative;
  width: 100%;
  aspect-ratio: 2/3;
  border-radius: 12px;
  overflow: hidden;
  background-color: rgba(255,255,255,0.05);
}

.poster-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.rating-badge {
  position: absolute;
  top: 6px;
  left: 6px;
  background: rgba(0,0,0,0.65);
  backdrop-filter: blur(4px);
  border-radius: 6px;
  padding: 2px 6px;
  display: flex;
  align-items: center;
  gap: 2px;
  color: #FFD700;
  font-weight: bold;
  font-size: 0.75rem;
}

.star-icon {
  color: #FFD700;
}

.movie-year {
  margin: 6px 0 2px 0;
  font-size: 0.7rem;
  color: var(--color-text-secondary, #aaa);
  line-height: 1.2;
}

.movie-title {
  font-size: 0.85rem;
  text-align: center;
  margin: 0;
  color: var(--color-text-primary, #fff);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
  line-height: 1.3;
}
</style>