<template>
  <div class="skeleton-card">
    <div class="skeleton-poster"></div>
    <div class="skeleton-line short"></div>
    <div class="skeleton-line medium"></div>
  </div>
</template>

<style scoped>
.skeleton-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
}

.skeleton-poster {
  width: 100%;
  aspect-ratio: 2/3;
  border-radius: 12px;
  background: linear-gradient(90deg, #2a2a2a 25%, #3a3a3a 50%, #2a2a2a 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
}

.skeleton-line {
  height: 10px;
  border-radius: 4px;
  margin-top: 8px;
  background: #2a2a2a;
  animation: shimmer 1.5s infinite;
}
.skeleton-line.short {
  width: 60%;
}
.skeleton-line.medium {
  width: 80%;
}

@keyframes shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}
</style>