<template>
  <v-app>
    <router-view />
  </v-app>
</template>

<script setup>
// خالی – همه چیز در main.js مدیریت می‌شود
</script>